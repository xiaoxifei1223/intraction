# Hermes Team Skills Registry

A governed, version-locked Skill registry for team-wide Hermes Agent usage.

## Quick Start for Team Members

```bash
# 1. Add this registry as a tap (one-time)
hermes skills tap add my-team/hermes-team-skills

# 2. Browse available skills
hermes skills browse --source github

# 3. Install a skill (version-locked via registry.yaml)
hermes skills install my-team/hermes-team-skills/devops/deploy-k8s

# 4. Check for updates
hermes skills check
hermes skills update
```

## Repository Structure

```
hermes-team-skills/
├── skills/                     # Actual skill directories
│   ├── devops/
│   │   └── deploy-k8s/
│   ├── security/
│   │   └── secret-scan/
│   └── internal/
│       └── onboarding/
├── .team-registry/             # Registry metadata & tooling
│   ├── registry.yaml           # Central index (auto-generated)
│   ├── schema/
│   │   └── skill-schema.json   # Frontmatter validation schema
│   ├── policies/
│   │   └── threat-rules-team.yaml  # Custom security rules
│   ├── scripts/
│   │   ├── lint_skills.py      # Format / policy linter
│   │   ├── custom_threat_scan.py   # Security scanner
│   │   └── update_registry.py  # Auto-update registry.yaml
│   └── reports/                # Scan reports (auto-generated)
└── .github/workflows/          # CI/CD pipelines
    ├── skill-lint.yaml
    ├── skill-scan.yaml
    └── skill-publish.yaml
```

## Governance Model (No Human Review Gate)

This registry uses **automated governance**:

1. **Format Compliance** (`skill-lint.yaml`)
   - Validates SKILL.md frontmatter against schema
   - Enforces naming conventions (kebab-case, name == directory)
   - Enforces `description ≤ 60` chars, period-terminated
   - Checks `platforms` against actual script content
   - Verifies all referenced scripts/files exist

2. **Security Scanning** (`skill-scan.yaml`)
   - Runs Hermes-compatible threat detection
   - Custom team rules: no prod secrets, no hardcoded `~/.hermes`, no core file references
   - Blocks `dangerous` verdicts automatically
   - Warns on `caution` verdicts

3. **Version Locking** (`skill-publish.yaml`)
   - On every merge to `main`, CI updates `registry.yaml`
   - Records exact `commit_sha` for reproducible installs
   - Attaches scan reports to each skill entry

## Adding a New Skill

1. Create a directory under `skills/<category>/<skill-name>/`
2. Add `SKILL.md` with proper frontmatter
3. Add helper scripts under `scripts/`, references under `references/`
4. Open a Pull Request
5. CI will lint + scan automatically
6. On merge, `registry.yaml` is updated automatically

### SKILL.md Template

```markdown
---
name: my-skill
description: "Short one-sentence description ending with a period."
version: 1.0.0
author: "your-name@company.com"
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [tag1, tag2]
    category: my-category
---

# My Skill

2-3 sentence intro stating what it does and doesn't do.

## When to Use

## Prerequisites

## How to Run

## Quick Reference

## Procedure

## Verification

## Pitfalls
```

## Visibility & Permissions

| Level | Meaning | Install Requirement |
|-------|---------|-------------------|
| `public` | Anyone in the org | No restrictions |
| `internal` | Specific teams | Belongs to `allowed_teams` |
| `restricted` | Extra sensitive | Team membership + future signing |

Edit `visibility` and `allowed_teams` directly in `registry.yaml` **after** CI generates it.

## Local Development

You can run the same checks locally before pushing:

```bash
# Install Python deps
pip install pyyaml

# Run linter
python .team-registry/scripts/lint_skills.py \
  --schema .team-registry/schema/skill-schema.json \
  skills/

# Run security scanner
python .team-registry/scripts/custom_threat_scan.py \
  --rules .team-registry/policies/threat-rules-team.yaml \
  --output .team-registry/reports \
  skills/

# Preview registry update
python .team-registry/scripts/update_registry.py
```

## Future Enhancements

- [ ] GPG signing for `restricted` skills
- [ ] Hermes plugin for team-permission enforcement at install time
- [ ] Web dashboard for skill catalog browsing
- [ ] Usage analytics (opt-in)
