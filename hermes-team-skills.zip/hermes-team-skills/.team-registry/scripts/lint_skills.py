#!/usr/bin/env python3
"""
Skill Lint — Format and policy checker for Team Skill Registry.

Usage:
    python lint_skills.py --schema ../schema/skill-schema.json skills/

Exit codes:
    0 = all clean
    1 = lint violations found
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path
from typing import List, Tuple

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML is required. Install: pip install pyyaml")
    sys.exit(1)


SEVERITY_WEIGHT = {"error": 3, "warning": 2, "info": 1}


def load_schema(schema_path: Path) -> dict:
    with schema_path.open("r", encoding="utf-8") as f:
        return json.load(f)


def parse_frontmatter(skill_md_path: Path) -> Tuple[dict, List[str]]:
    """Parse YAML frontmatter from SKILL.md. Returns (data, errors)."""
    errors = []
    text = skill_md_path.read_text(encoding="utf-8")

    if not text.startswith("---"):
        return {}, [f"{skill_md_path}: Missing YAML frontmatter (must start with '---')"]

    match = re.search(r"\n---\s*\n", text[3:])
    if not match:
        return {}, [f"{skill_md_path}: Malformed frontmatter (missing closing '---')"]

    yaml_text = text[3 : 3 + match.start() + 3]
    try:
        data = yaml.safe_load(yaml_text) or {}
        if not isinstance(data, dict):
            return {}, [f"{skill_md_path}: Frontmatter is not a YAML mapping"]
        return data, errors
    except yaml.YAMLError as exc:
        return {}, [f"{skill_md_path}: Invalid YAML — {exc}"]


def check_naming(skill_dir: Path, fm: dict) -> List[Tuple[str, str, str]]:
    """Check that skill name matches directory name and follows kebab-case."""
    findings = []
    expected_name = skill_dir.name
    actual_name = fm.get("name", "")

    if not actual_name:
        findings.append(("error", "name.missing", f"Missing 'name' in frontmatter (expected: {expected_name})"))
    elif actual_name != expected_name:
        findings.append(("error", "name.mismatch",
            f"Frontmatter name '{actual_name}' does not match directory '{expected_name}'"))

    if not re.fullmatch(r"[a-z][a-z0-9_-]*", expected_name):
        findings.append(("error", "name.format",
            f"Directory name '{expected_name}' is not kebab-case (lowercase, digits, hyphens, underscores)"))

    return findings


def check_description(fm: dict) -> List[Tuple[str, str, str]]:
    findings = []
    desc = fm.get("description", "")

    if not desc:
        findings.append(("error", "description.missing", "Missing 'description' in frontmatter"))
        return findings

    if len(desc) > 60:
        findings.append(("error", "description.length",
            f"Description is {len(desc)} chars (max 60): '{desc}'"))

    if not desc.endswith("."):
        findings.append(("warning", "description.period",
            f"Description should end with a period: '{desc}'"))

    # Marketing words check
    marketing_words = {"powerful", "comprehensive", "seamless", "advanced", "cutting-edge", "robust"}
    lower_desc = desc.lower()
    found = [w for w in marketing_words if w in lower_desc]
    if found:
        findings.append(("warning", "description.marketing",
            f"Description contains marketing words ({', '.join(found)}); prefer plain language"))

    return findings


def check_version(fm: dict) -> List[Tuple[str, str, str]]:
    findings = []
    version = fm.get("version", "")
    if not version:
        findings.append(("error", "version.missing", "Missing 'version' in frontmatter"))
        return findings

    semver_re = re.compile(
        r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
        r"(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?"
        r"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
    )
    if not semver_re.match(version):
        findings.append(("error", "version.semver",
            f"Version '{version}' is not valid SemVer"))

    return findings


def check_platforms(skill_dir: Path, fm: dict) -> List[Tuple[str, str, str]]:
    findings = []
    platforms = fm.get("platforms", [])
    if not platforms:
        findings.append(("error", "platforms.missing",
            "Missing 'platforms' in frontmatter (required per team policy)"))
        return findings

    valid = {"linux", "macos", "windows"}
    invalid = [p for p in platforms if p not in valid]
    if invalid:
        findings.append(("error", "platforms.invalid",
            f"Invalid platforms: {invalid}. Must be subset of {sorted(valid)}"))

    # Cross-platform audit: if scripts use POSIX-only primitives, gating is required
    scripts_dir = skill_dir / "scripts"
    if scripts_dir.exists():
        posix_only_patterns = [
            (r"\bos\.setsid\b", "os.setsid"),
            (r"\bsignal\.SIGKILL\b", "signal.SIGKILL"),
            (r"\bfcntl\b", "fcntl"),
            (r"\btermios\b", "termios"),
            (r"\bos\.kill\s*\(\s*[^,]+,\s*0\s*\)", "os.kill(pid, 0)"),
            (r"\bosascript\b", "osascript"),
            (r"\bsystemctl\b", "systemctl"),
            (r"\bapt\b", "apt"),
        ]
        for script in scripts_dir.rglob("*"):
            if not script.is_file():
                continue
            text = script.read_text(encoding="utf-8", errors="replace")
            for pattern, primitive in posix_only_patterns:
                if re.search(pattern, text):
                    if "windows" in platforms:
                        findings.append(("error", "platforms.gap",
                            f"Script '{script.name}' uses POSIX-only primitive '{primitive}' "
                            f"but 'windows' is declared in platforms"))
                    elif "linux" not in platforms and "macos" not in platforms:
                        findings.append(("warning", "platforms.suspicious",
                            f"Script uses POSIX primitive '{primitive}' but neither linux nor macos declared"))
    return findings


def check_references(skill_dir: Path, fm: dict) -> List[Tuple[str, str, str]]:
    """Ensure scripts/references/templates mentioned in SKILL.md actually exist."""
    findings = []
    skill_md = skill_dir / "SKILL.md"
    text = skill_md.read_text(encoding="utf-8")

    # Find references like `scripts/foo.sh`, `references/bar.md`, `templates/baz.md`
    ref_patterns = [
        re.compile(r"`scripts/([^`]+)`"),
        re.compile(r"`references/([^`]+)`"),
        re.compile(r"`templates/([^`]+)`"),
    ]

    for pat in ref_patterns:
        for match in pat.finditer(text):
            rel_path = match.group(1)
            full = skill_dir / match.group(0).strip("`")
            if not full.exists():
                findings.append(("error", "reference.missing",
                    f"SKILL.md references '{rel_path}' but file does not exist in {skill_dir.name}/"))

    return findings


def check_hardcoded_paths(skill_dir: Path) -> List[Tuple[str, str, str]]:
    """Check for hardcoded ~/.hermes or Path.home() / '.hermes' patterns."""
    findings = []
    bad_patterns = [
        (re.compile(r'Path\.home\(\)\s*/\s*["\']\.hermes["\']'), "Path.home() / '.hermes'"),
        (re.compile(r'["\']~/\.hermes["\']'), "'~/.hermes'"),
        (re.compile(r'\$HOME/\.hermes'), "$HOME/.hermes"),
    ]

    for f in skill_dir.rglob("*"):
        if not f.is_file() or f.name == "SKILL.md":
            continue
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        for pat, example in bad_patterns:
            if pat.search(text):
                findings.append(("error", "path.hardcoded",
                    f"'{f.name}' contains hardcoded Hermes home path ({example}). "
                    f"Use get_hermes_home() from hermes_constants instead."))

    return findings


def lint_skill(skill_dir: Path, schema: dict) -> List[Tuple[str, str, str]]:
    """Run all lint checks on a single skill directory."""
    findings = []
    skill_md = skill_dir / "SKILL.md"

    if not skill_md.exists():
        findings.append(("error", "skill_md.missing", "SKILL.md not found"))
        return findings

    fm, parse_errors = parse_frontmatter(skill_md)
    for err in parse_errors:
        findings.append(("error", "frontmatter.parse", err))

    if not fm:
        return findings

    findings.extend(check_naming(skill_dir, fm))
    findings.extend(check_description(fm))
    findings.extend(check_version(fm))
    findings.extend(check_platforms(skill_dir, fm))
    findings.extend(check_references(skill_dir, fm))
    findings.extend(check_hardcoded_paths(skill_dir))

    # Schema validation (basic required fields)
    required = schema.get("required", [])
    for field in required:
        if field not in fm:
            findings.append(("error", f"schema.required.{field}", f"Missing required field: '{field}'"))

    return findings


def main() -> int:
    parser = argparse.ArgumentParser(description="Lint team skills")
    parser.add_argument("skills_dir", type=Path, help="Path to skills/ directory")
    parser.add_argument("--schema", type=Path, default=None, help="Path to skill-schema.json")
    parser.add_argument("--max-description-len", type=int, default=60)
    parser.add_argument("--fail-on-warning", action="store_true", help="Treat warnings as failures")
    args = parser.parse_args()

    schema = {}
    if args.schema and args.schema.exists():
        schema = load_schema(args.schema)

    skills_dir: Path = args.skills_dir
    if not skills_dir.exists():
        print(f"ERROR: Skills directory not found: {skills_dir}")
        return 1

    all_findings: List[Tuple[Path, List[Tuple[str, str, str]]]] = []

    # Walk categories
    for category_dir in sorted(skills_dir.iterdir()):
        if not category_dir.is_dir() or category_dir.name.startswith((".", "_")):
            continue
        for skill_dir in sorted(category_dir.iterdir()):
            if not skill_dir.is_dir() or skill_dir.name.startswith((".", "_")):
                continue
            findings = lint_skill(skill_dir, schema)
            if findings:
                all_findings.append((skill_dir, findings))

    if not all_findings:
        print("[PASS] All skills passed lint checks.")
        return 0

    # Report
    error_count = 0
    warning_count = 0
    for skill_dir, findings in all_findings:
        print(f"\n[DIR] {skill_dir.relative_to(skills_dir.parent)}")
        for severity, code, message in findings:
            icon = {"error": "[ERR]", "warning": "[WARN]", "info": "[INFO]"}.get(severity, "[?]")
            print(f"   {icon} [{severity.upper()}] {code}: {message}")
            if severity == "error":
                error_count += 1
            elif severity == "warning":
                warning_count += 1

    print(f"\n{'─' * 50}")
    print(f"Summary: {error_count} error(s), {warning_count} warning(s)")

    if error_count > 0:
        return 1
    if args.fail_on_warning and warning_count > 0:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
