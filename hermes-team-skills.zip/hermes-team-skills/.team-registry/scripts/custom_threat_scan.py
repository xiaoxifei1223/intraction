#!/usr/bin/env python3
"""
Custom Threat Scan — Team-specific security scanner for Skills.

Extends Hermes Skills Guard with organization-specific rules.
Runs regex-based static analysis on all skill files.

Usage:
    python custom_threat_scan.py --rules ../policies/threat-rules-team.yaml skills/

Exit codes:
    0 = no findings above threshold
    1 = findings found (CI should fail on critical/high)
"""

import argparse
import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Tuple

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML is required. Install: pip install pyyaml")
    sys.exit(1)


SEVERITY_RANK = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


@dataclass
class Finding:
    rule_id: str
    severity: str
    category: str
    message: str
    file: str
    line: int
    match: str


@dataclass
class ScanResult:
    skill_name: str
    skill_path: str
    verdict: str  # safe | caution | dangerous
    findings: List[Finding] = field(default_factory=list)
    scanned_at: str = ""


def load_rules(rules_path: Path) -> List[dict]:
    data = yaml.safe_load(rules_path.read_text(encoding="utf-8"))
    if not data or "rules" not in data:
        print(f"ERROR: No 'rules' key in {rules_path}")
        sys.exit(1)
    return data["rules"]


def should_exempt(file_path: Path, skill_dir: Path, exempt_paths: List[str]) -> bool:
    """Check if file matches any exempt glob pattern."""
    rel = str(file_path.relative_to(skill_dir.parent.parent))
    for pattern in exempt_paths:
        # Very basic glob matching
        if pattern.endswith("/**"):
            prefix = pattern[:-3]
            if rel.startswith(prefix.replace("/", os.sep)):
                return True
        elif "*" in pattern:
            # Convert simple glob to regex
            pat = pattern.replace(".", r"\.")
            pat = pat.replace("**", ".*")
            pat = pat.replace("*", "[^/]*")
            pat = pat.replace("?", ".")
            if re.search(pat, rel):
                return True
        else:
            if rel.startswith(pattern.replace("/", os.sep)):
                return True
    return False


def scan_skill(skill_dir: Path, rules: List[dict]) -> ScanResult:
    findings: List[Finding] = []
    skill_name = skill_dir.name

    for rule in rules:
        rid = rule.get("id", "unknown")
        pattern_str = rule.get("pattern", "")
        severity = rule.get("severity", "medium")
        category = rule.get("category", "unknown")
        message = rule.get("message", "")
        exempt_paths = rule.get("exempt_paths", [])

        if not pattern_str:
            continue

        try:
            compiled = re.compile(pattern_str)
        except re.error as exc:
            print(f"WARNING: Invalid regex in rule {rid}: {exc}")
            continue

        for file_path in skill_dir.rglob("*"):
            if not file_path.is_file():
                continue
            if should_exempt(file_path, skill_dir, exempt_paths):
                continue

            try:
                text = file_path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue

            for line_no, line in enumerate(text.splitlines(), start=1):
                for match in compiled.finditer(line):
                    # Limit match length for readability
                    snippet = match.group(0)
                    if len(snippet) > 120:
                        snippet = snippet[:117] + "..."

                    findings.append(Finding(
                        rule_id=rid,
                        severity=severity,
                        category=category,
                        message=message,
                        file=str(file_path.relative_to(skill_dir)),
                        line=line_no,
                        match=snippet,
                    ))

    # Determine verdict
    max_severity = 0
    for f in findings:
        max_severity = max(max_severity, SEVERITY_RANK.get(f.severity, 0))

    if max_severity >= SEVERITY_RANK["critical"]:
        verdict = "dangerous"
    elif max_severity >= SEVERITY_RANK["high"]:
        verdict = "caution"
    else:
        verdict = "safe"

    return ScanResult(
        skill_name=skill_name,
        skill_path=str(skill_dir),
        verdict=verdict,
        findings=findings,
        scanned_at=datetime.now(timezone.utc).isoformat(),
    )


def format_scan_report(result: ScanResult) -> str:
    lines = [
        f"\n{'=' * 60}",
        f"Scan Report: {result.skill_name}",
        f"Path: {result.skill_path}",
        f"Verdict: {result.verdict.upper()}",
        f"Findings: {len(result.findings)}",
        f"{'=' * 60}",
    ]

    if not result.findings:
        lines.append("✅ No findings.")
        return "\n".join(lines)

    grouped: dict = {}
    for f in result.findings:
        key = (f.severity, f.rule_id)
        grouped.setdefault(key, []).append(f)

    for (severity, rule_id), items in sorted(
        grouped.items(),
        key=lambda kv: (-SEVERITY_RANK.get(kv[0][0], 0), kv[0][1]),
    ):
        icon = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🔵", "info": "⚪"}.get(severity, "•")
        lines.append(f"\n{icon} [{severity.upper()}] {rule_id}: {items[0].message}")
        for item in items[:5]:  # Show max 5 occurrences per rule
            lines.append(f"   → {item.file}:{item.line}  |  {item.match[:80]}")
        if len(items) > 5:
            lines.append(f"   ... and {len(items) - 5} more occurrence(s)")

    return "\n".join(lines)


def save_json_report(result: ScanResult, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_name = result.skill_name.replace("/", "-")
    out = output_dir / f"{safe_name}-scan.json"
    payload = {
        "skill_name": result.skill_name,
        "skill_path": result.skill_path,
        "verdict": result.verdict,
        "scanned_at": result.scanned_at,
        "findings_count": len(result.findings),
        "findings": [
            {
                "rule_id": f.rule_id,
                "severity": f.severity,
                "category": f.category,
                "message": f.message,
                "file": f.file,
                "line": f.line,
                "match": f.match,
            }
            for f in result.findings
        ],
    }
    out.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Team custom threat scanner")
    parser.add_argument("skills_dir", type=Path, help="Path to skills/ directory")
    parser.add_argument("--rules", type=Path, required=True, help="Path to threat-rules-team.yaml")
    parser.add_argument("--output", type=Path, default=Path(".team-registry/reports"), help="Report output dir")
    parser.add_argument("--fail-on-dangerous", action="store_true", help="Exit 1 if any dangerous verdict")
    parser.add_argument("--warn-on-caution", action="store_true", help="Exit 1 if any caution verdict")
    args = parser.parse_args()

    if not args.rules.exists():
        print(f"ERROR: Rules file not found: {args.rules}")
        return 1

    rules = load_rules(args.rules)
    skills_dir: Path = args.skills_dir
    if not skills_dir.exists():
        print(f"ERROR: Skills directory not found: {skills_dir}")
        return 1

    any_dangerous = False
    any_caution = False

    for category_dir in sorted(skills_dir.iterdir()):
        if not category_dir.is_dir() or category_dir.name.startswith((".", "_")):
            continue
        for skill_dir in sorted(category_dir.iterdir()):
            if not skill_dir.is_dir() or skill_dir.name.startswith((".", "_")):
                continue

            result = scan_skill(skill_dir, rules)
            print(format_scan_report(result))

            if result.verdict == "dangerous":
                any_dangerous = True
            elif result.verdict == "caution":
                any_caution = True

            save_json_report(result, args.output)
            print(f"📄 JSON report saved: {args.output}/{skill_dir.name}-scan.json")

    print(f"\n{'=' * 60}")
    if any_dangerous:
        print("❌ Scan completed with DANGEROUS verdict(s).")
        if args.fail_on_dangerous:
            return 1
    elif any_caution:
        print("⚠️ Scan completed with CAUTION verdict(s).")
        if args.warn_on_caution:
            return 1
    else:
        print("✅ All skills passed custom threat scan.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
