#!/usr/bin/env python3
"""
Registry Updater — Auto-generate registry.yaml on CI merge.

Scans the skills/ directory, extracts metadata from SKILL.md,
reads latest Git commit SHA, and updates registry.yaml.

Usage (run from repo root):
    python .team-registry/scripts/update_registry.py

Environment:
    GITHUB_SHA — commit SHA to record (provided by GitHub Actions)
"""

import json
import os
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    print("ERROR: PyYAML is required")
    sys.exit(1)

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
SKILLS_DIR = REPO_ROOT / "skills"
REGISTRY_PATH = REPO_ROOT / ".team-registry" / "registry.yaml"
REPORTS_DIR = REPO_ROOT / ".team-registry" / "reports"


def get_git_sha() -> str:
    sha = os.environ.get("GITHUB_SHA")
    if sha:
        return sha
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True, text=True, cwd=REPO_ROOT, check=True,
        )
        return result.stdout.strip()
    except Exception:
        return "UNKNOWN"


def parse_skill_md(skill_dir: Path) -> Optional[dict]:
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        return None

    text = skill_md.read_text(encoding="utf-8")
    if not text.startswith("---"):
        return None

    match = re.search(r"\n---\s*\n", text[3:])
    if not match:
        return None

    yaml_text = text[3 : 3 + match.start() + 3]
    try:
        return yaml.safe_load(yaml_text) or {}
    except yaml.YAMLError:
        return None


def load_existing_registry() -> dict:
    if REGISTRY_PATH.exists():
        return yaml.safe_load(REGISTRY_PATH.read_text(encoding="utf-8")) or {}
    return {}


def load_scan_report(skill_name: str, version: str) -> dict:
    """Load scan report if available."""
    safe_name = skill_name.replace("/", "-")
    # Try both naming conventions
    candidates = [
        REPORTS_DIR / f"{safe_name}-scan.json",
        REPORTS_DIR / f"{safe_name}-{version}-scan.json",
    ]
    for cand in candidates:
        if cand.exists():
            try:
                return json.loads(cand.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
    return {}


def build_registry() -> dict:
    git_sha = get_git_sha()
    now = datetime.now(timezone.utc).isoformat()

    existing = load_existing_registry()
    registry_meta = existing.get("registry", {})

    skills_catalog = {}

    for category_dir in sorted(SKILLS_DIR.iterdir()):
        if not category_dir.is_dir() or category_dir.name.startswith((".", "_")):
            continue
        for skill_dir in sorted(category_dir.iterdir()):
            if not skill_dir.is_dir() or skill_dir.name.startswith((".", "_")):
                continue

            fm = parse_skill_md(skill_dir)
            if not fm:
                print(f"WARNING: Could not parse SKILL.md in {skill_dir}")
                continue

            skill_key = f"{category_dir.name}/{skill_dir.name}"
            name = fm.get("name", skill_dir.name)
            version = fm.get("version", "0.0.0")

            # Load scan report
            scan_data = load_scan_report(name, version)
            verdict = scan_data.get("verdict", "unknown")
            findings_count = scan_data.get("findings_count", 0)

            # Preserve existing metadata that shouldn't be auto-overwritten
            existing_entry = existing.get("skills", {}).get(skill_key, {})

            # Determine visibility from directory or existing
            visibility = existing_entry.get("visibility", "internal")
            allowed_teams = existing_entry.get("allowed_teams", [])

            entry = {
                "name": name,
                "category": category_dir.name,
                "description": fm.get("description", ""),
                "version": version,
                "author": fm.get("author", ""),
                "maintainer": existing_entry.get("maintainer", ""),
                "platforms": fm.get("platforms", []),
                "min_hermes_version": existing_entry.get("min_hermes_version", "0.14.0"),
                "commit_sha": git_sha,
                "signed_tag": existing_entry.get("signed_tag", ""),
                "audit_status": existing_entry.get("audit_status", "approved"),
                "approved_by": existing_entry.get("approved_by", "ci-bot"),
                "approved_at": existing_entry.get("approved_at", now[:10]),
                "security_scan": {
                    "scanner": "hermes-skills-guard/2.0",
                    "verdict": verdict,
                    "findings_count": findings_count,
                    "scan_report_url": f".team-registry/reports/{category_dir.name}-{skill_dir.name}-{version}.json",
                },
                "visibility": visibility,
                "allowed_teams": allowed_teams,
                "restricted_to": existing_entry.get("restricted_to", []),
                "requires_skills": existing_entry.get("requires_skills", []),
                "required_toolsets": existing_entry.get("required_toolsets", []),
            }

            skills_catalog[skill_key] = entry

    # Rebuild registry
    new_registry = {
        "schema_version": existing.get("schema_version", "1.0"),
        "registry": {
            "name": registry_meta.get("name", "my-team/hermes-team-skills"),
            "base_url": registry_meta.get("base_url", ""),
            "default_branch": registry_meta.get("default_branch", "main"),
            "updated_at": now,
        },
        "signing": existing.get("signing", {"required_for": ["restricted"], "public_keys_dir": ".team-registry/signing/keys"}),
        "skills": skills_catalog,
    }

    return new_registry


def save_registry(registry: dict) -> None:
    REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Use custom YAML dumper to preserve order and add comments
    text = yaml.dump(registry, sort_keys=False, allow_unicode=True, width=120, default_flow_style=False)
    header = (
        "# ============================================================\n"
        "# Team Skill Registry — Central Index\n"
        "# ============================================================\n"
        "# DO NOT EDIT MANUALLY. This file is auto-generated by CI on\n"
        "# every merge to the main branch.\n"
        "# ============================================================\n\n"
    )
    REGISTRY_PATH.write_text(header + text, encoding="utf-8")


def main() -> int:
    if not SKILLS_DIR.exists():
        print(f"ERROR: Skills directory not found: {SKILLS_DIR}")
        return 1

    print("🔧 Building registry from skills/ ...")
    registry = build_registry()
    save_registry(registry)
    print(f"✅ Registry updated: {REGISTRY_PATH}")
    print(f"   Skills indexed: {len(registry.get('skills', {}))}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
