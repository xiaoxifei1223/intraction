---
name: onboarding
description: "Guide new team members through environment setup."
version: 1.0.0
author: "platform-team@company.com"
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [onboarding, setup, environment, new-hire]
    category: internal
    related_skills: []
---

# Onboarding Skill

This skill helps new team members set up their development environment, access internal tools, and understand team conventions.

## When to Use

Run this skill for every new team member on their first day.

## Prerequisites

- Admin access to team GitHub organization
- `terminal` toolset enabled

## How to Run

The user provides their operating system. The agent generates a personalized checklist.

## Procedure

### Step 1: Account Provisioning Checklist

Verify the new member has access to:
- GitHub organization invitation accepted
- Slack workspace joined
- VPN configured (if applicable)
- AWS / GCP IAM account created

### Step 2: Local Environment

Install common tools:

```
terminal(command="git --version")
terminal(command="docker --version || echo 'Docker not installed'")
terminal(command="python3 --version || python --version")
```

Clone the team monorepo:

```
terminal(command="git clone git@github.com:my-team/monorepo.git ~/workspace/monorepo")
```

### Step 3: Hermes Setup

Verify Hermes is configured:

```
terminal(command="hermes --version")
terminal(command="hermes skills tap list")
```

Install recommended team skills:

```
terminal(command="hermes skills install my-team/hermes-team-skills/devops/deploy-k8s")
```

### Step 4: Team Conventions

Summarize key conventions for the user:
- Branch naming: `feature/TICKET-description`
- Commit format: conventional commits
- PR requires 1 approval before merge
- Deployments run via `deploy-k8s` skill only

## Verification

Confirm the user can:
1. Run `hermes skills list` and see team skills
2. Access the monorepo
3. Run local tests successfully
4. Connect to VPN and internal dashboards

## Pitfalls

- **Skipping VPN setup**: Many internal tools are only accessible behind VPN. Do not skip.
- **Using personal Git config**: Ensure `git config user.email` uses the company email address.
- **Forgetting SSH keys**: GitHub access requires SSH keys; HTTPS with PAT is discouraged.
