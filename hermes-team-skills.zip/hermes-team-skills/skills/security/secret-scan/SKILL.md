---
name: secret-scan
description: "Scan repositories for leaked secrets and credentials."
version: 1.0.0
author: "security-team@company.com"
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [security, secrets, audit, scanning]
    category: security
    related_skills: []
---

# Secret Scan Skill

This skill performs automated secret detection in Git repositories using `gitleaks` or `trufflehog`. It reports findings with file paths and remediation steps.

## When to Use

Use this skill when:
- Onboarding a new repository to check for historical secret leakage
- Performing a security audit of existing code
- Setting up CI pre-commit hooks

## Prerequisites

- `gitleaks` or `trufflehog` installed (the skill will attempt to install if missing)
- `terminal` toolset enabled
- `search_files` tool available

## How to Run

Provide the repository path. The agent will choose the best scanner available and run a full-history scan.

## Procedure

### Step 1: Detect Scanner

```
terminal(command="which gitleaks || which trufflehog")
```

### Step 2: Run Scan

With gitleaks:

```
terminal(command="gitleaks detect --source <repo-path> --verbose --report-format json --report-path /tmp/gitleaks-report.json")
```

With trufflehog:

```
terminal(command="trufflehog filesystem <repo-path> --json --only-verified > /tmp/trufflehog-report.json")
```

### Step 3: Parse and Report

Read the JSON report and summarize:
- Number of findings
- Severity (verified vs unverified)
- Affected files and commit SHAs
- Recommended remediation (rotate credentials, use secret manager)

## Verification

After remediation, re-run the scanner to confirm zero findings.

## Pitfalls

- **Unverified findings**: Trufflehog may report entropy-based matches that are false positives. Always verify.
- **History rewrite**: Removing secrets requires `git filter-repo` or BFG; simple deletion leaves secrets in Git history.
- **Rate limiting**: Verified checks against live APIs (AWS, Slack) may hit rate limits. Use `--only-verified` sparingly on large repos.
