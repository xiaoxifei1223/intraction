#!/usr/bin/env bash
# health-check.sh — Basic K8s deployment health verification
# Usage: bash health-check.sh <namespace> <app-label>

set -euo pipefail

NAMESPACE="${1:-default}"
APP_LABEL="${2:-app}"
TIMEOUT="${3:-120}"

echo "=== Health Check: namespace=$NAMESPACE, app=$APP_LABEL ==="

# Check pods are ready
kubectl wait --for=condition=ready pod -l app="$APP_LABEL" -n "$NAMESPACE" --timeout="${TIMEOUT}s"

# Check no restarts exceeding threshold
RESTARTS=$(kubectl get pods -l app="$APP_LABEL" -n "$NAMESPACE" -o jsonpath='{range .items[*]}{.status.containerStatuses[0].restartCount}{"\n"}{end}' | awk '{s+=$1} END {print s}')
if [ "$RESTARTS" -gt 2 ]; then
    echo "WARNING: High restart count detected ($RESTARTS). Investigate logs."
    exit 1
fi

# Check pod events for errors
EVENT_ERRORS=$(kubectl get events -n "$NAMESPACE" --field-selector type=Warning --sort-by='.lastTimestamp' | tail -n 10 || true)
if [ -n "$EVENT_ERRORS" ]; then
    echo "Recent warnings:"
    echo "$EVENT_ERRORS"
fi

echo "=== Health check passed ==="
