---
name: deploy-k8s
description: "Zero-downtime Kubernetes deployment with rollback support."
version: 1.0.0
author: "devops-team@company.com"
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags: [devops, kubernetes, deploy, rollback]
    category: devops
    related_skills: []
---

# Deploy K8s Skill

This skill guides you through zero-downtime Kubernetes deployments using standard `kubectl` and `helm` commands. It includes health checks, canary validation, and automated rollback procedures.

## When to Use

Use this skill when you need to:
- Deploy an application to a Kubernetes cluster
- Perform a rolling update with zero downtime
- Validate a deployment before committing traffic
- Roll back a failed deployment safely

Do not use this skill for cluster provisioning or infrastructure creation — use the `terraform-module` skill for that.

## Prerequisites

- `kubectl` configured with access to the target cluster (`kubectl config current-context` works)
- `helm` installed (only if using Helm charts)
- Docker image already built and pushed to an accessible registry
- `terminal` toolset enabled

## How to Run

1. Provide the target cluster context, namespace, and application name.
2. Provide the container image tag to deploy.
3. The agent will execute the deployment, verify health, and report status.

## Quick Reference

| Command | Purpose |
|---------|---------|
| `kubectl apply -f` | Apply raw manifests |
| `helm upgrade --install` | Deploy or upgrade a Helm release |
| `kubectl rollout status` | Wait for rollout to complete |
| `kubectl rollout undo` | Roll back to previous revision |

## Procedure

### Step 1: Pre-flight Checks

Validate the environment before deploying:

```
terminal(command="kubectl config current-context")
terminal(command="kubectl get nodes")
terminal(command="kubectl get namespace <namespace> || kubectl create namespace <namespace>")
```

### Step 2: Deploy

For Helm-based deployments:

```
terminal(command="helm upgrade --install <release> ./helm-chart --namespace <namespace> --set image.tag=<tag> --wait --timeout 5m")
```

For raw manifests:

```
terminal(command="kubectl apply -k ./k8s/overlays/<env>/ -n <namespace>")
terminal(command="kubectl rollout status deployment/<app> -n <namespace> --timeout=5m")
```

### Step 3: Health Verification

Run the bundled health check script to validate endpoints:

```
terminal(command="bash scripts/health-check.sh <namespace> <app>")
```

If any health check fails, proceed to Step 5 (Rollback).

### Step 4: Canary / Smoke Test (Optional)

If the cluster supports canary traffic splitting:

```
terminal(command="kubectl get pods -l app=<app> -n <namespace>")
terminal(command="kubectl logs -l app=<app> -n <namespace> --tail=50")
```

Check for error rates, crash loops, or resource throttling.

### Step 5: Rollback (On Failure)

If the deployment fails health checks:

```
terminal(command="helm rollback <release> 0 -n <namespace>")
```

Or for raw manifests:

```
terminal(command="kubectl rollout undo deployment/<app> -n <namespace>")
terminal(command="kubectl rollout status deployment/<app> -n <namespace> --timeout=5m")
```

## Verification

After deployment or rollback, confirm:

1. Pods are running: `kubectl get pods -n <namespace>`
2. Service endpoints respond correctly
3. No CrashLoopBackOff or ImagePullBackOff states
4. Previous replica set is scaled down (for roll-forward) or current replica set matches pre-deploy state (for rollback)

## Pitfalls

- **Missing `--wait` or `--timeout`**: Helm/Kubectl may return success before pods are ready. Always use `--wait`.
- **No resource limits**: Deployments without CPU/memory limits can destabilize the node. Verify limits are set.
- **Image tag as `latest`**: Using `latest` makes rollback unreliable. Always use immutable tags.
- **Ignoring `kubectl rollout status` exit code**: A non-zero exit code means the rollout failed — do not proceed.

## References

- `references/kubectl-cheatsheet.md` — Common commands for debugging
