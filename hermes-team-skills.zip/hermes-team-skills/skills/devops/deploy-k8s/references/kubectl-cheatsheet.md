# Kubectl Cheatsheet

## Pod Operations

```bash
# Get pods
kubectl get pods -n <namespace>

# Get pod logs
kubectl logs <pod-name> -n <namespace> --tail=100 -f

# Exec into pod
kubectl exec -it <pod-name> -n <namespace> -- /bin/sh

# Port forward
kubectl port-forward svc/<service> 8080:80 -n <namespace>
```

## Deployment Operations

```bash
# View rollout history
kubectl rollout history deployment/<name> -n <namespace>

# Rollback to specific revision
kubectl rollout undo deployment/<name> -n <namespace> --to-revision=2

# Pause rollout
kubectl rollout pause deployment/<name> -n <namespace>

# Resume rollout
kubectl rollout resume deployment/<name> -n <namespace>
```

## Debugging

```bash
# Describe resource (events + status)
kubectl describe pod <pod-name> -n <namespace>

# Check resource usage
kubectl top pod -n <namespace>

# Get events sorted by time
kubectl get events -n <namespace> --sort-by='.lastTimestamp'
```
