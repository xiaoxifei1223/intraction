# 07 Agent Harness 框架选型（内核框架）

> 本章针对"以 harness 规范构建 Agent 内核"的选型，替代 [05 章](./05-框架与平台选型对比.md)中以图编排（LangGraph 式）为主的视角。
> "Harness"指围绕 LLM 的脚手架：工具调用循环 + 规划 + 文件系统 + 子代理 + 上下文管理 + 人机回路的组合体（Claude Code 是这一形态的标杆）。2026 年行业话语是"模型不再是产品，Harness 才是"、"Harness Engineering"成为显学。

## 1. Harness 规范：事实标准的能力清单

以 LangChain Deep Agents 官方文档的分类为骨架（它与 Claude Code 同构，行业基本收敛于此）：

| 能力域 | 内容 | 典型实现 |
|---|---|---|
| 执行环境 | 工具调用、虚拟文件系统、可选沙箱、REPL | `read/write/edit/ls/glob/grep`、`execute` |
| 上下文管理 | 历史摘要、大结果卸载、Prompt 缓存、技能/记忆按需加载 | 自动 summarization、context offloading |
| 委派 | 任务规划（`write_todos`）+ 子代理（隔离上下文窗口） | `task` 工具 spawn 子代理 |
| 引导/控制 | HITL 审批、中断、工具级权限 | interrupt + approval |
| 长期进化 | 记忆、技能、Prompt 基于真实使用持续更新 | memory/skills 文件 + 评测门控 |

判断一个框架是不是"harness 规范"：不是给你积木让你自己拼循环（那是 LangGraph/smolagents 的定位），而是**开箱即有一个带上述能力的、有主见的（opinionated）Agent 运行时**，你再往里换模型、加工具、改 Prompt。

## 2. 候选 Harness 框架对比

| 维度 | **DeepAgents** (LangChain) | **Claude Agent SDK** (Anthropic) | **Agno / AgentOS** | **OpenHands V1 SDK** | **AgentScope** (阿里) |
|---|---|---|---|---|---|
| 模型 | 任意（100+ 提供商） | 仅 Claude（含 Bedrock/Vertex/Azure 渠道） | 任意（23+ 提供商） | 任意（LiteLLM） | 任意，国产模型生态深 |
| License | MIT | SDK 为 MIT（Claude Code 本体闭源） | 开源 | MIT | Apache 2.0 |
| 沙箱模式 | 可插拔：Agent 可在沙箱内，或在外部把远程沙箱当工具 | 仅"Agent 跑在沙箱内" | 运行时外部化 | 可选沙箱（V1 起 opt-in） | 支持分布式 Actor |
| 多租户 | 内置概念：scoped threads、按用户沙箱、RBAC | 需自建 | AgentOS 控制平面 | 容器化 agent server 天然支持 SaaS 式多租户 | 2.0 面向多租户/零信任 |
| Serving 层 | `langgraph build` 出独立镜像，含流式/线程/运行历史/Webhook/认证 | 需自建 HTTP/SSE 服务与认证 | 预置 FastAPI runtime（SSE）+ 控制平面 UI | 内置 REST/WebSocket agent server | HiClaw 网关方案 |
| 记忆/进化钩子 | 文件系统后端（State/Filesystem/Store/Composite）+ skills + memory | 会话级，跨会话学习无 | 内置 user memory / knowledge(20+ 向量库) / culture 共享记忆 | 事件溯源状态 + 确定性回放 | 集成 Mem0/ReMe |
| 持久执行 | 底层 LangGraph checkpoint/durable | — | 异步优先、长任务设计 | 事件溯源可回放 | — |
| 生态热度 | 发布后快速增长（第三方报道 15k+ stars） | 依附 Claude Code 生态 | 25k+ stars（前身 Phidata 22k+） | 64k+ stars、18 个月数百贡献者（论文口径） | 国内生态活跃 |

来源：
- Deep Agents 官方文档：https://docs.langchain.com/oss/python/deepagents/overview 、https://docs.langchain.com/oss/python/deepagents/comparison
- OpenHands V1 SDK 论文（arXiv:2511.03690）：https://arxiv.org/html/2511.03690v2
- Agno 官网/GitHub：https://www.agno.com/blog/performance-matters-why-agno-treats-performance-as-a-first-class-citizen
- CSDN 三方对比：https://blog.csdn.net/m0_65555479/article/details/161058812
- ContextStudios 对比：https://www.contextstudios.ai/comparisons/claude-agent-sdk-vs-langchain

## 3. 关键实证数据（均标注口径）

- **Deep Agents CLI 在 Terminal-Bench 2.0 上以 Claude Sonnet 4.5 取得约 42.65%，与同模型档位的 Claude Code 相当**（flowtivity.ai 与 CSDN 文章引用，建议复核官方榜单）。说明模型无关 harness 可以达到厂商原生 harness 的水平。
- **安全红队测试**（Lasso Security, 2026-08）：Claude Agent SDK 与 deepagents 在攻击目标达成率上几乎相同（约 21% vs 19%）——**harness 选择不构成安全性差异，安全要靠沙箱与工具级治理**。
- **Agno 性能自测**（厂商口径，Apple M4，2025-10）：Agent 实例化约 3μs（称比 LangGraph 快 529×）、内存约 6.6KiB（称低 24×）。官方自己注明"请勿直接采信，请自测"。对多用户平台而言，**每用户/每会话的实例化开销确实是关键指标**，值得实测复核。
- **OpenHands 在 SWE-bench Verified**：搭配 Claude Opus 4.6 报 68.4%；搭配开源 Devstral 24B 报 46.8%（Spheron 部署文引用的公开榜单口径）。证明开源 harness + 开源模型的上限已不低。
- **框架存储开销基准 AgentFootprint**（arXiv:2607.11149）测量了 LangGraph/AutoGen/CrewAI/SmolAgents/OpenAI Agents SDK/Agno 等 8 个框架在持久会话下的磁盘足迹——多租户平台做容量规划时值得一读。

## 4. 与本项目需求的匹配分析

项目需求：多用户（多租户 + 租户内多用户）、云上（沙箱化、可伸缩）、可进化（记忆/技能/Prompt 可更新且有门控）。

| 需求 | 最佳匹配 | 说明 |
|---|---|---|
| 模型无关（企业客户常要求换国产模型/私有化模型） | DeepAgents、Agno、OpenHands | Claude Agent SDK 此项直接出局（除非只做 Claude 专线产品） |
| 多租户开箱支持 | DeepAgents（scoped threads/RBAC/按用户沙箱）、Agno AgentOS | 其余需自建包装层 |
| 沙箱后端可插拔（对接 E2B/gVisor/K8s） | DeepAgents（backend 抽象）、OpenHands（Workspace 抽象，Docker/远程） | 这是云上部署的硬要求 |
| 可进化钩子（记忆/技能文件化、Prompt 可按模型调优） | DeepAgents（skills+memory+harness profiles 按模型声明式调优） | harness profiles 正好服务"同一 harness 多模型"的企业场景 |
| 生产 serving 层 | Agno（FastAPI runtime）、DeepAgents（langgraph build）、OpenHands（agent server） | Claude Agent SDK 需完全自建 |
| 编码类场景上限 | OpenHands（SWE-bench 验证最充分） | 若平台主打软件工程场景优先考虑 |

## 5. 选型建议

**主推荐：DeepAgents 作为 harness 内核**，理由：

1. **解耦最彻底**：模型、沙箱后端、部署目标三者独立可选（官方设计原则），符合企业平台"不被任何一家绑定"的底线；
2. **多租户与 RBAC 是一等公民**（官方对比页明确将其作为与 Claude Agent SDK 的差异点），与 02 章的多租户架构直接衔接；
3. **MIT 协议 + 底层是 LangGraph 成熟运行时**（checkpoint/流式/HITL 都是久经验证的），同时保留了"必要时降层到 LangGraph 自定义图"的逃生门——harness 与图编排不互斥；
4. **skills/memory/harness profiles 的文件化设计天然对接"可进化"**：进化产物（新技能、新 Prompt profile）就是文件系统里的版本化资产，可以套用 03 章的"生成→沙箱验证→评测门控→灰度→归档"流水线。

**备选/组合**：

- **Agno（AgentOS）**：若团队更看重开箱 serving 层与极致实例化开销，且愿意接受其自有抽象体系；建议先做实例化与内存的实测复核厂商数据。
- **OpenHands V1 SDK**：若平台核心场景是"软件工程 Agent"，其 Workspace/agent server/Secret Registry/SecurityAnalyzer 设计（arXiv:2511.03690）是目前公开文献中最完整的生产级参考架构，即使不采用也强烈建议通读。
- **Claude Agent SDK**：仅当产品定位就是"Claude 原生编码 Agent"时考虑；多租户、serving、模型切换都要自建，与本项目目标不符。
- **AgentScope**：团队为 Java 栈、深度绑定阿里云生态时考虑。

**必须明确的边界**：harness 只解决"单个 Agent 怎么跑得靠谱"。02/04 章的网关、RBAC、计费、审计、MCP Gateway、评测门控仍是平台层自建内容——任何 harness 都不附带完整平台。

## 6. 落地验证清单（建议选型 PoC 的测试项）

1. 用同一份任务集在 DeepAgents / Agno 上跑 Terminal-Bench 类评测，复核 harness 差异（模型固定）；
2. 实测单实例内存与实例化耗时 × 目标并发会话数，推算每节点容量；
3. 验证沙箱后端对接：DeepAgents 自定义 backend → E2B/gVisor 各打通一次；
4. 验证多租户：两个 tenant 并发跑，检查线程隔离、沙箱归属、RBAC 生效；
5. 验证进化闭环：往 skills/ 目录注入一个新技能文件，走评测门控后灰度到 5% 会话，确认可回滚。

## 7. 关键边界：网关与控制平面怎么办（DeepAgents 不附带平台）

选型时必须认清：harness 只解决"单个 Agent 跑得靠谱"，**网关和控制平面是自建的平台本体**。`langgraph build` 出的自托管 Agent Server 只提供原语：Agent Server（流式/threads/runs/webhooks）、Assistants（同 graph 多配置实例，可作 Agent 注册的运行时表示）、Custom Auth（`@auth.on.threads.*` 资源级 handler）、Store 命名空间、harness backend 挂钩。

**License 陷阱（已核实）**：完整资源级授权/RBAC 是 LangGraph Platform 商业特性（SaaS + Enterprise 自托管）；纯 OSS 部署下官方威胁模型明确"持有有效 thread_id 即可读该 thread 状态"，租户隔离只剩应用层过滤。两条出路：
1. 购买 Enterprise License；或
2. 持久层强制租户包裹——社区参考实现 `langgraph-tenancy`（PyPI，MIT）：`tenant::thread` 键前缀、缺租户上下文即报错、按租户 usage 计量与配额（check-then-write，超限后续 run 拒绝）、GDPR 擦除。

**落地分工**：

- 网关（自建，FastAPI/Kong+OPA）：SSO/JWT 最上游解析 tenant_id → 控制平面查权限配额 → Prompt 防火墙 → 服务端生成 `{tenant}::{uuid}` 的 thread_id（禁止客户端传）→ 审计落库 → 转发 Agent Server（custom auth 只信网关注入身份）。
- 控制平面（自建微服务 + PG）：tenants/orgs/users/roles、agents（模型/Prompt/skills/tools 定义 → 下发为 assistant config）、skills 版本管理、quotas/usage/audit。
- 内核与控制平面接口仅三个：assistant config 下发、thread/store 命名空间约定、usage 计量回流——这就是"内核外再包一层自有抽象"的具体形态，未来换 harness 时平台层不动。

来源：LangChain 官方 custom auth 博客（2024-12）、LangChain 论坛 2617 帖（auth 为 platform feature）、github.com/ac12644/langgraph-tenancy。

## 8. 对照：Agno AgentOS 自带多少平台层（2026-07 官方文档核实）

与 DeepAgents/LangGraph 栈的最大差异：**AgentOS 把资源级授权与用户级数据隔离开源内置了**。

开源自托管即获得：FastAPI runtime（80+ 端点、SSE/WS、后台执行、断线重连、run 取消）；JWT 认证（JWKS/多 issuer/可接 Auth0·Okta·WorkOS 或自有后端签发）；RBAC（JWT scopes claim 逐端点门控，默认 owner/admin/member 三角色）；**用户级数据隔离**（`user_isolation=True`，非 admin 调用方 session/memory 读取自动按 JWT sub 过滤，需 PG 记录 user_id）；请求隔离（每 run deep_copy Agent）；内置 MCP server / A2A server / AG-UI / IM 接口；evals、OTel tracing、scheduler、HITL approvals；Docker/K8s Helm/三大云部署模板。

仍需自建或付费的：
- **网关层**：官方明确 rate limiting/WAF/IP allowlists/mTLS 由自有反向代理负责；SSO 联邦、Prompt 防火墙、审计总线照例如建；
- **组织模型与计费**：租户/部门层级、配额、token 计费、Skill 注册中心均无；`user_isolation` 是按用户（JWT sub）而非按企业租户隔离，落地要么把 tenant 编入身份/scope，要么**每租户一个 AgentOS 实例**（契合 K8s namespace 硬隔离方案）；
- **官方控制平面（os.agno.com）**：Live 连接需付费计划，自定义角色为 Enterprise；但自托管可完全绕开——自有后端/IdP 签发带 scopes 的 JWT 即可。

**对选型的修正**：在"网关+控制平面自建成本"维度 Agno 占优（DeepAgents 栈的 Enterprise 授权与第三方租户包裹都被它开源内置）；DeepAgents 剩余优势为 harness 能力更满（skills/harness profiles/子代理上下文隔离）、LangGraph durable runtime 更成熟、生态更大。另有混合路线：AgentOS 支持多框架 adapter（可挂 LangGraph/Claude Agent SDK Agent），可作运行时外壳 + DeepAgents 内核，代价是两套抽象叠加，建议 PoC 验证。选 Agno 路线时应重点实测其 harness 深度（子代理隔离、长任务上下文管理、技能/记忆进化钩子）是否满足可进化需求。

来源：https://docs.agno.com/agent-os/introduction 、https://docs.agno.com/features/security-and-auth 、https://docs.agno.com/deploy/templates/docker/deploy
