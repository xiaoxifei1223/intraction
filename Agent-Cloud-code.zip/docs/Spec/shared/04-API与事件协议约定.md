# Shared-04 · API 与事件协议约定

| 状态 | draft | 读者 | platform-api / agent-runtime / mcp-gateway / web-console 所有开发 |
|---|---|---|---|

## 1. API 分层

| 层 | 前缀 | 消费方 | 认证 |
|---|---|---|---|
| 终端 Open API | `/v1/...` | 终端用户应用、第三方集成 | JWT（SSO/OIDC）或 API Key |
| 管理 API | `/v1/admin/...` | 控制台、运维 | JWT + 管理角色 |
| 内部 API | `/internal/...` | 服务间（platform-api → agent-runtime 等） | 内网身份头（shared/02 §1），不暴露公网 |

## 2. Open API v1 端点（D08 §13 定稿）

| 端点 | 说明 |
|---|---|
| `POST /v1/sessions` | 创建会话（body: agent_id）→ `{session_id}` |
| `GET /v1/sessions` · `GET /v1/sessions/{id}` | 会话列表/详情（含历史消息摘要） |
| `POST /v1/sessions/{id}/runs` | 发起 run，**SSE 流式返回**（事件协议见 §3） |
| `POST /v1/runs/{id}/cancel` | 取消 |
| `POST /v1/runs/{id}/approve` | HITL 审批（body: decision: approve/edit/reject + payload） |
| `GET /v1/agents` · `POST /v1/agents` · `GET /v1/agents/{id}` | Agent 定义 |
| `POST /v1/agents/{id}/versions` · `GET /v1/agents/{id}/versions` | 版本管理 |
| `POST /v1/agents/{id}/releases` · `POST /v1/releases/{id}/rollback` | 发布 / 回滚 |
| `GET/POST /v1/skills` · `POST /v1/skills/{id}/versions` · `POST /v1/skill-versions/{id}/submit-review` | Skill 管理（P3 完整化） |
| `GET /v1/usage?period=` | 用量与账单 |
| `GET /v1/audit?...` | 审计检索（P2） |
| `GET /v1/admin/tenants` 等 | 租户/组织/用户管理 |

## 3. Run 事件协议（SSE）

统一信封：

```json
{
  "id": "<单调递增事件 id，断线重连用 last-event-id>",
  "type": "token | tool_call | tool_result | todo | interrupt | usage | run_started | done | error | heartbeat",
  "run_id": "...",
  "ts": "...",
  "data": { ... }
}
```

| type | data 内容 | 来源 |
|---|---|---|
| `run_started` | agent_version、spec_hash | runtime |
| `token` | 增量文本 | LLM 流 |
| `tool_call` / `tool_result` | 工具名、参数摘要、结果摘要、risk 标注 | MCP 网关经 runtime 透传 |
| `todo` | 当前计划列表 | TodoListMiddleware（F3，opt-in 开启） |
| `interrupt` | 待审批的工具调用详情（approval_id） | HITL（F5） |
| `usage` | 累计 token/成本 | checkpointer usage_metadata |
| `done` / `error` | 终态 + 错误码 | runtime |
| `heartbeat` | 每 15s | 网关代理层 |

规则：心跳由 platform-api 代理层注入；支持 `Last-Event-ID` 断线重连；事件中的工具参数/结果一律**摘要化**（截断 + 脱敏），完整内容只进审计/trace。

## 4. 错误模型

```json
{ "error": { "code": "quota_exceeded", "message": "...", "request_id": "...", "retryable": false } }
```

HTTP 语义：`400` 参数/协议错误（含客户端偷传 thread_id）；`401/403` 认证/授权；`402`→ 不用，配额用 `403 + quota_exceeded`；`404` 资源不存在或**跨租户不可见**（不泄露存在性）；`409` 状态冲突（如重复发布）；`429` 限流；`5xx` 平台错误。

错误码全集（初版）：`tenant_context_missing / tenant_suspended / quota_exceeded / rate_limited / version_not_published / skill_not_published / permission_denied / prompt_blocked / sandbox_unavailable / spec_invalid / internal_error`。

## 5. 通用约定

- 分页：`cursor` 制（`?cursor=&limit=`），响应带 `next_cursor`；
- 幂等：所有 POST 支持 `Idempotency-Key` 头（24h 内重放返回首个结果）；
- 版本：URL 大版本 `/v1`；响应兼容期内的字段只增不改；
- 全链路 `X-Request-ID` 透传，与 trace_id 关联（D08 §16）。
