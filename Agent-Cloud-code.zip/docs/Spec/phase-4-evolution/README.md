# Phase 4 · 持续演进（占位）

| 状态 | placeholder | 说明 | 本阶段无固定周期，随 Phase 3 出口评审立项 |
|---|---|---|---|

候选方向（D08 §18 P4 + §10.2）：

1. **多 Agent 协同**：AsyncSubAgent 远程调度（deepagents 已支持 Agent Protocol 对接）+ A2A 跨组织编排；
2. **跨区域/数据驻留**：docs/02 租户区域化方案落地；
3. **L4 研究**：Agent 改自身代码——**仅限内部研究环境**，进生产需单独安全评审（D08 §10.2 红线）；
4. **Firecracker 沙箱档**：高安全租户第二档隔离（sandbox-pool `SandboxDriver` 抽象已实现预留）；
5. **记忆服务升级**：评估 Mem0 等外部记忆服务（Phase 1 已预留接口位，D08 §7）。

立项规则：每个方向单独立项，补齐 requirements/design/tasks 三件套后进入开发，流程同 Spec/README §2。
