# Phase 0 · PoC — Tasks

| 状态 | draft | 周期 | 2–3 周 |
|---|---|---|---|

图例：`[ ]` 未开始 `[~]` 进行中 `[x]` 完成。每个任务标注覆盖的 AC。

## S1 内核能力验证（第 1 周）

- [ ] **T1** 环境就绪：Python 3.11+ venv，`deepagents==0.7.x` 锁版本，本地 Postgres（docker）+ langgraph checkpoint 表初始化。覆盖：全部 AC-0.1.x 前置
- [ ] **T2** demo_todos.py + demo_subagents.py（规划/子代理/`task`）。覆盖：AC-0.1.1（规划、子代理部分）
- [ ] **T3** demo_skills.py + demo_memory.py（CompositeBackend `/memories/` 路由、跨 thread 可见性）。覆盖：AC-0.1.1（技能、记忆）、AC-0.1.2
- [ ] **T4** demo_hitl.py（interrupt_on + Postgres checkpointer 中断/审批/恢复 + 上下文恢复）。覆盖：AC-0.1.1（HITL）、AC-0.1.4
- [ ] **T5** 长会话 checkpoint 体积测试（≥50 轮，DeepAgentState DeltaChannel 验证）。覆盖：AC-0.1.3
- [ ] **T6** S1 结论文档：D08 §6.2 映射表逐项确认/差距清单。覆盖：AC-0.1.x 汇总

## S2 租户包裹层 spike（第 1–2 周，与 S1 并行）

- [ ] **T7** `TenantScopedCheckpointer` + `TenantScopedStore` 原型（contextvars 注入）。覆盖：AC-0.2.1
- [ ] **T8** 串租户矩阵测试 + `list()` 拒绝测试。覆盖：AC-0.2.1
- [ ] **T9** RLS 策略原型 + 绕过包裹层直连验证。覆盖：AC-0.2.2
- [ ] **T10** 工作量实测记录 → Q2 ADR 输入。覆盖：AC-0.2.3

## S3 沙箱 spike（第 2 周）

- [ ] **T11** 最小沙箱服务（docker SDK + `/exec` HTTP）。覆盖：AC-0.3.1
- [ ] **T12** `PocSandboxBackend(BaseSandbox)` 适配器 + demo_execute.py 端到端。覆盖：AC-0.3.1
- [ ] **T13** 断网白名单实验 + 结构化错误验证。覆盖：AC-0.3.2
- [ ] **T14** 冷启动耗时实测 → Q3 ADR 输入。覆盖：AC-0.4.2（Q3）

## S4 契约 freeze 与决策（第 2–3 周）

- [ ] **T15** 契约骨架包 `s4-contract/`（kernel + DeepAgentsRunner 最小实现 + contract tests）。覆盖：AC-0.4.1
- [ ] **T16** 契约 freeze 评审会（字段完备性对照 D08 §6.2）。覆盖：AC-0.4.1
- [ ] **T17** ADR-Q1：网关语言（含 FastAPI SSE 并发实测）。覆盖：AC-0.4.2
- [ ] **T18** ADR-Q2：Enterprise vs 自研（含 T10 数据 + 报价）。覆盖：AC-0.4.2
- [ ] **T19** ADR-Q3：沙箱方案（含 T14 数据）。覆盖：AC-0.4.2
- [ ] **T20** D08 §18 P0 五项清单打钩归档 + Phase 1 requirements 修订评审。覆盖：AC-0.4.3

## 出口检查单

- [ ] AC-0.1.1 ~ AC-0.1.4 全部通过
- [ ] AC-0.2.1 ~ AC-0.2.3 全部通过
- [ ] AC-0.3.1 ~ AC-0.3.2 通过
- [ ] 三份 ADR decided、契约包 freeze
- [ ] Phase 1 spec 修订完成并 approved
