# Phase 0 · PoC — Requirements

| 状态 | draft | 周期 | 2–3 周 | 上游 | D08 §18 P0、§19 Q1/Q2/Q3 |
|---|---|---|---|---|---|

## 1. 目标

用最小成本**证伪/证实**四个关键技术假设，并关闭 Phase 1 开工前的全部决策项（Q1/Q2/Q3 + 抽象层契约 freeze）。PoC 代码可抛弃，但 spike 结论必须形成文档。

## 2. 范围

**In**：DeepAgents 0.7.x 能力验证；租户包裹层 spike；沙箱 execute 端到端打通；内核抽象层契约 v1；决策记录（ADR）。

**Out**：任何生产化代码（认证、控制台、MCP 网关、计费、多副本部署）；Agno 深度对比（仅当 S1 发现 DeepAgents 阻断性缺陷时启动备选验证，D08 §17）。

## 3. 用户故事与验收标准

### US-0.1 内核能力验证（S1）
> 作为平台架构师，我要确认 deepagents 0.7.x 提供的能力足以支撑 D08 §6.2 的全部映射，不留盲区。

- **AC-0.1.1** When 用 `create_deep_agent` 装配一个带 `TodoListMiddleware`（显式 opt-in，F3）、skills、memory_files、subagents、`interrupt_on` 的 agent，Then 规划/技能渐进加载/记忆注入/子代理 `task` 调用/HITL 中断-审批-恢复 五项行为各有一个可运行 demo 且结果符合预期。
- **AC-0.1.2** When 用 `CompositeBackend(default=StateBackend(), routes={"/memories/": StoreBackend(...)})` 组合 backend，Then Agent 对 `/memories/` 的写入跨 thread 可见，且其余路径文件仅会话内有效（验证 F2/F7）。
- **AC-0.1.3** When 自定义 state 继承 `DeepAgentState`，Then 长会话（≥50 轮）checkpoint 体积增长接近线性（验证 F8 DeltaChannel 未被破坏）。
- **AC-0.1.4** When checkpointer 中断后恢复 run，Then 租户上下文与 HITL 状态完整恢复。

### US-0.2 租户包裹层 spike（S2）
> 作为平台架构师，我要确认"checkpointer/store 外包租户作用域层 + PG RLS"能做到 fail-closed 的租户隔离，并给出工作量实证。

- **AC-0.2.1** Given 两个租户 A/B 各有一个 thread，When 以 A 的上下文访问 B 的 thread / store namespace，Then 全部抛错，无静默成功；`list()` 不带租户范围被拒绝。
- **AC-0.2.2** When 绕过包裹层直连 PG 查询 checkpoint 表，Then RLS 策略阻止跨租户行可见。
- **AC-0.2.3** spike 产出实测工作量记录，校准 Q2（自研 2–3 人周估算是否成立）。

### US-0.3 沙箱 execute 打通（S3）
> 作为平台架构师，我要验证"自研沙箱服务 → `SandboxBackendProtocol` 适配器 → deepagents `execute` 工具"链路可行（F4）。

- **AC-0.3.1** When 实现一个最小 sandbox 服务（本地 Docker 容器即可，非 gVisor）+ `BaseSandbox` 子类适配器，Then Agent 能通过 `execute` 工具在容器内执行命令并拿到 stdout/exit_code，且 `ls/read_file/write_file` 经 `BaseSandbox` 的 shell 实现自动可用。
- **AC-0.3.2** When 沙箱容器断网（除白名单外），Then Agent 的出站请求失败且错误结构化返回给模型（不误判为工具不存在）。

### US-0.4 契约 freeze 与决策（S4）
- **AC-0.4.1** shared/01 抽象层契约落为可 import 的 Python 骨架包（Protocol + Pydantic 模型 + contract test 套件雏形），评审通过即 freeze。
- **AC-0.4.2** Q1（网关语言）、Q2（Enterprise vs 自研）、Q3（沙箱方案）各产出一份 ADR，含数据支撑与最终决策。
- **AC-0.4.3** D08 §18 P0 验收清单（docs/07 §6 五项）逐项打钩归档。

## 4. 出口验收（Exit Criteria，全部通过才可开 Phase 1）

1. AC-0.1.x 全部通过，无阻断性能力缺口（若有 → 启动 Agno 备选验证并升级风险）；
2. AC-0.2.x 全部通过，隔离方案评审确认；
3. AC-0.3.x 通过；
4. 三份 ADR + freeze 的契约包入库；
5. Phase 1 的 requirements.md 根据 spike 结论修订完毕。
