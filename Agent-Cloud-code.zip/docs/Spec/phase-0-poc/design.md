# Phase 0 · PoC — Design

| 状态 | draft | 约束 | 全部代码放 `poc/` 目录，可抛弃；不建 CI、不做生产化配置 |
|---|---|---|---|

## 1. Spike 架构

```
poc/
├── s1-kernel/            # US-0.1：deepagents 能力验证脚本（每项一个可运行 demo）
│   ├── demo_todos.py         # TodoListMiddleware 显式 opt-in（F3）
│   ├── demo_skills.py        # skills/ 目录 + SkillsMiddleware 渐进加载
│   ├── demo_memory.py        # memory=[...] + CompositeBackend /memories/ 路由
│   ├── demo_subagents.py     # task 工具 + general-purpose 默认子代理
│   └── demo_hitl.py          # interrupt_on + checkpointer 中断/审批/恢复
├── s2-tenancy/           # US-0.2：租户包裹层 spike
│   ├── tenant_checkpointer.py    # 包裹 AsyncPostgresSaver，键前缀注入/校验
│   ├── tenant_store.py           # 包裹 PostgresStore，namespace 首段强制
│   ├── rls.sql                   -- RLS 策略原型
│   └── test_isolation_matrix.py  # 串租户矩阵测试
├── s3-sandbox/           # US-0.3：沙箱适配 spike
│   ├── sandbox_server.py         # 最小沙箱服务（docker SDK 起容器 + exec HTTP 接口）
│   ├── poc_sandbox_backend.py    # BaseSandbox 子类：execute → HTTP 调用沙箱服务
│   └── demo_execute.py           # Agent execute 工具端到端
└── s4-contract/          # US-0.4：契约骨架包（未来 agent-runtime 的 kernel/ 雏形）
    ├── kernel/spec.py            # AgentSpec/RunContext/RunEvent（shared/01 的代码化）
    ├── kernel/runner.py          # AgentRunner Protocol
    ├── harness/deepagents/runner.py  # DeepAgentsRunner 最小实现
    └── tests/contract/           # 契约测试套件雏形
```

## 2. 关键设计点

### 2.1 S1 验证矩阵（D08 §6.2 × 源码事实）

| 验证项 | 方法 | 通过判据 |
|---|---|---|
| 规划 | 显式传 `TodoListMiddleware`（0.7 起不在默认栈） | 长任务先出 todo 再执行 |
| 上下文管理 | 默认 SummarizationMiddleware + 大结果驱逐 | 超阈值工具结果落 backend，消息内留引用 |
| 子代理 | 声明式 SubAgent + `task` | 子代理隔离上下文，只回传最终报告 |
| HITL | `interrupt_on` + Postgres checkpointer | 中断→approve→恢复，状态无损 |
| 记忆/技能 | `memory=` + `skills=` + CompositeBackend | 跨 thread 记忆可见；skills 只读 |

### 2.2 S2 包裹层形态（spike 结论将直接进 Phase 1）

- `TenantScopedCheckpointer`：包装 `AsyncPostgresSaver`，所有 `get/put/list` 注入 `{tenant_id}::` 前缀并校验；无 ctx 抛 `MissingTenantContextError`；
- `TenantScopedStore`：包装 `PostgresStore`，`namespace[0]` 强制 = ctx.tenant_id；
- ctx 传递：spike 期用 contextvars；Phase 1 与 RunContext 合并；
- RLS：`current_setting('app.tenant_id')` 对比行 tenant_id，连接级 SET。

### 2.3 S3 沙箱适配（F4）

- 沙箱服务：最小 HTTP 接口 `POST /exec {command, timeout} → {output, exit_code}`，内部 docker SDK；
- 适配器：`class PocSandboxBackend(BaseSandbox)` 只实现 `execute` + `id`，文件操作全部继承 `BaseSandbox` 的 shell 实现——**验证对接面确实只有 execute**；
- 网络约束：容器 `--network` 隔离 + iptables 白名单 demo（AC-0.3.2）。

### 2.4 S4 契约骨架

- 以 shared/01 为蓝本生成 Pydantic 模型；`DeepAgentsRunner` 最小实现跑通 S1 的 demo 场景；
- contract test：给定同一 AgentSpec/输入，断言 Runner 输出事件序列满足协议（shared/04 §3 的雏形）；
- freeze 评审点：字段完备性（覆盖 D08 §6.2 全部行）、版本化策略、替换性验收方式。

## 3. ADR 模板（Q1/Q2/Q3 各一份）

```
# ADR-Qn: <标题>
状态: proposed → decided
背景 / 选项对比（含 PoC 实测数据）/ 决策 / 后果（正/负）/ 复审时点
```

- Q1 数据需求：FastAPI SSE 单机并发实测（目标 ≥500 并发流不劣化）；
- Q2 数据需求：S2 实测人日 vs LangGraph Enterprise 报价；
- Q3 数据需求：S3 冷启动耗时实测 + gVisor 环境可行性（运维输入）。

## 4. 风险

| 风险 | 缓解 |
|---|---|
| deepagents 0.7.x 文档与代码漂移 | 一切结论以源码 + 可运行 demo 为准，不引用旧文档 |
| spike 范围蔓延成生产代码 | 目录隔离 `poc/`；评审时逐文件确认"可抛弃"标记 |
