# Phase 1 · MVP — Requirements

| 状态 | draft | 周期 | ~12 周 | 上游 | D08 §18 P1；依赖 Phase 0 出口（契约 freeze + ADR Q1/Q2/Q3） |
|---|---|---|---|---|---|

## 1. 目标

交付一个**单租户试点可真实使用**的最小闭环：用户登录 → 创建会话 → 与 Agent 对话（含工具调用、沙箱执行、HITL 审批、长期记忆 L1）→ 用量可见。多租户基座（隔离、配额预检、审计基础）第一天内置，但企业级能力（RBAC 细粒度、灰度、计费账单）留到 Phase 2。

## 2. 范围

**In**：
1. `platform-api`（FastAPI 模块化单体，Q5 决策：gateway + control-plane 合并）：认证（dev OIDC/JWT）、租户/用户/Agent/版本/Session CRUD、配额预检（token 月配额单维度）、SSE 代理、审计基础（请求级落表）；
2. `agent-runtime`：runtime-api（内部）、DeepAgentsRunner、TenantFSBackend v1、TenantScopedCheckpointer/Store、EffectiveAgentSpec 拉取与缓存；
3. `mcp-gateway` 最小版：工具静态注册、按 ToolGrant 过滤、凭证注入（环境变量级，非 Vault）、风险标注、调用审计；
4. `sandbox-pool` v1：`allocate/exec/release`，单会话单沙箱，无热池；
5. 记忆 L1：用户记忆（`users/{uid}/memory/`）Agent 自编辑 + 组织记忆只读注入；
6. `web-console` 基础：登录、Agent 列表、对话 UI（SSE 渲染、todo/工具调用/审批交互）；
7. Langfuse 自托管接入（trace 带租户标签）；
8. 单机 docker-compose 部署形态（K8s 部署留 Phase 2）。

**Out**：RBAC/ABAC 细粒度、SSO 企业对接、灰度/回滚、账单导出、Skill 审核流、进化流水线、热池/多副本 HPA、Prompt 防火墙（仅留接口位）、IM。

## 3. 用户故事与验收标准

### US-1.1 租户与 Agent 管理（platform-api）
> 作为平台管理员，我要能创建租户、用户、Agent 定义与版本，并发布给租户使用。

- **AC-1.1.1** When 管理员经管理 API 创建 Tenant/User/AgentDefinition/AgentVersion，Then 数据落 shared/03 表结构，AgentVersion 不可变且 `spec_hash` 正确计算。
- **AC-1.1.2** When 创建 Release 指向某 AgentVersion（MVP 仅全量发布，rollout_pct=100），Then 该租户用户可对齐版本发起会话；未发布版本发起会话返回 `version_not_published`。
- **AC-1.1.3** When 客户端请求携带 `tenant_id`/`thread_id`/`sandbox_id` 字段，Then 返回 400（shared/02 §1.3）。

### US-1.2 会话与 Run（核心闭环）
> 作为终端用户，我要在控制台与 Agent 对话，看到流式输出、计划、工具调用过程。

- **AC-1.2.1** When `POST /v1/sessions` + `POST /v1/sessions/{id}/runs`，Then 返回 SSE 流，事件序列符合 shared/04 §3（run_started → token/todo/tool_call/tool_result → usage → done）。
- **AC-1.2.2** When run 执行中刷新页面/断线重连（Last-Event-ID），Then 会话状态可从 checkpoint 恢复，历史消息完整。
- **AC-1.2.3** When 同一会话发起多轮对话，Then Agent 记得本会话上下文（checkpointer 生效）。
- **AC-1.2.4** When `POST /v1/runs/{id}/cancel`，Then run 在下一个 checkpoint 边界停止，事件流收到 `done(cancelled)`，状态可查询。

### US-1.3 租户隔离（红线）
- **AC-1.3.1** 串租户矩阵测试全量通过（shared/02 §6：thread/store/TenantFS/Redis/对象存储五类资源互不可见）。
- **AC-1.3.2** When 租户 B 用户请求租户 A 的 session_id，Then 返回 404（不泄露存在性）。
- **AC-1.3.3** When runtime 任一请求缺失租户上下文，Then 抛错 fail-closed，无默认租户路径。

### US-1.4 工具与沙箱
> 作为 Agent，我要能调用被授权的工具并在沙箱里执行代码；未授权工具对我不可见。

- **AC-1.4.1** When AgentVersion 的 ToolGrant 只授权工具子集，Then Agent 可见工具恰好为该子集（MCP 网关过滤，F9）。
- **AC-1.4.2** When Agent 调用 `execute` 工具，Then 命令在该 (tenant, session) 的沙箱容器内执行，会话结束沙箱销毁；文件经 TenantFS workspace 路径持久。
- **AC-1.4.3** When 沙箱内发起非白名单出站请求，Then 失败并结构化返回（MVP 白名单 = mcp-gateway + 对象存储）。
- **AC-1.4.4** When 工具标注 `risk=high` 被调用，Then 触发 interrupt，SSE 收到 `interrupt` 事件；`approve` 后 run 恢复执行，`reject` 后工具调用以拒绝结果返回给模型（F5）。

### US-1.5 记忆 L1
- **AC-1.5.1** When 用户在会话中告知偏好，Then Agent 将记忆写入 `users/{uid}/memory/`；**新会话**中该记忆自动注入生效（跨 thread，StoreBackend 路由，F2）。
- **AC-1.5.2** When 管理员在 TenantFS `agents/{aid}/memory/` 预置组织记忆文件，Then 该 Agent 所有会话注入该记忆；Agent 运行时尝试写入该路径返回 `permission_denied`（shared/02 §3.3）。
- **AC-1.5.3** When Agent 尝试写 `skills/` 路径或 `..` 逃逸路径，Then 返回 `permission_denied`。

### US-1.6 配额与用量
- **AC-1.6.1** When 租户当月 token 用量达配额上限，Then 新 run 在首次 checkpoint 前被拒绝（`quota_exceeded`），进行中的 run 跑完不打断。
- **AC-1.6.2** When `GET /v1/usage?period=month`，Then 返回按 tenant/user/agent/model 维度的 token 用量（来源 `usage_records`，由 checkpointer 钩子写入）。

### US-1.7 可观测与审计
- **AC-1.7.1** When 完成一次 run，Then Langfuse 中存在完整 trace，标签含 `tenant_id/user_id/agent_id/version`；LLM 调用与 MCP 工具调用串联在同一 trace。
- **AC-1.7.2** When 任何 API 请求/工具调用发生，Then `audit_events` 表有对应记录（actor/action/resource/decision），MVP 提供 SQL 级查询即可。

### US-1.8 控制台
- **AC-1.8.1** When 用户登录控制台，Then 可见本租户已发布 Agent 列表，可创建会话、流式对话、查看 todo/工具过程、审批 HITL 中断、查看个人用量。

## 4. 出口验收（Exit Criteria）

1. AC-1.1 ~ AC-1.8 全部通过；
2. **1 个试点租户真实使用一周**：≥20 个真实会话，无 P0/P1 级缺陷，无串租户事件；
3. 试点反馈归档，形成 Phase 2 需求输入。
