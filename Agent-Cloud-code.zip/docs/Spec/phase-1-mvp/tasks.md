# Phase 1 · MVP — Tasks

| 状态 | draft | 周期 | ~12 周 | 前置 | Phase 0 出口全部通过 |
|---|---|---|---|---|---|

依赖关系：M1（基座）→ M2/M3 并行 → M4 → M5/M6 并行 → M7 联调 → M8 试点。

## M1 基座（第 1–2 周）

- [ ] **T1** 仓库结构初始化（monorepo：`services/platform-api`、`services/agent-runtime`、`services/mcp-gateway`、`services/sandbox-pool`、`web/`，共享 `packages/kernel`）；CI（lint/test/build）。覆盖：全部 AC 前置
- [ ] **T2** `packages/kernel`：Phase 0 freeze 契约迁入 + contract test 骨架。覆盖：AC-1.2.x 前置
- [ ] **T3** docker-compose 开发环境（PG×2库/Redis/MinIO/Keycloak/LiteLLM/Langfuse）+ shared/03 全量建表 + RLS 策略。覆盖：AC-1.1.1、AC-1.3.x 前置
- [ ] **T4** `tenancy/`：TenantScopedCheckpointer/Store 产品化（contextvars、fail-closed、RLS 连接注入）+ shared/02 §6 隔离测试基座。覆盖：AC-1.3.1、AC-1.3.3

## M2 platform-api（第 2–5 周）

- [ ] **T5** identity 模块：OIDC 登录、JWT 解析、租户上下文装配、客户端禁传字段拒绝。覆盖：AC-1.1.3、AC-1.3.2
- [ ] **T6** registry 模块：Tenant/User/AgentDefinition/AgentVersion CRUD + spec_hash 计算 + 不可变约束。覆盖：AC-1.1.1
- [ ] **T7** Release 全量发布 + 生效版本解析 + spec 缓存主动失效接口。覆盖：AC-1.1.2
- [ ] **T8** sessions 模块：Session 创建、thread_key 派生（`{tenant}::{uuid}`）、会话查询。覆盖：AC-1.2.1 前置
- [ ] **T9** quota 模块：Redis 月度计数预检 + `quota_exceeded` 拒绝路径。覆盖：AC-1.6.1（预检半）
- [ ] **T10** audit 模块：请求级审计异步落表（append-only）。覆盖：AC-1.7.2（请求半）
- [ ] **T11** runproxy 模块：SSE 代理 + 心跳 + Last-Event-ID 重连重放（Redis 缓存）。覆盖：AC-1.2.1、AC-1.2.2

## M3 agent-runtime（第 2–6 周，与 M2 并行）

- [ ] **T12** runtime_api：`/internal/runs`（SSE）、`/cancel`、`/approve`，内网身份头校验。覆盖：AC-1.2.1、AC-1.2.4、AC-1.4.4
- [ ] **T13** specclient：EffectiveAgentSpec 拉取、spec_hash 校验、内容哈希缓存、fail-closed。覆盖：AC-1.1.2（runtime 侧）
- [ ] **T14** TenantFSBackend v1：CompositeBackend 组合 + 占位符物化 + 白名单/逃逸防护 + skills/组织记忆只读。覆盖：AC-1.5.2、AC-1.5.3
- [ ] **T15** DeepAgentsRunner：装配链路（model/tools/subagents/skills/memory/permissions/interrupt_on）+ 事件桥（astream_events → RunEvent）。覆盖：AC-1.2.1、AC-1.2.3
- [ ] **T16** cancel/approve：task 取消 + `Command(resume=...)` 恢复。覆盖：AC-1.2.4、AC-1.4.4
- [ ] **T17** 配额记账钩子：checkpoint usage_metadata → usage_records + 首次 checkpoint 前超额拒绝。覆盖：AC-1.6.1（精确半）、AC-1.6.2 前置
- [ ] **T18** 记忆 L1：用户记忆读写路径 + memory_files 注入 + 跨会话生效验证。覆盖：AC-1.5.1

## M4 工具与沙箱（第 5–7 周）

- [ ] **T19** mcp-gateway：server 注册（配置驱动）、`tools/list` 按 ToolGrant 过滤、调用代理、凭证注入（env 级）。覆盖：AC-1.4.1
- [ ] **T20** risk 标注透传 → runtime interrupt_on 生成；调用审计落表。覆盖：AC-1.4.4（网关半）、AC-1.7.2（工具半）
- [ ] **T21** sandbox-pool v1：allocate/exec/release + 容器约束（caps/限额/TTL）+ egress 白名单。覆盖：AC-1.4.2、AC-1.4.3
- [ ] **T22** `TenantSandboxBackend(BaseSandbox)` 接入 runtime；`sandbox-exec` MCP server 包装（Agent 不直连沙池）。覆盖：AC-1.4.2

## M5 控制台（第 6–9 周，与 M4/M6 并行）

- [ ] **T23** 登录 + Agent 列表 + 会话列表页。覆盖：AC-1.8.1
- [ ] **T24** 对话页：SSE 渲染（token/todo/tool 卡片）、断线重连。覆盖：AC-1.8.1、AC-1.2.2（UI 侧）
- [ ] **T25** HITL 审批弹窗 + 个人用量页。覆盖：AC-1.4.4（UI 侧）、AC-1.8.1

## M6 可观测（第 7–8 周）

- [ ] **T26** OTel 埋点三服务 + 租户标签强制 + Langfuse 串联（LiteLLM callback + MCP 上下文传播）。覆盖：AC-1.7.1
- [ ] **T27** `GET /v1/usage` 聚合查询。覆盖：AC-1.6.2

## M7 端到端联调（第 9–10 周）

- [ ] **T28** 核心闭环 E2E 测试：登录→建会话→多轮对话→工具→沙箱→审批→记忆跨会话→用量入账。覆盖：AC-1.2.x/1.4.x/1.5.x/1.6.x
- [ ] **T29** 隔离红线回归：shared/02 §6 全矩阵（含 404 不泄露存在性）。覆盖：AC-1.3.x
- [ ] **T30** 故障演练：runtime 重启 run 恢复、sandbox 崩溃错误结构化、配额打满行为。覆盖：AC-1.2.2、AC-1.4.3、AC-1.6.1

## M8 试点（第 11–12 周）

- [ ] **T31** 试点租户数据初始化 + 1 个真实业务 Agent 上架（含 1 个技能 + 组织记忆 + 工具授权）。覆盖：出口 2
- [ ] **T32** 试点运行一周，缺陷分级处理；反馈归档 → Phase 2 requirements 修订输入。覆盖：出口 2、3

## 出口检查单

- [ ] AC-1.1.1 ~ AC-1.8.1 全部通过（T28/T29 为最终判定依据）
- [ ] 试点租户 ≥20 真实会话、无 P0/P1 遗留、零串租户事件
- [ ] Phase 2 spec 修订并 approved
