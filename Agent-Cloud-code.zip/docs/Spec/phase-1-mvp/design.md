# Phase 1 · MVP — Design

| 状态 | draft | 上游契约 | shared/01（freeze 版）、shared/02、shared/03、shared/04 |
|---|---|---|---|

## 1. 总体形态

Q5 决策落地：**gateway + control-plane 合并为 `platform-api` 模块化单体**（FastAPI），内部按模块分包，预留 Phase 2 拆缝。MVP 部署形态 = 单机 docker-compose（PG ×2 库、Redis、MinIO、Langfuse、platform-api、agent-runtime、mcp-gateway、sandbox-pool）。

```
浏览器(web-console)
   │ HTTPS/SSE
   ▼
platform-api (FastAPI 单体)
   ├── modules/identity      认证、租户上下文装配（shared/02 §1）
   ├── modules/registry      租户/用户/Agent/版本/Release CRUD（shared/03）
   ├── modules/sessions      Session 创建、thread_key 派生
   ├── modules/quota         配额预检（Redis 计数 + PG 账本对账）
   ├── modules/audit         请求级审计异步落表
   └── modules/runproxy      /v1/sessions/{id}/runs → agent-runtime SSE 代理 + 心跳 + Last-Event-ID
   │ 内网（X-Tenant-ID 等身份头）
   ▼
agent-runtime (FastAPI 薄层 + kernel)
   ├── runtime_api/          POST /internal/runs、/runs/{id}/cancel、/runs/{id}/approve
   ├── kernel/               ★ Phase 0 freeze 的契约包（spec/runner/context）
   ├── harness/deepagents/   DeepAgentsRunner：AgentSpec → create_deep_agent 参数装配
   ├── tenancy/              TenantScopedCheckpointer / TenantScopedStore（Phase 0 spike 产品化）
   ├── tenantfs/             TenantFSBackend（CompositeBackend 组合，shared/02 §3）
   └── specclient/           EffectiveAgentSpec 拉取 + 内容哈希缓存（TTL 5min，fail-closed）
   │
   ├──► mcp-gateway          工具发现/调用唯一出口（ToolGrant 过滤、凭证注入、风险标注、审计）
   │         └──► sandbox-pool    allocate/exec/release（docker SDK，MVP）
   ├──► model-gateway        MVP 直接 LiteLLM Proxy 容器（多模型路由/计量）
   ├──► PG(runtime 库)        checkpoints + store（RLS）
   └──► Langfuse             OTel trace（租户标签）
```

## 2. 关键设计

### 2.1 platform-api 模块化单体

- 模块间只允许经 service 层接口调用（禁跨模块 import DB 模型），为 Phase 2 拆分留缝；
- 认证：MVP 用内置 OIDC provider（Keycloak 容器）或 dev JWT issuer；签发 claims 含 `tenant_id/user_id/roles`；
- 配额预检：Redis `INCR` 月度计数 + PG `usage_records` 定时对账；精确扣减仍在 runtime 的 checkpoint 钩子（shared/02 §4.4）——预检是"快速拒绝"，钩子是"精确账本"；
- SSE 代理：流式透传 + 15s 心跳 + 事件 id 单调分配（支撑 Last-Event-ID 重连重放，重放缓存 Redis TTL 1h）。

### 2.2 EffectiveAgentSpec 解析链路

```
run 请求(agent_id)
  → platform-api 查当前生效 Release → agent_version_id（MVP 全量，无灰度）
  → agent-runtime specclient 按 version 拉 spec_jsonb
  → 装配 AgentSpec（shared/01）：
      tools: ToolGrant → mcp-gateway /internal/tools/list?grant=... 返回过滤后工具 schema
      skills: SkillRef → 对象存储 bundle 物化到 TenantFS skills/ 只读路径
      model: ModelRoute → LiteLLM 虚拟 key（按租户签发，计量维度 tenant+agent）
  → spec_hash 校验 == agent_versions.spec_hash（防篡改）
```

缓存：按 spec_hash 缓存（TTL 5min）；Release 变更时 platform-api 主动调 runtime `/internal/spec-cache/invalidate`。拉取失败 → run 拒绝（fail-closed）。

### 2.3 DeepAgentsRunner 装配（shared/01 §2 的实现侧）

```python
graph = create_deep_agent(
    model=litellm_chat_model(spec.model, tenant_virtual_key),
    tools=mcp_tools,                      # langchain-mcp-adapters → mcp-gateway，已按 grant 过滤
    system_prompt=spec.system_prompt,
    middleware=[TodoListMiddleware()],    # F3：显式 opt-in
    subagents=[to_subagent(s) for s in spec.subagents],
    skills=mounted_skill_paths,           # TenantFS 物化路径
    memory=spec.memory_files,             # 组织记忆 + 用户记忆 AGENTS.md 路径
    permissions=fs_permissions,           # skills 只读 + 白名单（shared/02 §3）
    interrupt_on=hitl_config,             # 来自 MCP 网关 risk 标注
    checkpointer=TenantScopedCheckpointer(pg_pool, ctx),
    store=TenantScopedStore(pg_pool, ctx),
    backend=TenantFSBackend(ctx, s3, redis),   # CompositeBackend 组合（F2）
)
```

- RunContext 经 contextvars 贯穿：runtime_api 入口从身份头构建 → runner → checkpointer/store/backend 全部从 ctx 取租户（shared/02 §1.4 fail-closed）；
- 事件桥：graph `astream_events` → 映射为 shared/04 §3 RunEvent（token/tool/todo/interrupt/usage）；
- cancel：asyncio task 取消 + `PatchToolCallsMiddleware` 保证历史合法（deepagents 内置）；
- approve：`resume` 经 `Command(resume=decision)` 恢复中断点。

### 2.4 TenantFSBackend v1（组合实现，F2/F7）

```
CompositeBackend(
  default = DenyBackend(),                       # 白名单制：未路由即拒绝
  routes = {
    "/tenants/{t}/agents/{a}/skills/":  ReadOnly(S3Backend(bundle 物化目录)),
    "/tenants/{t}/agents/{a}/memory/":  ReadOnly(StoreBackend(ns=[t,"memories","agents",a])),
    "/tenants/{t}/users/{u}/memory/":   StoreBackend(ns=[t,"memories","users",u]),      # 读写
    "/sessions/{s}/workspace/":         WorkspaceBackend(MinIO + Redis 热缓存),          # 读写
  })
```

- 占位符 `{t}/{u}/{a}/{s}` 在 run 启动时由 RunContext 物化，**禁止来自用户输入**；
- 路径规范化 + `..` 拒绝 + 前缀白名单（对齐 deepagents `virtual_mode` 语义）；
- run 结束：workspace 变更集回写 MinIO；用户记忆变更直接落 Store（版本 = namespace 下条目 + updated_at，进化平面后续消费）。

### 2.5 mcp-gateway 最小版

- 配置驱动：`mcp_servers` 表 + 启动加载；下游适配 = streamable HTTP 连接各 MCP server（MVP 内置 2 个示例 server：`filesystem-tools`、`sandbox-exec`——后者代理 sandbox-pool，**Agent 不直连沙池**，D08 §9.2）；
- 治理四件事（MVP 范围）：ToolGrant 过滤、凭证注入（server 级 env，后续换 Vault）、`risk` 标注透传（驱动 interrupt_on）、调用审计（args 摘要/结果摘要/耗时 → audit_events）。

### 2.6 sandbox-pool v1

- API：`POST /allocate {tenant, session, image}` → sandbox_id；`POST /{id}/exec {command, timeout}`；`POST /{id}/release`；
- 实现：docker SDK 起容器（MVP 宿主机 docker；gVisor runsc 留 Phase 2），约束：drop ALL caps、no-new-privileges、CPU/内存限额、egress 白名单（iptables 或 docker 内部网络 + 代理）、TTL 看门狗（会话结束/超时自动 release）；
- runtime 侧适配：`TenantSandboxBackend(BaseSandbox)` 实现 `execute`→ sandbox-pool `/exec`（F4，Phase 0 S3 产品化）。

### 2.7 记忆 L1 数据流

- 用户记忆：Agent 经文件工具自编辑 `users/{u}/memory/*.md`；`memory_files` 将该路径 AGENTS.md 注入 prompt（MemoryMiddleware）；
- 组织记忆：管理员经控制台上传/编辑（platform-api 直写 Store namespace），Agent 只读；
- **写回与版本**：MVP 仅记录 Store 条目变更日志（audit），git 式版本 DAG 留 Phase 3 进化平面。

### 2.8 控制台（Next.js）

页面：登录（OIDC 跳转）、Agent 列表、会话列表、对话页（SSE 渲染 token 流、todo 面板、tool_call 折叠卡、interrupt 审批弹窗）、个人用量页。调 `/v1` API，不直连内部服务。

### 2.9 可观测

- OTel SDK 埋点：platform-api / agent-runtime / mcp-gateway；trace 标签强制 `tenant_id/user_id/agent_id/version`（D08 §16）；
- Langfuse docker-compose 自托管；LLM 调用经 LiteLLM 的 Langfuse callback 接入，MCP 调用经 trace 上下文传播串联。

## 3. 部署（docker-compose）

服务：`postgres`（两库：platform / runtime）、`redis`、`minio`、`keycloak`、`litellm`、`langfuse`、`platform-api`、`agent-runtime`、`mcp-gateway`、`sandbox-pool`、`web-console`。沙箱容器与 compose 同宿主机 docker daemon（MVP 接受此信任边界，文档明示，Phase 2 改 runsc）。

## 4. 关键风险与缓解（本阶段）

| 风险 | 缓解 |
|---|---|
| SSE 代理在高并发下成为瓶颈 | MVP 单租户试点量级可控；Q1 ADR 已留 Go 拆分缝 |
| StoreBackend 大文件不适合 | 记忆文件限定 ≤64KB，超出引导写 workspace（对象存储） |
| docker 沙箱隔离弱 | 仅试点租户 + 工具白名单 + 断网；文档明示信任边界 |
| spec 拉取 fail-closed 导致可用性敏感 | 内容哈希缓存 + 主动失效；platform-api 与 runtime 同 compose 网络 |

## 5. 留缝清单（Phase 2/3 接入点，本阶段不做但不堵死）

- platform-api 模块边界 → 微服务拆分；
- Release.rollout_pct 字段已在表结构 → 灰度；
- mcp-gateway 凭证注入点 → Vault/KMS；
- sandbox-pool API 与 runtimeclass 无关 → runsc/Firecracker 替换；
- TenantFS 变更集日志 → 进化平面消费；
- audit_events append-only 设计 → 审计检索 API。
