# Phase 2 · 企业化 — Design

| 状态 | draft | 上游契约 | shared/01–04（不变更则沿用；本阶段允许向后兼容演进） |
|---|---|---|---|

## 1. 服务拆分（落地 D08 §2.1）

按 Phase 1 预留的模块缝拆分：

```
api-gateway      ← 从 platform-api 拆出：认证/上下文装配/限流/Prompt 防火墙/SSE 代理/审计写入
                   （语言按 ADR-Q1：FastAPI 平迁 或 Go 重写）
control-plane    ← 从 platform-api 拆出：registry/quota/billing/audit/release/eval 管理 API
agent-runtime    ← 无状态多副本（HPA）
mcp-gateway      ← 凭证源切换到 Vault/KMS
sandbox-pool     ← runsc RuntimeClass + 热池控制器
evolution-worker ← 本阶段仅承担"评测执行器"角色（进化流水线 Phase 3 启用）
model-gateway    ← LiteLLM Proxy（HA 部署）
web-console      ← 增加审计/配额/评测/发布页
```

拆分纪律：共享/03 数据模型不变；platform-api 模块代码平移，先合库后按表 ownership 分库（control-plane 库 / runtime 库本就物理分离）。

## 2. 权限设计

- **RBAC**：`roles` 预置 5 角色，权限 = 资源 × 动作矩阵（表驱动，`role_permissions` 配置化而非硬编码）；`user_roles` 支持绑定到 Organization 节点（部门管理员作用域 = 子树）；
- **ABAC**：规则 DSL（JSON：subject attrs × resource attrs × env attrs → allow/deny），控制平面编译为 scope 集合，签发进 JWT（短 TTL 10min + refresh）；网关在上下文装配时展开 scope 做端点级判定；数据级判定（如"仅本部门 Agent"）下推 control-plane 查询层（SQL WHERE 注入 org 子树条件）；
- **SSO**：OIDC generic 连接器（每租户可配 IdP）；`users.external_sub` 映射；SCIM  provisioning 留接口位（本阶段手工/CSV 同步）。

## 3. 配额计费

- **维度**：`quotas(tenant_id, metric, limit, period)`，metric ∈ `tokens_month / concurrent_runs / kb_storage_bytes / tool_calls_month`；
- **预检**（gateway，快速拒绝）：Redis 计数器（token 月度、并发 run 集合、工具调用月度）；
- **精确账本**（runtime 钩子 → `usage_records`）：checkpoint usage_metadata 抽取；并发 run 用 Redis 租约（run 开始 acquire/结束 release，崩溃由 TTL 兜底）；
- **对账**：每日 job 校准 Redis vs PG 漂移 >1% 告警；账单导出 = `usage_records` 聚合 + 定价表（控制平面可配）。

## 4. K8s 生产化

- 命名空间与 NetworkPolicy 按 D08 §14；Helm chart 全量化（每服务一 chart + umbrella）；
- HPA：agent-runtime 暴露 `active_runs`/`run_queue_depth` 自定义指标（Prometheus adapter），target = 每副本 N 并发 run（N 经压测定，初始 10）；
- 高等级租户硬隔离：`tenant-<id>` 命名空间模板化（terraform/helm 参数化创建）。

## 5. 沙箱池生产化

```
sandbox-pool 控制器
├── PoolManager：按 (镜像, 租户等级) 维护热池（min_idle 预热，runsc RuntimeClass）
├── Allocator：allocate(tenant, session, image) → 热池取/冷起；p95 <2s（AC-2.4.2）
├── SessionBinder：会话内复用；release 时销毁 rootfs，workspace PV 按策略保留
└── Guardrails：egress 白名单（NetworkPolicy + egress proxy）、资源限额、TTL 看门狗
```

- 镜像：基础镜像（python/node/常用 CLI）+ 租户自定义镜像（registry 审核后入池）；
- Firecracker 档：仅接口预留（`SandboxDriver` 抽象：docker(弃)/runsc/firecracker），本阶段不实现。

## 6. 评测基础设施 v1

```
eval-runner（evolution-worker 角色之一，K8s Job 执行）
  输入：EvalDataset + AgentVersion(spec_hash)
  执行：隔离命名空间起临时 runtime 实例（专用 Langfuse project = 评测通道物理隔离，D08 §10.2）
       逐 case 回放 → 评估器打分（代码评估器 | LLM-as-judge | 人工队列）
  输出：eval_scores（二元 pass/fail）+ eval_runs.summary
```

- 低分 trace 转化：Langfuse API 拉取 score<阈值 的 trace → 脱敏 → 人工确认 → 入 dataset；
- LLM-as-judge：校准集机制（人工标注 100 条基准，judge 一致率 ≥85% 才允许用于门控）。

## 7. 灰度发布与回滚

- **分桶**：`hash(user_id, release_id) % 100 < rollout_pct` 命中新版本；解析点在 control-plane「生效版本解析」接口（Phase 1 的 T7 扩展）；
- **观察**：Langfuse 按 `release_id` 标签对比通过率/成本/延迟；达标手工/自动全量（v1 手工确认）；
- **回滚**：Release status 指针回拨 + spec 缓存主动失效 → 秒级生效（新会话）；
- **血统**：`agent_versions` + `releases` + `eval_runs` 关联查询即得（Phase 3 接入 evolution_candidates 后自动延伸）。

## 8. 安全加固

- Prompt 防火墙：LLM Guard 自托管 sidecar 于 gateway；标记模式（事件打 `prompt_flagged` 标签 + 审计），不拦截；
- 输出敏感信息检测：run 结束异步扫描（PII/凭证正则 + 分类器），命中打标告警；
- Vault：mcp-gateway 经 k8s service account 取短期凭证，按租户注入下游调用；
- 渗透测试：范围 = 五类隔离面（shared/02 §6 矩阵的攻击版）+ 沙箱逃逸 + SSRF。

## 9. 风险（本阶段）

| 风险 | 缓解 |
|---|---|
| 单体拆分引入回归 | 先拆包后拆服务；E2E 套件（Phase 1 T28）全程绿灯才切换流量 |
| runsc 与 GPU/特殊依赖兼容 | 基础镜像白名单制；不兼容场景回退独立节点池 |
| ABAC 规则复杂度失控 | DSL 限定字段集与操作符；规则数 >20 触发架构评审 |
| LLM-as-judge 不稳定 | 校准集门槛 + 评测通道隔离 + 二元分数 |
