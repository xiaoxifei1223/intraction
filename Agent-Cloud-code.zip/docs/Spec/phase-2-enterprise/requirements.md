# Phase 2 · 企业化 — Requirements

| 状态 | draft | 周期 | ~12 周 | 上游 | D08 §18 P2；依赖 Phase 1 出口（试点通过） |
|---|---|---|---|---|---|

## 1. 目标

从"试点可用"到"**生产可售**"：权限体系（RBAC/ABAC + SSO）、完整配额计费与审计、K8s 生产部署（含 gVisor 沙箱池）、评测基础设施与门控 v1、灰度/回滚发布。

## 2. 范围

**In**：
1. RBAC（5 预置角色）+ ABAC 规则编译 scope 签发进 JWT（D08 §5.1）；企业 SSO/OIDC 对接；
2. 配额计费完整版：多维度配额（tokens/月、并发 run、知识库存储、工具调用次数）、usage 账本、账单导出；
3. 审计检索 API + 控制台审计页；
4. K8s 生产部署：D08 §14 命名空间划分、NetworkPolicy、HPA（自定义指标）、服务间 mTLS（Istio/Linkerd 择一）；
5. sandbox-pool 生产化：gVisor(runsc) RuntimeClass、热池预热（冷启动 <2s 分配）、按租户等级分池；
6. 评测基础设施 v1：EvalDataset/Case 管理、代码评估器 + LLM-as-judge、EvalRun 离线执行；
7. 发布管理：灰度（按租户/用户百分比）+ 一键回滚 + 版本血统查询；
8. Prompt 防火墙上线（LLM Guard 自托管，标记模式）；输出敏感信息检测（标记模式）；
9. 平台拆分：platform-api 按预留模块缝拆出 `control-plane` 与 `api-gateway`（若 Q1 ADR 决策 Go 则网关此时重写）。

**Out**：Skill 审核流完整状态机、进化流水线自动化、IM 集成、A2A、多区域。

## 3. 用户故事与验收标准

### US-2.1 权限与 SSO
> 作为租户管理员，我要按组织树分配角色，控制谁能用/能开发/能发布 Agent。

- **AC-2.1.1** When 配置 RBAC 角色绑定（平台超管/租户管理员/部门管理员/Agent 开发者/普通用户），Then 各角色对 `/v1` 与 `/v1/admin` 端点的访问矩阵与权限表一致（测试全覆盖）。
- **AC-2.1.2** When 配置 ABAC 规则（如"仅工作时间""仅本部门 Agent"），Then 规则编译为 scope 签发进 JWT，越权请求被 403 且审计留痕。
- **AC-2.1.3** When 对接企业 IdP（OIDC），Then 用户经 SSO 登录，external_sub 映射到 users 表，禁用 IdP 侧账号后 5 分钟内平台会话失效。

### US-2.2 配额计费
- **AC-2.2.1** When 配置四维配额（tokens/月、并发 run、知识库存储、工具调用次数），Then 任一维度超额即拒绝对应新请求并返回 `quota_exceeded`，进行中的 run 不打断。
- **AC-2.2.2** When 并发 run 配额=3 的租户发起第 4 个并发 run，Then 排队或拒绝（行为可配置），已在运行的不受影响。
- **AC-2.2.3** When 导出月度账单（CSV），Then 按 tenant/user/agent/model 维度与 `usage_records` 对账一致（误差 <0.1%）。

### US-2.3 审计
- **AC-2.3.1** When 经 `GET /v1/audit` 按时间/actor/action/resource 组合检索，Then 结果与 audit_events 一致；审计流 append-only（DB 层拒绝 UPDATE/DELETE）。

### US-2.4 生产部署与沙箱生产化
- **AC-2.4.1** When 部署到 K8s（D08 §14 命名空间），Then NetworkPolicy 生效：sandbox 命名空间 egress 仅通 mcp-gateway 与对象存储；agent-runtime 仅接受 gateway 流量（渗透式验证）。
- **AC-2.4.2** When 沙箱池热池预热运行中，Then 沙箱分配 p95 <2s；会话沙箱复用；会话结束 rootfs 销毁。
- **AC-2.4.3** When run 并发上升，Then HPA 按自定义指标（run 并发数/队列深度）扩容 agent-runtime 副本，扩容期间无 run 丢失（checkpoint 恢复）。
- **AC-2.4.4** When 高等级租户开通硬隔离档，Then 其 runtime + 沙箱落入专属 `tenant-<id>` 命名空间。

### US-2.5 评测基础设施 v1
> 作为 Agent 开发者，我要给 Agent 建评测集并跑回归，作为发布与后续进化的质量门。

- **AC-2.5.1** When 创建 EvalDataset（人工录入 + 从 Langfuse 低分 trace 转化），Then case 含 input 与期望（确定性断言或 judge rubric）。
- **AC-2.5.2** When 对某 AgentVersion 发起 EvalRun，Then 系统在隔离环境回放全部 case，产出二元 pass/fail 分数与汇总报告；评测通道与生产 trace 通道物理隔离（独立 Langfuse project）。
- **AC-2.5.3** LLM-as-judge 评估器上线前经人工校准集验证（一致率 ≥85% 方可用）。

### US-2.6 灰度与回滚
- **AC-2.6.1** When 创建 Release（rollout_pct=5%，按用户哈希分桶），Then 命中桶的会话使用新版本，其余用旧版本；Langfuse 可按 release_id 对比指标。
- **AC-2.6.2** When 触发回滚，Then Release 指针秒级回拨，新会话立即恢复旧版本，进行中的 run 不受影响。
- **AC-2.6.3** When 查询某 Agent 版本血统，Then 可列出"版本 ← 来源（人工编辑/评测通过）→ 哪些 Release 引用过"完整链。

### US-2.7 安全加固
- **AC-2.7.1** Prompt 防火墙：注入攻击样本集（≥50 条）标记率 ≥90%，误标率 <5%（标记不拦截，控制台可见标记事件）。
- **AC-2.7.2** 服务间 mTLS 全量开启；凭证迁移至 Vault/KMS（mcp-gateway 运行时注入，D08 §8.2）。
- **AC-2.7.3** 完成一次第三方/内部租户隔离渗透测试，高危项清零（D08 §15）。

## 4. 出口验收（Exit Criteria）

1. AC-2.1 ~ AC-2.7 全部通过；
2. 生产环境承载 ≥3 个付费/准付费租户两周无 P0；
3. 渗透测试报告归档、SOC2 对照项（D08 §15 审计行）自评完成；
4. Phase 3 spec 修订并 approved。
