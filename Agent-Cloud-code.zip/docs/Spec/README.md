# DeepAgents Cloud — Spec 开发总览

| 项 | 值 |
|---|---|
| 状态 | Draft v0.1（待评审） |
| 日期 | 2026-08-09 |
| 上游基准 | [docs/08-DeepAgents-Cloud-Agent-系统设计.md](../08-DeepAgents-Cloud-Agent-系统设计.md)（架构基准，下称 **D08**） |
| 内核基线 | `deepagents==0.7.x`（锁版本，季度评估升级，见 D08 §19 Q6） |

## 1. 本目录是什么

D08 是**架构层面的设计基准**；本目录把 D08 拆成**可执行的阶段化 Spec**，采用 Spec-Driven Development（SDD）模式：

```
D08（架构基准）
  └── docs/Spec/
        ├── shared/          # 跨阶段全局契约（所有阶段 spec 的公共前提）
        ├── phase-0-poc/     # 验证与决策
        ├── phase-1-mvp/     # 最小可用产品
        ├── phase-2-enterprise/  # 企业化
        ├── phase-3-platform/    # 平台化（进化闭环）
        └── phase-4-evolution/   # 持续演进（占位）
```

**冲突仲裁**：Spec 与 D08 冲突时，以实现期的 Spec 为准，但必须回写修订 D08，保持基准不过期。

## 2. Spec 开发流程（每个阶段/特性都一样）

每个 phase 目录固定三件套：

| 文件 | 内容 | 门禁 |
|---|---|---|
| `requirements.md` | 目标、范围（In/Out）、用户故事 + 验收标准（可测试的 When/Then） | **评审通过才允许写代码** |
| `design.md` | 技术设计：组件、接口、数据、关键决策（引用 shared/ 契约） | 评审通过才允许拆任务 |
| `tasks.md` | 编号任务清单（可勾选），每个任务映射到验收标准编号 | 全部完成 + 验收通过 = 阶段完成 |

约定：

1. **顺序**：requirements → design → tasks → 实现 → 验收，每步有显式评审点；允许回退修改，但不允许跳步。
2. **可追溯**：任务编号 `T<n>`，验收标准编号 `AC-<phase>.<n>`，任务必须标注覆盖哪些 AC。
3. **状态机**：`draft → approved → in-progress → done`，标注在每个文件头部。
4. **最小改动**：实现只做 tasks.md 里列出的事，新增需求先改 spec 再改代码。
5. **阶段门禁**：下一阶段启动前，上一阶段的"出口验收"（Exit Criteria）必须全部通过。

## 3. 阶段地图与依赖

```
Phase 0 (PoC, 2–3 周)          Phase 1 (MVP, ~12 周)         Phase 2 (企业化, ~12 周)      Phase 3 (平台化, ~16 周)
┌─────────────────────┐      ┌────────────────────────┐    ┌────────────────────────┐   ┌────────────────────────┐
│ S1 内核能力验证       │      │ platform-api 模块化单体  │    │ RBAC/ABAC + SSO        │   │ Skill Registry + 审核流 │
│ S2 租户包裹层 spike   │      │ agent-runtime 打通      │ ─▶ │ 配额计费 + 审计查询      │ ─▶ │ 进化流水线 L1 半自动     │
│ S3 沙箱 execute 打通  │      │ TenantFS + 记忆 L1      │    │ 沙箱池生产化 (gVisor)   │   │ L2/L3 灰度发布          │
│ S4 抽象层契约 freeze  │      │ MCP 网关最小版           │    │ 评测基础设施 + 门控 v1   │   │ IM 集成 / A2A           │
│ → 决策: Q1/Q2/Q3     │      │ 控制台基础 + Langfuse    │    │ 灰度/回滚发布           │   │                        │
└─────────────────────┘      └────────────────────────┘    └────────────────────────┘   └────────────────────────┘
  出口: 五项验证清单            出口: 1 个试点租户真实使用       出口: 生产可用、首批签约         出口: 商业化闭环
```

关键路径：`S2 租户包裹层 → agent-runtime → 沙箱/配额生产化 → 进化流水线`。内核抽象层契约（shared/01）在 Phase 0 结束时 freeze，之后所有阶段只准向后兼容地演进。

与 D08 §18 里程碑一一对应（P0–P4），本目录是其可执行化。

## 4. 基于源码调研的关键事实（影响所有 spec）

调研 `langchain-ai/deepagents@main`（release 0.7.5）后确认，以下事实已写入各 spec，实现时不得违反：

| # | 事实 | 影响 |
|---|---|---|
| F1 | `create_deep_agent(...)` 返回标准 `CompiledStateGraph`；`checkpointer`/`store`/`cache` 透传 | 租户包裹层 = 给这两个参数包一层租户作用域实现，无需 fork |
| F2 | `CompositeBackend(default=..., routes={...})` 按路径前缀路由 backend；`StoreBackend` 的 `namespace` 工厂是官方多租户隔离点 | `TenantFSBackend` 用**组合**实现（对象存储路由 + Store 路由），不从零实现 `BackendProtocol` |
| F3 | **0.7.0 breaking**：`TodoListMiddleware`/`write_todos` 移出默认栈，需显式传入；`FilesystemMiddleware`/`SubAgentMiddleware` 为核心受保护件 | 规划能力在 spec 中显式声明为 opt-in middleware |
| F4 | 沙箱对接面 = `SandboxBackendProtocol`（`id` + `execute`），`BaseSandbox` 已用 shell 实现全部文件操作 | sandbox-pool 对内核只暴露一个 `execute` 适配器；partners/ 包（daytona/modal/runloop）是参考实现 |
| F5 | `FilesystemPermission`（allow/deny/interrupt）+ `interrupt_on` 自动生成 HITL | 高危工具审批链路直接复用，无需自研中断机制 |
| F6 | `deepagents-cli` 的声明式布局：`agent.json + AGENTS.md + tools.json + skills/ + subagents/` | 作为 `AgentSpec`/Skill 包格式的设计蓝本 |
| F7 | `StateBackend` 文件随 checkpointer 持久化但**跨线程不共享**；`FilesystemBackend` 官方明示不适合多租户 | 会话工作区与长期记忆必须走 `StoreBackend`/自研路由，禁止裸用 `FilesystemBackend` |
| F8 | `DeepAgentState` 的 `messages` 用 `DeltaChannel`（checkpoint 增长 O(N)） | 自定义 state 必须继承 `DeepAgentState`，不得绕开 |
| F9 | 官方安全模型是 "trust the LLM"，边界须在 tool/sandbox 层强制 | 与 D08 原则 P4 一致：所有授权在 MCP 网关/backend 层执行 |

## 5. 阶段状态追踪

| 阶段 | requirements | design | tasks | 实现 | 出口验收 |
|---|---|---|---|---|---|
| Phase 0 PoC | draft | draft | draft | — | — |
| Phase 1 MVP | draft | draft | draft | — | — |
| Phase 2 企业化 | draft | draft | draft | — | — |
| Phase 3 平台化 | draft | draft | draft | — | — |
| Phase 4 演进 | placeholder | — | — | — | — |

## 6. 待评审决策项（Phase 0 出口必须关闭）

沿用 D08 §19，spec 化如下：

| # | 决策 | 当前倾向 | 关闭时点 |
|---|---|---|---|
| Q1 | 网关语言：Go vs FastAPI | FastAPI（与 runtime 同栈） | Phase 0 出口 |
| Q2 | LangGraph Enterprise vs 纯 OSS 自研包裹层 | 纯 OSS 自研（2–3 人周估） | Phase 0 出口（报价对比后） |
| Q3 | 沙箱首版：gVisor vs E2B 托管/自托管 | gVisor on K8s | Phase 0 出口 |
| Q5 | gateway + control-plane 合并为模块化单体 | **采纳，合并为 `platform-api`** | 本 spec 已按合并编写 |
