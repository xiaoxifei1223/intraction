# Phase 3 · 平台化 — Requirements

| 状态 | draft | 周期 | ~16 周 | 上游 | D08 §18 P3、§10；依赖 Phase 2 出口（评测门控 + 灰度发布就绪） |
|---|---|---|---|---|---|

## 1. 目标

交付**差异化核心**（D08 §10）：Skill Registry 完整生命周期 + 进化流水线（L1 半自动、L2/L3 灰度）——让 Agent 的记忆、技能、Prompt 在"评测门控 + 灰度 + 可回滚"的受控流水线下持续进化；同时完成 IM 渠道与 A2A 开放协同。

## 2. 范围

**In**：
1. Skill Registry：Skill 包格式（manifest + 文件集，参照 deepagents `skills/<name>/SKILL.md` 布局，F6）、版本化存储、审核状态机（draft→scanning→review→published→deprecated）、安全扫描（静态 + 沙箱试跑）；
2. 进化流水线（evolution-worker 完整版）：失败模式挖掘 → 候选生成（L1 记忆/L2 技能/L3 Prompt-Profile）→ 沙箱回放验证 → 评测门控 → 审核（L2/L3 强制人工，L1 可配置）→ 灰度发布 → 归档；
3. 进化产物文件化与血统：全部产物 = 文件变更集，git 式 DAG 血统（D08 §10.2）；
4. 进化预算：按租户月度 token 上限，超预算自动暂停；
5. IM 集成：飞书/企微/Teams 至少其一（消息 ↔ 会话桥接，复用 Open API）；
6. A2A：Agent 以 A2A Server 暴露，跨系统调用经网关治理（租户授权 + 计量）。

**Out**：L4（Agent 改自身代码，仅研究环境）、多区域部署、Agent 市场/商业化分发。

## 3. 用户故事与验收标准

### US-3.1 Skill Registry
> 作为 Agent 开发者，我要把可复用能力封装为 Skill 包，经审核后发布给租户内 Agent 使用。

- **AC-3.1.1** When 上传 Skill 包（manifest.yaml：名称/描述/工具依赖/风险等级 + SKILL.md + 资源文件），Then 包校验通过入对象存储，元数据入 `skill_versions`（hash 寻址）。
- **AC-3.1.2** When 提交审核，Then 状态机按 draft→scanning（自动静态扫描 + 沙箱试跑）→review（人工）→published 流转，每步留痕；扫描发现高危（网络外联/凭证读取模式）自动驳回。
- **AC-3.1.3** When AgentVersion 引用某 Skill 版本，Then 运行时 TenantFS `skills/` 物化的恰为该版本内容（hash 校验）；引用 deprecated 版本的新发布被拒绝。
- **AC-3.1.4** 运行时 Agent 写 skills 路径仍被拒绝（shared/02 §3.2 回归）。

### US-3.2 进化流水线
> 作为租户管理员，我要系统从低分会话中自动发现改进点，以受控方式让 Agent 变好，且每一步可审、可退。

- **AC-3.2.1** When evolution-worker 对生产 trace（低分聚类）执行失败模式挖掘，Then 产出带证据（trace 引用列表）的改进机会清单；挖掘任务本身经 model-gateway 计量并扣进化预算。
- **AC-3.2.2** When 生成 EvolutionCandidate（L1 记忆条目 / L2 Skill diff / L3 Prompt diff），Then 产物为文件变更集（diff_uri），血统 DAG 记录父版本。
- **AC-3.2.3** When 候选进入验证，Then 依次通过：沙箱回放（历史输入重跑不崩溃）→ 评测门控（EvalDataset 回归，二元判定，不劣于基线）→ 审核（L2/L3 强制人工；L1 按租户配置自动或人工一键采纳，Q4 默认人工）；任一环节失败候选终止并留因。
- **AC-3.2.4** When 候选批准，Then 自动生成新版本 + Release（默认 5% 灰度，复用 Phase 2 发布链路），观察窗指标达标后人工确认全量；不达标一键回滚。
- **AC-3.2.5** When 租户进化预算（月度 token）耗尽，Then 该租户进化任务自动暂停并通知；生产对话不受影响。
- **AC-3.2.6** 防 reward hacking：评测通道与生成通道物理隔离回归（独立 Langfuse project、独立评测数据访问凭证）；生成侧代码无评测集读取权限（IaC 层保证）。

### US-3.3 IM 集成
- **AC-3.3.1** When 租户配置 IM 渠道（飞书或企微），Then 用户在 IM 中对话自动映射到平台 Session（同 IM 线程 = 同 session），流式回复以消息更新呈现；HITL 审批以卡片交互完成。

### US-3.4 A2A 开放协同
- **AC-3.4.1** When Agent 开启 A2A 暴露，Then 生成标准 Agent Card（能力/端点/认证方式）；外部系统调用经网关认证 + 租户授权 + 计量，事件计入同一 trace。

## 4. 出口验收（Exit Criteria）

1. AC-3.1 ~ AC-3.4 全部通过；
2. **进化闭环实证**：试点租户至少 1 个 L1 与 1 个 L2 候选完整走通"挖掘→门控→灰度→全量"，且评测分数提升可量化；
3. 至少 1 个 IM 渠道在生产租户日常使用；
4. Phase 4 演进规划评审。
