# Phase 3 · 平台化 — Design

| 状态 | draft | 上游契约 | shared/01–04；复用 Phase 2 的评测与发布链路 |
|---|---|---|---|

## 1. Skill Registry

```
skill bundle（对象存储，hash 寻址）
├── manifest.yaml    # name/description/version/risk_level/tool_dependencies/entry
├── SKILL.md         # 技能说明（deepagents SkillsMiddleware 渐进披露格式，F6）
└── resources/...    # 脚本、模板等
```

- **审核流水线**：upload → scanning（静态规则：危险 API/网络外联/凭证读取模式 + 沙箱试跑冒烟）→ review（控制台人工）→ published；deprecated 不可逆；
- **运行时物化**：specclient 解析 SkillRef → 下载 bundle → 校验 hash → 挂载 TenantFS `skills/` 只读路由（Phase 1 T14 的完整版）；
- **工具依赖声明**：manifest 声明所需 MCP 工具，发布校验与 ToolGrant 求交，缺授权时发布阻断并提示。

## 2. 进化流水线（D08 §10.1 实现版）

```
[挖掘]  Langfuse 低分 trace（score<阈值）→ 聚类（embedding + LLM 归纳）→ 失败模式清单（带证据）
   │
[生成]  LLM 生成候选 diff（L1 memory 条目 / L2 skill 修订或新增 / L3 prompt/profile 修订）
   │     产物 = 文件变更集，写对象存储 diff_uri；evolution_candidates 记录 kind/parent/hash
   │
[验证]  沙箱回放：候选应用到隔离环境，重放失败 case 输入 → 不崩溃且输出改善
   │
[门控]  eval-runner 全量回归（Phase 2 M5）：二元判定，pass_rate ≥ 基线 且 无新增高危失败
   │
[审核]  L2/L3 强制人工（控制台 diff 视图）；L1 按租户策略（默认人工一键采纳）
   │
[发布]  生成新版本 → Release 5% → 观察窗（通过率/成本/延迟，Langfuse release_id 对比）→ 全量或回滚
   │
[归档]  全部版本 + 血统 DAG 入对象存储；回滚任意历史版本
```

关键机制：

- **血统 DAG**：每个进化产物记录 `parent_hash`；memory/skill/prompt 三类产物共享同一 DAG 存储（对象存储 git-like 布局：`objects/` + `refs/`）；
- **通道隔离**：生成通道（生产 Langfuse project + 生成专用模型 key）与评测通道（独立 project + 独立 key + 评测集独立 bucket）在 IaC 层分离（AC-3.2.6）；
- **预算**：`quotas` 增加 `evolution_tokens_month`；worker 所有 LLM 调用经 model-gateway 租户维度计量，耗尽即暂停调度（AC-3.2.5）；
- **调度**：evolution-worker = K8s CronJob（挖掘每日）+ 事件驱动（候选状态机推进）。

## 3. IM 集成

- `im-connector` 服务：渠道适配（飞书/企微 webhook ↔ Open API）；IM 线程 ↔ session 映射表；流式渲染 = 消息卡片原地更新（节流 1s）；HITL = 交互卡片按钮 → `/v1/runs/{id}/approve`。

## 4. A2A

- agent-runtime 侧挂 A2A Server（标准 Agent Card + tasks/sendSubscribe）；
- 外部调用 → api-gateway（A2A 专用认证域 + 租户授权 `a2a_grants`）→ 内部转为普通 run（复用配额/审计/计量全链路）。

## 5. 风险（本阶段）

| 风险 | 缓解 |
|---|---|
| 坏技能/坏记忆上线 | 门控阈值 + 默认人工审 + 5% 灰度 + 秒级回滚（D08 §20） |
| 进化成本失控 | 独立预算维度 + 自动暂停 + 月度报表 |
| 挖掘误报淹没审核 | 聚类去重 + 证据强制（无 trace 证据不出候选）+ 每周上限 |
| LLM 生成 diff 质量不稳 | 候选模板化（L1 条目结构固定）；L2/L3 diff 必须过沙箱回放才进人工 |
