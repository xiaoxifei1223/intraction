# DeepAgents Cloud Agent 系统设计文档

| 项 | 值 |
|---|---|
| 文档状态 | **评审稿 v0.1（待评审，评审通过后进入编码）** |
| 日期 | 2026-08-09 |
| 依据 | docs/01–07 调研结论；内核选型：DeepAgents（docs/07） |
| 读者 | 架构评审、后端/平台工程团队 |

## 1. 目标与非目标

### 1.1 目标

为企业构建一套 **多用户、云上、可进化** 的 Agent 系统：

1. **多用户**：多租户（企业/部门）+ 租户内多用户，数据/计算/记忆三级隔离，RBAC/ABAC 权限，配额计费；
2. **云上**：容器化部署于 K8s，Agent 执行不可信代码于独立沙箱，弹性伸缩，按租户计量；
3. **可进化**：Agent 的记忆、技能（Skill）、Prompt/Profile 可基于真实使用持续更新，且所有进化产物经过"评测门控 + 灰度 + 可回滚"的受控流水线。

### 1.2 非目标（本期不做）

- 不做低代码/可视化编排画布（Agent 以声明式配置 + 代码定义，API 先行）；
- 不做 Agent 自主改写自身代码（进化 L4，仅保留研究跟进，见 docs/03）；
- 不做模型训练/微调平台（模型经模型网关接入，平台只路由与计量）；
- 不做 IM 全渠道适配（P1 仅 Web + Open API，IM 集成 P3）。

### 1.3 关键设计原则

| # | 原则 | 出处/理由 |
|---|---|---|
| P1 | 内核外包一层自有抽象，harness 可替换 | docs/07：生态 18 个月翻新一次 |
| P2 | tenant_id 在网关最上游注入，下游只读 | docs/02：多租户第一纪律 |
| P3 | 进化产物一律文件化、版本化、可回滚 | docs/03：AWM/Alita/AgentGit 共识 |
| P4 | 工具边界即安全边界，不信任模型自觉 | DeepAgents "trust the tools" 哲学 |
| P5 | 成本治理与评测门控第一天内置 | docs/01：Gartner 40% 项目取消警告 |
| P6 | 标准协议优先（MCP/A2A/OTel GenAI），不自研协议 | docs/05 |

## 2. 总体架构

```
┌──────────────────────────────────────────────────────────────────┐
│ 接入层     Web 控制台 │ Open API │ (P3: 飞书/企微/Teams)            │
├──────────────────────────────────────────────────────────────────┤
│ API 网关   SSO/JWT · 租户解析 · 权限/配额预检 · Prompt 防火墙        │
│            · 限流 · 审计 · SSE 代理                                 │
├──────────────────────────────────────────────────────────────────┤
│ 控制平面   租户/组织/用户 · RBAC · Agent 注册中心 · Skill Registry  │
│            · 配额计费 · 发布管理（灰度/回滚）· 审计查询              │
├──────────────────────────────────────────────────────────────────┤
│ 进化平面   评测集管理 · 离线评测 · 进化流水线 · 门控 · 灰度 · 归档   │
├──────────────────────────────────────────────────────────────────┤
│ Agent 内核  agent-runtime（自有抽象层）                              │
│            └── DeepAgents harness（规划/文件系统/子代理/skills）     │
│                └── LangGraph Server（threads/runs/checkpoint）     │
├──────────────────────────────────────────────────────────────────┤
│ 能力层     MCP 网关（工具治理）│ 记忆服务 │ 知识库 RAG               │
├──────────────────────────────────────────────────────────────────┤
│ 运行时     沙箱池（gVisor/K8s，预留 Firecracker）· 每租户隔离        │
├──────────────────────────────────────────────────────────────────┤
│ 基础设施   K8s · PostgreSQL(RLS) · Redis · Milvus · 对象存储         │
│            · 模型网关（多模型路由/计量）· Langfuse(OTel) · MinIO/S3  │
└──────────────────────────────────────────────────────────────────┘
```

### 2.1 服务拆分（微服务清单）

| 服务 | 技术 | 职责 |
|---|---|---|
| `web-console` | Next.js | 管理控制台 + 终端用户对话 UI |
| `api-gateway` | Go (或 FastAPI，见 §11 开放问题) | §4 |
| `control-plane` | FastAPI + PG | §5 |
| `agent-runtime` | Python + DeepAgents + LangGraph Server | §6 |
| `mcp-gateway` | Python/Go | §8 |
| `sandbox-pool` | Python + K8s API | §9 |
| `evolution-worker` | Python（离线任务） | §10 |
| `model-gateway` | LiteLLM Proxy（复用开源） | 多模型路由/fallback/计量 |

## 3. 核心概念与领域模型

```
Tenant（租户/企业）
 └── Organization（部门/团队，树形）
      └── User（用户，角色绑定）
           └── Session（会话 = LangGraph thread，键：{tenant_id}::{uuid}）
                └── Run（一次执行，含事件流、用量）
Tenant 级资源：
 ├── AgentDefinition（Agent 定义 + 版本）
 │     └── 引用 SkillVersion[]、HarnessProfile、ModelRoute
 ├── Skill（技能包，版本化文件集）
 ├── KnowledgeBase（知识库 → Milvus collection/租户）
 └── MCPServerGrant（租户可用的工具服务器及授权范围）
Platform 级资源：
 ├── EvalDataset / EvalRun（评测）
 ├── EvolutionCandidate（进化候选）
 └── Release（发布：版本 × 租户范围 × 灰度比例）
```

**关键映射**：

| 平台概念 | DeepAgents/LangGraph 概念 |
|---|---|
| AgentDefinition 某版本 | `create_deep_agent(...)` 的参数集（model/prompt/tools/middleware/subagents/backend），或 LangGraph Server 的 assistant config |
| Session | thread（`{tenant_id}::{uuid}`，服务端生成） |
| 租户长期记忆 | LangGraph Store namespace `[tenant_id, "memories", ...]` |
| Agent 的工作文件/skills | DeepAgents backend（自定义 `TenantFSBackend`，见 §6.3） |
| 工具 | MCP 工具，经 `langchain-mcp-adapters` 指向 MCP 网关 |

### 3.1 内核抽象层（原则 P1 的落地）

`agent-runtime` 对内只暴露自有契约，业务代码不直接 import deepagents：

```python
# 自有抽象（示意，非最终实现）
class AgentSpec(BaseModel):        # 控制平面下发的 Agent 定义快照
    spec_version: str
    model: ModelRoute              # 模型路由声明（provider 无关）
    system_prompt: str
    skills: list[SkillRef]         # 版本化技能引用
    tools: list[ToolGrant]         # MCP 工具授权（按租户过滤后）
    subagents: list[SubagentSpec]
    harness_profile: str | None    # 按模型调优的 profile 名
    limits: RunLimits              # max_steps/max_tokens/timeout

class AgentRunner(Protocol):
    async def run(self, spec: AgentSpec, ctx: RunContext,
                  input: RunInput) -> AsyncIterator[RunEvent]: ...

# RunContext 携带：tenant_id / user_id / session_id / sandbox_handle / trace_ctx
```

实现：`DeepAgentsRunner(AgentRunner)`。替换 harness 时新增实现类即可，网关/控制平面零改动。

## 4. API 网关设计

职责四件套 + 两项（docs/02 共识 + 本项目 SSE 代理需求）：

### 4.1 请求处理流水线

```
请求 → ①认证：JWT(企业 SSO/OIDC) 或 API Key → 解析 tenant_id/user_id/roles
     → ②上下文装配：查控制平面（Redis 缓存 60s）→ 租户状态/配额/Agent 权限
     → ③限流：令牌桶，维度 = (tenant, user, endpoint 类别)
     → ④Prompt 防火墙：注入检测（LLM Guard 自托管），可疑请求标记而非直接拒绝（首版）
     → ⑤路由：/v1/agents/runs* → agent-runtime；其余 → control-plane
     → ⑥审计：请求元数据 + 决策结果异步写审计流（Kafka → PG）
     → ⑦SSE 代理：透传 agent-runtime 事件流，附带心跳与断线重连 last-event-id
```

### 4.2 关键规则

- **客户端禁止传 thread_id/sandbox_id**；Session 由网关/控制平面创建并返回不透明 ID；
- 所有下游请求头携带 `X-Tenant-ID / X-User-ID / X-Request-ID`，agent-runtime 的 custom auth 只信网关注入（网络层仅允许网关访问，NetworkPolicy 强制）；
- 配额预检：`quota_remaining(tenant) > 0` 才放行 run；精确扣减在持久层（§6.4）。

## 5. 控制平面设计

### 5.1 模块

| 模块 | 说明 |
|---|---|
| 租户与组织 | Tenant/Organization/User CRUD；租户状态机（trial/active/suspended）；三级组织树 |
| RBAC/ABAC | 预置角色（平台超管/租户管理员/部门管理员/Agent 开发者/普通用户）；ABAC 规则（时间/部门/数据级标签）编译为 scope 集合，签发进 JWT |
| Agent 注册中心 | AgentDefinition + 版本；版本 = 不可变快照（model/prompt/skills/profile/limits 的哈希寻址）；发布动作生成 Release（版本 × 目标租户/部门 × 灰度比例） |
| Skill Registry | Skill 包（文件集 + manifest.yaml：名称/描述/工具依赖/风险等级）；版本化存储于对象存储，元数据入 PG；审核状态机（draft→scanning→review→published→deprecated） |
| 配额计费 | 配额定义（tokens/月、并发 run、知识库存储、工具调用次数）；usage 账本（§6.4）；账单导出 |
| 发布管理 | 灰度策略（按租户/用户百分比）、一键回滚（Release 指针回拨）、版本血统查询 |
| 审计查询 | 全量操作/请求/工具调用审计的检索 API（供控制台与合规导出） |

### 5.2 与控制平面的接口约定

agent-runtime 启动 run 前向控制平面拉取 **EffectiveAgentSpec**（Agent 版本快照 × 租户灰度命中 × 工具授权过滤 × 模型路由），拉取失败 fail-closed。Spec 按内容哈希缓存（TTL 5min），控制平面发布时主动失效。

## 6. Agent 内核设计（agent-runtime）

### 6.1 构成

```
agent-runtime 服务
├── runtime-api（FastAPI 薄层，仅供网关调用）
│     POST /runs（创建 run，返回 SSE）│ POST /runs/{id}/cancel │ GET /sessions
├── AgentRunner 实现：DeepAgentsRunner
│     └── create_deep_agent(model, tools, system_prompt,
│                           middleware=[TodoListMiddleware, SummarizationMiddleware],
│                           subagents=..., backend=TenantFSBackend(ctx))
├── 持久化：TenantScopedCheckpointer / TenantScopedStore（Postgres，见 6.4）
└── 部署形态：langgraph build 独立镜像 × N 副本（无状态，状态全在 PG/Redis/对象存储）
```

### 6.2 Harness 能力映射

| 需求 | DeepAgents 机制 | 本项目配置 |
|---|---|---|
| 规划 | `write_todos`（TodoListMiddleware，v0.7 起 opt-in） | 默认开启（长任务场景需要显式规划） |
| 上下文管理 | 自动摘要 + 大结果卸载到 FS | 开启；卸载目录走 TenantFS |
| 子代理 | `task` 工具，隔离上下文窗口 | SubagentSpec 由控制平面定义（限制可用工具子集） |
| HITL | interrupt + 审批 | 高 risk 工具（由 MCP 网关标注）触发中断，经网关推送审批到控制台 |
| 按模型调优 | harness profiles | Profile 存控制平面，随 Spec 下发 |
| 技能/记忆 | skills + memory 文件 | 见 6.3、§7 |

### 6.3 TenantFSBackend（自定义 backend）

实现 DeepAgents backend 协议，路径规划：

```
/tenants/{tenant_id}/agents/{agent_id}/skills/        ← 只读，来自 Skill Registry 已发布版本
/tenants/{tenant_id}/agents/{agent_id}/memory/        ← 读写，Agent 长期记忆（进化 L1 落点）
/tenants/{tenant_id}/users/{user_id}/memory/          ← 读写，用户级记忆
/sessions/{session_id}/workspace/                     ← 读写，会话工作区（可挂沙箱卷）
```

- 底层存储：对象存储（S3/MinIO）+ Redis 热缓存；启动 run 时物化（lazy fetch），run 结束回写变更集（write-back 产生新记忆版本，供进化平面消费）；
- 路径逃逸防护：所有路径经规范化 + 前缀白名单校验，拒绝 `..`；
- skills 目录在运行时**只读**——Agent 不能直接改自己的技能，技能变更必须走进化流水线（原则 P3）。

### 6.4 租户隔离与配额强制（持久层）

- Checkpointer/Store 外包租户作用域层（参照 `langgraph-tenancy` 模式自研或直接采用）：
  - thread 物理键 `{tenant_id}::{thread_id}`；store namespace 首段强制 tenant_id；
  - 缺租户上下文直接抛错（fail-closed）；`list()` 无租户范围即拒绝；
  - 底层 PG 另开 RLS 双保险（高等级租户可升级独立 Schema/独立库，docs/02 三级隔离）；
- 配额账本：从 checkpoint 的 `usage_metadata` 抽取 token 用量入 `usage_records`（按 tenant/user/agent/model 维度），check-then-write：超额租户的新 run 在首次 checkpoint 前拒绝（参照其 `QuotaExceededError` 语义），进行中的 run 不打断。

### 6.5 custom auth（LangGraph Server 层）

实现 `@auth.on.threads.*` / `@auth.on.store.*` handler：校验网关注入身份、thread 键前缀与 tenant 匹配、run 的 assistant/spec 哈希与该租户已发布 Release 一致。注意：完整资源级授权为 LangGraph Platform 商业特性，OSS 部署下本层 + 6.4 持久层包裹 + 网关强制三者叠加兜底（docs/07 §7）。

## 7. 记忆系统设计

| 层 | 内容 | 存储 | 读写方 |
|---|---|---|---|
| 会话记忆 | 当前 session 消息/checkpoint | PG（checkpointer） | harness 自动 |
| 用户记忆 | 偏好、事实、历史摘要 | TenantFS `users/{uid}/memory/` + Store namespace | Agent 运行中自编辑（MemGPT 式） |
| 组织记忆 | 租户共享经验、FAQ 沉淀 | TenantFS `agents/{aid}/memory/` | 进化流水线写入（人工/门控后），Agent 只读 |
| 知识库 | 业务文档 RAG | Milvus（每租户 collection） | 经 MCP 网关的检索工具 |

说明：不引入 Mem0 等外部记忆服务（P1 先用 TenantFS + Store 的自研薄层，避免组件膨胀；P2 若检索质量不足再评估接入，接口预留）。

## 8. 工具层：MCP 网关设计

DeepAgents 经 `langchain-mcp-adapters` 连接 **MCP 网关**（唯一出口），网关职责：

1. **工具目录与授权**：工具注册到控制平面（名称/schema/风险等级/所属租户）；EffectiveAgentSpec 的 ToolGrant 决定 Agent 可见工具集——权限在工具层强制执行（原则 P4）；
2. **凭证注入**：第三方 API 密钥存 KMS/Vault，按租户注入，Agent 与模型永远看不到原始凭证；
3. **参数过滤与风险标注**：高危操作（写/删/外发）标注 `risk=high` → 触发 harness HITL 审批；
4. **限流熔断**：按 (tenant, server) 限流；下游故障熔断并返回结构化错误给 Agent；
5. **审计**：每次调用（agent/run/tool/args 摘要/结果摘要/耗时）入审计流；
6. 协议：上游对 Agent 暴露标准 MCP（streamable HTTP）；下游适配各 MCP Server 或封装企业内部 API 为 MCP。

## 9. 沙箱层设计（sandbox-pool）

### 9.1 决策

P1 采用 **gVisor(runsc) on K8s**（运维轻、支持 GPU、与 K8s 体系一致）；高安全等级租户/场景预留 **Firecracker microVM**（E2B 自托管或自建）作为第二档——docs/04：纯 runc 不足，microVM 最强但运维重（Nomad 系）。

### 9.2 生命周期

- 粒度：**每 (tenant, session) 一个沙箱**，会话结束即销毁（ephemeral rootfs）；长会话挂独立 PV 卷映射到 TenantFS workspace；
- 池化：热池预热 N 个基础镜像沙箱（目标冷启动 <2s 分配），按租户等级分池；
- 约束：drop ALL capabilities、seccomp、默认拒网（egress 白名单仅放行 MCP 网关与对象存储）、CPU/内存/时长限额；
- 接口：sandbox-pool 暴露 `allocate(tenant, session, image) / exec / release`；agent-runtime 的 `execute` 工具经 MCP 网关调用它——**Agent 不直连沙池**，复用工具治理链路。

## 10. 进化平面设计（差异化核心）

### 10.1 流水线

```
生产 trace（Langfuse, 带 tenant/run/score 标签）
  → ①失败模式挖掘（evolution-worker 离线任务：聚类低分 trace）
  → ②生成进化候选 EvolutionCandidate：
       L1 组织记忆条目（新增/修订 memory 文件）
       L2 新技能或技能修订（Skill 包 diff）
       L3 Prompt/Profile 修订
  → ③沙箱离线验证：候选在回放环境 + 评测子集跑通
  → ④评测门控：EvalDataset 回归，二元通过/失败，阈值不劣于基线
  → ⑤审核：L2/L3 强制人工；L1 可配置自动
  → ⑥发布：新版本 → Release 灰度（默认 5% 会话）→ 指标观察窗
  → ⑦归档：全部版本入对象存储，Release 指针可一键回滚
```

### 10.2 关键规则

- 进化产物全是**文件变更集**（memory/skill/profile 文件 diff），血统 = git 式 DAG；
- 评测通道与生成通道物理隔离（防 reward hacking，docs/03 DGM 实证）；
- 进化预算按租户计量（每月进化 token 上限），超预算自动暂停该租户进化任务；
- L4（Agent 改自身代码）不进生产，仅内部研究环境。

### 10.3 评测基础设施

EvalDataset 来源：人工标注 + 生产低分 trace 转化 + 种子集；评估器三类：代码评估器（确定性检查）、LLM-as-judge（需人工校准）、人工标注队列；分数一律二元 pass/fail（Langfuse 实践建议）。

## 11. 关键流程时序

### 11.1 发起一次 Agent 对话（Run）

```
User → Web → Gateway
  ① JWT 解析 → tenant/user；② 配额预检；③ Prompt 防火墙
Gateway → ControlPlane：创建 Session（返回 session_id）
Gateway → agent-runtime：POST /runs {session_id, agent_version_hash, input}
agent-runtime：
  ④ custom auth 校验（tenant 与 thread 前缀一致、版本已发布）
  ⑤ 拉 EffectiveAgentSpec（含工具授权、skills 版本、profile）
  ⑥ TenantFS 物化（skills 只读 + memory 读写 + workspace）
  ⑦ 分配/复用沙箱（经 MCP 网关 → sandbox-pool）
  ⑧ DeepAgents 执行循环：
       LLM 调用 → model-gateway（计量）
       工具调用 → MCP 网关（授权/凭证/审计；高危 → interrupt → 网关 → 用户审批）
       检查点 → TenantScopedCheckpointer（记账）
  ⑨ 事件流（token/tool/todo/interrupt）→ SSE → Gateway → User
  ⑩ run 结束：memory 变更集回写；usage 入账；trace 入 Langfuse
```

### 11.2 发布一个进化产物（以新技能为例）

```
evolution-worker：低分 trace 聚类 → 生成 Skill diff → 沙箱回放验证
  → 离线评测（EvalDataset 回归）→ 提交人工审核
审核通过 → ControlPlane：Skill 新版本（published）
  → Release（target=tenantA, rollout=5%）→ Spec 缓存失效
5% 会话命中新版本 → Langfuse 对比指标（通过率/成本/延迟）
  → 达标：全量；不达标：Release 回滚（旧版本秒级恢复）
```

## 12. 数据模型（控制平面 PG，核心表）

```sql
tenants(id, name, tier, status, region, created_at)
organizations(id, tenant_id, parent_id, name)                 -- 树形
users(id, tenant_id, org_id, external_sub, display_name, status)
roles / user_roles / abac_policies
agent_definitions(id, tenant_id, name, description, status)
agent_versions(id, agent_id, version, spec_jsonb, spec_hash, created_by, created_at)
skills(id, tenant_id, name, risk_level, status)               -- 状态机见 §5.1
skill_versions(id, skill_id, version, manifest_jsonb, bundle_uri, hash)
releases(id, tenant_id, target_type, target_id, agent_version_id,
         rollout_pct, status, created_at)                     -- 灰度与回滚指针
sessions(id, tenant_id, user_id, agent_version_id, thread_key, created_at)  -- thread_key = tenant::uuid
usage_records(id, tenant_id, user_id, agent_id, model,
              input_tokens, output_tokens, run_id, ts)
quotas(tenant_id, metric, limit, period)
audit_events(id, tenant_id, actor, action, resource, decision, detail_jsonb, ts)
eval_datasets / eval_cases / eval_runs / eval_scores
evolution_candidates(id, tenant_id, kind, diff_uri, status, metrics_jsonb)
```

Agent 运行时状态（checkpoints/store）在 agent-runtime 自己的 PG 库，经租户包裹层访问；控制平面库与运行时库**物理分离**。

## 13. 对外 API 概要（Open API v1）

| 端点 | 说明 |
|---|---|
| `POST /v1/sessions` | 创建会话（body: agent_id）→ `{session_id}` |
| `POST /v1/sessions/{id}/runs` | 发起 run（SSE 流式返回事件） |
| `POST /v1/runs/{id}/cancel` / `POST /v1/runs/{id}/approve` | 取消 / HITL 审批 |
| `GET /v1/agents` · `POST /v1/agents` · `POST /v1/agents/{id}/versions` | Agent 定义与版本 |
| `POST /v1/agents/{id}/releases` · `POST /v1/releases/{id}/rollback` | 发布与回滚 |
| `GET/POST /v1/skills...` | Skill 管理（含审核提交） |
| `GET /v1/usage?tenant=&period=` | 用量与账单 |
| `GET /v1/audit?...` | 审计检索 |

管理端 API（控制平面）与终端 API 分两套前缀与权限域。

## 14. 部署架构（K8s）

```
namespace: platform        ← gateway / control-plane / web / langfuse / model-gateway
namespace: agent-runtime   ← agent-runtime 副本（HPA 按 run 并发伸缩）
namespace: sandbox         ← sandbox-pool + 沙箱 Pod（runsc RuntimeClass）
namespace: tenant-<id>     ← 仅高等级租户：专属 runtime + 沙箱（硬隔离档）
namespace: data            ← PG / Redis / Milvus / MinIO（或云托管）
```

- NetworkPolicy：sandbox 命名空间 egress 仅允许到 mcp-gateway 与对象存储；agent-runtime 仅接受 gateway 流量；
- HPA 指标：run 并发数 / 队列深度（自定义指标），非 CPU；
- 多可用区：P2 单区域双 AZ；多区域/数据驻留 P3+（docs/02 租户区域化方案）。

## 15. 安全设计清单

| 层 | 措施 |
|---|---|
| 传输 | 全链路 TLS；服务间 mTLS（P2，Istio 或 Linkerd） |
| 身份 | OIDC 对接企业 IdP；API Key 可旋转；service account 最小权限 |
| 数据 | PG RLS + 租户键前缀双保险；Milvus 每租户 collection；Redis key 前缀；备份加密 |
| 凭证 | Vault/KMS；MCP 网关运行时注入；日志全量脱敏（凭证/PII 扫描） |
| 执行 | 沙箱（§9）；skills 只读；路径白名单；工具级授权 |
| 输入 | Prompt 防火墙；输出敏感信息检测（P2） |
| 审计 | 不可变审计流（append-only，定期归档对象存储）对齐 SOC2 CC6.3 / ISO 27001 A.12.4.1 |
| 渗透 | P2 起定期租户隔离渗透测试（docs/02 最佳实践） |

## 16. 可观测设计

- Trace：OTel GenAI 语义约定，trace 标签强制带 `tenant_id/user_id/agent_id/version/release_id`；后端 Langfuse 自托管；MCP 调用经 `_meta` 串联跨服务 trace；
- 指标：token 成本（tenant/user/agent/model 四维）、p95 首 token 延迟、工具调用分布、死循环检测（同 tool 连续 N 次同参调用告警）、沙箱分配时延；
- 日志：结构化 JSON，tenant 标签，PII 脱敏；
- 告警：成本突增、评测分数跌落、配额耗尽、沙箱异常退出率。

## 17. 技术选型定案表

| 组件 | 选择 | 备选/备注 |
|---|---|---|
| Harness 内核 | DeepAgents（MIT） | Agno（PoC 对比后最终确认，docs/07 §6 清单） |
| 持久执行 | LangGraph Server + Postgres checkpointer | — |
| 租户隔离 | 自研租户包裹层（参照 langgraph-tenancy）+ PG RLS | 或购 LangGraph Enterprise |
| 沙箱 | gVisor on K8s（runsc） | Firecracker（高安全档，P3） |
| 工具协议 | MCP + 自建 MCP 网关 | — |
| Agent 间协议 | A2A（P3 开放跨系统协同时启用） | — |
| 模型网关 | LiteLLM Proxy | 自研薄层亦可 |
| 记忆/知识 | TenantFS + Store；Milvus RAG | P2 评估 Mem0 |
| 可观测 | OTel GenAI + Langfuse（自托管） | LangSmith（若购 Enterprise） |
| 数据库 | PostgreSQL 14+（RLS） | — |
| 向量库 | Milvus | pgvector（小规模可先用） |
| 对象存储 | S3/MinIO | — |
| 后端语言 | Python（runtime/control-plane），Go 待议（gateway） | 见 §19 Q1 |
| 前端 | Next.js | — |

## 18. 里程碑（与 docs/06 对齐）

| 阶段 | 周期 | 交付 | 验收 |
|---|---|---|---|
| P0 PoC | 2–3 周 | DeepAgents vs Agno 对比实测；租户包裹层 spike；沙箱打通 | docs/07 §6 五项清单 |
| P1 MVP | ~12 周 | 网关基础 + 多租户基座 + runtime 打通 + 基础记忆(L1) + MCP 网关最小版 + 控制台 + Langfuse | 1 个试点租户真实使用 |
| P2 企业化 | ~12 周 | RBAC/ABAC、审计、配额计费、SSO、沙箱池生产化、评测门控 | 生产可用，首批签约 |
| P3 平台化 | ~16 周 | Skill Registry/审核流、进化流水线半自动（L2/L3 灰度）、IM 集成、A2A | 商业化闭环 |
| P4 演进 | 持续 | 多 Agent 协同、跨区域、L4 研究 | 生态壁垒 |

## 19. 开放问题（评审需决策）

| # | 问题 | 选项 | 建议 |
|---|---|---|---|
| Q1 | 网关语言 | Go（性能/生态） vs FastAPI（与 runtime 同栈，团队效率高） | 流量不大时 FastAPI；明确 SSE 高并发后 Go |
| Q2 | LangGraph Enterprise License | 购买（省自研包裹层） vs 纯 OSS + 自研 | P0 spike 后按报价决策；自研工作量估 2–3 人周 |
| Q3 | 沙箱首版 | gVisor（运维轻） vs 直接用 E2B 托管（最快） vs E2B 自托管 | 建议 gVisor；预算充足且接受数据出域可短期用 E2B 托管起步 |
| Q4 | 组织记忆的写入权 | 全自动（L1 免审） vs 一律人工审 | 默认"低分 trace 聚类 + 人工一键采纳"，全自动延后 |
| Q5 | 单体优先还是微服务起步 | P1 合并 gateway+control-plane 为单服务（模块化单体） | 建议合并，P2 再拆（KISS） |
| Q6 | DeepAgents 版本跟进策略 | 锁版本季度升级 vs 紧跟 | 锁版本 + 每季度评估；抽象层保证升级可控 |

## 20. 风险登记（Top 5）

| 风险 | 等级 | 缓解 |
|---|---|---|
| DeepAgents 快速演进导致升级断裂 | 中 | 抽象层（§3.1）+ 锁版本（Q6） |
| 租户隔离实现缺陷导致串数据 | 高 | 三层兜底（网关/持久层包裹/RLS）+ P2 渗透测试 |
| 沙箱冷启动影响体验 | 中 | 热池预热 + 会话沙箱复用 |
| 进化质量不稳定（坏技能上线） | 中 | 门控阈值 + 灰度 + 秒级回滚 + 默认人工审 |
| token 成本失控 | 高 | 配额硬熔断 + 模型路由（小模型优先）+ 进化预算独立计量 |
