"""S1-Demo 3：技能渐进式披露（SkillsMiddleware + skills 目录）。

验证 AC-0.1.1（技能部分）：
  agent 启动时只见技能元数据，需要时自行 read_file 加载全文并照做。

注意：本地 PoC 用 FilesystemBackend(virtual_mode=True) 锚定在示例工作区内；
     生产环境禁止裸用 FilesystemBackend（官方明示不适合多租户），
     Phase 1 将替换为 TenantFSBackend 的只读 skills 路由（见 docs/Spec/shared/02 §3）。

运行：python poc/s1-kernel/demo_skills.py
"""
import asyncio
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from poc.common.llm import describe_backend, make_chat_model
from poc.common.persistence import open_checkpointer
from poc.common.settings import banner, step

SKILL_MD = """---
name: report-format
description: 公司标准调研报告格式：先结论、再要点、最后风险段
---

# 标准报告技能

使用该技能时，输出必须严格包含三段：
1. `## 结论` —— 一句话结论
2. `## 要点` —— 3-5 条 bullet
3. `## 风险` —— 至少 1 条风险提示
"""


async def main() -> None:
    banner("S1-Demo 3: SkillsMiddleware 技能渐进披露")
    step(f"LLM 后端: {describe_backend()}")

    ws = Path(tempfile.mkdtemp(prefix="poc-skills-"))
    skill_dir = ws / "skills" / "report-format"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text(SKILL_MD, encoding="utf-8")
    step(f"示例工作区: {ws}（内含 skills/report-format/SKILL.md）")

    from deepagents import create_deep_agent
    from deepagents.backends import FilesystemBackend

    model = make_chat_model()
    async with open_checkpointer() as checkpointer:
        agent = create_deep_agent(
            model=model,
            backend=FilesystemBackend(root_dir=str(ws), virtual_mode=True),
            skills=["/skills"],
            system_prompt="你有一个技能目录 /skills。写报告前请查看是否有可用技能并严格遵循。",
            checkpointer=checkpointer,
        )
        step("agent 装配完成（skills=['/skills']）")

        read_skill = []
        config = {"configurable": {"thread_id": "s1-skills-1"}}
        final_text = ""
        async for event in agent.astream_events(
            {"messages": [{"role": "user", "content": "给我一份关于'向量数据库选型'的简短报告。"}]},
            config=config,
            version="v2",
        ):
            if event.get("event") == "on_tool_start" and event.get("name") == "read_file":
                path = str(event.get("data", {}).get("input", {}).get("file_path", ""))
                if "SKILL.md" in path:
                    read_skill.append(path)
                    step(f"agent 按需加载技能全文: {path}")
            elif event.get("event") == "on_chat_model_end":
                out = event.get("data", {}).get("output")
                if out and getattr(out, "content", None) and isinstance(out.content, str):
                    final_text = out.content

        banner("结果")
        ok_read = bool(read_skill)
        ok_format = all(h in final_text for h in ("结论", "要点", "风险"))
        print(f"最终回复（截断）:\n{final_text[:500]}")
        if ok_read and ok_format:
            step("✅ AC-0.1.1(技能) 通过：技能被按需加载且输出遵循技能格式")
        else:
            step(f"❌ 未完全达标：加载技能={ok_read}, 遵循格式={ok_format}（可重试或调整 prompt）")
            sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
