"""S1-Demo 1：规划能力（TodoListMiddleware 显式 opt-in）。

验证 AC-0.1.1（规划部分）：
  deepagents 0.7.0 起 TodoListMiddleware 已移出默认栈（breaking change），
  云端封装必须显式传入 —— 本 demo 验证显式传入后 write_todos 可用。

运行：python -m poc.s1-kernel.demo_todos  →  Windows 下模块名含连字符，请用脚本方式：
      python poc/s1-kernel/demo_todos.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))  # backend/ 加入 sys.path

from poc.common.llm import describe_backend, make_chat_model
from poc.common.persistence import open_checkpointer
from poc.common.settings import banner, step


async def main() -> None:
    banner("S1-Demo 1: TodoListMiddleware 显式 opt-in（规划能力）")
    step(f"LLM 后端: {describe_backend()}")

    from deepagents import create_deep_agent

    # 0.7 起需从 langchain 显式引入并传入（不再默认启用）
    try:
        from langchain.agents.middleware import TodoListMiddleware
    except ImportError:
        from langchain.agents.middleware.todo import TodoListMiddleware  # 兼容路径

    model = make_chat_model()
    async with open_checkpointer() as checkpointer:
        agent = create_deep_agent(
            model=model,
            middleware=[TodoListMiddleware()],
            system_prompt="你是一个谨慎的执行 agent，处理多步骤任务前必须先制定计划。",
            checkpointer=checkpointer,
        )
        step("agent 装配完成（middleware 含 TodoListMiddleware）")

        config = {"configurable": {"thread_id": "s1-todos-1"}}
        task = (
            "帮我完成一个三步骤任务：1) 在 /workspace 下写一个 hello.txt 内容为 'step1 done'；"
            "2) 再写一个 summary.txt 总结第一步；3) 列出 /workspace 目录确认两个文件都在。"
            "请先制定 todo 计划再执行。"
        )
        step(f"发起任务: {task[:50]}...")
        result = await agent.ainvoke({"messages": [{"role": "user", "content": task}]}, config=config)

    todos = result.get("todos") or []
    banner("结果：todos 状态")
    if todos:
        for i, t in enumerate(todos, 1):
            print(f"  {i}. [{t.get('status')}] {t.get('content')}")
        step("✅ AC-0.1.1(规划) 通过：agent 产出并维护了 todo 计划")
    else:
        step("❌ 未在 state 中发现 todos —— 请检查 TodoListMiddleware 是否生效")
        sys.exit(1)

    # 打印最终回复摘要
    final = result["messages"][-1]
    print(f"\n最终回复（截断）: {str(final.content)[:300]}")


if __name__ == "__main__":
    asyncio.run(main())
