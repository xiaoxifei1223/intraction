"""S1-Demo 4：长期记忆（CompositeBackend 路由 /memories/ → StoreBackend）。

验证 AC-0.1.2：
  - /memories/ 下的写入经 StoreBackend 落到 BaseStore，**跨 thread 可见**（长期记忆）；
  - 其余路径走 StateBackend，仅当前 thread 有效（会话内临时文件）。

这正是 Phase 1 TenantFSBackend 的组合范式（docs/Spec/README.md F2）。

运行：python poc/s1-kernel/demo_memory.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from poc.common.llm import describe_backend, make_chat_model
from poc.common.persistence import open_checkpointer, open_store
from poc.common.settings import banner, step

MEMORY_PATH = "/memories/AGENTS.md"


async def main() -> None:
    banner("S1-Demo 4: CompositeBackend 长期记忆（跨 thread 可见性）")
    step(f"LLM 后端: {describe_backend()}")

    from deepagents import create_deep_agent
    from deepagents.backends import CompositeBackend, StateBackend, StoreBackend

    model = make_chat_model()
    async with open_checkpointer() as checkpointer, open_store() as store:

        def make_agent():
            return create_deep_agent(
                model=model,
                # 关键组合：默认会话内 StateBackend；/memories/ 路由到 StoreBackend（跨 thread 持久）
                backend=CompositeBackend(
                    default=StateBackend(),
                    routes={"/memories/": StoreBackend(namespace=lambda rt: ("demo-tenant", "memories"))},
                ),
                memory=[MEMORY_PATH],  # 启动时注入 system prompt
                system_prompt="你有长期记忆文件 /memories/AGENTS.md，重要用户偏好要写入其中。",
                checkpointer=checkpointer,
                store=store,
            )

        # --- thread 1：告知偏好 ---
        step("thread-1：告知 agent 一个用户偏好（应写入 /memories/）")
        agent1 = make_agent()
        r1 = await agent1.ainvoke(
            {"messages": [{"role": "user", "content": "请记住：我喜欢所有回复都用要点列表，不用长段落。"}]},
            config={"configurable": {"thread_id": "s1-memory-t1"}},
        )
        step(f"thread-1 回复（截断）: {str(r1['messages'][-1].content)[:200]}")

        # --- thread 2：新会话，验证记忆注入 ---
        step("thread-2（全新会话）：观察记忆是否自动注入生效")
        agent2 = make_agent()
        r2 = await agent2.ainvoke(
            {"messages": [{"role": "user", "content": "帮我总结一下 REST 和 GraphQL 的区别。"}]},
            config={"configurable": {"thread_id": "s1-memory-t2"}},
        )
        final = str(r2["messages"][-1].content)
        print(f"\nthread-2 回复（截断）:\n{final[:500]}")

        # --- 直接检查 store 落盘证据 ---
        banner("结果")
        items = await store.asearch(("demo-tenant", "memories"))
        persisted = any("AGENTS.md" in str(it.key) for it in items)
        step(f"Store 中 /memories/ 条目数: {len(items)}，含 AGENTS.md: {persisted}")

        style_hit = ("-" in final or "•" in final or "1." in final) and len(final) > 0
        if persisted and style_hit:
            step("✅ AC-0.1.2 通过：记忆跨 thread 持久化，且新会话回复遵循了记忆中的偏好")
        elif persisted:
            step("⚠️ 记忆已持久化但回复风格不明显（模型因素），核心机制验证通过")
        else:
            step("❌ /memories/ 未落盘 —— 检查 CompositeBackend/StoreBackend 装配")
            sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
