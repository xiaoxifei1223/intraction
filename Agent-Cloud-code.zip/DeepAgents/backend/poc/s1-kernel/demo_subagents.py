"""S1-Demo 2：子代理机制（task 工具 + 声明式 SubAgent + general-purpose 默认子代理）。

验证 AC-0.1.1（子代理部分）：
  - 声明式 SubAgent 经 task 工具被调用；
  - 子代理上下文隔离：只把最终报告返回给主 agent；
  - 未显式提供 general-purpose 时，deepagents 自动补一个同模型默认子代理。

运行：python poc/s1-kernel/demo_subagents.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from poc.common.llm import describe_backend, make_chat_model
from poc.common.persistence import open_checkpointer
from poc.common.settings import banner, step


async def main() -> None:
    banner("S1-Demo 2: SubAgent / task 工具")
    step(f"LLM 后端: {describe_backend()}")

    from deepagents import create_deep_agent

    researcher = {
        "name": "researcher",
        "description": "负责资料调研与要点归纳的子代理",
        "system_prompt": "你是调研子代理。对被交办的主题，输出不超过 5 条的要点清单作为最终报告。",
    }

    model = make_chat_model()
    async with open_checkpointer() as checkpointer:
        agent = create_deep_agent(
            model=model,
            subagents=[researcher],  # 未提供 general-purpose → 框架应自动补一个
            system_prompt=(
                "你是主 agent。凡涉及调研/归纳类工作，必须通过 task 工具委派给 "
                "researcher 子代理完成，不要自己直接回答调研内容。"
            ),
            checkpointer=checkpointer,
        )
        step("agent 装配完成（含 1 个声明式 subagent）")

        step("发起任务：要求委派子代理调研")
        config = {"configurable": {"thread_id": "s1-subagents-1"}}
        task_called = []

        # 用 stream 观察事件，捕获 task 工具调用（证据：子代理确实被调用）
        async for event in agent.astream_events(
            {"messages": [{"role": "user", "content": "调研一下'多租户 SaaS 数据隔离'的三种常见模式，给我要点。"}]},
            config=config,
            version="v2",
        ):
            kind = event.get("event")
            if kind == "on_tool_start":
                name = event.get("name", "")
                if name == "task":
                    inp = event.get("data", {}).get("input", {})
                    task_called.append(inp.get("subagent_type", "?"))
                    step(f"主 agent 发起 task 调用 → subagent_type={inp.get('subagent_type')}")

        banner("结果")
        if task_called:
            step(f"✅ AC-0.1.1(子代理) 通过：task 工具被调用 {len(task_called)} 次，类型={task_called}")
        else:
            step("❌ 未观察到 task 工具调用 —— 模型可能未委派，可调整 system_prompt 重试")
            sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
