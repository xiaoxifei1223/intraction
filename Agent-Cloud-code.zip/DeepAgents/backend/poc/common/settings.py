"""PoC 全局配置：从 .env 加载，所有 demo 共用。"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BACKEND_ROOT = Path(__file__).resolve().parents[2]  # DeepAgents/backend
load_dotenv(BACKEND_ROOT / ".env")


@dataclass(frozen=True)
class Settings:
    llm_backend: str  # "kimi" | "litellm"
    kimi_api_key: str | None
    kimi_base_url: str
    kimi_model: str
    litellm_base_url: str | None
    litellm_api_key: str | None
    litellm_model: str
    database_url: str | None
    sandbox_image: str
    sandbox_server: str


def get_settings() -> Settings:
    return Settings(
        llm_backend=os.getenv("LLM_BACKEND", "kimi").lower(),
        kimi_api_key=os.getenv("KIMI_API_KEY") or None,
        kimi_base_url=os.getenv("KIMI_BASE_URL", "https://api.moonshot.cn/v1"),
        kimi_model=os.getenv("KIMI_MODEL", "kimi-k2-0905-preview"),
        litellm_base_url=os.getenv("LITELLM_BASE_URL") or None,
        litellm_api_key=os.getenv("LITELLM_API_KEY") or None,
        litellm_model=os.getenv("LITELLM_MODEL", "kimi-k2-0905-preview"),
        database_url=os.getenv("DATABASE_URL") or None,
        sandbox_image=os.getenv("SANDBOX_IMAGE", "python:3.12-slim"),
        sandbox_server=os.getenv("SANDBOX_SERVER", "http://localhost:8100"),
    )


def banner(title: str) -> None:
    print(f"\n{'=' * 60}\n  {title}\n{'=' * 60}", flush=True)


def step(msg: str) -> None:
    """demo 步骤打点，保证运行时可见进度。"""
    print(f"[poc] {msg}", flush=True)
