"""checkpointer / store 公共助手。

- 配置了 DATABASE_URL：用 Postgres（langgraph 官方 saver/store），贴近生产形态；
- 未配置：退化为内存实现并打印警告（方便快速跑通 demo，但跨进程不持久）。

注意：Postgres saver/store 需要先执行一次 `setup()` 建表（本模块自动处理）。
"""
from __future__ import annotations

from contextlib import asynccontextmanager

from .settings import get_settings, step


@asynccontextmanager
async def open_checkpointer():
    """yield 一个 langgraph Checkpointer（AsyncPostgresSaver 或 MemorySaver）。"""
    url = get_settings().database_url
    if not url:
        step("未配置 DATABASE_URL，checkpointer 退化为 MemorySaver（仅进程内有效）")
        from langgraph.checkpoint.memory import MemorySaver

        yield MemorySaver()
        return

    from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

    async with AsyncPostgresSaver.from_conn_string(url) as saver:
        await saver.setup()  # 幂等建表
        step(f"checkpointer = AsyncPostgresSaver({url})")
        yield saver


@asynccontextmanager
async def open_store():
    """yield 一个 langgraph BaseStore（AsyncPostgresStore 或 InMemoryStore）。"""
    url = get_settings().database_url
    if not url:
        step("未配置 DATABASE_URL，store 退化为 InMemoryStore（仅进程内有效）")
        from langgraph.store.memory import InMemoryStore

        yield InMemoryStore()
        return

    from langgraph.store.postgres.aio import AsyncPostgresStore

    async with AsyncPostgresStore.from_conn_string(url) as store:
        await store.setup()  # 幂等建表
        step(f"store = AsyncPostgresStore({url})")
        yield store
