"""LLM 工厂：Kimi / LiteLLM 均为 OpenAI 兼容接口，同一个客户端切换 base_url 即可。

- kimi:    直连 Moonshot 官方端点（https://api.moonshot.cn/v1）
- litellm: 指向自部署 LiteLLM Proxy（预留，提供 URL + Token 即可启用，无额外开发）

后续 Phase 1 的 model-gateway 适配层将替换本工厂，demo 不感知。
"""
from __future__ import annotations

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_openai import ChatOpenAI

from .settings import get_settings


def make_chat_model(**overrides) -> BaseChatModel:
    s = get_settings()
    if s.llm_backend == "litellm":
        if not (s.litellm_base_url and s.litellm_api_key):
            raise RuntimeError("LLM_BACKEND=litellm 需要配置 LITELLM_BASE_URL / LITELLM_API_KEY")
        return ChatOpenAI(
            model=s.litellm_model,
            base_url=s.litellm_base_url,
            api_key=s.litellm_api_key,
            **overrides,
        )
    # 默认 kimi
    if not s.kimi_api_key:
        raise RuntimeError("请在 .env 配置 KIMI_API_KEY（或切换 LLM_BACKEND=litellm）")
    return ChatOpenAI(
        model=s.kimi_model,
        base_url=s.kimi_base_url,
        api_key=s.kimi_api_key,
        **overrides,
    )


def describe_backend() -> str:
    s = get_settings()
    if s.llm_backend == "litellm":
        return f"litellm({s.litellm_base_url}, model={s.litellm_model})"
    return f"kimi({s.kimi_base_url}, model={s.kimi_model})"
