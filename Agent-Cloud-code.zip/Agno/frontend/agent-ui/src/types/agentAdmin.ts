// 「Agent 管理」模块类型定义

export interface AgentComponent {
  component_id: string
  component_type: string
  name: string
  description?: string
  current_version?: number
  metadata?: Record<string, unknown>
  created_at?: number
  updated_at?: number
}

export interface PaginationMeta {
  page: number
  limit: number
  total_pages: number
  total_count: number
  search_time_ms?: number
}

export interface PaginatedResponse<T> {
  data: T[]
  meta: PaginationMeta
}

export interface BuiltinAgent {
  id: string
  name?: string
  description?: string
}

export interface ToolCatalogItem {
  name: string
  description?: string
  parameters?: Record<string, unknown>
}

export interface CreateAgentPayload {
  name: string
  description: string
  instructions: string
  tools: string[]
  user_profile: boolean
  user_memory: boolean
  session_context: boolean
  markdown: boolean
  num_history_runs: number
}

export interface CreateAgentResponse {
  component_id?: string
  version?: number
  spec_hash?: string
  [key: string]: unknown
}

// GET /console/agents/{id} 的表单化视图（编辑回显用）
export interface ConsoleAgentFormResponse {
  component_id: string
  version?: number
  stage?: string
  form: CreateAgentPayload
}

export type ConfigStage = 'draft' | 'published' | string

export interface ComponentConfig {
  component_id: string
  version: number
  stage: ConfigStage
  created_at?: number
  updated_at?: number
  notes?: string
  config?: Record<string, unknown>
}
