import { toast } from 'sonner'

import { APIRoutes } from './routes'

import {
  AgentComponent,
  BuiltinAgent,
  ComponentConfig,
  ConsoleAgentFormResponse,
  CreateAgentPayload,
  CreateAgentResponse,
  PaginatedResponse,
  ToolCatalogItem
} from '@/types/agentAdmin'

// 与 src/api/os.ts 保持一致的请求头封装（携带 Bearer token）
const createHeaders = (authToken?: string): HeadersInit => {
  const headers: HeadersInit = {
    'Content-Type': 'application/json'
  }

  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`
  }

  return headers
}

// 从错误响应中提取可读的错误信息
const extractErrorMessage = async (response: Response): Promise<string> => {
  try {
    const data = await response.json()
    if (typeof data?.detail === 'string') return data.detail
    if (typeof data?.message === 'string') return data.message
    return `${response.status} ${response.statusText}`
  } catch {
    return `${response.status} ${response.statusText}`
  }
}

// 获取组件化的 Agent 列表（console 创建的 agent）
export const getAgentComponentsAPI = async (
  endpoint: string,
  authToken?: string
): Promise<AgentComponent[]> => {
  try {
    const url = new URL(APIRoutes.GetComponents(endpoint))
    url.searchParams.set('component_type', 'agent')
    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: createHeaders(authToken)
    })
    if (!response.ok) {
      toast.error(`获取 Agent 列表失败：${await extractErrorMessage(response)}`)
      return []
    }
    const data: PaginatedResponse<AgentComponent> = await response.json()
    return data.data ?? []
  } catch {
    toast.error('获取 Agent 列表时发生网络错误')
    return []
  }
}

// 获取代码内置的 Agent 列表（不可编辑）
export const getBuiltinAgentsAPI = async (
  endpoint: string,
  authToken?: string
): Promise<BuiltinAgent[]> => {
  try {
    const response = await fetch(APIRoutes.GetAgents(endpoint), {
      method: 'GET',
      headers: createHeaders(authToken)
    })
    if (!response.ok) {
      toast.error(`获取内置 Agent 失败：${await extractErrorMessage(response)}`)
      return []
    }
    return await response.json()
  } catch {
    toast.error('获取内置 Agent 时发生网络错误')
    return []
  }
}

// 获取工具目录（创建 Agent 时的可选项）
export const getToolCatalogAPI = async (
  endpoint: string,
  authToken?: string
): Promise<ToolCatalogItem[]> => {
  try {
    const response = await fetch(APIRoutes.GetToolCatalog(endpoint), {
      method: 'GET',
      headers: createHeaders(authToken)
    })
    if (!response.ok) {
      toast.error(`获取工具目录失败：${await extractErrorMessage(response)}`)
      return []
    }
    return await response.json()
  } catch {
    toast.error('获取工具目录时发生网络错误')
    return []
  }
}

// 创建 Agent，成功返回 201 及响应体（含 spec_hash）
export const createAgentAPI = async (
  endpoint: string,
  payload: CreateAgentPayload,
  authToken?: string
): Promise<CreateAgentResponse | null> => {
  try {
    const response = await fetch(APIRoutes.CreateAgent(endpoint), {
      method: 'POST',
      headers: createHeaders(authToken),
      body: JSON.stringify(payload)
    })
    if (!response.ok) {
      toast.error(`创建 Agent 失败：${await extractErrorMessage(response)}`)
      return null
    }
    return await response.json()
  } catch {
    toast.error('创建 Agent 时发生网络错误')
    return null
  }
}

// 获取组件当前版本的表单化视图（编辑模式回显用）
export const getConsoleAgentAPI = async (
  endpoint: string,
  componentId: string,
  authToken?: string
): Promise<ConsoleAgentFormResponse | null> => {
  try {
    const response = await fetch(
      APIRoutes.GetConsoleAgent(endpoint, componentId),
      {
        method: 'GET',
        headers: createHeaders(authToken)
      }
    )
    if (!response.ok) {
      toast.error(`获取 Agent 配置失败：${await extractErrorMessage(response)}`)
      return null
    }
    return await response.json()
  } catch {
    toast.error('获取 Agent 配置时发生网络错误')
    return null
  }
}

// 基于已有组件创建新版本（编辑模式提交入口），成功返回 201
export const createAgentVersionAPI = async (
  endpoint: string,
  componentId: string,
  payload: CreateAgentPayload,
  authToken?: string
): Promise<CreateAgentResponse | null> => {
  try {
    const response = await fetch(
      APIRoutes.CreateAgentVersion(endpoint, componentId),
      {
        method: 'POST',
        headers: createHeaders(authToken),
        body: JSON.stringify(payload)
      }
    )
    if (!response.ok) {
      toast.error(`创建新版本失败：${await extractErrorMessage(response)}`)
      return null
    }
    return await response.json()
  } catch {
    toast.error('创建新版本时发生网络错误')
    return null
  }
}

// 获取组件的配置版本列表
export const getComponentConfigsAPI = async (
  endpoint: string,
  componentId: string,
  authToken?: string
): Promise<ComponentConfig[]> => {
  try {
    const response = await fetch(
      APIRoutes.GetComponentConfigs(endpoint, componentId),
      {
        method: 'GET',
        headers: createHeaders(authToken)
      }
    )
    if (!response.ok) {
      toast.error(`获取版本列表失败：${await extractErrorMessage(response)}`)
      return []
    }
    return await response.json()
  } catch {
    toast.error('获取版本列表时发生网络错误')
    return []
  }
}

// 发布某个 draft 版本
export const publishConfigAPI = async (
  endpoint: string,
  componentId: string,
  version: number,
  authToken?: string
): Promise<boolean> => {
  try {
    const response = await fetch(
      APIRoutes.UpdateComponentConfig(endpoint, componentId, version),
      {
        method: 'PATCH',
        headers: createHeaders(authToken),
        body: JSON.stringify({ stage: 'published' })
      }
    )
    if (!response.ok) {
      toast.error(`发布版本失败：${await extractErrorMessage(response)}`)
      return false
    }
    return true
  } catch {
    toast.error('发布版本时发生网络错误')
    return false
  }
}

// 将某个 published 版本设为当前生效版本
export const setCurrentConfigAPI = async (
  endpoint: string,
  componentId: string,
  version: number,
  authToken?: string
): Promise<boolean> => {
  try {
    const response = await fetch(
      APIRoutes.SetCurrentConfig(endpoint, componentId, version),
      {
        method: 'POST',
        headers: createHeaders(authToken)
      }
    )
    if (!response.ok) {
      toast.error(`设置当前版本失败：${await extractErrorMessage(response)}`)
      return false
    }
    return true
  } catch {
    toast.error('设置当前版本时发生网络错误')
    return false
  }
}
