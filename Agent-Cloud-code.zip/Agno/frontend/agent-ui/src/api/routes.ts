export const APIRoutes = {
  GetAgents: (agentOSUrl: string) => `${agentOSUrl}/agents`,
  AgentRun: (agentOSUrl: string) => `${agentOSUrl}/agents/{agent_id}/runs`,
  Status: (agentOSUrl: string) => `${agentOSUrl}/health`,
  GetSessions: (agentOSUrl: string) => `${agentOSUrl}/sessions`,
  GetSession: (agentOSUrl: string, sessionId: string) =>
    `${agentOSUrl}/sessions/${sessionId}/runs`,

  DeleteSession: (agentOSUrl: string, sessionId: string) =>
    `${agentOSUrl}/sessions/${sessionId}`,

  GetTeams: (agentOSUrl: string) => `${agentOSUrl}/teams`,
  TeamRun: (agentOSUrl: string, teamId: string) =>
    `${agentOSUrl}/teams/${teamId}/runs`,

  GetWorkflows: (agentOSUrl: string) => `${agentOSUrl}/workflows`,
  WorkflowRun: (agentOSUrl: string, workflowId: string) =>
    `${agentOSUrl}/workflows/${workflowId}/runs`,

  // HITL：审批与暂停 run 恢复
  AgentRunContinue: (agentOSUrl: string, agentId: string, runId: string) =>
    `${agentOSUrl}/agents/${agentId}/runs/${runId}/continue`,
  TeamRunContinue: (agentOSUrl: string, teamId: string, runId: string) =>
    `${agentOSUrl}/teams/${teamId}/runs/${runId}/continue`,
  WorkflowRunContinue: (
    agentOSUrl: string,
    workflowId: string,
    runId: string
  ) => `${agentOSUrl}/workflows/${workflowId}/runs/${runId}/continue`,
  GetApprovals: (agentOSUrl: string) => `${agentOSUrl}/approvals`,
  ResolveApproval: (agentOSUrl: string, approvalId: string) =>
    `${agentOSUrl}/approvals/${approvalId}/resolve`,
  DeleteTeamSession: (agentOSUrl: string, teamId: string, sessionId: string) =>
    `${agentOSUrl}/v1//teams/${teamId}/sessions/${sessionId}`,

  // 「Agent 管理」相关路由
  GetComponents: (agentOSUrl: string) => `${agentOSUrl}/components`,
  GetToolCatalog: (agentOSUrl: string) => `${agentOSUrl}/console/tool-catalog`,
  CreateAgent: (agentOSUrl: string) => `${agentOSUrl}/console/agents`,
  GetConsoleAgent: (agentOSUrl: string, componentId: string) =>
    `${agentOSUrl}/console/agents/${componentId}`,
  CreateAgentVersion: (agentOSUrl: string, componentId: string) =>
    `${agentOSUrl}/console/agents/${componentId}/versions`,
  GetComponentConfigs: (agentOSUrl: string, componentId: string) =>
    `${agentOSUrl}/components/${componentId}/configs`,
  UpdateComponentConfig: (
    agentOSUrl: string,
    componentId: string,
    version: number
  ) => `${agentOSUrl}/components/${componentId}/configs/${version}`,
  SetCurrentConfig: (
    agentOSUrl: string,
    componentId: string,
    version: number
  ) => `${agentOSUrl}/components/${componentId}/configs/${version}/set-current`
}
