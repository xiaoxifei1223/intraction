import { Suspense } from 'react'

import AgentAdminPage from '@/components/agents-admin/AgentAdminPage'

export default function AgentsAdmin() {
  // 复用与聊天页一致的 token 机制：优先使用环境变量中的安全密钥
  const envToken = process.env.NEXT_PUBLIC_OS_SECURITY_KEY || ''
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <AgentAdminPage envToken={envToken} />
    </Suspense>
  )
}
