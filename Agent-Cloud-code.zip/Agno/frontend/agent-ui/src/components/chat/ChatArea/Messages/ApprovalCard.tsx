'use client'

import { FC, useState } from 'react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import Icon from '@/components/ui/icon'
import { getApprovalsAPI, resolveApprovalAPI } from '@/api/os'
import useAIChatStreamHandler from '@/hooks/useAIStreamHandler'
import { useStore } from '@/store'
import { HITLInfo } from '@/types/os'

interface ApprovalCardProps {
  hitl: HITLInfo
}

const ApprovalCard: FC<ApprovalCardProps> = ({ hitl }) => {
  const selectedEndpoint = useStore((state) => state.selectedEndpoint)
  const authToken = useStore((state) => state.authToken)
  const setMessages = useStore((state) => state.setMessages)
  const isStreaming = useStore((state) => state.isStreaming)
  const { continueRun } = useAIChatStreamHandler()
  const [isResolving, setIsResolving] = useState(false)

  const setResolvedStatus = (status: 'approved' | 'rejected') => {
    setMessages((prevMessages) =>
      prevMessages.map((message) =>
        message.role === 'agent' && message.hitl?.run_id === hitl.run_id
          ? { ...message, hitl: { ...message.hitl, status } }
          : message
      )
    )
  }

  const handleResolve = async (status: 'approved' | 'rejected') => {
    if (isResolving || hitl.status !== 'pending') return
    setIsResolving(true)
    try {
      const approvals = await getApprovalsAPI(
        selectedEndpoint,
        hitl.run_id,
        authToken
      )
      const toolName = hitl.requirements[0]?.tool_execution?.tool_name
      const approval =
        approvals.find(
          (entry) => entry.status === 'pending' && entry.tool_name === toolName
        ) ??
        approvals.find((entry) => entry.status === 'pending') ??
        approvals[0]

      if (!approval) {
        throw new Error('No pending approval found for this run')
      }

      await resolveApprovalAPI(selectedEndpoint, approval.id, status, authToken)
      setResolvedStatus(status)
      await continueRun(hitl.run_id, hitl.session_id)
    } catch (error) {
      toast.error(
        `Failed to resolve approval: ${
          error instanceof Error ? error.message : String(error)
        }`
      )
    } finally {
      setIsResolving(false)
    }
  }

  return (
    <div className="flex w-full flex-col gap-3 rounded-xl border border-primary/15 bg-accent p-4 font-dmmono">
      <div className="flex items-center gap-2 text-xs font-medium uppercase text-primary">
        <Icon type="hammer" size="xs" />
        Approval Required
      </div>
      {hitl.requirements.length > 0 ? (
        hitl.requirements.map((requirement, index) => {
          const toolExecution = requirement.tool_execution
          return (
            <div
              key={`${toolExecution?.tool_name ?? 'tool'}-${index}`}
              className="flex flex-col gap-1 rounded-lg bg-background-secondary p-3"
            >
              <p className="text-xs font-medium uppercase text-primary">
                {toolExecution?.tool_name ?? 'Unknown tool'}
              </p>
              {toolExecution?.tool_args && (
                <pre className="max-h-40 overflow-y-auto whitespace-pre-wrap break-all text-xs text-muted">
                  {JSON.stringify(toolExecution.tool_args, null, 2)}
                </pre>
              )}
            </div>
          )
        })
      ) : (
        <p className="text-xs text-muted">
          The run is paused and waiting for approval.
        </p>
      )}
      {hitl.status === 'pending' ? (
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            disabled={isResolving || isStreaming}
            onClick={() => handleResolve('approved')}
            className="rounded-xl bg-primary text-xs font-medium uppercase text-background hover:bg-primary/80"
          >
            {isResolving ? 'Resolving...' : '批准'}
          </Button>
          <Button
            size="sm"
            variant="ghost"
            disabled={isResolving || isStreaming}
            onClick={() => handleResolve('rejected')}
            className="rounded-xl border border-destructive/40 text-xs font-medium uppercase text-destructive hover:bg-destructive/10"
          >
            拒绝
          </Button>
        </div>
      ) : (
        <p
          className={`text-xs font-medium uppercase ${
            hitl.status === 'approved' ? 'text-positive' : 'text-destructive'
          }`}
        >
          {hitl.status === 'approved' ? '已批准' : '已拒绝'}
        </p>
      )}
    </div>
  )
}

export default ApprovalCard
