'use client'

import { useCallback, useEffect, useState } from 'react'
import dayjs from 'dayjs'
import { toast } from 'sonner'

import {
  getComponentConfigsAPI,
  publishConfigAPI,
  setCurrentConfigAPI
} from '@/api/agentAdmin'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/skeleton'
import { AgentComponent, ComponentConfig } from '@/types/agentAdmin'

interface VersionsDialogProps {
  component: AgentComponent | null
  onOpenChange: (open: boolean) => void
  endpoint: string
  authToken: string
  onChanged: () => void
}

const formatTime = (timestamp?: number) =>
  timestamp ? dayjs.unix(timestamp).format('YYYY-MM-DD HH:mm:ss') : '-'

const VersionsDialog = ({
  component,
  onOpenChange,
  endpoint,
  authToken,
  onChanged
}: VersionsDialogProps) => {
  const [configs, setConfigs] = useState<ComponentConfig[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [pendingVersion, setPendingVersion] = useState<number | null>(null)

  const loadConfigs = useCallback(async () => {
    if (!component) return
    setIsLoading(true)
    const data = await getComponentConfigsAPI(
      endpoint,
      component.component_id,
      authToken
    )
    setConfigs(
      [...data].sort((a, b) => (b.version ?? 0) - (a.version ?? 0))
    )
    setIsLoading(false)
  }, [component, endpoint, authToken])

  useEffect(() => {
    if (component) loadConfigs()
  }, [component, loadConfigs])

  const handlePublish = async (version: number) => {
    if (!component) return
    setPendingVersion(version)
    const ok = await publishConfigAPI(
      endpoint,
      component.component_id,
      version,
      authToken
    )
    setPendingVersion(null)
    if (ok) {
      toast.success(`版本 v${version} 已发布`)
      await loadConfigs()
      onChanged()
    }
  }

  const handleSetCurrent = async (version: number) => {
    if (!component) return
    setPendingVersion(version)
    const ok = await setCurrentConfigAPI(
      endpoint,
      component.component_id,
      version,
      authToken
    )
    setPendingVersion(null)
    if (ok) {
      toast.success(`已将 v${version} 设为当前版本`)
      await loadConfigs()
      onChanged()
    }
  }

  return (
    <Dialog open={!!component} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[560px]">
        <DialogHeader>
          <DialogTitle className="text-sm font-medium uppercase text-primary">
            版本管理 - {component?.name}
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-2 font-dmmono">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, index) => (
              <Skeleton key={index} className="h-16 w-full rounded-xl" />
            ))
          ) : configs.length === 0 ? (
            <p className="p-3 text-xs text-muted">暂无版本记录</p>
          ) : (
            configs.map((config) => {
              const isCurrent = config.version === component?.current_version
              const isPending = pendingVersion === config.version
              return (
                <div
                  key={config.version}
                  className="flex items-center justify-between gap-3 rounded-xl border border-primary/15 bg-accent p-3"
                >
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2 text-xs font-medium text-primary">
                      <span>v{config.version}</span>
                      <span
                        className={`rounded-md px-1.5 py-0.5 text-[10px] uppercase ${
                          config.stage === 'published'
                            ? 'bg-positive/15 text-positive'
                            : 'bg-muted/15 text-muted'
                        }`}
                      >
                        {config.stage === 'published' ? '已发布' : '草稿'}
                      </span>
                      {isCurrent && (
                        <span className="rounded-md bg-primary/15 px-1.5 py-0.5 text-[10px] uppercase text-primary">
                          当前生效
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-muted">
                      创建时间：{formatTime(config.created_at)}
                    </span>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    {config.stage === 'draft' && (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={isPending}
                        onClick={() => handlePublish(config.version)}
                        className="text-xs"
                      >
                        发布
                      </Button>
                    )}
                    {config.stage === 'published' && !isCurrent && (
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={isPending}
                        onClick={() => handleSetCurrent(config.version)}
                        className="text-xs"
                      >
                        设为当前
                      </Button>
                    )}
                  </div>
                </div>
              )
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default VersionsDialog
