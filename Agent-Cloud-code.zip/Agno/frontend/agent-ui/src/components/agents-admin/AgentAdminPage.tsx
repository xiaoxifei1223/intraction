'use client'

import { useCallback, useEffect, useState } from 'react'
import Link from 'next/link'
import dayjs from 'dayjs'

import { getAgentComponentsAPI, getBuiltinAgentsAPI } from '@/api/agentAdmin'
import CreateAgentDialog from '@/components/agents-admin/CreateAgentDialog'
import VersionsDialog from '@/components/agents-admin/VersionsDialog'
import { Button } from '@/components/ui/button'
import { Skeleton } from '@/components/ui/skeleton'
import { useStore } from '@/store'
import { AgentComponent, BuiltinAgent } from '@/types/agentAdmin'

interface AgentAdminPageProps {
  envToken: string
}

const formatTime = (timestamp?: number) =>
  timestamp ? dayjs.unix(timestamp).format('YYYY-MM-DD HH:mm:ss') : '-'

const AgentAdminPage = ({ envToken }: AgentAdminPageProps) => {
  const { selectedEndpoint, authToken, hydrated } = useStore()
  const effectiveToken = authToken || envToken

  const [components, setComponents] = useState<AgentComponent[]>([])
  const [builtinAgents, setBuiltinAgents] = useState<BuiltinAgent[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editTarget, setEditTarget] = useState<AgentComponent | null>(null)
  const [versionsTarget, setVersionsTarget] = useState<AgentComponent | null>(
    null
  )

  const loadData = useCallback(async () => {
    setIsLoading(true)
    const [componentData, builtinData] = await Promise.all([
      getAgentComponentsAPI(selectedEndpoint, effectiveToken),
      getBuiltinAgentsAPI(selectedEndpoint, effectiveToken)
    ])
    setComponents(componentData)
    // 与组件列表按名称去重：同名组件优先展示为可编辑的组件
    const componentNames = new Set(componentData.map((item) => item.name))
    setBuiltinAgents(
      builtinData.filter((agent) => !componentNames.has(agent.name ?? agent.id))
    )
    setIsLoading(false)
  }, [selectedEndpoint, effectiveToken])

  useEffect(() => {
    if (hydrated) loadData()
  }, [hydrated, loadData])

  return (
    <div className="flex h-screen flex-col bg-background/80 font-dmmono">
      <header className="flex items-center justify-between border-b border-border px-6 py-4">
        <div className="flex items-center gap-4">
          <Link
            href="/"
            className="text-xs font-medium uppercase text-muted hover:text-primary"
          >
            ← 返回聊天
          </Link>
          <h1 className="text-sm font-medium uppercase text-primary">
            Agent 管理
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={loadData}
            disabled={isLoading}
            className="text-xs uppercase text-muted"
          >
            刷新
          </Button>
          <Button
            size="sm"
            onClick={() => setIsCreateOpen(true)}
            className="rounded-xl bg-primary text-xs font-medium uppercase text-background hover:bg-primary/80"
          >
            新建 Agent
          </Button>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto p-6">
        <div className="mx-auto flex max-w-4xl flex-col gap-3">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, index) => (
              <Skeleton key={index} className="h-24 w-full rounded-xl" />
            ))
          ) : components.length === 0 && builtinAgents.length === 0 ? (
            <p className="p-6 text-center text-xs text-muted">
              暂无 Agent，点击右上角「新建 Agent」创建一个
            </p>
          ) : (
            <>
              {components.map((component) => (
                <div
                  key={component.component_id}
                  className="flex items-start justify-between gap-4 rounded-xl border border-primary/15 bg-accent p-4"
                >
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-primary">
                        {component.name}
                      </span>
                      <span className="rounded-md bg-muted/15 px-1.5 py-0.5 text-[10px] uppercase text-muted">
                        组件
                      </span>
                    </div>
                    {component.description && (
                      <p className="text-xs text-muted">
                        {component.description}
                      </p>
                    )}
                    <p className="text-xs text-muted">
                      当前版本：v{component.current_version ?? '-'} ·
                      创建时间：{formatTime(component.created_at)}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditTarget(component)}
                      className="text-xs"
                    >
                      编辑（新版本）
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setVersionsTarget(component)}
                      className="text-xs"
                    >
                      版本管理
                    </Button>
                  </div>
                </div>
              ))}
              {builtinAgents.map((agent) => (
                <div
                  key={agent.id}
                  className="flex items-start justify-between gap-4 rounded-xl border border-primary/15 bg-accent p-4 opacity-80"
                >
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-primary">
                        {agent.name ?? agent.id}
                      </span>
                      <span className="rounded-md bg-primary/15 px-1.5 py-0.5 text-[10px] uppercase text-primary">
                        内置
                      </span>
                    </div>
                    {agent.description && (
                      <p className="text-xs text-muted">{agent.description}</p>
                    )}
                    <p className="text-xs text-muted">
                      代码内置 Agent，不可编辑
                    </p>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      </main>
      <CreateAgentDialog
        open={isCreateOpen}
        onOpenChange={setIsCreateOpen}
        endpoint={selectedEndpoint}
        authToken={effectiveToken}
        onCreated={loadData}
      />
      <CreateAgentDialog
        open={Boolean(editTarget)}
        onOpenChange={(open) => {
          if (!open) setEditTarget(null)
        }}
        endpoint={selectedEndpoint}
        authToken={effectiveToken}
        onCreated={loadData}
        editTarget={editTarget}
      />
      <VersionsDialog
        component={versionsTarget}
        onOpenChange={(open) => {
          if (!open) setVersionsTarget(null)
        }}
        endpoint={selectedEndpoint}
        authToken={effectiveToken}
        onChanged={loadData}
      />
    </div>
  )
}

export default AgentAdminPage
