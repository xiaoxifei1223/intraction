'use client'

import { useEffect, useState } from 'react'
import { toast } from 'sonner'

import {
  createAgentAPI,
  createAgentVersionAPI,
  getConsoleAgentAPI,
  getToolCatalogAPI
} from '@/api/agentAdmin'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from '@/components/ui/dialog'
import { Skeleton } from '@/components/ui/skeleton'
import {
  AgentComponent,
  CreateAgentPayload,
  ToolCatalogItem
} from '@/types/agentAdmin'

interface CreateAgentDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  endpoint: string
  authToken: string
  onCreated: () => void
  // 编辑模式：传入组件则从 GET /console/agents/{id} 回显表单，提交创建新版本
  editTarget?: AgentComponent | null
}

const inputClassName =
  'flex h-9 w-full items-center rounded-xl border border-primary/15 bg-accent p-3 text-xs font-medium text-muted placeholder:text-muted/50 focus:outline-none'

const CreateAgentDialog = ({
  open,
  onOpenChange,
  endpoint,
  authToken,
  onCreated,
  editTarget
}: CreateAgentDialogProps) => {
  const isEditMode = Boolean(editTarget)
  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [instructions, setInstructions] = useState('')
  const [selectedTools, setSelectedTools] = useState<string[]>([])
  const [userProfile, setUserProfile] = useState(false)
  const [userMemory, setUserMemory] = useState(true)
  const [sessionContext, setSessionContext] = useState(true)
  const [numHistoryRuns, setNumHistoryRuns] = useState(10)
  const [markdown, setMarkdown] = useState(true)

  const [toolCatalog, setToolCatalog] = useState<ToolCatalogItem[]>([])
  const [isCatalogLoading, setIsCatalogLoading] = useState(false)
  const [isFormLoading, setIsFormLoading] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (!open) return
    const loadToolCatalog = async () => {
      setIsCatalogLoading(true)
      const catalog = await getToolCatalogAPI(endpoint, authToken)
      setToolCatalog(catalog)
      setIsCatalogLoading(false)
    }
    loadToolCatalog()
  }, [open, endpoint, authToken])

  // 编辑模式：打开时回显当前版本的表单；创建模式：打开时重置表单
  useEffect(() => {
    if (!open) return
    if (!editTarget) {
      resetForm()
      return
    }
    const loadForm = async () => {
      setIsFormLoading(true)
      const data = await getConsoleAgentAPI(
        endpoint,
        editTarget.component_id,
        authToken
      )
      if (data) {
        const form = data.form
        setName(form.name ?? '')
        setDescription(form.description ?? '')
        setInstructions(form.instructions ?? '')
        setSelectedTools(form.tools ?? [])
        setUserProfile(form.user_profile ?? false)
        setUserMemory(form.user_memory ?? true)
        setSessionContext(form.session_context ?? true)
        setNumHistoryRuns(form.num_history_runs ?? 10)
        setMarkdown(form.markdown ?? true)
      }
      setIsFormLoading(false)
    }
    loadForm()
  }, [open, editTarget, endpoint, authToken])

  const resetForm = () => {
    setName('')
    setDescription('')
    setInstructions('')
    setSelectedTools([])
    setUserProfile(false)
    setUserMemory(true)
    setSessionContext(true)
    setNumHistoryRuns(10)
    setMarkdown(true)
  }

  const toggleTool = (toolName: string) => {
    setSelectedTools((prev) =>
      prev.includes(toolName)
        ? prev.filter((tool) => tool !== toolName)
        : [...prev, toolName]
    )
  }

  const handleSubmit = async () => {
    const trimmedName = name.trim()
    if (!trimmedName) {
      toast.error('名称为必填项')
      return
    }
    const payload: CreateAgentPayload = {
      name: trimmedName,
      description: description.trim(),
      instructions: instructions.trim(),
      tools: selectedTools,
      user_profile: userProfile,
      user_memory: userMemory,
      session_context: sessionContext,
      markdown,
      num_history_runs: numHistoryRuns
    }
    setIsSubmitting(true)
    const result = isEditMode
      ? await createAgentVersionAPI(
          endpoint,
          editTarget!.component_id,
          payload,
          authToken
        )
      : await createAgentAPI(endpoint, payload, authToken)
    setIsSubmitting(false)
    if (result) {
      toast.success(
        isEditMode
          ? `新版本创建成功${result.spec_hash ? `，spec_hash: ${result.spec_hash}` : ''}`
          : `Agent 创建成功${result.spec_hash ? `，spec_hash: ${result.spec_hash}` : ''}`
      )
      resetForm()
      onOpenChange(false)
      onCreated()
    }
  }

  const switchItems: {
    label: string
    value: boolean
    onChange: (value: boolean) => void
  }[] = [
    {
      label: 'user_profile（用户画像）',
      value: userProfile,
      onChange: setUserProfile
    },
    {
      label: 'user_memory（用户记忆）',
      value: userMemory,
      onChange: setUserMemory
    },
    {
      label: 'session_context（会话上下文）',
      value: sessionContext,
      onChange: setSessionContext
    }
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[560px]">
        <DialogHeader>
          <DialogTitle className="text-sm font-medium uppercase text-primary">
            {isEditMode ? `编辑 ${editTarget!.name}（新版本）` : '创建 Agent'}
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col gap-4 font-dmmono">
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium uppercase text-primary">
              名称 <span className="text-destructive">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="请输入 Agent 名称"
              disabled={isEditMode}
              className={inputClassName}
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium uppercase text-primary">
              描述
            </label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="请输入描述"
              className={inputClassName}
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium uppercase text-primary">
              指令（instructions）
            </label>
            <textarea
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              placeholder="请输入系统指令，支持多行文本"
              rows={4}
              className="flex w-full resize-y rounded-xl border border-primary/15 bg-accent p-3 text-xs font-medium text-muted placeholder:text-muted/50 focus:outline-none"
            />
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium uppercase text-primary">
              工具（{selectedTools.length} 项已选）
            </label>
            <div className="flex max-h-40 flex-col gap-1 overflow-y-auto rounded-xl border border-primary/15 bg-accent p-2">
              {isCatalogLoading ? (
                Array.from({ length: 3 }).map((_, index) => (
                  <Skeleton key={index} className="h-8 w-full rounded-lg" />
                ))
              ) : toolCatalog.length === 0 ? (
                <p className="p-2 text-xs text-muted">暂无可用工具</p>
              ) : (
                toolCatalog.map((tool) => (
                  <label
                    key={tool.name}
                    className="flex cursor-pointer items-start gap-2 rounded-lg p-2 hover:bg-background/50"
                  >
                    <input
                      type="checkbox"
                      checked={selectedTools.includes(tool.name)}
                      onChange={() => toggleTool(tool.name)}
                      className="mt-0.5 accent-primary"
                    />
                    <span className="flex flex-col">
                      <span className="text-xs font-medium text-primary">
                        {tool.name}
                      </span>
                      {tool.description && (
                        <span className="text-xs text-muted">
                          {tool.description}
                        </span>
                      )}
                    </span>
                  </label>
                ))
              )}
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium uppercase text-primary">
              开关
            </label>
            <div className="flex flex-col gap-1">
              {switchItems.map((item) => (
                <label
                  key={item.label}
                  className="flex cursor-pointer items-center gap-2 text-xs text-muted"
                >
                  <input
                    type="checkbox"
                    checked={item.value}
                    onChange={(e) => item.onChange(e.target.checked)}
                    className="accent-primary"
                  />
                  {item.label}
                </label>
              ))}
              <label className="flex cursor-pointer items-center gap-2 text-xs text-muted">
                <input
                  type="checkbox"
                  checked={markdown}
                  onChange={(e) => setMarkdown(e.target.checked)}
                  className="accent-primary"
                />
                markdown（Markdown 渲染）
              </label>
            </div>
          </div>
          <div className="flex flex-col gap-2">
            <label className="text-xs font-medium uppercase text-primary">
              num_history_runs（历史轮数）
            </label>
            <input
              type="number"
              min={0}
              value={numHistoryRuns}
              onChange={(e) => setNumHistoryRuns(Number(e.target.value))}
              className={inputClassName}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
              className="text-xs uppercase"
            >
              取消
            </Button>
            <Button
              size="sm"
              onClick={handleSubmit}
              disabled={isSubmitting || isFormLoading}
              className="rounded-xl bg-primary text-xs font-medium uppercase text-background hover:bg-primary/80"
            >
              {isSubmitting
                ? '提交中...'
                : isEditMode
                  ? '创建新版本'
                  : '创建'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

export default CreateAgentDialog
