import { useCallback } from 'react'

import { APIRoutes } from '@/api/routes'

import useChatActions from '@/hooks/useChatActions'
import { useStore } from '../store'
import { RunEvent, RunResponseContent, type RunResponse } from '@/types/os'
import { constructEndpointUrl } from '@/lib/constructEndpointUrl'
import useAIResponseStream from './useAIResponseStream'
import { ToolCall } from '@/types/os'
import { useQueryState } from 'nuqs'
import { getJsonMarkdown } from '@/lib/utils'

interface StreamState {
  lastContent: string
  newSessionId: string | null
  sessionName: string
}

const useAIChatStreamHandler = () => {
  const setMessages = useStore((state) => state.setMessages)
  const { addMessage, focusChatInput } = useChatActions()
  const [agentId] = useQueryState('agent')
  const [teamId] = useQueryState('team')
  const [workflowId] = useQueryState('workflow')
  const [sessionId, setSessionId] = useQueryState('session')
  const selectedEndpoint = useStore((state) => state.selectedEndpoint)
  const authToken = useStore((state) => state.authToken)
  const mode = useStore((state) => state.mode)
  const setStreamingErrorMessage = useStore(
    (state) => state.setStreamingErrorMessage
  )
  const setIsStreaming = useStore((state) => state.setIsStreaming)
  const setSessionsData = useStore((state) => state.setSessionsData)
  const { streamResponse } = useAIResponseStream()

  const updateMessagesWithErrorState = useCallback(() => {
    setMessages((prevMessages) => {
      const newMessages = [...prevMessages]
      const lastMessage = newMessages[newMessages.length - 1]
      if (lastMessage && lastMessage.role === 'agent') {
        lastMessage.streamingError = true
      }
      return newMessages
    })
  }, [setMessages])

  /**
   * Processes a new tool call and adds it to the message
   * @param toolCall - The tool call to add
   * @param prevToolCalls - The previous tool calls array
   * @returns Updated tool calls array
   */
  const processToolCall = useCallback(
    (toolCall: ToolCall, prevToolCalls: ToolCall[] = []) => {
      const toolCallId =
        toolCall.tool_call_id || `${toolCall.tool_name}-${toolCall.created_at}`

      const existingToolCallIndex = prevToolCalls.findIndex(
        (tc) =>
          (tc.tool_call_id && tc.tool_call_id === toolCall.tool_call_id) ||
          (!tc.tool_call_id &&
            toolCall.tool_name &&
            toolCall.created_at &&
            `${tc.tool_name}-${tc.created_at}` === toolCallId)
      )
      if (existingToolCallIndex >= 0) {
        const updatedToolCalls = [...prevToolCalls]
        updatedToolCalls[existingToolCallIndex] = {
          ...updatedToolCalls[existingToolCallIndex],
          ...toolCall
        }
        return updatedToolCalls
      } else {
        return [...prevToolCalls, toolCall]
      }
    },
    []
  )

  /**
   * Processes tool calls from a chunk, handling both single tool object and tools array formats
   * @param chunk - The chunk containing tool call data
   * @param existingToolCalls - The existing tool calls array
   * @returns Updated tool calls array
   */
  const processChunkToolCalls = useCallback(
    (
      chunk: RunResponseContent | RunResponse,
      existingToolCalls: ToolCall[] = []
    ) => {
      let updatedToolCalls = [...existingToolCalls]
      // Handle new single tool object format
      if (chunk.tool) {
        updatedToolCalls = processToolCall(chunk.tool, updatedToolCalls)
      }
      // Handle legacy tools array format
      if (chunk.tools && chunk.tools.length > 0) {
        for (const toolCall of chunk.tools) {
          updatedToolCalls = processToolCall(toolCall, updatedToolCalls)
        }
      }

      return updatedToolCalls
    },
    [processToolCall]
  )

  /**
   * Dispatches a single SSE chunk to the message list.
   * Shared by the initial run stream and the HITL continue stream.
   * Unknown events are ignored silently.
   */
  const handleChunk = useCallback(
    (chunk: RunResponseContent, streamState: StreamState) => {
      if (
        chunk.event === RunEvent.RunStarted ||
        chunk.event === RunEvent.TeamRunStarted ||
        chunk.event === RunEvent.WorkflowStarted ||
        chunk.event === RunEvent.WorkflowRunStarted ||
        chunk.event === RunEvent.ReasoningStarted ||
        chunk.event === RunEvent.TeamReasoningStarted
      ) {
        streamState.newSessionId = chunk.session_id as string
        setSessionId(chunk.session_id as string)
        if (
          (!sessionId || sessionId !== chunk.session_id) &&
          chunk.session_id
        ) {
          const sessionData = {
            session_id: chunk.session_id as string,
            session_name: streamState.sessionName,
            created_at: chunk.created_at
          }
          setSessionsData((prevSessionsData) => {
            const sessionExists = prevSessionsData?.some(
              (session) => session.session_id === chunk.session_id
            )
            if (sessionExists) {
              return prevSessionsData
            }
            return [sessionData, ...(prevSessionsData ?? [])]
          })
        }
      } else if (
        chunk.event === RunEvent.ToolCallStarted ||
        chunk.event === RunEvent.TeamToolCallStarted ||
        chunk.event === RunEvent.ToolCallCompleted ||
        chunk.event === RunEvent.TeamToolCallCompleted
      ) {
        setMessages((prevMessages) => {
          const newMessages = [...prevMessages]
          const lastMessage = newMessages[newMessages.length - 1]
          if (lastMessage && lastMessage.role === 'agent') {
            lastMessage.tool_calls = processChunkToolCalls(
              chunk,
              lastMessage.tool_calls
            )
          }
          return newMessages
        })
      } else if (chunk.event === RunEvent.StepStarted) {
        // Workflow step boundary: reset content dedup and show a step pill
        streamState.lastContent = ''
        setMessages((prevMessages) => {
          const newMessages = [...prevMessages]
          const lastMessage = newMessages[newMessages.length - 1]
          if (lastMessage && lastMessage.role === 'agent') {
            lastMessage.tool_calls = processToolCall(
              {
                role: 'tool',
                content: null,
                tool_call_id: `step-${chunk.step_id ?? chunk.step_name ?? ''}`,
                tool_name: `Step: ${chunk.step_name ?? 'Unknown'}`,
                tool_args: {},
                tool_call_error: false,
                metrics: { time: 0 },
                created_at: chunk.created_at
              },
              lastMessage.tool_calls
            )
          }
          return newMessages
        })
      } else if (chunk.event === RunEvent.StepCompleted) {
        setMessages((prevMessages) => {
          const newMessages = [...prevMessages]
          const lastMessage = newMessages[newMessages.length - 1]
          if (lastMessage && lastMessage.role === 'agent') {
            lastMessage.tool_calls = processToolCall(
              {
                role: 'tool',
                content: null,
                tool_call_id: `step-${chunk.step_id ?? chunk.step_name ?? ''}`,
                tool_name: `Step: ${chunk.step_name ?? 'Unknown'} ✓`,
                tool_args: {},
                tool_call_error: false,
                metrics: { time: 0 },
                created_at: chunk.created_at
              },
              lastMessage.tool_calls
            )
          }
          return newMessages
        })
      } else if (chunk.event === RunEvent.RunPaused) {
        // HITL: run is waiting for approval, render an approval card inline
        setMessages((prevMessages) => {
          const newMessages = [...prevMessages]
          const lastMessage = newMessages[newMessages.length - 1]
          if (lastMessage && lastMessage.role === 'agent') {
            lastMessage.hitl = {
              run_id: (chunk.run_id as string) ?? '',
              session_id:
                (chunk.session_id as string) ??
                streamState.newSessionId ??
                sessionId ??
                '',
              requirements: chunk.requirements ?? [],
              status: 'pending'
            }
          }
          return newMessages
        })
      } else if (
        chunk.event === RunEvent.RunContent ||
        chunk.event === RunEvent.TeamRunContent
      ) {
        setMessages((prevMessages) => {
          const newMessages = [...prevMessages]
          const lastMessage = newMessages[newMessages.length - 1]
          if (
            lastMessage &&
            lastMessage.role === 'agent' &&
            typeof chunk.content === 'string'
          ) {
            const uniqueContent = chunk.content.replace(
              streamState.lastContent,
              ''
            )
            lastMessage.content += uniqueContent
            streamState.lastContent = chunk.content

            // Handle tool calls streaming
            lastMessage.tool_calls = processChunkToolCalls(
              chunk,
              lastMessage.tool_calls
            )
            if (chunk.extra_data?.reasoning_steps) {
              lastMessage.extra_data = {
                ...lastMessage.extra_data,
                reasoning_steps: chunk.extra_data.reasoning_steps
              }
            }

            if (chunk.extra_data?.references) {
              lastMessage.extra_data = {
                ...lastMessage.extra_data,
                references: chunk.extra_data.references
              }
            }

            lastMessage.created_at = chunk.created_at ?? lastMessage.created_at
            if (chunk.images) {
              lastMessage.images = chunk.images
            }
            if (chunk.videos) {
              lastMessage.videos = chunk.videos
            }
            if (chunk.audio) {
              lastMessage.audio = chunk.audio
            }
          } else if (
            lastMessage &&
            lastMessage.role === 'agent' &&
            typeof chunk?.content !== 'string' &&
            chunk.content !== null
          ) {
            const jsonBlock = getJsonMarkdown(chunk?.content)

            lastMessage.content += jsonBlock
            streamState.lastContent = jsonBlock
          } else if (
            chunk.response_audio?.transcript &&
            typeof chunk.response_audio?.transcript === 'string'
          ) {
            const transcript = chunk.response_audio.transcript
            lastMessage.response_audio = {
              ...lastMessage.response_audio,
              transcript: lastMessage.response_audio?.transcript + transcript
            }
          }
          return newMessages
        })
      } else if (
        chunk.event === RunEvent.ReasoningStep ||
        chunk.event === RunEvent.TeamReasoningStep
      ) {
        setMessages((prevMessages) => {
          const newMessages = [...prevMessages]
          const lastMessage = newMessages[newMessages.length - 1]
          if (lastMessage && lastMessage.role === 'agent') {
            const existingSteps = lastMessage.extra_data?.reasoning_steps ?? []
            const incomingSteps = chunk.extra_data?.reasoning_steps ?? []
            lastMessage.extra_data = {
              ...lastMessage.extra_data,
              reasoning_steps: [...existingSteps, ...incomingSteps]
            }
          }
          return newMessages
        })
      } else if (
        chunk.event === RunEvent.ReasoningCompleted ||
        chunk.event === RunEvent.TeamReasoningCompleted
      ) {
        setMessages((prevMessages) => {
          const newMessages = [...prevMessages]
          const lastMessage = newMessages[newMessages.length - 1]
          if (lastMessage && lastMessage.role === 'agent') {
            if (chunk.extra_data?.reasoning_steps) {
              lastMessage.extra_data = {
                ...lastMessage.extra_data,
                reasoning_steps: chunk.extra_data.reasoning_steps
              }
            }
          }
          return newMessages
        })
      } else if (
        chunk.event === RunEvent.RunError ||
        chunk.event === RunEvent.TeamRunError ||
        chunk.event === RunEvent.TeamRunCancelled ||
        chunk.event === RunEvent.WorkflowRunError
      ) {
        updateMessagesWithErrorState()
        const errorContent =
          (chunk.content as string) ||
          (chunk.event === RunEvent.TeamRunCancelled
            ? 'Run cancelled'
            : 'Error during run')
        setStreamingErrorMessage(errorContent)
        if (streamState.newSessionId) {
          setSessionsData(
            (prevSessionsData) =>
              prevSessionsData?.filter(
                (session) => session.session_id !== streamState.newSessionId
              ) ?? null
          )
        }
      } else if (
        chunk.event === RunEvent.UpdatingMemory ||
        chunk.event === RunEvent.TeamMemoryUpdateStarted ||
        chunk.event === RunEvent.TeamMemoryUpdateCompleted ||
        chunk.event === RunEvent.RunContinued
      ) {
        // No-op for now; could surface a lightweight UI indicator in the future
      } else if (
        chunk.event === RunEvent.WorkflowCompleted ||
        chunk.event === RunEvent.WorkflowRunCompleted ||
        ((chunk.event === RunEvent.RunCompleted ||
          chunk.event === RunEvent.TeamRunCompleted) &&
          mode !== 'workflow')
      ) {
        setMessages((prevMessages) => {
          const newMessages = prevMessages.map((message, index) => {
            if (index === prevMessages.length - 1 && message.role === 'agent') {
              let updatedContent: string
              if (typeof chunk.content === 'string' && chunk.content) {
                updatedContent = chunk.content
              } else if (
                chunk.content === null ||
                chunk.content === undefined
              ) {
                updatedContent = message.content
              } else {
                try {
                  updatedContent = JSON.stringify(chunk.content)
                } catch {
                  updatedContent = 'Error parsing response'
                }
              }
              return {
                ...message,
                content: updatedContent,
                tool_calls: processChunkToolCalls(chunk, message.tool_calls),
                images: chunk.images ?? message.images,
                videos: chunk.videos ?? message.videos,
                response_audio: chunk.response_audio,
                created_at: chunk.created_at ?? message.created_at,
                extra_data: {
                  reasoning_steps:
                    chunk.extra_data?.reasoning_steps ??
                    message.extra_data?.reasoning_steps,
                  references:
                    chunk.extra_data?.references ??
                    message.extra_data?.references
                }
              }
            }
            return message
          })
          return newMessages
        })
      } else if (
        chunk.event === RunEvent.RunCompleted ||
        chunk.event === RunEvent.TeamRunCompleted
      ) {
        // Inner executor run completed inside a workflow: merge tool calls
        // and media but keep the already-streamed content untouched.
        setMessages((prevMessages) => {
          const newMessages = prevMessages.map((message, index) => {
            if (index === prevMessages.length - 1 && message.role === 'agent') {
              return {
                ...message,
                tool_calls: processChunkToolCalls(chunk, message.tool_calls),
                images: chunk.images ?? message.images,
                videos: chunk.videos ?? message.videos,
                created_at: chunk.created_at ?? message.created_at
              }
            }
            return message
          })
          return newMessages
        })
      }
    },
    [
      mode,
      sessionId,
      setSessionId,
      setSessionsData,
      setMessages,
      processChunkToolCalls,
      processToolCall,
      updateMessagesWithErrorState,
      setStreamingErrorMessage
    ]
  )

  const handleStreamResponse = useCallback(
    async (input: string | FormData) => {
      setIsStreaming(true)

      const formData = input instanceof FormData ? input : new FormData()
      if (typeof input === 'string') {
        formData.append('message', input)
      }

      setMessages((prevMessages) => {
        if (prevMessages.length >= 2) {
          const lastMessage = prevMessages[prevMessages.length - 1]
          const secondLastMessage = prevMessages[prevMessages.length - 2]
          if (
            lastMessage.role === 'agent' &&
            lastMessage.streamingError &&
            secondLastMessage.role === 'user'
          ) {
            return prevMessages.slice(0, -2)
          }
        }
        return prevMessages
      })

      addMessage({
        role: 'user',
        content: formData.get('message') as string,
        created_at: Math.floor(Date.now() / 1000)
      })

      addMessage({
        role: 'agent',
        content: '',
        tool_calls: [],
        streamingError: false,
        created_at: Math.floor(Date.now() / 1000) + 1
      })

      const streamState: StreamState = {
        lastContent: '',
        newSessionId: sessionId,
        sessionName: formData.get('message') as string
      }
      try {
        const endpointUrl = constructEndpointUrl(selectedEndpoint)

        let RunUrl: string | null = null

        if (mode === 'team' && teamId) {
          RunUrl = APIRoutes.TeamRun(endpointUrl, teamId)
        } else if (mode === 'workflow' && workflowId) {
          RunUrl = APIRoutes.WorkflowRun(endpointUrl, workflowId)
        } else if (mode === 'agent' && agentId) {
          RunUrl = APIRoutes.AgentRun(endpointUrl).replace(
            '{agent_id}',
            agentId
          )
        }

        if (!RunUrl) {
          updateMessagesWithErrorState()
          setStreamingErrorMessage(
            'Please select an agent, team or workflow first.'
          )
          setIsStreaming(false)
          return
        }

        formData.append('stream', 'true')
        formData.append('session_id', sessionId ?? '')

        // Create headers with auth token if available
        const headers: Record<string, string> = {}
        if (authToken) {
          headers['Authorization'] = `Bearer ${authToken}`
        }

        await streamResponse({
          apiUrl: RunUrl,
          headers,
          requestBody: formData,
          onChunk: (chunk: RunResponse) => handleChunk(chunk, streamState),
          onError: (error) => {
            updateMessagesWithErrorState()
            setStreamingErrorMessage(error.message)
            if (streamState.newSessionId) {
              setSessionsData(
                (prevSessionsData) =>
                  prevSessionsData?.filter(
                    (session) => session.session_id !== streamState.newSessionId
                  ) ?? null
              )
            }
          },
          onComplete: () => {}
        })
      } catch (error) {
        updateMessagesWithErrorState()
        setStreamingErrorMessage(
          error instanceof Error ? error.message : String(error)
        )
        if (streamState.newSessionId) {
          setSessionsData(
            (prevSessionsData) =>
              prevSessionsData?.filter(
                (session) => session.session_id !== streamState.newSessionId
              ) ?? null
          )
        }
      } finally {
        focusChatInput()
        setIsStreaming(false)
      }
    },
    [
      setMessages,
      addMessage,
      updateMessagesWithErrorState,
      selectedEndpoint,
      authToken,
      streamResponse,
      agentId,
      teamId,
      workflowId,
      mode,
      setStreamingErrorMessage,
      setIsStreaming,
      focusChatInput,
      setSessionsData,
      sessionId,
      handleChunk
    ]
  )

  /**
   * Resumes a paused run (HITL) via the continue endpoint and streams the
   * remaining events into the current last agent message.
   */
  const continueRun = useCallback(
    async (runId: string, runSessionId: string) => {
      const endpointUrl = constructEndpointUrl(selectedEndpoint)

      let ContinueUrl: string | null = null

      if (mode === 'team' && teamId) {
        ContinueUrl = APIRoutes.TeamRunContinue(endpointUrl, teamId, runId)
      } else if (mode === 'workflow' && workflowId) {
        ContinueUrl = APIRoutes.WorkflowRunContinue(
          endpointUrl,
          workflowId,
          runId
        )
      } else if (mode === 'agent' && agentId) {
        ContinueUrl = APIRoutes.AgentRunContinue(endpointUrl, agentId, runId)
      }

      if (!ContinueUrl) {
        setStreamingErrorMessage(
          'Please select an agent, team or workflow first.'
        )
        return
      }

      setIsStreaming(true)

      const formData = new FormData()
      formData.append('tools', '')
      formData.append('session_id', runSessionId)
      formData.append('stream', 'true')

      // Create headers with auth token if available
      const headers: Record<string, string> = {}
      if (authToken) {
        headers['Authorization'] = `Bearer ${authToken}`
      }

      const streamState: StreamState = {
        lastContent: '',
        newSessionId: runSessionId,
        sessionName: ''
      }

      try {
        await streamResponse({
          apiUrl: ContinueUrl,
          headers,
          requestBody: formData,
          onChunk: (chunk: RunResponse) => handleChunk(chunk, streamState),
          onError: (error) => {
            updateMessagesWithErrorState()
            setStreamingErrorMessage(error.message)
          },
          onComplete: () => {}
        })
      } catch (error) {
        updateMessagesWithErrorState()
        setStreamingErrorMessage(
          error instanceof Error ? error.message : String(error)
        )
      } finally {
        focusChatInput()
        setIsStreaming(false)
      }
    },
    [
      selectedEndpoint,
      authToken,
      mode,
      agentId,
      teamId,
      workflowId,
      streamResponse,
      handleChunk,
      updateMessagesWithErrorState,
      setStreamingErrorMessage,
      setIsStreaming,
      focusChatInput
    ]
  )

  return { handleStreamResponse, continueRun }
}

export default useAIChatStreamHandler
