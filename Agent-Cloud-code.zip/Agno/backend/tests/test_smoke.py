"""冒烟测试：无需 LLM key，验证装配与认证边界。

运行：MOONSHOT_API_KEY=dummy pytest tests/test_smoke.py
（构造 Agent 不发起模型调用；仅验证 AgentOS 装配、建表、认证拦截）
"""
import os

os.environ.setdefault("MOONSHOT_API_KEY", "dummy-for-smoke")
os.environ.setdefault("AGNO_DB_FILE", "smoke_test.db")

import time

import jwt
from fastapi.testclient import TestClient

from app.main import app
from app.settings import get_settings


def _admin_token() -> str:
    """与 scripts/make_token.py 同构的 HS256 admin token。"""
    now = int(time.time())
    payload = {
        "sub": "t1:admin",
        "scope": "agent_os:admin",
        "scopes": ["agent_os:admin"],
        "iat": now,
        "exp": now + 3600,
    }
    return jwt.encode(payload, get_settings().jwt_secret, algorithm="HS256")


def _auth_headers() -> dict:
    return {"Authorization": f"Bearer {_admin_token()}"}


def test_health_ok():
    client = TestClient(app)
    resp = client.get("/health")
    assert resp.status_code == 200


def test_auth_required_on_sessions():
    client = TestClient(app)
    resp = client.get("/sessions")
    assert resp.status_code in (401, 403), f"未认证应被拒，实际 {resp.status_code}"


def test_wrong_token_rejected():
    client = TestClient(app)
    resp = client.get("/sessions", headers={"Authorization": "Bearer wrong-token"})
    assert resp.status_code in (401, 403)


def test_workflows_include_content_pipeline():
    client = TestClient(app)
    resp = client.get("/workflows", headers=_auth_headers())
    assert resp.status_code == 200
    ids = [w.get("id") for w in resp.json()]
    assert "content-pipeline" in ids, f"/workflows 缺少 content-pipeline，实际 {ids}"


def test_agents_include_builtin():
    client = TestClient(app)
    resp = client.get("/agents", headers=_auth_headers())
    assert resp.status_code == 200
    ids = [a.get("id") for a in resp.json()]
    assert "assistant" in ids, f"/agents 缺少 assistant，实际 {ids}"
    assert "deep-researcher" in ids, f"/agents 缺少 deep-researcher，实际 {ids}"


def test_tool_catalog_ok():
    client = TestClient(app)
    resp = client.get("/console/tool-catalog", headers=_auth_headers())
    assert resp.status_code == 200
    names = [t["name"] for t in resp.json()]
    assert "run_in_sandbox" in names, f"tool-catalog 缺少 run_in_sandbox，实际 {names}"


def test_console_agent_form_404_on_missing_component():
    client = TestClient(app)
    resp = client.get("/console/agents/not-exist-component", headers=_auth_headers())
    assert resp.status_code == 404
