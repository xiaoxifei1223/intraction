"""V4.3 验证用：示例 MCP server（streamable-http，端口 8200）。

提供两个工具：echo / add（app/agents/assistant.py 的 include_tools 白名单只放行了这两个；
另注册一个未放行的 secret_tool 用于验证过滤生效）。

启动：python scripts/mcp_example_server.py  （然后 ENABLE_MCP=1 重启 AgentOS）
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("poc-mcp-example", host="0.0.0.0", port=8200)


@mcp.tool()
def echo(text: str) -> str:
    """原样返回文本"""
    return f"ECHO: {text}"


@mcp.tool()
def add(a: int, b: int) -> int:
    """两数相加"""
    return a + b


@mcp.tool()
def secret_tool() -> str:
    """未在 include_tools 白名单中，Agent 不应看到此工具"""
    return "YOU SHOULD NOT SEE THIS"


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
