"""V1 验证：SSE 流式消费 + 断线重连（resume/replay）+ cancel。

用法（先启动 AgentOS 与沙箱服务，并先 make_token 拿 token）：
  python scripts/sse_client.py --token <JWT> --message "你好，介绍一下你自己"
  python scripts/sse_client.py --token <JWT> --message "..." --kill-after 3   # 3 秒后断开再 resume
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

import argparse
import json
import time

import httpx

BASE = "http://localhost:8000"


def consume(resp: httpx.Response, seen: list[str], max_seconds: float | None = None) -> str | None:
    """消费 SSE 流，返回最后一个 run_id；max_seconds 到点抛中断模拟断线。"""
    run_id = None
    start = time.time()
    for line in resp.iter_lines():
        if max_seconds and time.time() - start > max_seconds:
            raise TimeoutError("simulated disconnect")
        if not line:
            continue
        if line.startswith("event:"):
            etype = line[6:].strip()
            seen.append(etype)
            print(f"  event: {etype}")
        elif line.startswith("data:"):
            try:
                data = json.loads(line[5:].strip())
                run_id = data.get("run_id") or run_id
                if data.get("content"):
                    print(data["content"], end="", flush=True)
            except json.JSONDecodeError:
                pass
    print()
    return run_id


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--token", required=True)
    parser.add_argument("--message", default="用三句话介绍多租户 SaaS。")
    parser.add_argument("--agent", default="assistant")
    parser.add_argument("--session", default=f"sse-demo-{int(time.time())}")
    parser.add_argument("--kill-after", type=float, default=None, help="N 秒后模拟断线并重连")
    args = parser.parse_args()

    headers = {"Authorization": f"Bearer {args.token}"}
    payload = {"message": args.message, "stream": "true",
               "session_id": args.session, "user_id": None}

    seen: list[str] = []
    run_id = None
    print(f"[v1] POST /agents/{args.agent}/runs (stream)")
    with httpx.Client(base_url=BASE, headers=headers, timeout=300) as client:
        try:
            with client.stream("POST", f"/agents/{args.agent}/runs",
                               data={k: v for k, v in payload.items() if v}) as resp:
                print(f"[v1] status={resp.status_code}")
                resp.raise_for_status()
                run_id = consume(resp, seen, max_seconds=args.kill_after)
        except TimeoutError:
            print(f"\n[v1] 模拟断线！run_id={run_id}，尝试 resume 重连...")
            with client.stream("POST", f"/agents/{args.agent}/runs/{run_id}/resume") as resp:
                print(f"[v1] resume status={resp.status_code}")
                consume(resp, seen)

    print("\n[v1] 事件类型清单（去重）:")
    for e in dict.fromkeys(seen):
        print(f"  - {e}")
    print("[v1] 完成。把上方事件清单填入 AC-A.1.1 报告。")


if __name__ == "__main__":
    main()
