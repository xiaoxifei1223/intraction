"""T18：MCP include_tools 白名单过滤验证（in-process，无需重启后端）。

前置：先启动示例 MCP server：
    python scripts/mcp_example_server.py   # 端口 8200

断言：MCPTools(url=..., transport="streamable-http", include_tools=["echo","add"])
初始化后工具列表只有 echo/add，secret_tool 不可见。

用法：python scripts/verify_mcp.py
"""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

from agno.tools.mcp import MCPTools


async def main() -> None:
    print("[t18] 连接 MCP server http://localhost:8200/mcp (streamable-http)，include_tools=['echo','add']")
    tools = MCPTools(
        url="http://localhost:8200/mcp",
        transport="streamable-http",
        include_tools=["echo", "add"],
    )
    await tools.connect()

    # agno 2.x：工具以 Function 形式注册在 toolkit.functions
    names = sorted(tools.functions.keys())
    print("[t18] 白名单过滤后 Agent 可见的工具:", names)

    ok = names == ["add", "echo"]
    print(f"[t18] 断言: 只有 echo/add={ok}；secret_tool 可见={'secret_tool' in names}")
    await tools.close()

    print("===== T18 结果:", "PASS ✅" if ok else "FAIL ❌", "=====")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    asyncio.run(main())
