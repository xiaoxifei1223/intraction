"""签发测试 JWT（HS256）。

用法：
  python scripts/make_token.py --sub t1:u1 --scope "agents:read agents:run"
  python scripts/make_token.py --sub t1:admin --scope "agent_os:admin" --days 1

租户编码（E1）：sub 格式 "{tenant_id}:{user_id}"，网关层未来强制前缀一致性。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

import argparse
import time

import jwt

from app.settings import get_settings


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sub", required=True, help='格式 "{tenant}:{user}"，如 t1:u1')
    parser.add_argument("--scope", default="agents:read agents:run", help="空格分隔的 scope")
    parser.add_argument("--days", type=int, default=7)
    args = parser.parse_args()

    if ":" not in args.sub:
        raise SystemExit('sub 必须是 "{tenant}:{user}" 格式')

    now = int(time.time())
    payload = {
        "sub": args.sub,
        "scope": args.scope,
        "scopes": args.scope.split(),  # 兼容两种 claim 形态
        "iat": now,
        "exp": now + args.days * 86400,
    }
    token = jwt.encode(payload, get_settings().jwt_secret, algorithm="HS256")
    print(token)


if __name__ == "__main__":
    main()
