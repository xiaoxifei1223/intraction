"""T15：Team coordinate 委派验证（release-team，Researcher + Writer）。

断言：
1. 流式事件中观察到 leader 向 Researcher、Writer 两个成员的委派（delegate_task_to_member /
   成员 ToolCall 事件），即 coordinate 委派真实发生；
2. 最终有汇总输出。

用法：python scripts/verify_team.py
"""
from __future__ import annotations

import asyncio
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

from app.main import team  # 装配好的 release-team
from app.settings import step

SESSION_ID = f"t15-team-{int(time.time())}"


async def main() -> None:
    delegations: list[str] = []      # 成员委派记录
    member_runs: set[str] = set()    # 出现过的成员 agent id
    final_parts: list[str] = []

    step(f"release-team 运行: session={SESSION_ID}")
    stream = team.arun(
        "调研一下 WASM 在服务端的优势，写成简报。",
        user_id="t15-user", session_id=SESSION_ID,
        stream=True, stream_events=True,
    )
    async for event in stream:
        etype = getattr(event, "event", "") or ""
        agent_id = getattr(event, "agent_id", None)
        tool = getattr(event, "tool", None)

        if etype == "ToolCallStarted" and tool is not None:
            tname = getattr(tool, "tool_name", "") or ""
            targs = getattr(tool, "tool_args", None) or {}
            print(f"  [leader tool] {tname} {str(targs)[:120]}")
            if "delegate" in tname or "transfer" in tname:
                member = targs.get("member_id") or targs.get("agent_id") or str(targs)
                delegations.append(str(member))
        # 成员 run 事件带成员 agent_id
        if agent_id and agent_id not in ("release-team",):
            member_runs.add(agent_id)
        if etype in ("TeamRunContent",):
            content = getattr(event, "content", None)
            if isinstance(content, str):
                final_parts.append(content)

    final_text = "".join(final_parts)
    print("\n[t15] 委派记录:", delegations)
    print("[t15] 出现过的成员 agent_id:", sorted(member_runs))
    print("[t15] 最终输出长度:", len(final_text))
    print("[t15] 最终输出摘录:", final_text[:300].replace("\n", " "))

    has_researcher = any("researcher" in d.lower() for d in delegations) or "researcher" in member_runs
    has_writer = any("writer" in d.lower() for d in delegations) or "writer" in member_runs
    has_output = len(final_text) > 100

    print(f"\n[t15] 断言: Researcher 被调用={has_researcher} Writer 被调用={has_writer} 有汇总输出={has_output}")
    ok = has_researcher and has_writer and has_output
    print("===== T15 结果:", "PASS ✅" if ok else "FAIL ❌", "=====")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    asyncio.run(main())
