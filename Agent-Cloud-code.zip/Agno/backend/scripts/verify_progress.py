"""T13：SessionContext Progress 字段更新机制验证实验。

源码结论（agno 2.8.2）：
- progress 由「抽取 LLM」在后台任务中通过 save_session_context(summary, goal, plan, progress) 工具写入；
  agent 主流程没有任何代码会自动把已完成步骤写进 progress —— 完全由抽取模型判断。
- 关键时序（agent/_run.py step 7 vs step 9）：learning 抽取任务在【模型调用之前】启动，
  且只快照当时的 run_messages（system+history+本轮 user），看不到本轮 assistant 的回复与工具结果。
  => 本轮完成的步骤最早只能在【下一轮】的抽取中被标记为 progress（滞后一轮）。

本实验：同一 session 跑两个 run，逐轮读 learnings 表观察 goal/plan/progress 变化。

用法：python scripts/verify_progress.py
"""
from __future__ import annotations

import asyncio
import json
import sqlite3
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

from app.main import assistant  # 装配好的 assistant（含 LearningMachine session_context 规划模式）
from app.settings import get_settings, step

SESSION_ID = f"t13-progress-{int(time.time())}"
USER = "t13-user"


def read_context() -> dict | None:
    db = sqlite3.connect(get_settings().db_file)
    row = db.execute(
        "select content from learnings where learning_type='session_context' and session_id=?",
        (SESSION_ID,),
    ).fetchone()
    db.close()
    return json.loads(row[0]) if row else None


def show(tag: str) -> dict | None:
    ctx = read_context()
    if ctx is None:
        print(f"[{tag}] learnings 无记录")
        return None
    print(f"[{tag}] goal    : {ctx.get('goal')}")
    print(f"[{tag}] plan    : {json.dumps(ctx.get('plan'), ensure_ascii=False)}")
    print(f"[{tag}] progress: {json.dumps(ctx.get('progress'), ensure_ascii=False)}")
    return ctx


async def main() -> None:
    print(f"session_id = {SESSION_ID}")

    step("Run 1：两步沙箱任务（规划+执行）...")
    r1 = await assistant.arun(
        "帮我做两件事：1) 在沙箱 /workspace 创建目录 t13demo；"
        "2) 在 t13demo 里写文件 hello.txt 内容为 hi。请规划并执行。",
        user_id=USER, session_id=SESSION_ID,
    )
    print("Run 1 回复摘录:", (r1.content or "")[:200].replace("\n", " "))
    step("等待后台 learning 抽取落库 ...")
    await asyncio.sleep(15)
    ctx1 = show("after run1")

    step("Run 2：同 session 追问进展 ...")
    r2 = await assistant.arun(
        "刚才那两件事的进展如何？都完成了吗？",
        user_id=USER, session_id=SESSION_ID,
    )
    print("Run 2 回复摘录:", (r2.content or "")[:200].replace("\n", " "))
    await asyncio.sleep(15)
    ctx2 = show("after run2")

    print("\n===== 判定 =====")
    p1 = (ctx1 or {}).get("progress") or []
    p2 = (ctx2 or {}).get("progress") or []
    print(f"run1 后 progress 条数 = {len(p1)}；run2 后 progress 条数 = {len(p2)}")
    if p2 and not p1:
        print("符合源码推论：progress 滞后一轮，由抽取 LLM 在看到历史中的已完成工作后填写。")
    elif p1:
        print("run1 后即出现 progress（抽取模型仅凭 user 请求填写），仍属 LLM 判断行为。")
    else:
        print("两轮后 progress 仍为空 —— 抽取模型未填写，需进一步排查。")


if __name__ == "__main__":
    asyncio.run(main())
