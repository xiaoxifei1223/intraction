"""V2 验证：多用户隔离 + 漏网端点扫描（工程约束 E2）。

前置：
  1. AgentOS 运行中（authorization + user_isolation 开启）；
  2. 先以用户 A 的 token 跑过至少一个 run（产生 session/记忆数据）；
  3. 准备 A、B 两个 token（make_token.py，sub 分别为 t1:u1 / t1:u2）。

用法：
  python scripts/isolation_scan.py --token-a <A_JWT> --token-b <B_JWT> [--session-id <A的session>]
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

import argparse

import httpx

BASE = "http://localhost:8000"

# 覆盖 AgentOS 主要资源端点（2.8.2）
RESOURCE_PATHS = [
    "/sessions",
    "/sessions/{sid}",
    "/memories",
    "/metrics",
    "/traces",
    "/approvals",
    "/eval-runs",
    "/agents",
    "/agents/assistant/runs",  # POST 语义不同，仅 GET 探测路由存在性
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--token-a", required=True)
    parser.add_argument("--token-b", required=True)
    parser.add_argument("--session-id", default=None, help="用户 A 的 session_id（越权访问靶标）")
    args = parser.parse_args()

    ha = {"Authorization": f"Bearer {args.token_a}"}
    hb = {"Authorization": f"Bearer {args.token_b}"}

    report: list[tuple[str, str, str]] = []  # (check, result, detail)

    with httpx.Client(base_url=BASE, timeout=30) as client:
        # 0. 认证基线
        r = client.get("/sessions")
        report.append(("无 token 访问 /sessions", "PASS" if r.status_code in (401, 403) else "FAIL",
                       f"status={r.status_code}"))

        # 1. 各端点跨用户访问
        for path in RESOURCE_PATHS:
            real = path.format(sid=args.session_id or "nonexistent")
            ra = client.get(real, headers=ha)
            rb = client.get(real, headers=hb)
            if "{sid}" in path and args.session_id:
                # B 访问 A 的 session：必须 403/404（不泄露存在性）
                ok = rb.status_code in (403, 404)
                report.append((f"B 访问 A 的资源 {real}", "PASS" if ok else "FAIL",
                               f"A={ra.status_code} B={rb.status_code}"))
            else:
                leak = False
                if rb.status_code == 200 and ra.status_code == 200:
                    # 列表类端点：B 的结果不应包含 A 的数据（以 session_id 出现为粗判据）
                    if args.session_id and args.session_id in rb.text:
                        leak = True
                report.append((f"GET {real}（B 视角不含 A 数据）",
                               "FAIL" if leak else "PASS",
                               f"A={ra.status_code} B={rb.status_code}"))

        # 2. 越权写操作（B cancel A 的 run —— 无 run_id 时仅验证端点鉴权形态）
        if args.session_id:
            rb = client.post(f"/agents/assistant/runs/fake-run-id/cancel", headers=hb)
            report.append(("B cancel 不属于自己的 run", "PASS" if rb.status_code in (401, 403, 404) else "FAIL",
                           f"status={rb.status_code}"))

    print("\n===== 隔离扫描报告 =====")
    fails = 0
    for check, result, detail in report:
        mark = "✅" if result == "PASS" else "❌"
        if result == "FAIL":
            fails += 1
        print(f"{mark} {check}  ({detail})")
    print(f"\n总计 {len(report)} 项，失败 {fails} 项 → 填入 AC-A.2.2")


if __name__ == "__main__":
    main()
