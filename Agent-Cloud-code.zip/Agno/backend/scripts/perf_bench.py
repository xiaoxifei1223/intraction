"""V5 性能实测：冷启动 / 首 token 延迟 / 50 轮长会话（E3 膨胀曲线）/ 10 并发（E7）。

用法：
  python scripts/perf_bench.py                # 全部
  python scripts/perf_bench.py --only latency
  python scripts/perf_bench.py --only long-session --turns 50
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

import argparse
import asyncio
import sqlite3
import statistics
import time

from app.models import describe_backend
from app.settings import get_settings, step

USER = "t1:u1"


async def bench_latency(n: int = 20) -> None:
    from app.main import assistant

    step(f"首 token 延迟基准：{n} 次同 prompt")
    samples: list[float] = []
    for i in range(n):
        started = time.time()
        stream = assistant.arun("用一句话解释缓存。", user_id=USER,
                                session_id=f"bench-lat-{i}", stream=True)  # async generator，不 await
        async for event in stream:
            if getattr(event, "event", "") == "RunContent":
                samples.append((time.time() - started) * 1000)
                break
    samples.sort()
    p50 = statistics.median(samples)
    p95 = samples[int(len(samples) * 0.95) - 1]
    print(f"\n[perf] 首 token 延迟 ms：P50={p50:.0f}  P95={p95:.0f}  min={samples[0]:.0f}  max={samples[-1]:.0f}")


async def bench_long_session(turns: int = 50) -> None:
    from app.main import assistant

    s = get_settings()
    session_id = f"bench-long-{int(time.time())}"
    step(f"长会话基准：{turns} 轮（每轮记录延迟 + sessions 行大小）")
    print(f"{'turn':>4} {'latency_s':>10} {'row_bytes':>12}")
    for i in range(1, turns + 1):
        started = time.time()
        await assistant.arun(f"第{i}轮：用一句话说一个分布式系统知识点（不要重复之前说过的）。",
                             user_id=USER, session_id=session_id)
        latency = time.time() - started
        row_bytes = -1
        try:
            with sqlite3.connect(s.db_file) as conn:
                cur = conn.execute("SELECT length(raw_json) FROM sessions WHERE session_id=?",
                                   (session_id,)) if _has_raw_json(conn) else conn.execute(
                    "SELECT length(session_data)+length(COALESCE(runs,'')) FROM sessions WHERE session_id=?",
                    (session_id,))
                row = cur.fetchone()
                row_bytes = row[0] if row else -1
        except sqlite3.Error:
            pass
        print(f"{i:>4} {latency:>10.1f} {row_bytes:>12}", flush=True)


def _has_raw_json(conn: sqlite3.Connection) -> bool:
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sessions)")]
    return "raw_json" in cols


async def bench_concurrency(runs: int = 10) -> None:
    from app.main import assistant

    step(f"并发基准：{runs} 个 run（2 用户均分）")
    started = time.time()

    async def one(i: int) -> str:
        user = f"t1:u{i % 2 + 1}"
        await assistant.arun(f"并发测试 {i}：回答 1+1=?", user_id=user,
                             session_id=f"bench-conc-{i}")
        return user

    results = await asyncio.gather(*(one(i) for i in range(runs)), return_exceptions=True)
    errors = [r for r in results if isinstance(r, Exception)]
    elapsed = time.time() - started
    print(f"\n[perf] 并发完成 {len(results) - len(errors)}/{len(results)}，失败 {len(errors)}，总耗时 {elapsed:.1f}s")
    for e in errors:
        print(f"  ERROR: {e}")


def bench_cold_start() -> None:
    step("冷启动基准：import + 装配耗时（近似服务启动）")
    started = time.time()
    import importlib

    import app.main  # noqa: F401
    importlib.reload(app.main)
    print(f"[perf] 装配耗时 {time.time() - started:.1f}s（uvicorn 启动另加 ~1-2s）")


async def amain() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--only", choices=["cold", "latency", "long-session", "concurrency"], default=None)
    parser.add_argument("--turns", type=int, default=50)
    args = parser.parse_args()

    step(f"性能基准启动，LLM 后端: {describe_backend()}")
    which = args.only
    if which in (None, "cold"):
        bench_cold_start()
    if which in (None, "latency"):
        await bench_latency()
    if which in (None, "long-session"):
        await bench_long_session(args.turns)
    if which in (None, "concurrency"):
        await bench_concurrency()


if __name__ == "__main__":
    asyncio.run(amain())
