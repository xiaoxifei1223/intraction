"""DeepResearch 运行器：流式打印 + 保存报告 + 打印规划追踪。

用法：
  python scripts/run_deepresearch.py "你的研究问题"
  python scripts/run_deepresearch.py "..." --session my-research --user t1:u1
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))  # backend/ 入 sys.path

import argparse
import asyncio
import time
from pathlib import Path

from app.main import db
from app.agents.deepresearch import build_deepresearch
from app.models import describe_backend
from app.settings import step


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("question", help="研究问题")
    parser.add_argument("--session", default=f"dr-{int(time.time())}")
    parser.add_argument("--user", default="t1:u1")
    parser.add_argument("--out", default=None, help="报告输出文件（默认 research_report_<ts>.md）")
    args = parser.parse_args()

    step(f"DeepResearch 启动 | 后端: {describe_backend()} | session: {args.session}")
    agent = build_deepresearch(db)

    started = time.time()
    tool_calls: list[str] = []

    out = Path(args.out or f"research_report_{int(time.time())}.md")
    step(f"报告将增量写入: {out}（即使中断也保留已生成部分）")

    with out.open("w", encoding="utf-8") as fout:
        stream = agent.arun(args.question, user_id=args.user, session_id=args.session,
                            stream=True, stream_events=True)
        async for event in stream:
            etype = getattr(event, "event", "")
            if etype == "ToolCallStarted":
                name = getattr(getattr(event, "tool", None), "tool_name", "?")
                tool_calls.append(name)
                step(f"工具调用: {name}")
            elif etype == "RunContent":
                content = getattr(event, "content", None)
                if content:
                    print(content, end="", flush=True)
                    fout.write(content)  # 增量写盘
                    fout.flush()

    elapsed = time.time() - started
    report = out.read_text(encoding="utf-8")

    print(f"\n\n{'=' * 60}")
    step(f"完成 | 耗时 {elapsed:.0f}s | 工具调用 {len(tool_calls)} 次 {tool_calls}")
    step(f"报告已保存: {out}")

    # 规划模式追踪（SessionContext）
    try:
        ctx = agent.learning_machine.session_context_store.get(session_id=args.session)
        if ctx:
            print(f"\n--- SessionContext（规划追踪） ---")
            print(f"Goal: {getattr(ctx, 'goal', None)}")
            print(f"Plan: {getattr(ctx, 'plan', None)}")
            print(f"Progress: {getattr(ctx, 'progress', None)}")
    except Exception as e:
        step(f"session_context 读取失败（不影响主流程）: {e}")


if __name__ == "__main__":
    asyncio.run(main())
