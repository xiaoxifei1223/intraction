"""T12：跨会话记忆验证（user_profile + user_memory，LearningMachine ALWAYS 模式）。

步骤：
1. HTTP 跑 assistant（user_id=t12-user，session A）：告诉它两條事实。
2. 等后台 learning 抽取落库，断言 learnings 表出现该用户的 user_profile/user_memory 记录。
3. 开全新 session B 再问，断言回答包含 Rust 与 星海。

token 自动从 frontend/agent-ui/.env.local 的 NEXT_PUBLIC_OS_SECURITY_KEY 读取。

用法：python scripts/verify_memory.py
前置：AgentOS 后端运行在 8000 端口。
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
import time
from pathlib import Path

import httpx

BACKEND_ROOT = Path(__file__).resolve().parents[1]
BASE = "http://localhost:8000"
USER = "t12-user"
TS = int(time.time())
SESSION_A = f"t12-mem-a-{TS}"
SESSION_B = f"t12-mem-b-{TS}"


def load_token() -> str:
    env = BACKEND_ROOT.parent / "frontend" / "agent-ui" / ".env.local"
    m = re.search(r"NEXT_PUBLIC_OS_SECURITY_KEY=(\S+)", env.read_text(encoding="utf-8"))
    assert m, "未在 frontend/agent-ui/.env.local 找到 NEXT_PUBLIC_OS_SECURITY_KEY"
    return m.group(1)


def jwt_sub(token: str) -> str:
    """解码 JWT payload 的 sub（HTTP 模式下 AgentOS 以 JWT sub 为有效 user_id，
    会覆盖请求体里的 user_id 参数）。"""
    import base64

    payload = token.split(".")[1]
    payload += "=" * (-len(payload) % 4)
    return json.loads(base64.urlsafe_b64decode(payload))["sub"]


def run_agent(client: httpx.Client, message: str, session_id: str) -> str:
    resp = client.post(
        f"/agents/assistant/runs",
        data={"message": message, "stream": "false",
              "session_id": session_id, "user_id": USER},
        timeout=300,
    )
    resp.raise_for_status()
    data = resp.json()
    return data.get("content") or ""


def query_learnings(effective_user: str) -> list[tuple[str, str]]:
    db = sqlite3.connect(BACKEND_ROOT / "agno.db")
    rows = db.execute(
        "select learning_type, content from learnings where user_id=?", (effective_user,)
    ).fetchall()
    db.close()
    return rows


def main() -> None:
    token = load_token()
    ok = True

    with httpx.Client(base_url=BASE, headers={"Authorization": f"Bearer {token}"}) as client:
        print(f"[t12] Run A: session={SESSION_A} user={USER}")
        content_a = run_agent(
            client,
            "请记住两件关于我的事：我最喜欢的编程语言是 Rust，我的团队叫星海。",
            SESSION_A,
        )
        print("[t12] Run A 回复摘录:", content_a[:150].replace("\n", " "))

        print("[t12] 等待后台 learning 抽取落库 ...")
        time.sleep(20)

        eff_user = jwt_sub(token)
        print(f"[t12] 注：HTTP 模式有效 user_id 取 JWT sub = {eff_user!r}（请求体 user_id={USER!r} 被覆盖）")
        rows = query_learnings(eff_user)
        print(f"[t12] learnings 表中 user_id={eff_user} 的记录数: {len(rows)}")
        profile_ok = memory_ok = False
        for lt, content in rows:
            if lt == "session_context":
                continue
            snippet = content[:300].replace("\n", " ")
            print(f"  - {lt}: {snippet}")
            if lt == "user_profile":
                profile_ok = True
            if lt == "user_memory":
                memory_ok = True
        # 落库断言：user_memory（或 user_profile）存在且内容包含两条事实
        def decoded(c: str) -> str:
            try:
                return json.dumps(json.loads(c), ensure_ascii=False)
            except Exception:
                return c

        mem_hit = any(
            lt in ("user_memory", "user_profile")
            and "rust" in decoded(content).lower() and "星海" in decoded(content)
            for lt, content in rows
        )
        if not ((profile_ok or memory_ok) and mem_hit):
            print("[t12] FAIL: learnings 表无包含 Rust/星海 的 user_profile/user_memory 落库记录")
            ok = False
        else:
            print(f"[t12] 落库断言 PASS: user_profile={profile_ok} user_memory={memory_ok} 且含 Rust+星海")

        print(f"[t12] Run B: 全新 session={SESSION_B} 提问")
        content_b = run_agent(
            client,
            "我最喜欢的编程语言是什么？我的团队叫什么？",
            SESSION_B,
        )
        print("[t12] Run B 回复:", content_b[:400].replace("\n", " "))

        has_rust = "rust" in content_b.lower()
        has_team = "星海" in content_b
        print(f"[t12] 召回断言: 包含 Rust={has_rust} 包含 星海={has_team}")
        if not (has_rust and has_team):
            ok = False

    print("\n===== T12 结果:", "PASS ✅" if ok else "FAIL ❌", "=====")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
