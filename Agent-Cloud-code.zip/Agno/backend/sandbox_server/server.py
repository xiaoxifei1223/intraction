"""自研沙箱服务（V4）：allocate / exec / release。

- docker SDK 管理容器；每 sandbox_id 一个容器，工作目录 /workspace 持久至 release；
- 网络模式：none（默认，完全断网）或 restricted（白名单演示：仅允许宿主机网关，用于 AC-A.4.2）；
- TTL 看门狗：超时未活动的沙箱自动回收；
- 信任边界：PoC 直挂宿主机 docker daemon，仅限本机验证（生产改 runsc/K8s，见主 Spec）。

启动：uvicorn sandbox_server.server:app --port 8100
"""
from __future__ import annotations

import threading
import time

import docker
from docker.errors import NotFound
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from app.settings import get_settings

IDLE_TTL_SECONDS = 1800
MAX_OUTPUT = 64 * 1024

app = FastAPI(title="poc-sandbox-server")
_client = None
_sandboxes: dict[str, dict] = {}  # id -> {container, last_used}
_lock = threading.Lock()


def _get_client():
    """延迟初始化 docker client：Docker Desktop 未启动时给出可读错误而非 import 崩溃。"""
    global _client
    if _client is None:
        try:
            _client = docker.from_env()
        except docker.errors.DockerException as e:
            raise HTTPException(503, f"Docker 不可用（请启动 Docker Desktop）: {e}")
    return _client


class AllocReq(BaseModel):
    sandbox_id: str = "default"
    network: str = "none"  # none | restricted


class ExecReq(BaseModel):
    command: str
    timeout: int = 60


def _allocate(sandbox_id: str, network: str) -> None:
    s = get_settings()
    client = _get_client()
    try:
        c = client.containers.get(f"poc-sbx-{sandbox_id}")
        c.start() if c.status != "running" else None
    except NotFound:
        network_mode = "none" if network == "none" else "bridge"
        c = client.containers.run(
            s.sandbox_image,
            command="sleep infinity",
            name=f"poc-sbx-{sandbox_id}",
            detach=True,
            network_mode=network_mode,
            working_dir="/workspace",
            mem_limit="512m",
            nano_cpus=1_000_000_000,
            cap_drop=["ALL"],
            security_opt=["no-new-privileges"],
            pids_limit=256,
        )
        c.exec_run(["mkdir", "-p", "/workspace"])
    _sandboxes[sandbox_id] = {"container": c, "last_used": time.time()}


@app.post("/sandboxes")
def allocate(req: AllocReq):
    with _lock:
        if req.sandbox_id not in _sandboxes:
            _allocate(req.sandbox_id, req.network)
    return {"sandbox_id": req.sandbox_id, "status": "ready"}


@app.post("/sandboxes/{sandbox_id}/exec")
def exec_cmd(sandbox_id: str, req: ExecReq):
    with _lock:
        entry = _sandboxes.get(sandbox_id)
    if not entry:
        raise HTTPException(404, f"sandbox {sandbox_id} not allocated")
    entry["last_used"] = time.time()
    result = entry["container"].exec_run(
        ["sh", "-c", req.command],
        workdir="/workspace",
        demux=False,
    )
    output = (result.output or b"").decode("utf-8", errors="replace")
    truncated = len(output) > MAX_OUTPUT
    return {
        "output": output[:MAX_OUTPUT],
        "exit_code": result.exit_code,
        "truncated": truncated,
    }


@app.delete("/sandboxes/{sandbox_id}")
def release(sandbox_id: str):
    with _lock:
        entry = _sandboxes.pop(sandbox_id, None)
    if not entry:
        return {"released": False}
    try:
        entry["container"].remove(force=True)
    except NotFound:
        pass
    return {"released": True}


@app.get("/health")
def health():
    return {"ok": True, "sandboxes": list(_sandboxes)}


def _reaper():
    while True:
        time.sleep(60)
        now = time.time()
        with _lock:
            expired = [k for k, v in _sandboxes.items() if now - v["last_used"] > IDLE_TTL_SECONDS]
        for sid in expired:
            release(sid)


threading.Thread(target=_reaper, daemon=True).start()
