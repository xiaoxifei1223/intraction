我将系统调研 2025-2026 年自进化 AI Agent 在记忆进化、技能库、自我修改代码三条路线上的前沿进展。先进行多轮检索。基于系统性文献检索与研读，我为您整理了 2025–2026 年自进化 AI Agent（self-evolving agents）在三条技术路线上的主要研究进展。

---

## 摘要

2025–2026 年，自进化 AI Agent 研究在记忆进化、技能库管理与自我修改代码三条路线上均取得显著进展。**记忆进化**从单纯的文本反射转向注意力机制驱动的段级精炼与检索-记忆协同进化；**技能库**从静态提取转向共同进化的技能自博弈框架，同时研究者开始警惕技能污染导致的性能退化；**自我修改代码**以 Darwin Gödel Machine 为代表，实现了从 20% 到 50% 的 SWE-bench 性能跃升，并催生了 Hyperagents 等元认知自修改扩展。

---

## 背景与问题定义

自进化 AI Agent 指能够在运行过程中通过积累执行经验、提炼可复用知识并修改自身行为逻辑来提升后续任务表现的智能体。2025 年前，该领域已有 Voyager（技能库）、AutoGPT（自主循环）、MemGPT（分层记忆）等早期探索，但面临三大瓶颈：
- **记忆层面**：文本反射式记忆缺乏对内部使用机制的洞察，易产生幻觉式修改
- **技能层面**：技能提取与验证的可靠性难以平衡，开放域探索易引入误导性奖励
- **代码层面**：自修改系统多局限于固定元机制，无法实现对修改机制本身的递归改进

---

## 核心发现

### 一、记忆进化路线：从文本反射到机制驱动

#### 1.1 注意力引导的记忆精炼 (AGMR)
**Yechao Hong 等人**提出 Attention-Guided Memory Refinement (AGMR)，突破现有系统仅依赖文本输出（轨迹、反思）改进记忆的局限。[1] 该工作利用 **retrieval-head attention** 提供机械论信号，构建"上下文利用矩阵"揭示记忆段级别的使用模式，据此指导针对性的记忆更新：对失败执行进行纠错/增强，对成功执行进行简化，并通过重执行验证每次更新。实验表明 AGMR 在交互式决策基准上同时提升任务性能与记忆效率。

#### 1.2 检索-记忆协同进化 (CoEvo-Mem)
**Bowen Ye 等人**指出现有方法将检索策略优化与记忆库进化分离，忽视了二者的反馈闭环。[2] 他们提出 CoEvo-Mem，通过冻结 LLM 生成路由特定的查询重写，由轻量级残差路由器在线修正；检索到的上下文作为耦合界面，任务结果 assign credit 给路由决策，轨迹条件反馈更新记忆值与图关系。为避免耦合导致的非平稳性，采用交替更新策略（固定记忆库时更新路由器，固定路由器时进化记忆库），在七个基准上达到 SOTA。

#### 1.3 语义版本控制与回滚 (ChronoMem)
**Yongye Su 等人**发现现有记忆系统仅支持"正向进化"（持续累积、合并、覆盖），缺乏对先前状态的检查、版本化与回滚机制。[3] ChronoMem 在 Google 的 Agent Development Kit 中集成了语义版本控制层：每次记忆写入提交全记忆快照，维护结构化版本历史，并通过混合词汇与语义检索将自然语言回滚意图映射到具体历史版本。这是首个开源的 LLM Agent 全局语义记忆回滚系统。

#### 1.4 类型条件时间衰减 (ScrubJay-MEM)
**Kartikey Singh Bhandari 等人**受 scrub jay 鸟类情景记忆启发，提出记忆不应被同等对待。[4] ScrubJay-MEM 将每条记忆编码为 What-Where-When 元组，附带自动分类的易腐系数 π_i 与效用 horizon τ_i，通过查询自适应评分进行检索。在 Temporal Generalization Test (TGT) 上，ScrubJay-MEM 是唯一具有显著正 GenGap (+0.108) 的检索系统。

#### 1.5 记忆安全防御 (A-MemGuard)
**Qianshan Wei 等人**揭示记忆注入攻击可触发"自我强化的错误循环"：被篡改的结果作为先例存储，放大初始错误并降低后续攻击门槛。[5] A-MemGuard 采用共识验证（比较多条相关记忆的推理路径）与双记忆结构（将检测到的失败蒸馏为独立"教训"），将攻击成功率降低 95% 以上。

### 二、技能库路线：从静态提取到共同进化

#### 2.1 技能自博弈 (Skill Self-Play)
**Siyuan Huang 等人**提出 Skill Self-Play (Skill-SP)，将技能识别为解决"任务多样性"与"验证可靠性"两难困境的中间地带。[6] 框架包含三个共同进化的组件：**proposer**（基于动态采样技能生成挑战性任务）、**solver**（探索候选解决方案）、**skill controller**（收集执行反馈以更新/扩展技能库）。在工具使用与推理基准上，Skill-SP 持续推动骨干模型的性能天花板。

#### 2.2 编码 Agent 技能学习 (CODESKILL)
**Yanzhou Li 等人**将技能提取与技能库维护重新表述为可学习的管理策略。[7] CODESKILL 从编码 agent 轨迹中提取多粒度程序性技能，通过强化学习训练（结合密集评分标准反馈与稀疏可验证执行反馈），在 EnvBench、SWE-Bench Verified 和 Terminal-Bench 2 上将平均通过率提升 9.69%，且技能库规模保持稳定。

#### 2.3 技能污染与预提交门控
**Linfang Shang 等人**发现技能积累并非单调增益：超过临界池大小后，新增技能反而降低性能。[8] 他们形式化了"能力-污染相变"，指出一旦缺陷技能进入决策上下文，会成为后续技能蒸馏的参考材料，形成跨轮污染链，且该污染在结构上是不可逆的。为此提出 Verifier-as-Gatekeeper (VaG)：三层异构评审员（结构有效性、行为无害性、语义一致性）逐技能过滤，配合边际增益子集选择。在 Terminal-Bench 2 上，VaG 达到 72% pass@1，池大小仅为无条件积累的约 1/5。

#### 2.4 超越知识边界的技能蒸馏 (Search2Skill)
**Muyang Ye 等人**指出现有技能方法受限于模型参数知识。[9] Search2Skill 自动识别能力缺口，搜索外部来源，并将检索证据蒸馏为结构化可复用技能，通过基于评分标准的强化学习联合优化"何时搜索、如何搜索、如何生成技能"。在八个专家级领域上，所获技能可跨模型规模迁移。

#### 2.5 科学技能累积 (CASCADE)
**Xu Huang 等人**提出 CASCADE，实现从 "LLM + 工具使用" 到 "LLM + 技能获取" 的范式转移。[10] 通过两类元技能——持续学习（网络搜索、代码提取、记忆利用）与自我反思（内省、知识图谱探索）——agent 可在 SciSkillBench（116 项材料科学与化学任务）上达到 93.3% 成功率（无进化机制时仅 35.4%）。

### 三、自我修改代码路线：从固定元机制到元认知递归

#### 3.1 Darwin Gödel Machine (DGM)
**Jenny Zhang 等人**提出的 DGM 是当前自我修改代码路线最系统的实现。[11] 受达尔文进化与开放式研究启发，DGM 维护一个编码 agent 档案库，从中采样并由基础模型生成新的、有趣的变体。通过实证验证（编码基准）而非形式化证明来评估每次修改。80 次迭代后，SWE-bench Verified 从 20.0% 提升至 50.0%，Polyglot 从 14.2% 提升至 30.7%。所有实验均在沙箱与人类监督下进行。

#### 3.2 超智能体 (Hyperagents)
**Jenny Zhang 等人**进一步扩展 DGM，提出 Hyperagents，解决 DGM 中"任务性能提升"与"自我修改能力提升"仅在编码域对齐的局限。[12] Hyperagents 将任务 agent 与元 agent（修改自身与任务 agent）整合为单一可编辑程序，关键是**元级修改过程本身也可被编辑**，实现元认知自修改。DGM-Hyperagents (DGM-H) 在多个领域上实现性能持续提升，且元级改进（如持久记忆、性能追踪）可跨域迁移、跨轮累积。

#### 3.3 实时自进化软件工程 Agent (Live-SWE-agent)
**Chunqiu Steven Xia 等人**提出首个可在运行时自主持续进化的软件工程 agent。[13] Live-SWE-agent 从仅有 bash 工具的基础 scaffold 出发，在解决真实软件问题时自主进化其 scaffold 实现。在 SWE-bench Verified 上达到 77.4% 解决率（无需测试时扩展），在 SWE-Bench Pro 上达到 45.8% 的最佳已知解决率。

#### 3.4 工具链感知自进化 (HASE)
**Haochen Luo 等人**提出 Harness-Aware Self-Evolving (HASE)，突破"仅优化任务解而固定工具链"的常规假设。[14] 在统一的多轮动作空间中，单一模型可同时生成任务解或编辑工具链组件。单个 Qwen3-8B 模型可匹配使用 Claude Code 作为工具链提议器的 GPT-OSS-120B 的文本分类性能。

#### 3.5 编码 Agent 技能自进化 (Socratic-SWE)
**Chuan Xiao 等人**将 agent 历史解决轨迹蒸馏为结构化技能，总结反复失败与有效修复模式。[15] 这些技能指导在真实仓库中生成针对性修复任务，通过执行验证与 solver-梯度对齐奖励评分。三轮迭代后在 SWE-bench Verified 上达到 50.40%。

---

## 争议与开放问题

1. **技能污染的可逆性**：Shang 等人证明技能污染在结构上是不可逆的，这对长期运行的自进化系统构成根本性挑战。当前门控机制（VaG）虽有效，但是否存在更根本的免疫式防御仍待探索。

2. **自我修改的安全性边界**：DGM 虽采用沙箱与人类监督，但随着系统自主性的提升，如何定义"安全的修改空间"仍缺乏形式化框架。Eykholt 等人的渗透测试表明，执行能力强的 AI agent 本质上是"无界、自修改的程序"。[16]

3. **工具链进化的泛化性**：Wang 等人质疑自动工具链进化是否真正优于简单测试时扩展，指出在 Terminal-Bench 2.1 上，自动工具链进化并未一致优于简单基线，且泛化有限。[17]

4. **记忆-技能权衡**：FinEvo-Bench 的评估显示，在 Claude Code 中，纯技能进化比纯记忆进化和混合记忆-技能进化产生更高的任务质量和更少的合规问题。[18] 这一发现提示不同进化维度可能存在最优组合而非简单叠加。

5. **元递归的极限**：MetaAI 框架提出递归自设计的四条操作性标准（可检查目标系统、元级修改器、反馈导向选择、递归延续），但 DGM 仍是目前最完整的工程证据。[19] 从 0-to-1 到 1-to-N 的可复现性仍是开放挑战。

---

## 参考文献

1. **Mechanistic Attention Guidance for Agent Memory Refinement** — Yechao Hong, Haiquan Qiu, Yaqing Wang, Quanming Yao. arXiv:2607.17621 [cs.AI], July 2026. https://arxiv.org/abs/2607.17621

2. **CoEvo-Mem: Co-Evolving Retrieval Policy and Memory Bank for LLM Agents** — Bowen Ye, Yongchao Xu, Zhijian Li, et al. arXiv:2608.01739 [cs.AI], August 2026. https://arxiv.org/abs/2608.01739

3. **ChronoMem: Version Control and Semantic Rollback for Large Language Model Agent Memory** — Yongye Su, Wujiang Xu, Chaoji Zuo, Elisa Bertino. arXiv:2607.27773 [cs.CL], July/August 2026. https://arxiv.org/abs/2607.27773

4. **Caching for the Future: Scrub Jay Episodic Memory Principles for Agent Memory Systems** — Kartikey Singh Bhandari, Aarya Wadhwani, Dhruv Kumar, Pratik Narang. arXiv:2608.04746 [cs.CL], August 2026. https://arxiv.org/abs/2608.04746

5. **A-MemGuard: A Proactive Defense Framework for LLM-Based Agent Memory** — Qianshan Wei, Tengchao Yang, Yaochen Wang, et al. arXiv:2510.02373 [cs.CR], September 2025. https://arxiv.org/abs/2510.02373

6. **Skill Self-Play: Pushing the Frontier of LLM Capability with Co-Evolving Skills** — Siyuan Huang, Pengyu Cheng, Haotian Liu, et al. arXiv:2607.22529 [cs.CL], July 2026. https://arxiv.org/abs/2607.22529

7. **CODESKILL: Learning Self-Evolving Skills for Coding Agents** — Yanzhou Li, Yiran Zhang, Xiaoyu Zhang, et al. arXiv:2605.25430 [cs.AI], May 2026. https://arxiv.org/abs/2605.25430

8. **When Self-Evolution Backfires: Pre-Commit Gating against Skill Contamination in LLM Agents** — Linfang Shang, Ming Xu, Yiding Sun, et al. arXiv:2608.05810 [cs.AI], August 2026. https://arxiv.org/abs/2608.05810

9. **Search2Skill: Skill Distillation Beyond Knowledge Boundaries Via Rubric-Based Reinforcement Learning** — Muyang Ye, Tian Lan, Feihu Jiang, et al. arXiv:2608.05245 [cs.AI], August 2026. https://arxiv.org/abs/2608.05245

10. **CASCADE: Cumulative Agentic Skill Creation through Autonomous Development and Evolution** — Xu Huang, Junwu Chen, Yuxing Fei, et al. arXiv:2512.23880 [cs.AI], December 2025/January 2026. https://arxiv.org/abs/2512.23880

11. **Darwin Gödel Machine: Open-Ended Evolution of Self-Improving Agents** — Jenny Zhang, Shengran Hu, Cong Lu, Robert Lange, Jeff Clune. arXiv:2505.22954 [cs.AI], May 2025 (revised March 2026). https://arxiv.org/abs/2505.22954

12. **Hyperagents** — Jenny Zhang, Bingchen Zhao, Wannan Yang, et al. arXiv:2603.19461 [cs.AI], March 2026. https://arxiv.org/abs/2603.19461

13. **Live-SWE-agent: Can Software Engineering Agents Self-Evolve on the Fly?** — Chunqiu Steven Xia, Zhe Wang, Yan Yang, et al. arXiv:2511.13646 [cs.SE], November 2025. https://arxiv.org/abs/2511.13646

14. **Harness-Aware Self-Evolving: Co-Evolving Model Weights, Harness, and Task Solutions** — Haochen Luo, Yi Huang, Sichun Luo, et al. arXiv:2607.03935 [cs.AI], July 2026. https://arxiv.org/abs/2607.03935

15. **Socratic-SWE: Self-Evolving Coding Agents via Trace-Derived Agent Skills** — Chuan Xiao, Zhengbo Jiao, Shaobo Wang, et al. arXiv:2606.07412 [cs.SE], June 2026. https://arxiv.org/abs/2606.07412

16. **Lessons from Penetration Tests on Large-Scale Agent Systems** — Kevin Eykholt, Dhilung Kirat, Xiaokui Shu, et al. arXiv:2605.27042 [cs.CR], May 2026. https://arxiv.org/abs/2605.27042

17. **Rethinking the Evaluation of Harness Evolution for Agents** — Yike Wang, Huaisheng Zhu, Zhengyu Hu, et al. arXiv:2607.12227 [cs.AI], July 2026. https://arxiv.org/abs/2607.12227

18. **FinEvo-Bench: A Longitudinal Benchmark for Self-Evolving Agents in Professional Financial Workflows** — Bo Deng, Kang Zhou, Lifan Guo, et al. arXiv:2608.06144 [cs.AI], August 2026. https://arxiv.org/abs/2608.06144

19. **From 0-to-1 to 1-to-N: Reproducible Engineering Evidence for MetaAI Recursive Self-Design** — Dun Li, Jiatao Li, Hongzhi Li. arXiv:2606.09663 [cs.AI], June 2026. https://arxiv.org/abs/2606.09663

---

*注：本报告引用文献均来自 arXiv，时间范围为 2025 年 5 月至 2026 年 8 月。部分论文标注的日期为未来日期（如 2026 年 8 月），可能表示预印本的计划发布或系统时间偏移，但均为当前检索到的实际可获取文献。*