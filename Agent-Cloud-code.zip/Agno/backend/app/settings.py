"""PoC 全局配置：从 .env 加载。"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BACKEND_ROOT = Path(__file__).resolve().parents[1]  # Agno/backend
load_dotenv(BACKEND_ROOT / ".env")


@dataclass(frozen=True)
class Settings:
    llm_backend: str  # "kimi" | "litellm"
    moonshot_api_key: str | None
    kimi_base_url: str
    kimi_model: str
    litellm_base_url: str | None
    litellm_api_key: str | None
    litellm_model: str
    jwt_secret: str
    db_backend: str  # "sqlite" | "postgres"
    db_file: str
    database_url: str | None
    sandbox_server: str
    sandbox_image: str
    enable_mcp: bool


def get_settings() -> Settings:
    return Settings(
        llm_backend=os.getenv("LLM_BACKEND", "kimi").lower(),
        moonshot_api_key=os.getenv("MOONSHOT_API_KEY") or None,
        kimi_base_url=os.getenv("KIMI_BASE_URL", "https://api.moonshot.cn/v1"),
        kimi_model=os.getenv("KIMI_MODEL", "kimi-k2.6"),
        litellm_base_url=os.getenv("LITELLM_BASE_URL") or None,
        litellm_api_key=os.getenv("LITELLM_API_KEY") or None,
        litellm_model=os.getenv("LITELLM_MODEL", "kimi-k2.6"),
        jwt_secret=os.getenv("JWT_SECRET", "poc-secret-change-me"),
        db_backend=os.getenv("DB_BACKEND", "sqlite").lower(),
        db_file=os.getenv("AGNO_DB_FILE", str(BACKEND_ROOT / "agno.db")),
        database_url=os.getenv("DATABASE_URL") or None,
        sandbox_server=os.getenv("SANDBOX_SERVER", "http://localhost:8100"),
        sandbox_image=os.getenv("SANDBOX_IMAGE", "python:3.12-slim"),
        enable_mcp=os.getenv("ENABLE_MCP", "0") == "1",
    )


def step(msg: str) -> None:
    print(f"[poc] {msg}", flush=True)
