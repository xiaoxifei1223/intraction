"""AgentOS 主装配（00 文档 §2 范式）。

启动：uvicorn app.main:app --host 0.0.0.0 --port 8000
注意：telemetry=False + AGNO_TELEMETRY=false 双保险（E6）。
"""
from __future__ import annotations

from agno.os import AgentOS
from agno.registry import Registry

from .agents.assistant import build_assistant
from .agents.deepresearch import build_deepresearch
from .agents.team import build_team
from .auth import build_authorization_config
from .console import init_console, router as console_router
from .db import build_db
from .models import make_model
from .workflows.content_pipeline import build_content_pipeline
from .tools.sandbox_exec import run_in_sandbox
from .tools.sensitive_op import deploy_to_production
from .tools.web_fetch import fetch_webpage


db = build_db()
assistant = build_assistant(db)
deep_researcher = build_deepresearch(db)
team = build_team(db)
content_pipeline = build_content_pipeline(db)

# Registry：可序列化 config 中非序列化对象（工具/模型/db）的水合目录。
# 控制台创建的 agent config 里工具按名字从这里还原（路线 B 的关键）。
registry = Registry(
    name="poc-registry",
    tools=[run_in_sandbox, fetch_webpage, deploy_to_production],
    models=[make_model()],
    dbs=[db],
)

agent_os = AgentOS(
    id="poc-os",
    name="Agno PoC OS",
    agents=[assistant, deep_researcher],
    teams=[team],
    workflows=[content_pipeline],
    db=db,
    registry=registry,
    authorization=True,
    authorization_config=build_authorization_config(),
    cors_allowed_origins=["http://localhost:3000"],  # agent-ui 开发服务器
    tracing=True,      # OTel → traces/spans 表 + /traces 端点
    telemetry=False,   # E6：私有化必关
)

app = agent_os.get_app()

# 控制台 API（工具目录 + 表单装配创建 agent/版本）
init_console(db, registry)
app.include_router(console_router)
