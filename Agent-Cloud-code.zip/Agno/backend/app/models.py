"""模型工厂（Agno 原生模型类）。

- kimi:    agno.models.moonshot.MoonShot（国内端点 .cn）
- litellm: agno.models.openai.like.OpenAILike 直连 LiteLLM Proxy（OpenAI 兼容，不依赖 litellm 包）
"""
from __future__ import annotations

from .settings import get_settings


def make_model(**overrides):
    s = get_settings()
    if s.llm_backend == "litellm":
        if not (s.litellm_base_url and s.litellm_api_key):
            raise RuntimeError("LLM_BACKEND=litellm 需要 LITELLM_BASE_URL / LITELLM_API_KEY")
        from agno.models.openai.like import OpenAILike

        return OpenAILike(id=s.litellm_model, base_url=s.litellm_base_url,
                          api_key=s.litellm_api_key, **overrides)

    if not s.moonshot_api_key:
        raise RuntimeError("请在 .env 配置 MOONSHOT_API_KEY（或切换 LLM_BACKEND=litellm）")
    from agno.models.moonshot import MoonShot

    return MoonShot(id=s.kimi_model, base_url=s.kimi_base_url,
                    api_key=s.moonshot_api_key, **overrides)


def describe_backend() -> str:
    s = get_settings()
    if s.llm_backend == "litellm":
        return f"litellm({s.litellm_base_url}, model={s.litellm_model})"
    return f"kimi({s.kimi_base_url}, model={s.kimi_model})"
