"""主验证 Agent（00 文档 §2 标准装配范式）。

- LearningMachine：user_profile + user_memory（跨会话记忆，V3.1）
- SessionContext 规划模式：enable_planning=True（V3.2）
- 工具：自研沙箱（V4）+ @approval 敏感操作（V3.3）+ 可选 MCP（V4.3）
- 红线：不给内置 ShellTools/PythonTools（E4）
"""
from __future__ import annotations

from agno.agent import Agent
from agno.db.sqlite import SqliteDb
from agno.learn import LearningMachine, SessionContextConfig

from ..models import make_model
from ..settings import get_settings
from ..tools.sandbox_exec import run_in_sandbox
from ..tools.sensitive_op import deploy_to_production

INSTRUCTIONS = """\
你是一个任务执行型助手。工作准则：
1. 多步骤任务先规划再执行，执行中跟踪进度（你的 session context 会自动记录 goal/plan/progress）。
2. 需要运行代码/命令时，一律使用 run_in_sandbox 工具（隔离容器），不要假设本地环境。
3. deploy_to_production 是高风险操作，需要管理员审批后才会真正执行。
4. 用户的重要偏好和事实要记住（你的 learning 体系会自动沉淀）。
5. 回复使用 markdown，简洁、要点化。
"""


def build_assistant(db: SqliteDb) -> Agent:
    s = get_settings()
    tools: list = [run_in_sandbox, deploy_to_production]

    if s.enable_mcp:
        # V4.3：MCP 示例 server（streamable-http）。ENABLE_MCP=1 时需先启动 scripts/mcp_example_server.py
        from agno.tools.mcp import MCPTools

        tools.append(MCPTools(url="http://localhost:8200/mcp",
                              transport="streamable-http",
                              include_tools=["echo", "add"]))  # include_tools 白名单过滤验证

    return Agent(
        id="assistant",
        name="PoC Assistant",
        model=make_model(),
        db=db,
        tools=tools,
        learning=LearningMachine(
            user_profile=True,   # 跨会话用户事实
            user_memory=True,    # 跨会话用户观察
            session_context=SessionContextConfig(
                enable_planning=True,  # 规划模式：goal/plan/progress 快照注入 prompt
            ),
        ),
        add_history_to_context=True,
        num_history_runs=10,
        markdown=True,
        instructions=INSTRUCTIONS,
    )
