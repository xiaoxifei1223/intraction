"""多代理验证 Team（V3.4）：coordinate 模式 + Team 级 SessionContext 规划模式。"""
from __future__ import annotations

from agno.agent import Agent
from agno.db.sqlite import SqliteDb
from agno.learn import LearningMachine, SessionContextConfig
from agno.team import Team
from agno.team.team import TeamMode

from ..models import make_model


def build_team(db: SqliteDb) -> Team:
    researcher = Agent(
        id="researcher",
        name="Researcher",
        model=make_model(),
        role="负责调研与要点归纳，输出不超过 5 条要点。",
        markdown=True,
    )
    writer = Agent(
        id="writer",
        name="Writer",
        model=make_model(),
        role="负责把调研要点写成结构化报告（结论/要点/风险三段式）。",
        markdown=True,
    )
    return Team(
        id="release-team",
        name="Release Team",
        model=make_model(),
        members=[researcher, writer],
        mode=TeamMode.coordinate,
        db=db,
        learning=LearningMachine(
            session_context=SessionContextConfig(enable_planning=True),
        ),
        markdown=True,
        instructions="你是协调者：调研类子任务委派给 Researcher，成文委派给 Writer；汇总后回复。",
    )
