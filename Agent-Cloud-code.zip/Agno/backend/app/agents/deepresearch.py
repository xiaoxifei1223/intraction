"""DeepResearch Agent：科研向深度调研。

Agno 原生装配：
- DuckDuckGoTools：迭代搜索；
- fetch_webpage：读原文；
- run_in_sandbox：数据计算/图表/验证性实验（隔离容器）；
- LearningMachine + SessionContext 规划模式：goal/plan/progress 全程追踪；
- 输出：带引用的结构化研究报告（markdown）。
"""
from __future__ import annotations

from agno.agent import Agent
from agno.db.sqlite import SqliteDb
from agno.learn import LearningMachine, SessionContextConfig
from agno.tools.duckduckgo import DuckDuckGoTools

from ..models import make_model
from ..tools.sandbox_exec import run_in_sandbox
from ..tools.web_fetch import fetch_webpage

INSTRUCTIONS = """\
你是一名严谨的科研调研助手（deep research）。工作方式：

1. **规划**：先把研究问题拆解为 3-6 个子问题（你的 session context 会自动追踪 goal/plan/progress）。
2. **检索**：用 duckduckgo_search 迭代搜索——先宽后窄；每次搜索后评估结果质量，必要时换关键词（中英文都试）。
3. **研读**：对高价值来源用 fetch_webpage 读原文；区分一手来源（论文/官方文档）与二手转述。
4. **验证**：涉及数据/计算时，用 run_in_sandbox 跑代码验证，不要凭感觉给数字。
5. **成文**：输出结构化研究报告（markdown）：
   - `## 摘要`（150 字内）
   - `## 背景与问题定义`
   - `## 核心发现`（分小节，每个论断后用 [n] 标注来源编号）
   - `## 争议与开放问题`
   - `## 参考文献`（编号列表：标题 + URL）
6. **纪律**：不做无来源的断言；找不到证据就明说"未找到可靠来源"；时间敏感信息标注日期。
"""


def build_deepresearch(db: SqliteDb) -> Agent:
    return Agent(
        id="deep-researcher",
        name="Deep Researcher",
        model=make_model(),
        db=db,
        tools=[
            DuckDuckGoTools(fixed_max_results=5, timeout=20),
            fetch_webpage,
            run_in_sandbox,
        ],
        learning=LearningMachine(
            user_profile=True,
            user_memory=True,
            session_context=SessionContextConfig(enable_planning=True),
        ),
        add_history_to_context=True,
        num_history_runs=10,
        markdown=True,
        instructions=INSTRUCTIONS,
    )
