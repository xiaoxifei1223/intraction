"""AgentOS 认证/授权装配（JWT HS256 + user_isolation）。

PoC 用对称密钥；生产应改 RS256/JWKS（AuthorizationConfig 支持 jwks_file）。
租户编码方案（工程约束 E1）：JWT sub = "{tenant_id}:{user_id}"，
未来由网关层强制 sub 前缀与签发租户一致；PoC 用 scripts/make_token.py 模拟。
"""
from __future__ import annotations

from agno.os.config import AuthorizationConfig

from .settings import get_settings


def build_authorization_config() -> AuthorizationConfig:
    s = get_settings()
    return AuthorizationConfig(
        verification_keys=[s.jwt_secret],
        algorithm="HS256",
        user_isolation=True,  # 多用户数据隔离开关（默认关，必须显式开）
    )
