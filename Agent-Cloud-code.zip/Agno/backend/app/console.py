"""控制台后端（路线 B：UI 表单创建 Agent）。

职责（PoC 精简版）：
- GET  /console/tool-catalog   可用工具目录（供 UI 勾选）
- POST /console/agents         按表单装配 config → 创建组件 + 首个版本（draft）
- GET  /console/agents/{id}    当前版本的表单化视图（config 反向映射回 AgentForm，供编辑回显）
- POST /console/agents/{id}/versions  创建新版本（同装配逻辑）
- DELETE /console/agents/{id}/versions/{version}  删除 draft 版本（current/published 拒删）
- 发布/回滚直接用 AgentOS 原生端点：POST /components/{id}/configs/current（set_current_config）

物化链路（全部 Agno 原生）：组件 config 存 agno_component_configs 表 →
请求时 resolve_agent → db.get_config(current_version) → Agent.from_dict(cfg, registry) → 可运行。
"""
from __future__ import annotations

import hashlib
import json
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from agno.tools.function import Function

from .models import make_model
from .settings import step

router = APIRouter(prefix="/console", tags=["console"])


def _serialize_tool(source) -> dict[str, Any]:
    """把 registry 中的工具（Function/Toolkit 成员/裸 callable）序列化为合法 Function dict。"""
    if isinstance(source, Function):
        return source.to_dict()
    if hasattr(source, "to_dict"):
        return source.to_dict()
    if callable(source):
        return Function.from_callable(source).to_dict()
    return {"name": getattr(source, "name", str(source)), "parameters": {}}

# 模块级注入（main.py 启动时调用 init_console）
_db = None
_registry = None


def init_console(db, registry) -> None:
    global _db, _registry
    _db, _registry = db, registry


def _tool_catalog() -> list[dict[str, Any]]:
    """从 Registry 提取可授权工具目录。"""
    catalog = []
    for name, source in _registry._entrypoint_lookup.items():
        try:
            d = _serialize_tool(source)
        except Exception:
            continue
        catalog.append({"name": d.get("name", name),
                        "description": (d.get("description") or "")[:200],
                        "parameters": d.get("parameters")})
    return sorted(catalog, key=lambda t: t["name"])


@router.get("/tool-catalog")
def tool_catalog() -> list[dict[str, Any]]:
    return _tool_catalog()


class AgentForm(BaseModel):
    name: str
    description: str = ""
    instructions: str = ""
    tools: list[str] = []                      # 勾选的工具名（必须在 catalog 内）
    user_profile: bool = False                 # LearningMachine stores
    user_memory: bool = True
    session_context: bool = True               # 会话上下文（含规划）
    markdown: bool = True
    num_history_runs: int = 10


def _assemble_config(form: AgentForm, agent_name: str) -> dict[str, Any]:
    """表单 → 可序列化的 Agent config dict（与 Agent.to_dict() 同构）。"""
    catalog = {t["name"]: t for t in _tool_catalog()}
    unknown = [t for t in form.tools if t not in catalog]
    if unknown:
        raise HTTPException(400, f"未知工具: {unknown}（可选: {sorted(catalog)}）")

    model = make_model()
    tools = [_serialize_tool(_registry._entrypoint_lookup[name]) for name in form.tools]

    config: dict[str, Any] = {
        "model": {"id": model.id, "name": getattr(model, "name", model.id),
                  "provider": getattr(model, "provider", "")},
        "name": agent_name,
        "description": form.description or None,
        "instructions": form.instructions or None,
        "db": {"id": _db.id},
        "tools": tools,
        "learning": {
            "user_profile": form.user_profile,
            "user_memory": form.user_memory,
            "session_context": form.session_context,
        },
        "add_history_to_context": True,
        "num_history_runs": form.num_history_runs,
        "markdown": form.markdown,
    }
    return {k: v for k, v in config.items() if v is not None}


def _spec_hash(config: dict) -> str:
    return hashlib.sha256(json.dumps(config, sort_keys=True, default=str).encode()).hexdigest()[:16]


@router.post("/agents", status_code=201)
def create_agent(form: AgentForm):
    component_id = form.name.lower().replace(" ", "-")
    config = _assemble_config(form, form.name)
    try:
        from agno.db.base import ComponentType

        component, cfg = _db.create_component_with_config(
            component_id=component_id,
            component_type=ComponentType.AGENT,
            name=form.name,
            description=form.description,
            config=config,
            label=None,
            stage="draft",
            metadata={"spec_hash": _spec_hash(config), "created_by": "console"},
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    step(f"console: 创建 agent 组件 {component_id}（draft, spec_hash={_spec_hash(config)}）")
    return {"component": component, "spec_hash": _spec_hash(config)}


@router.get("/agents/{component_id}")
def get_agent_form(component_id: str):
    """返回当前版本的表单化视图（config → AgentForm 字段反向映射，供前端编辑回显）。

    原生 GET /components/{id} 只返回组件元数据、GET /components/{id}/configs/current
    返回原始 config blob；本端点额外做表单反向映射。
    """
    if _db.get_component(component_id) is None:
        raise HTTPException(404, f"组件 {component_id} 不存在")
    cfg_row = _db.get_config(component_id)  # version=None → current
    if cfg_row is None:
        # 尚无 current（全是 draft）时回退到最新版本
        versions = _db.list_configs(component_id, include_config=True)
        if not versions:
            raise HTTPException(404, f"组件 {component_id} 没有任何配置版本")
        cfg_row = versions[0]
    config = cfg_row.get("config") or {}
    learning = config.get("learning") or {}
    form = {
        "name": config.get("name") or component_id,
        "description": config.get("description") or "",
        "instructions": config.get("instructions") or "",
        "tools": [t.get("name") for t in config.get("tools") or [] if isinstance(t, dict) and t.get("name")],
        "user_profile": bool(learning.get("user_profile", False)),
        "user_memory": bool(learning.get("user_memory", True)),
        "session_context": bool(learning.get("session_context", True)),
        "markdown": bool(config.get("markdown", True)),
        "num_history_runs": config.get("num_history_runs", 10),
    }
    return {
        "component_id": component_id,
        "version": cfg_row.get("version"),
        "stage": cfg_row.get("stage"),
        "form": form,
    }


@router.delete("/agents/{component_id}/versions/{version}", status_code=204)
def delete_agent_version(component_id: str, version: int):
    """删除 draft 版本（console 层强约束：current/published 拒删）。

    原生 DELETE /components/{id}/configs/{version} 已存在，但底层 sqlite 实现只拒删
    current、不拒 published；本端点在调用前显式校验 stage，保证只有 draft 可删。
    """
    cfg_row = _db.get_config(component_id, version=version)
    if cfg_row is None:
        raise HTTPException(404, f"组件 {component_id} 版本 v{version} 不存在")
    if cfg_row.get("stage") != "draft":
        raise HTTPException(400, f"仅允许删除 draft 版本（v{version} 当前 stage={cfg_row.get('stage')}）")
    try:
        _db.delete_config(component_id, version=version)
    except ValueError as e:  # 底层仍会拒删 current 版本
        raise HTTPException(400, str(e))


@router.post("/agents/{component_id}/versions", status_code=201)
def create_version(component_id: str, form: AgentForm):
    if _db.get_component(component_id) is None:
        raise HTTPException(404, f"组件 {component_id} 不存在")
    config = _assemble_config(form, form.name)
    try:
        cfg = _db.upsert_config(
            component_id=component_id,
            config=config,
            stage="draft",
            notes=f"spec_hash={_spec_hash(config)} created_by=console",
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"config": cfg, "spec_hash": _spec_hash(config)}
