"""示例 Workflow（Phase 0 功能验证）：调研 → 成文 两步内容流水线。

用 agno 原生 Workflow + Step 装配，成员与 team.py 的 researcher/writer 同型。
注册进 AgentOS 后可通过 /workflows/{id}/runs（SSE）运行。
"""
from __future__ import annotations

from agno.agent import Agent
from agno.db.sqlite import SqliteDb
from agno.workflow import Step, Workflow

from ..models import make_model


def build_content_pipeline(db: SqliteDb) -> Workflow:
    researcher = Agent(
        id="wf-researcher",
        name="Researcher",
        model=make_model(),
        role="负责调研与要点归纳，输出不超过 5 条要点。",
        markdown=True,
    )
    writer = Agent(
        id="wf-writer",
        name="Writer",
        model=make_model(),
        role="负责把调研要点写成结构化报告（结论/要点/风险三段式）。",
        markdown=True,
    )
    return Workflow(
        id="content-pipeline",
        name="Content Pipeline",
        description="调研 → 成文 两步内容流水线（PoC 功能验证）",
        steps=[
            Step(name="调研", agent=researcher),
            Step(name="成文", agent=writer),
        ],
        db=db,
        telemetry=False,  # E6：私有化必关
    )
