"""HITL 审批示例工具（V3.3）：required 审批 + 职责分离验证。

@approval(type="required")：调用即暂停 run（RunPaused），写 approvals 表，
需管理员经 /approvals resolve 后 continue 才真正执行；发起者不能自审。
"""
from __future__ import annotations

from datetime import datetime, timezone

from agno.approval import approval


@approval(type="required")
def deploy_to_production(service: str, version: str) -> str:
    """把服务部署到生产环境（高风险操作，需管理员审批）。

    Args:
        service: 服务名
        version: 版本号
    """
    # PoC：不真正部署，记录即代表执行
    ts = datetime.now(timezone.utc).isoformat()
    return f"DEPLOYED service={service} version={version} at={ts}"
