"""网页正文抓取工具（DeepResearch 用）：抓 URL → 去标签 → 截断返回。"""
from __future__ import annotations

import re

import httpx

MAX_CHARS = 6000


def fetch_webpage(url: str) -> str:
    """抓取网页并返回纯文本正文（截断到 6000 字符）。

    Args:
        url: 要抓取的网页 URL（http/https）
    """
    try:
        resp = httpx.get(url, timeout=20, follow_redirects=True,
                         headers={"User-Agent": "Mozilla/5.0 (research-bot)"})
        resp.raise_for_status()
    except httpx.HTTPError as e:
        return f"FETCH_ERROR: {e}"

    html = resp.text
    # 粗粒度去脚本/样式/标签（PoC 够用；生产换 readability/trafilatura）
    html = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", html, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", html)
    text = re.sub(r"\s+", " ", text).strip()
    truncated = len(text) > MAX_CHARS
    return text[:MAX_CHARS] + ("\n...[TRUNCATED]" if truncated else "")
