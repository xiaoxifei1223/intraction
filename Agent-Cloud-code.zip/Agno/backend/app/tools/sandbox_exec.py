"""自研沙箱工具（工程约束 E4：内置 ShellTools/PythonTools 是 RCE 面，不上线）。

Agent 侧只是一个普通 Function tool，经 HTTP 调用独立的沙箱服务
（sandbox_server/，docker 容器隔离）。沙箱服务可独立部署、独立加固。
"""
from __future__ import annotations

import httpx

from ..settings import get_settings


def run_in_sandbox(command: str, timeout: int = 60) -> str:
    """在隔离沙箱容器中执行 shell 命令并返回输出。

    沙箱是临时 docker 容器（无网络或白名单网络），适合运行不可信代码。
    同一会话内文件在沙箱 /workspace 下持久，会话结束容器销毁。

    Args:
        command: 要执行的 shell 命令（在容器 /workspace 目录下执行）
        timeout: 超时秒数（默认 60）
    Returns:
        命令的 stdout/stderr 与退出码
    """
    s = get_settings()
    try:
        with httpx.Client(base_url=s.sandbox_server, timeout=timeout + 30) as client:
            # 幂等确保默认沙箱存在（PoC 每进程一个默认沙箱）
            client.post("/sandboxes", json={"sandbox_id": "default"})
            resp = client.post("/sandboxes/default/exec",
                               json={"command": command, "timeout": timeout})
            resp.raise_for_status()
            data = resp.json()
    except httpx.HTTPError as e:
        return f"SANDBOX_ERROR: {e}"

    output = data.get("output", "")
    exit_code = data.get("exit_code", -1)
    truncated = "（输出被截断）" if data.get("truncated") else ""
    return f"exit_code={exit_code}{truncated}\n{output}"
