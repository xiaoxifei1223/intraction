"""DB 工厂：按 DB_BACKEND 切换 SqliteDb / PostgresDb。

- DB_BACKEND=sqlite（默认）：走本地 SqliteDb（AGNO_DB_FILE）。
- DB_BACKEND=postgres：走 PostgresDb（DATABASE_URL），表名与 sqlite 同构。
  仅切换层代码——本地未起 PG 时请勿以 postgres 模式启动后端
  （PostgresDb 构造即建 engine，首次访问表时才真正连接）。
- 两种后端都不声明 knowledge_table —— 本期禁用 RAG（AC-A.2.4 实证点）。
"""
from __future__ import annotations

from agno.db.base import BaseDb

from .settings import get_settings

# 11 张显式声明的表（两种后端同构；不声明 knowledge_table）
_TABLE_NAMES = dict(
    session_table="sessions",
    memory_table="memories",
    metrics_table="metrics",
    eval_table="evals",
    traces_table="traces",
    spans_table="spans",
    approvals_table="approvals",
    learnings_table="learnings",
    components_table="agno_components",
    component_configs_table="agno_component_configs",
    component_links_table="agno_component_links",
)


def build_db() -> BaseDb:
    s = get_settings()
    if s.db_backend == "postgres":
        if not s.database_url:
            raise ValueError("DB_BACKEND=postgres 需要设置 DATABASE_URL")
        # 惰性导入：未安装 psycopg 时模块仍可导入（仅 sqlite 路径可用）
        from agno.db.postgres import PostgresDb

        return PostgresDb(
            db_url=s.database_url,
            # db_schema 用默认 "ai"
            **_TABLE_NAMES,
        )
    if s.db_backend != "sqlite":
        raise ValueError(f"未知 DB_BACKEND: {s.db_backend}（可选: sqlite | postgres）")
    from agno.db.sqlite import SqliteDb

    return SqliteDb(db_file=s.db_file, **_TABLE_NAMES)
