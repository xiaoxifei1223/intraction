# Agno/backend — Phase 0 PoC

> Spec：`Agno/docs/phase-0-poc/`（requirements/design/tasks）。内核 `agno==2.8.2`（锁版本），SQLite，禁 RAG。

## 快速开始

```bash
cd Agno/backend

# 1. 环境（已完成则跳过）
uv venv .venv --python 3.12
UV_INDEX_URL=https://mirrors.aliyun.com/pypi/simple/ uv pip install --python .venv/Scripts/python.exe -r requirements.txt

# 2. 配置
cp .env.example .env     # 填入 MOONSHOT_API_KEY（Kimi token）

# 3. 启动沙箱服务（终端 1，K2/K8 与 V4 需要；需 Docker Desktop 运行中）
.venv/Scripts/python -m uvicorn sandbox_server.server:app --port 8100

# 4. 启动 AgentOS（终端 2）
.venv/Scripts/python -m uvicorn app.main:app --port 8000

# 5. 冒烟测试（无需 LLM key）
MOONSHOT_API_KEY=dummy .venv/Scripts/python -m pytest tests/test_smoke.py -v
```

## 验证脚本对照（spec tasks）

| 脚本 | 验证项 | 用法 |
|---|---|---|
| `scripts/make_token.py` | V2 前置 | `python scripts/make_token.py --sub t1:u1 --scope "agents:read agents:run"` |
| `scripts/sse_client.py` | V1 SSE/断线重连 | `python scripts/sse_client.py --token <JWT> --kill-after 3` |
| `scripts/isolation_scan.py` | V2 隔离扫描 | `python scripts/isolation_scan.py --token-a <A> --token-b <B> --session-id <A的session>` |
| `scripts/mcp_example_server.py` | V4.3 前置 | `python scripts/mcp_example_server.py`，然后 `ENABLE_MCP=1` 重启 AgentOS |
| `scripts/run_task_suite.py` | V5 任务集 K1–K8 | `python scripts/run_task_suite.py [--only K1 K2]` |
| `scripts/perf_bench.py` | V5 性能 | `python scripts/perf_bench.py [--only latency\|long-session\|concurrency\|cold]` |

## 常用验证顺序（建议）

1. `pytest tests/test_smoke.py` —— 装配/认证边界（离线）
2. 签 token → `sse_client.py` —— V1 流式链路
3. A/B token → `isolation_scan.py` —— V2 隔离
4. `run_task_suite.py` —— V3/V4/V5 任务完成质量（K4 记忆、K5 审批、K6 规划、K7 多代理）
5. `perf_bench.py` —— 性能与长会话/并发

## 目录

```
app/            AgentOS 装配（main.py 入口；agents/tools/auth/models/settings）
sandbox_server/ 自研沙箱服务（docker 容器隔离，allocate/exec/release）
scripts/        验证脚本（上表）
tests/          pytest（冒烟为主，LLM 依赖的验证走 scripts）
```
