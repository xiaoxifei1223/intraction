# Agno Phase 0 · PoC — Design

| 状态 | draft v0.2 | 上游 | Agno/docs/00（技术基线与工程约束 E1–E8） |
|---|---|---|---|

## 1. 目录与组件

```
Agno/backend/
├── requirements.txt          # agno[os,sqlite,mcp]==2.8.2 + fastapi/uvicorn/httpx/pyjwt/docker/pytest
├── .env.example              # MOONSHOT_API_KEY / KIMI_MODEL / JWT_SECRET / LITELLM_*（预留）
├── app/
│   ├── main.py               # AgentOS 装配（00 文档 §2 范式）
│   ├── settings.py           # .env 加载
│   ├── models.py             # make_model()：MoonShot(.cn) | OpenAILike(LiteLLM Proxy，预留)
│   ├── agents/
│   │   ├── assistant.py      # 主验证 Agent：LearningMachine + 沙箱工具 + MCP 工具
│   │   └── team.py           # Team(coordinate)（V3.4）
│   ├── tools/
│   │   ├── sandbox_exec.py   # 自研沙箱 Function tool（V4）
│   │   └── sensitive_op.py   # @approval(required) 示例工具（V3.3）
│   └── auth.py               # JWT HS256 配置
├── sandbox_server/
│   └── server.py             # FastAPI + docker SDK：allocate/exec/release + 网络白名单
├── scripts/
│   ├── make_token.py         # 签发不同 sub/scope 的测试 JWT
│   ├── sse_client.py         # SSE 消费/断线重连验证（V1）
│   ├── isolation_scan.py     # 漏网端点扫描（V2，E2）
│   ├── run_task_suite.py     # 标准任务集执行器（V5，K1–K8）
│   └── perf_bench.py         # 冷启动/首 token/长会话/并发（V5）
└── tests/                    # pytest：记忆、审批流、落库断言
```

**frontend/**：本阶段留空。验证交互 = AgentOS Control Plane（连本地 runtime）+ scripts。

## 2. 关键设计

### 2.1 模型工厂

```python
def make_model():
    if backend == "litellm":      # 预留：OpenAI 兼容直连 LiteLLM Proxy，不装 litellm 包
        return OpenAILike(id=LITELLM_MODEL, base_url=LITELLM_BASE_URL, api_key=LITELLM_API_KEY)
    return MoonShot(id=KIMI_MODEL, base_url="https://api.moonshot.cn/v1", api_key=MOONSHOT_API_KEY)
```

### 2.2 持久层（SqliteDb，本期）

- 按 00 文档 §2 声明六张表；**不声明 knowledge 表**（RAG 禁用实证，AC-A.2.4）；
- 开 WAL 模式；并发表现纳入 V5.3 观察（E7）；
- 已知形态：run 内嵌 session 行 JSON（E3）→ V5.2 实测膨胀曲线。

### 2.3 认证与租户编码（V2）

- `AuthorizationConfig(verification_keys=[JWT_SECRET], algorithm="HS256", user_isolation=True)`；
- `make_token.py`：`sub="{tenant}:{uid}"`，scope 按测试矩阵（如 `agents:read agents:run`）；
- 租户方案（E1）：`sub` 强制 `{tenant}:{uid}` 格式，未来网关层校验前缀与签发租户一致；PoC 用 `t1:u1 / t1:u2 / t2:u1` 三角验证；
- `isolation_scan.py`：从 `app.routes` 反射全部端点，以"A 的资源 ID + B 的 token"逐一请求，断言非 2xx，输出报告（E2）。

### 2.4 验证 Agent 装配

严格按 00 文档 §2 范式。两个执行体：

- `assistant`（Agent）：LearningMachine（user_profile + user_memory + SessionContext 规划模式）+ 沙箱工具 + `@approval` 工具 + MCPTools；
- `release_team`（Team，mode=coordinate）：两个成员 Agent + Team 级 LearningMachine（SessionContext 规划）。

### 2.5 LearningMachine 两处验证点（V3.1/V3.2）

- **记忆**：T1 轮注入偏好 → 断言 db memories 落库 → 新 session 提问验证生效；
- **规划**：多轮任务每轮后 `agent.learning_machine.session_context_store.get(session_id=...)` 断言 goal/plan/progress；同时记录 SSE 事件流中是否携带计划信息（E8 结论 → 前端计划面板数据源决策）。

### 2.6 HITL 审批流（V3.3）

```
agent 调 sensitive_op → RunPaused + approvals 表记录
  → 管理员 token（approvals:write scope）resolve
  → POST /agents/{id}/runs/{run_id}/continue → 恢复执行
断言：发起者 token resolve 自己的 required approval → 403（职责分离）
```

### 2.7 沙箱工具（V4，E4 红线）

- `sandbox_server/`：独立 FastAPI 服务，docker SDK 管理容器（allocate/exec/release，TTL 看门狗，网络白名单用独立 docker network 演示）；
- Agent 侧是普通 Function tool（httpx 调用）——验证"Agno 无沙箱抽象时自研工具的接入成本"；
- 红线：内置 ShellTools/PythonTools 不出现在任何 agent 的 tools 里。

### 2.8 任务集执行器（V5 核心交付）

`run_task_suite.py`：

1. 顺序执行 K1–K8（requirements §4），每个任务独立 session；
2. 自动判定：文件/输出断言（K1/K2）、AccuracyEval（K3）、库断言（K4）、流程断言（K5）、进度追踪（K6）、成员调用记录（K7）、拒绝行为（K8）；
3. 记录指标：pass/fail、轮数、tool 调用数、首 token 延迟、总耗时、人工干预次数；
4. 输出 Markdown 报告 + 原始 JSONL。

`perf_bench.py`：冷启动计时、首 token P50/P95（同 prompt × 20 次）、50 轮长会话（每轮记录延迟 + 读 sqlite 行大小）、10 并发 run。

## 3. 风险与对策（本阶段）

| 风险 | 对策 |
|---|---|
| E3 session 行膨胀 / E7 SQLite 并发 | V5 如实记录；结论注明"生产 PostgresDb 待复测" |
| E5 API 迭代快 | 锁 2.8.2；learning/审批用法集中在 app/agents/ 单点 |
| E6 遥测外发 | telemetry=False + AGNO_TELEMETRY=false |
| Control Plane 是云端 Web UI | 仅作观察工具，不形成依赖 |
| 沙箱 docker-in-docker 权限 | PoC 宿主机 docker daemon 直挂；信任边界文档明示 |
