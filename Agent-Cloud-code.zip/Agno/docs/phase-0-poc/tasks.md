# Agno Phase 0 · PoC — Tasks

| 状态 | draft v0.2 | 周期 | 1–2 周 | 前置 | spec 评审通过 |
|---|---|---|---|---|---|

图例：`[ ]` 未开始 `[~]` 进行中 `[x]` 完成。

## M1 环境与服务骨架（第 1 天）

- [x] **T1** requirements.txt（`agno[os,sqlite,mcp]==2.8.2` + fastapi/uvicorn/httpx/pyjwt/docker/pytest/pytest-asyncio）+ `.venv`（uv，国内镜像）。覆盖：全部 AC 前置 ✅ 2026-08-09
- [x] **T2** .env.example + settings.py + models.py（MoonShot .cn 端点；OpenAILike→LiteLLM Proxy 预留）。✅ 实测连通 kimi-k2.6
- [x] **T3** app/main.py：按 00 文档 §2 范式装配 AgentOS（authorization + user_isolation + tracing + telemetry=False），跑通 `/health`。✅ 冒烟 3/3 通过

## M2 V1 服务化链路（第 1–2 天）

- [x] **T4** scripts/sse_client.py：SSE 消费 + 事件落盘 + 事件清单文档。脚本就绪，待实测
- [S] **T5** 断线重连（resume/replay）+ cancel + background run 验证。⏭️ 用户决策跳过（2026-08-10），平移至 Phase 1 视情况补

## M3 V2 认证与隔离（第 2–4 天）

- [x] **T6** scripts/make_token.py（HS256，可配 sub/scope）。✅ 已用于 UI token 签发
- [S] **T7** RBAC scope 矩阵测试。⏭️ 用户决策跳过，平移 Phase 1（P1-T8）
- [S] **T8** 双用户隔离测试。⏭️ 用户决策跳过，平移 Phase 1（P1-T8）
- [S] **T9** 隔离扫描。⏭️ 用户决策跳过，平移 Phase 1（P1-T8，入 CI）
- [S] **T10** 租户编码验证。⏭️ 用户决策跳过，平移 Phase 1（P1-T7/T8）
- [~] **T11** SqliteDb 落库核查（六张声明表、user_id 列、WAL、无 knowledge 表）。部分确认（表已建、无 knowledge 表、learnings/traces 有数据），正式核查待做

## M4 V3 Agent 原生能力（第 3–5 天）

- [x] **T12** 记忆跨会话验证。✅ 2026-08-10 PASS（user_memory 落库 Rust/星海，新 session 正确召回；注意有效 user_id 取 JWT sub）
- [x] **T13** SessionContext 规划模式实测。✅ 2026-08-10 结论：**Progress 滞后一轮是框架设计**（抽取先于本轮模型调用、快照不含本轮回复），非 bug；前端计划面板读 learnings 表 session_context，plan 为骨架、progress 模糊匹配。证据：scripts/verify_progress.py
- [x] **T14** approvals 全链路。✅ 2026-08-10 PASS（RunPaused → GET /approvals → resolve → continue 恢复，curl + UI 内联审批卡片双验证；职责分离断言按决策暂缓）
- [x] **T15** Team(coordinate) 委派验证。✅ 2026-08-10 PASS（spans 表见 delegate_task_to_member + Researcher/Writer 双成员 run，产出三段式简报）

## M5 V4 工具与沙箱（第 4–6 天）

- [x] **T16** sandbox_server（allocate/exec/release + 网络白名单 + TTL 看门狗）。✅ 2026-08-09 全链路实测通过（断网隔离验证）
- [x] **T17** sandbox_exec Function tool 接入 agent + 端到端执行验证（K2 预演）。✅ 工具已接入 assistant/deep-researcher，沙箱服务手动验证通过
- [x] **T18** MCPTools 白名单验证。✅ 2026-08-10 PASS（include_tools=[echo,add] 过滤后 secret_tool 不可见，in-process 验证）

## M6 V5 任务集与性能（第 6–8 天）

- [~] **T19** 任务集：K1–K3 ✅ 2026-08-10 全 PASS（K1 56.7s、K2 68.7s 含沙箱计算 338350、K3 41.3s）；K4–K8 ⏭️ 用户决策跳过
- [S] **T20** 性能基准。⏭️ 用户决策跳过，平移 Phase 1（P1-T28，PG 环境下补跑）
- [S] **T21** 10 并发稳定性。⏭️ 用户决策跳过，平移 Phase 1（P1-T28）

## M7 收口（第 8–9 天）

- [x] **T22** 实测报告归档。✅ 2026-08-10 `docs/phase-0-poc/实测报告.md`（功能项全录，安全/性能项标注跳过原因）
- [ ] **T23** PoC 评审会（人类决策项）。输入已备齐：实测报告 + Phase 1 spec 三件套已展开

## 出口检查单

- [ ] AC-A.1.1 ~ AC-A.5.3 全部有结论
- [ ] 任务集实测报告归档
