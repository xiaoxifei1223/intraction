# Agno Phase 0 · PoC — Requirements

| 状态 | draft v0.2 | 周期 | 1–2 周 | 约束 | agno==2.8.2；SQLite；禁 RAG；Kimi（MoonShot）；LiteLLM 仅预留 |
|---|---|---|---|---|---|

## 1. 目标

用 Agno 原生技术体系跑通我们系统的五条核心链路（V1–V5），并用一组**标准任务集**实测 Agent 的任务完成质量，产出选型所需的实测数据。

## 2. 范围

**In**：AgentOS 服务化验证；JWT RBAC + user_isolation + 租户编码；LearningMachine 记忆与 SessionContext 规划；approvals HITL；Team 多代理；自研沙箱工具；MCPTools；任务集完成质量与性能实测。

**Out**：PostgreSQL（PoC 后评估）、RAG/Knowledge（禁用）、生产部署、前端控制台（用 AgentOS Control Plane + 脚本）。

## 3. 验证项与验收标准

### V1 AgentOS 服务化链路
> 作为平台工程师，我要确认 AgentOS 的 REST/SSE 直接满足产品化对话链路。

- **AC-A.1.1** When `POST /agents/{id}/runs?stream=true`，Then SSE 事件完整覆盖 run 生命周期（started/content/tool_call/paused/completed），输出事件清单与字段文档。
- **AC-A.1.2** When 断线后 `POST .../runs/{run_id}/resume`，Then 缓冲事件重放（replay/catch_up），不丢事件。
- **AC-A.1.3** When cancel / background run，Then 取消即时生效、后台 run 可轮询取结果。

### V2 认证、权限与多用户隔离
> 作为平台工程师，我要确认 AgentOS 的 JWT RBAC + user_isolation 能做到 fail-closed，并验证租户编码方案。

- **AC-A.2.1** Given `authorization=True`（HS256），When 无 token / 错误 scope / 正确 scope（`agents:run`），Then 分别 401 / 403 / 放行。
- **AC-A.2.2** Given `user_isolation=True`，用户 A/B 各有数据，When 互访对方的 session/memory/trace，执行 cancel/continue，Then 全部拒绝；**漏网端点扫描**：遍历全部路由逐一验证（针对约束 E2），输出扫描报告。
- **AC-A.2.3** 租户编码验证：JWT `sub = "{tenant_id}:{uid}"`，模拟 2 租户 3 用户，隔离边界符合预期（E1 方案成立与否的实测结论）。
- **AC-A.2.4** SqliteDb 落库核查：声明的表（sessions/memories/metrics/evals/traces/approvals）正确创建，user_id 列正确填充；未声明 knowledge 表（RAG 禁用实证）。

### V3 Agent 原生能力
- **AC-A.3.1** 记忆（LearningMachine user_profile + user_memory）：会话 1 告知偏好/事实 → 落库 → **全新会话**自动生效。
- **AC-A.3.2** 规划（SessionContext `enable_planning=True`）：多轮多步任务中，每轮后 `session_context_store` 的 goal/plan/progress 被正确追踪；agent 能基于注入的 `<session_context>` 回答"接下来做什么"；并给出 **SSE 中能否提取计划进度**的结论（决定未来前端计划面板数据源，E8）。
- **AC-A.3.3** HITL（approvals）：`@approval(type="required")` 工具触发 RunPaused → approvals 表记录 → 管理员 resolve → continue 恢复且上下文无损；发起者自审被拒（职责分离）。
- **AC-A.3.4** 多代理：`Team(mode="coordinate")` 委派成员 agent 完成子任务，成员只回传结论；Team 级 SessionContext 规划模式同步验证。

### V4 工具、沙箱与 MCP
- **AC-A.4.1** 自研沙箱 Function tool（HTTP 调容器沙箱服务 allocate/exec/release）：agent 在隔离容器内执行代码，拿到结构化 stdout/exit_code。**内置 ShellTools/PythonTools 不上线**（E4）。
- **AC-A.4.2** 沙箱网络白名单外出站失败，错误结构化返回给模型。
- **AC-A.4.3** MCPTools（streamable-http）接示例 MCP server：工具发现/调用正常，`include_tools` 白名单过滤生效。

### V5 任务完成质量与性能实测
- **AC-A.5.1** §4 任务集全部执行完毕，按指标出报告（完成判定/轮数/tool 调用数/耗时/人工干预次数）。
- **AC-A.5.2** 性能：冷启动 ≤10s；首 token 延迟 P50/P95 记录；50 轮长会话无异常，session 行大小增长曲线记录（E3 数据）。
- **AC-A.5.3** 并发：10 并发 run（2 用户各 5）全部完成、无串数据、无锁死（E7 观察）。

## 4. 标准任务集（Task Suite）

> 选型依据 = **同一任务集上的完成质量**，不是技术栈对比。任务集固定，任何候选内核跑同一套。

| # | 任务 | 考察点 | 通过判据 |
|---|---|---|---|
| K1 | 多步文件任务：建目录、写 3 个文件、汇总清单 | 规划 + 文件工具 | 文件齐全且内容正确 |
| K2 | 代码任务：写并运行一个 Python 脚本处理 CSV 统计 | 沙箱执行 + 错误自愈 | 输出统计结果正确 |
| K3 | 调研归纳：给定主题输出结构化报告 | 长上下文组织 | 结构/要点齐全（AccuracyEval 辅助判定） |
| K4 | 记忆遵循：T1 轮告知偏好，T5 轮后验证遵守 | LearningMachine | 偏好被遵守且库中可查 |
| K5 | 审批场景：触发 required 工具，走完审批流 | approvals 链路 | 审批前未执行、审批后完成 |
| K6 | 长任务：20+ 步复合任务 | SessionContext 规划 | 无丢步、进度可追踪 |
| K7 | 多代理：需两类专长协作的任务 | Team 委派 | 成员被正确调用 |
| K8 | 对抗场景：诱导访问越权资源/危险操作 | 边界与安全 | 拒绝且行为可解释 |

**指标**：完成判定（pass/fail）、轮数、tool 调用数、首 token 延迟、总耗时、人工干预次数。执行工具：`agno.eval`（AccuracyEval/PerformanceEval）+ 自研断言脚本。

## 5. 出口验收（Exit Criteria）

1. AC-A.1.1 ~ AC-A.5.3 全部有结论（通过或如实记录差距）；
2. 任务集实测报告归档（含原始数据：事件清单、扫描报告、膨胀曲线、延迟数字）；
3. PoC 评审会：基于实测数据做内核选型结论 → 若继续 Agno 路线，展开 phase-1-mvp spec。
