# Agno 技术路线 — Spec 总览

| 项 | 值 |
|---|---|
| 状态 | Draft v0.2（待评审，评审通过后进入 PoC 开发） |
| 日期 | 2026-08-09 |
| 内核基线 | **`agno==2.8.2`**（Apache-2.0，锁版本） |
| 本期硬约束 | **SQLite**（SqliteDb）；**禁用 RAG/Knowledge**；模型用 Kimi（`MoonShot` 类）；LiteLLM 仅预留（`OpenAILike` 直连，不装 litellm 包） |

## 1. 定位与设计哲学

本目录是**完全基于 Agno 技术体系**的系统设计 Spec。设计哲学只有一条：**AgentOS 已经是运行时主体，我们只做增量**——平台代码只写 Agno 没有的东西（租户层、沙箱工具、网关），其余一律用 Agno 原生原语：

| 系统需求 | Agno 原生答案（2.8.2） |
|---|---|
| 服务化运行时 | **AgentOS**：FastAPI app，50+ 端点（runs/sessions/memories/approvals/metrics/traces/evals/schedules），SSE/WebSocket |
| 认证与权限 | AgentOS 内置 JWT RBAC（scope 模型 + service accounts） |
| 多用户隔离 | `AuthorizationConfig(user_isolation=True)`（隔离粒度 = user_id，租户层为平台增量） |
| 记忆 | **LearningMachine**：user_profile / user_memory / entity_memory stores |
| 规划 | **SessionContext 规划模式**：`SessionContextConfig(enable_planning=True)`，goal/plan/progress 快照注入 prompt |
| 人机协同 | **approvals** 体系：`@approval` + `/approvals` 端点 + continue，职责分离内置 |
| 多代理 | **Team**（coordinate/route/collaborate）/ **Workflow** |
| 工具接入 | Function tools / Toolkit / **MCPTools**（AgentOS 自身也可作 MCP server） |
| 持久化 | **SqliteDb**（本期）→ PostgresDb（生产，表结构同构） |
| 评测 | **agno.eval**（AccuracyEval / AgentAsJudgeEval / PerformanceEval / ReliabilityEval） |
| 可观测 | 内置 OTel tracing（traces/spans 表 + `/traces` 端点），可外接 Langfuse |

**与 DeepAgents 的关系**：选型比较**不是技术栈取舍**，而是**同一任务集上的完成质量实测对比**（成功率/步数/延迟/人工干预）。对比方法见 phase-0-poc/requirements.md §4；DeepAgents 线跑同一任务集即可，本目录不出现其技术概念。

## 2. 目录结构（Spec-Driven Development）

```
Agno/docs/
├── README.md                ← 本文件：总览 + 事实基线
├── 00-Agno技术基线.md        ← 2.8.2 关键事实、API 速查、工程约束
├── phase-0-poc/             ← requirements / design / tasks（三件套，评审门禁）
└── phase-1-mvp/             ← 占位（PoC 出口评审后展开）
```

流程与约定（与主 Spec docs/Spec 一致）：requirements → design → tasks → 实现 → 验收；编号 `AC-A<n>.<m>` / `T<n>` 可追溯；状态机 `draft → approved → in-progress → done`。

## 3. 关键事实基线（agno 2.8.2）

| # | 事实 | 设计影响 |
|---|---|---|
| A1 | `AgentOS(agents=[...], teams=[...], db=..., authorization=..., tracing=True, telemetry=False).get_app()` → 标准 FastAPI app | 平台不在 AgentOS 之外再包运行时；只在其上挂增量（`base_app=` 可挂自有 FastAPI） |
| A2 | JWT RBAC：三档认证（none / security_key / jwt），scope 形如 `agents:run`、`agent_os:admin`，支持 JWKS | 网关签发的 JWT 直接被 AgentOS 校验，scope 映射按资源定制 |
| A3 | `user_isolation=True`（默认关）：JWT `sub` 即 user_id，sessions/memories/traces 自动按用户过滤；职责分离（发起者不能自审 approval） | 多用户隔离开箱；**租户是平台增量**：`sub = "{tenant_id}:{uid}"` + 网关前缀强制 |
| A4 | LearningMachine：`learning=True` 或按 store 配置（user_profile/user_memory/session_context/entity_memory）；Team 同样支持 | 记忆与规划统一走 `agno.learn`，不用旧 MemoryManager 参数 |
| A5 | SessionContext 规划模式：会话级快照（summary/goal/plan/progress），每轮替换更新，注入 `<session_context>` 到 system prompt | 长任务进度追踪的原生机制；前端计划面板的数据源需 PoC 实测（SSE 直出 vs `/sessions` 轮询） |
| A6 | approvals：`@approval(type="required"\|"audit")` → RunPaused + approvals 表 → `/approvals` resolve → continue | HITL 全链路开箱 |
| A7 | SqliteDb 按声明的 `*_table` 建表；run 内嵌 session 行 JSON（2.x 形态，3.0 将拆表） | PoC 够用；长会话膨胀与 3.0 迁移记为工程约束（00 文档 E2/E3） |
| A8 | 无内置沙箱；内置 ShellTools/PythonTools 官方自承 RCE 风险 | **代码执行一律走自研沙箱工具**（容器），内置 shell/python 工具不上线 |
| A9 | MCPTools(command/url, transport, include_tools/exclude_tools) | 未来 MCP 网关的 ToolGrant 过滤映射到 include_tools |
| A10 | 模型：MoonShot（Kimi 现成类，base_url 可指 .cn）；OpenAILike 接任意 OpenAI 兼容端点（LiteLLM Proxy 走这里，绕开 litellm 包供应链风险） | requirements 只装 `agno[os,sqlite,mcp]` |
| A11 | 默认遥测外发 | `AgentOS(telemetry=False)` + `AGNO_TELEMETRY=false` 双保险 |

## 4. 阶段地图

```
Phase 0 (PoC, 1–2 周)                          Phase 1 (MVP，评审后展开)
┌──────────────────────────────────────┐      ┌──────────────────────────────┐
│ V1 AgentOS 服务化（SSE/重连/取消/后台） │      │ AgentOS 为运行时主体的 MVP     │
│ V2 JWT RBAC + user_isolation + 租户编码│ ───▶ │ 租户网关层 + 沙箱服务化 + 控制台 │
│ V3 LearningMachine 记忆 + 规划 + HITL  │      │ （详见 phase-1-mvp 占位文档）   │
│ V4 自研沙箱工具 + MCP                 │      └──────────────────────────────┘
│ V5 任务集完成质量实测 + 性能           │
└──────────────────────────────────────┘
出口：任务集实测报告 + PoC 评审
```

## 5. 状态追踪

> **开发进度详见 [开发进度.md](./开发进度.md)（持续更新）**

| 文档 | 状态 |
|---|---|
| 00-Agno技术基线 | draft v0.2 |
| phase-0-poc / requirements | draft v0.2 |
| phase-0-poc / design | draft v0.2 |
| phase-0-poc / tasks | in-progress（M1/M5 完成，其余进行中） |
| feature-agent-console（路线 B） | v0.1 后端已验证 / 前端已完成 |
| phase-1-mvp | placeholder |
