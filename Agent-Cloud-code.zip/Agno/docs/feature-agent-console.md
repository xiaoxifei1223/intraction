# Feature · Agent 控制台（路线 B：UI 表单创建 Agent）

| 状态 | v0.1 后端已验证 / 前端开发中 | 日期 | 2026-08-09 | 归属 | 主 Spec phase-1「Agent 注册中心」的 PoC 提前实现 |
|---|---|---|---|---|

## 1. 决策与定位

用户通过**表单**在 UI 创建 Agent（声明式 spec），创建物进入**版本化 + 发布门控**体系。不用 Agno 云的 Agent Builder（对话式生成代码），不自研低代码画布（D08 §1.2 非目标）。

**关键发现**：AgentOS 2.8.2 内置完整的声明式组件注册机制，本特性直接复用，平台只写薄装配层：

```
组件注册：POST /components（component + 版本化 config，stage: draft）
版本管理：GET  /components/{id}/configs
发布门控：PATCH /components/{id}/configs/{v}（stage: draft→published）
生效指针：POST /components/{id}/configs/{v}/set-current（仅 published 可 current）
回滚    ：同 set-current 指回旧版本（秒级）
物化    ：请求时 resolve_agent → db.get_config(current) → Agent.from_dict(cfg, registry) → 可运行（无需重启）
```

映射主 Spec shared/03：组件 = AgentDefinition、config 版本 = AgentVersion、set-current = Release 指针。非序列化对象（工具/模型/db）经 **Registry 按名水合**——平台自建工具注册进 `AgentOS(registry=...)` 即可被声明式引用。

## 2. 平台薄层（唯一自研代码）

`app/console.py`（FastAPI router，挂在同一 app）：

| 端点 | 职责 |
|---|---|
| `GET /console/tool-catalog` | 可授权工具目录（从 Registry 提取，供表单勾选） |
| `POST /console/agents` | 表单 → 装配 config（model/db 引用 + 工具全序列化 + learning 开关）→ 建组件 + v1（draft） |
| `POST /console/agents/{id}/versions` | 同装配 → 新版本（draft） |

装配规则：工具用 `Function.from_callable().to_dict()` 全序列化（缺 parameters 会导致水合失败，已踩坑修复）；spec_hash（sha256 前 16 位）记入 metadata，为主 Spec 的 spec_hash 寻址预留。

## 3. 表单字段（PoC 版）

name / description / instructions / tools（勾选，白名单 = tool-catalog）/ learning 三开关（user_profile、user_memory、session_context 规划）/ num_history_runs / markdown。模型本期固定 Kimi（kimi-k2.6），多模型选择留 Phase 1。

## 4. 前端（agent-ui 扩展）

在开源 agent-ui 内新增「Agent 管理」页（不动其聊天架构）：

- **列表页**：GET /components?component_type=agent → 组件卡片（名称/描述/当前版本/stage）；
- **创建表单**：字段见 §3，工具选项来自 /console/tool-catalog；提交 → POST /console/agents；
- **版本管理**：版本列表（GET /components/{id}/configs）+ 每版本「发布」「设为当前」按钮（PATCH stage + set-current）；
- 创建成功后可直接在聊天页选择该 agent 对话（/agents 列表已含组件 agent）。

## 5. 验证记录（后端，2026-08-09 全链路通过）

```
POST /console/agents (weather-bot) → 201, v1 draft
PATCH configs/2 stage=published → 200
POST  configs/2/set-current → 200 (current_version=2)
POST  /agents/weather-bot/runs → 200，LLM 按 persona 正常回复 ✅
GET   /agents → 含 weather-bot ✅
```

## 6. 留缝（Phase 1 接入点，本期不做）

- 租户维度：组件表加 tenant 过滤（等 E1 租户编码落地后加 scope 校验）；
- 审批门控：stage published 目前直接可改 → 接入 approvals/角色权限；
- 灰度：set-current 是全量指针 → Release rollout_pct；
- 多模型选择与 LiteLLM 路由；
- 工具风险等级标注（deploy_to_production 类应默认带审批）。
