# 00 · Agno 2.8.2 技术基线

| 状态 | draft v0.2 | 依据 | agno 2.8.2 源码 + docs.agno.com（2026-08-09 调研） |
|---|---|---|---|

> 本文档是 Agno 技术路线的"事实底座"：所有 phase spec 只引用这里的事实与工程约束，不引入其他框架的概念。

## 1. 核心原语

| 原语 | 说明 | import |
|---|---|---|
| `Agent` | 执行单元：model + db + tools + learning + instructions | `agno.agent.Agent` |
| `Team` | 多代理协作（mode: coordinate/route/collaborate），成员只回传结论 | `agno.team.Team` |
| `Workflow` | 步骤化编排 | `agno.workflow.Workflow` |
| `AgentOS` | 运行时：FastAPI app，50+ 端点，SSE/WS | `agno.os.AgentOS` |
| `LearningMachine` | 学习/记忆/规划体系（stores 可独立配置） | `agno.learn.LearningMachine` |
| `SessionContextConfig` | 会话上下文配置，`enable_planning=True` 开规划模式 | `agno.learn.SessionContextConfig` |
| `@approval` | HITL 审批装饰器（required/audit） | `agno.approval.approval` |
| `MCPTools` | MCP client（stdio/sse/streamable-http，include/exclude 过滤） | `agno.tools.mcp.MCPTools` |
| `SqliteDb` | 本期持久层 | `agno.db.sqlite.SqliteDb` |
| `MoonShot` / `OpenAILike` | 模型类（Kimi / LiteLLM Proxy） | `agno.models.moonshot` / `agno.models.openai.like` |
| `agno.eval.*` | AccuracyEval / AgentAsJudgeEval / PerformanceEval / ReliabilityEval | `agno.eval` |

## 2. 标准装配范式（本项目的 canonical 写法）

```python
from agno.agent import Agent
from agno.db.sqlite import SqliteDb
from agno.learn import LearningMachine, SessionContextConfig
from agno.models.moonshot import MoonShot
from agno.os import AgentOS
from agno.os.config import AuthorizationConfig

db = SqliteDb(
    db_file="agno.db",
    session_table="sessions", memory_table="memories", metrics_table="metrics",
    eval_table="evals", traces_table="traces", approvals_table="approvals",
    # 不声明 knowledge_table —— 本期禁用 RAG
)

agent = Agent(
    id="assistant",
    name="Assistant",
    model=MoonShot(id="kimi-k2-0905-preview",
                   base_url="https://api.moonshot.cn/v1",
                   api_key=...),
    db=db,
    tools=[...],
    learning=LearningMachine(
        user_profile=True,          # 跨会话用户事实
        user_memory=True,           # 跨会话用户观察
        session_context=SessionContextConfig(
            enable_planning=True,   # 规划模式：goal/plan/progress 快照注入 prompt
        ),
    ),
    add_history_to_context=True,
    num_history_runs=10,
    markdown=True,
)

app = AgentOS(
    agents=[agent],
    db=db,
    authorization=True,
    authorization_config=AuthorizationConfig(
        verification_keys=[JWT_SECRET],
        algorithm="HS256",
        user_isolation=True,        # JWT sub 即 user_id；数据按用户隔离
    ),
    tracing=True,                   # OTel → traces/spans 表 + /traces 端点
    telemetry=False,                # 私有化必关
).get_app()
```

## 3. AgentOS 端点地图（PoC 用到）

| 端点 | 用途 |
|---|---|
| `POST /agents/{id}/runs?stream=true` | 发起 run，SSE 事件流（RunStarted/RunContent/ToolCall*/RunPaused/RunCompleted…） |
| `POST /agents/{id}/runs/{run_id}/cancel` · `/continue` · `/resume` | 取消 / 审批后恢复 / 断线重连（replay 缓冲事件） |
| `GET /sessions` · `/sessions/{id}` | 会话查询（含 history、summary） |
| `GET /memories` | 记忆查询 |
| `GET /approvals` · resolve | HITL 审批队列 |
| `GET /metrics` · `/traces` · `/eval-runs` | 用量 / 追踪 / 评测 |
| `arun(background=True)` | 后台 run + 轮询 |

## 4. 工程约束（风险登记，PoC 需实测或缓释）

| # | 约束 | 缓释/验证 |
|---|---|---|
| E1 | **无租户原语**：隔离粒度 = user_id | 平台增量：`sub = "{tenant_id}:{uid}"`，网关强制前缀；PoC V2 验证 |
| E2 | user_isolation 依赖各端点手工透传 user scope，存在静默漏防可能 | PoC 漏网端点扫描（遍历全部路由 × 跨用户访问），纳入 CI |
| E3 | run 内嵌 session 行 JSON（2.x），大会话单行膨胀；3.0 将拆表 | PoC V5 实测 50 轮膨胀曲线；锁版本，升级窗口规划 |
| E4 | 无沙箱抽象，内置 shell/python 工具 = RCE 面 | 自研沙箱 Function tool（容器）；内置工具不上线 |
| E5 | 迭代快，Learning 等概念多次改名 | 锁 2.8.2；learning 用法集中在 app/agents/ 单点 |
| E6 | 默认遥测外发 | telemetry=False + 环境变量双保险 |
| E7 | SQLite 写并发上限 | PoC 并发实测；结论注明生产 Postgres 待复测 |
| E8 | SessionContext 规划是后台 store 快照注入 prompt，非工具调用事件 | 前端计划面板数据源待 PoC 实测（SSE vs /sessions 轮询） |
