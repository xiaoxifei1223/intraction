# Agno Phase 1 · MVP

| 状态 | **spec 已展开**（draft v1.0，2026-08-10） | 前置 | Phase 0 功能验证收口 ✅（实测报告已归档；安全/性能项按用户决策带入 M2/M5） |
|---|---|---|---|

**Spec 三件套**：[requirements.md](./requirements.md) · [design.md](./design.md) · [tasks.md](./tasks.md)

## 设计基调（出发点，已被 spec 吸收）

**AgentOS 是运行时主体，平台只做增量。**MVP 各能力域的 Agno 原生承担方式：

| 能力域 | Agno 原生承担 | 平台增量（要写的代码） |
|---|---|---|
| 运行时 API | AgentOS 端点全集（runs/sessions/approvals/metrics/traces，SSE + 断线重连 + 后台 run） | 无 |
| 认证权限 | JWT RBAC + scope 映射 + service accounts | 租户层：`sub="{tenant}:{uid}"` 编码 + 网关前缀强制 + 隔离扫描入 CI |
| 记忆 | LearningMachine（user_profile/user_memory） | 组织级共享记忆（learning stores 粒度到 user，组织记忆需评估 entity_memory/learned_knowledge 或自建） |
| 规划 | SessionContext 规划模式 | 前端计划面板（数据源 = PoC T13 结论） |
| HITL | approvals 体系 + 职责分离 | 审批通知通道（控制台/IM 推送） |
| 多代理 | Team / Workflow | Agent 定义的声明式配置层（版本化、发布） |
| 代码执行 | —（无内置沙箱） | sandbox-server 服务化 + 沙箱 Function tool（PoC 已验证形态） |
| 工具治理 | MCPTools(include_tools=授权过滤) | MCP 网关（凭证注入/风险标注/审计） |
| 持久层 | SqliteDb → **PostgresDb**（生产，表结构同构） | 连接池/备份运维 |
| 评测 | agno.eval + /eval-runs | 评测集管理、门控流水线 |
| 可观测 | 内置 tracing（traces 表 + /traces） | 外接 Langfuse、租户维度成本聚合 |
| 渠道 | AgentOS interfaces（Slack/Telegram/WhatsApp/AG-UI/A2A 开箱） | 飞书/企微自研 interface（Agno interface 协议） |

## 展开时的输入

- PoC 实测报告（任务集 K1–K8、隔离扫描、膨胀曲线、延迟数据）；
- 工程约束 E1–E8 的实测结论（哪些已关闭、哪些带进 MVP 设计）；
- 主架构基准 docs/08 的目标与非目标（多租户/云上/可进化）。
