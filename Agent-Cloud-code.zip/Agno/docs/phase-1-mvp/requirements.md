# Agno Phase 1 · MVP — Requirements

| 状态 | draft v1.0 | 前置 | Phase 0 功能验证收口（实测报告已归档） | 日期 | 2026-08-10 |
|---|---|---|---|---|

## 1. 定位与基调

**AgentOS 是运行时主体，平台只做增量。** Phase 0 已实证：AgentOS 原生承担 runs/sessions/approvals/metrics/traces、JWT RBAC + user_isolation、LearningMachine 记忆、SessionContext 规划（一轮滞后）、Team/Workflow 多代理、tracing。MVP 只写 Agno 不承担的部分。

**UI 路线（用户决策）**：自托管 agent-ui 扩展，**不接 os.agno.com 托管 Control Plane**。Phase 0 已落地 workflow 聊天模式 + 内联审批卡片；Traces/Metrics/Evaluation/Memory 管理页列入本阶段任务。

**持久层路线**：`DB_BACKEND=sqlite|postgres` 切换层已就绪（仅代码）。云端 PG 申请中，到位后 `pip install -r requirements.txt` + 配置 `DATABASE_URL` 即可切换。

## 2. 目标（Goals）

- G1：多租户可用的 Agent 云平台 MVP：声明式创建/发布 Agent，UI 端到端可用（聊天/审批/管理）
- G2：生产级持久层（云端 Postgres）+ 租户隔离进入 CI 红线
- G3：工具治理（MCP 网关）与 HITL 闭环（审批通知）
- G4：评测门控 + 可观测外接，支撑"可进化"（08 基准目标）

## 3. 非目标（Non-Goals）

- 不自研复刻完整 Control Plane（不追求与 os.agno.com 功能对齐，只做平台需要的页面）
- 不做组织级共享记忆的自研存储（先评估 entity_memory/learned_knowledge，结论后再定）
- 不做多渠道全量接入（只做飞书一个渠道样板）
- 不做性能调优专项（Phase 0 性能基准未跑，带进 M5 再议）

## 4. 功能需求

### FR-1 声明式配置层（核心，已具雏形）
- FR-1.1 Agent 表单创建/编辑（新版本）/发布/设当前/删草稿 ✅（Phase 0 已完成，含编辑回显）
- FR-1.2 Team 声明式创建（成员引用已发布 Agent，mode 可选 coordinate/route）
- FR-1.3 Workflow 声明式创建（steps 引用已发布 Agent/Team；顺序编排即可，不做 condition/parallel）
- FR-1.4 配置层 RBAC：创建/发布/删除需管理员 scope（与 FR-2 租户层对齐）
- 验收：UI 上 5 分钟内完成「建 2 个 Agent → 组 1 个 Team → 跑通一次 Team run」

### FR-2 租户层（Phase 0 延期项收口）
- FR-2.1 `sub="{tenant}:{uid}"` 编码强制（签发入口统一，网关/中间件校验格式）
- FR-2.2 双用户隔离测试 + RBAC scope 矩阵 + 隔离扫描入 CI（Phase 0 T7–T10 平移）
- FR-2.3 JWT_SECRET 32+ 字节随机串（关 InsecureKeyLengthWarning）
- 验收：isolation_scan.py 全绿并接入 CI；2 租户 3 用户矩阵通过

### FR-3 Postgres 生产持久层
- FR-3.1 云端 PG 到位后：`DATABASE_URL` 切换 + 连接级冒烟（建表/读写/版本流转）
- FR-3.2 数据迁移：sqlite 现有 components/configs 导出 → PG 导入脚本（sessions/learnings 不迁）
- FR-3.3 验证 PG 分支 delete_config 的 stage 校验行为（Phase 0 遗留：sqlite 实现不拒删 published）
- 验收：`DB_BACKEND=postgres` 下冒烟测试全绿 + 控制台全链路（创建→发布→运行）

### FR-4 自托管 UI 管理页（向截图 Control Plane 元素对齐的最小集）
- FR-4.1 Traces 页：/traces 列表 + trace 详情（spans 瀑布），数据源为原生端点
- FR-4.2 Sessions 独立页：跨实体会话检索（agent/team/workflow 统一列表）
- FR-4.3 Metrics 页：/metrics 原生数据可视化（token/延迟/调用量）
- FR-4.4 Memory 页：learnings 表 user_profile/user_memory 查看（只读即可）
- FR-4.5 计划面板：读 `learnings` 表 `learning_type='session_context'` 的 content JSON（goal/plan/progress/summary）；**以 plan 为骨架、progress 模糊匹配标完成态，接受一轮滞后**（Phase 0 T13 结论）
- 验收：五个页面可用；计划面板能展示一次真实 run 的 goal/plan/progress

### FR-5 HITL 闭环
- FR-5.1 Approvals 管理页：pending 列表 + 批准/拒绝（UI 已有内联卡片，管理页做集中处理）
- FR-5.2 审批通知通道：pending 产生时推送（第一版：Webhook/企业微信机器人二选一，配置化）
- 验收：approval 产生 → 通知发出 → 管理页处理 → run 恢复，全链路 e2e

### FR-6 MCP 网关（工具治理）
- FR-6.1 MCP server 注册表（url/凭证/风险标注/可用工具白名单）
- FR-6.2 凭证注入：Agent 引用 MCP 工具时按租户注入凭证，凭证不进组件 config 明文
- FR-6.3 审计：MCP 工具调用记录（who/when/tool/args 摘要）落审计表
- 验收：注册 1 个真实 MCP server，控制台 Agent 勾选其工具，调用有审计记录

### FR-7 评测门控
- FR-7.1 评测集管理（用例 CRUD：input/期望断言）
- FR-7.2 发布门控：组件版本 published 前自动跑评测集，不达标阻断发布
- 验收：构造 1 个 5 用例评测集，故意改坏 instructions 后发布被阻断

### FR-8 可观测外接
- FR-8.1 Langfuse 接入（OTel export，与内置 tracing 并存）
- FR-8.2 租户维度 token/成本聚合报表（metrics 表按 user_id 前缀聚合）
- 验收：Langfuse 可见完整 trace；报表接口返回按租户聚合数据

### FR-9 渠道样板
- FR-9.1 飞书 interface（Agno interface 协议）：消息 → run → 回复卡片
- 验收：飞书群内 @机器人 完成一次 assistant 对话

### FR-10 沙箱服务化加固
- FR-10.1 沙箱服务纳入统一鉴权（当前无鉴权，仅内网假设）
- FR-10.2 配额：每租户并发沙箱数上限 + 每日调用量上限
- 验收：超配额返回 429；无 token 访问沙箱服务 401

## 5. 优先级矩阵

| 优先级 | 需求 | 理由 |
|---|---|---|
| P0 | FR-1 全量、FR-2、FR-3 | 多租户 MVP 的最低闭环 |
| P1 | FR-4、FR-5 | 运营/管理面可用性 |
| P2 | FR-6、FR-7 | 治理与进化能力 |
| P3 | FR-8、FR-9、FR-10 | 规模化后再做 |

## 6. 继承自 Phase 0 的结论与约束

- T13：SessionContext progress 天然滞后一轮（框架设计，非 bug）→ FR-4.5 的展示策略
- 遗留：agno sqlite delete_config 不拒删 published（console 层已挡；PG 分支待验证 → FR-3.3）
- E6 红线：telemetry=False 全局维持；新增组件（Workflow 已带 telemetry=False）逐一核查
- DDG 国内限流：评测/演示避免依赖 DuckDuckGo，生产换国内可用搜索 API
