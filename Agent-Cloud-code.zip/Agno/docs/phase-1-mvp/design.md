# Agno Phase 1 · MVP — Design

| 状态 | draft v1.0 | 关联 | [requirements.md](./requirements.md) | 日期 | 2026-08-10 |
|---|---|---|---|---|---|

## 1. 总体架构

```
┌────────────────────────────────────────────────────────────┐
│ 自托管 agent-ui（Next.js，扩展版）                            │
│  Chat(agent/team/workflow) │ 审批卡片 │ Agent 管理           │
│  + Traces / Sessions / Metrics / Memory / 计划面板 / Approvals│
└──────────────┬─────────────────────────────────────────────┘
               │ Bearer JWT（sub="{tenant}:{uid}"）
┌──────────────▼─────────────────────────────────────────────┐
│ AgentOS（FastAPI 运行时主体）                                │
│  原生：runs/sessions/approvals/metrics/traces/components    │
│  增量：/console/*（工具目录、表单装配、表单回显、草稿删除）     │
│  增量：/gateway/*（租户校验、MCP 网关、审计）—— M2 引入       │
│  Registry：工具/模型/db 水合目录                              │
└──────┬───────────────┬───────────────┬─────────────────────┘
       │               │               │
  PostgresDb      sandbox-server    MCP servers
  （云端，ai schema） （docker 隔离）   （凭证注入/白名单/审计）
```

**原则**：所有能落到 AgentOS 原生能力的需求，不允许在平台层重写；平台增量以独立 router/service 挂载，保持 `main.py` 薄装配。

## 2. 各能力域设计

### D1 声明式配置层（FR-1）

现状（Phase 0 已交付）：
- `POST /console/agents`（表单→`Agent.to_dict()` 同构 config→components 表，stage=draft）
- `POST /console/agents/{id}/versions`、`GET /console/agents/{id}`（表单回显反向映射）、`DELETE .../versions/{v}`（仅 draft）
- 发布/设当前复用原生 `POST /components/{id}/configs/{version}/set-current`
- 运行时水合：`Agent.from_dict(cfg, registry)`

扩展（Team/Workflow 声明式）：
- TeamForm：`{name, description, mode: coordinate|route, member_ids: [...], instructions}`；members 按 component_id 引用**已发布** Agent，装配时 `Agent.from_dict` 逐个物化后组 `Team(...).to_dict()` 落库
- WorkflowForm：`{name, description, steps: [{name, component_id}]}`（仅顺序 Step；condition/parallel 留给 Phase 2）
- 统一抽象：`_assemble_config(form)` 已存在，新增 `_assemble_team_config` / `_assemble_workflow_config` 同型函数；spec_hash 机制复用
- 风险点：成员 Agent 版本漂移——config 中记录成员 `component_id + version` 快照，发布 Team 时冻结成员版本

### D2 租户层（FR-2）

- 签发统一走 `scripts/make_token.py` 的正式化版本（`POST /console/tokens` 暂不做，MVP 保持脚本签发）
- 网关前缀强制：新增 Starlette 中间件 `TenantEnforcementMiddleware`——解析 JWT sub 必须为 `{tenant}:{uid}` 格式，拒绝畸形 sub（403）
- CI：isolation_scan.py + RBAC 矩阵测试进 CI 流水线（pytest -m security 标记）

### D3 Postgres 切换（FR-3）

已完成：`app/db.py` 工厂（sqlite/PostgresDb 惰性导入，表名同构，PG schema 默认 `ai`）。
剩余：云端 PG 到位后——
1. `pip install -r requirements.txt`（psycopg[binary]）
2. `.env`：`DB_BACKEND=postgres` + `DATABASE_URL=postgresql://...`
3. 连接级冒烟脚本 `scripts/pg_smoke.py`：建表断言（11 张表在 ai schema）+ 创建/发布/运行一轮
4. 迁移脚本 `scripts/migrate_sqlite_to_pg.py`：仅 components/configs/links 三表（声明式资产），逐行 INSERT；sessions/learnings/traces 不迁（PoC 数据无价值）

### D4 自托管 UI 页面（FR-4）

统一模式：每页 = 一个 route（`src/app/<page>/page.tsx`）+ 一个 API 模块函数 + 原生端点数据源。
- **Traces**：`GET /traces`（分页）→ 列表；`GET /traces/{id}` → spans 瀑布（层级缩进 + 耗时条，纯 CSS，不引图表库）
- **Sessions**：`GET /sessions?type=...` 三 tab（agent/team/workflow）
- **Metrics**：`GET /metrics` → 表格 + 简单聚合卡片（总 runs/tokens/错误率）
- **Memory**：`GET /learnings`（若无原生端点则加 `/console/learnings` 只读）→ user_profile/user_memory 分组展示
- **计划面板**：Chat 内侧栏，`GET /console/sessions/{id}/plan`（新增薄端点：读 learnings 表最新 session_context，返回 content JSON）；渲染 plan 为 checklist，progress 模糊匹配标 ✓，标注"进度滞后一轮"

### D5 HITL 闭环（FR-5）

- Approvals 页：`GET /approvals?status=pending` 轮询（30s）+ resolve 按钮（复用内联卡片的 resolve+continue 逻辑）
- 通知通道：`app/notifications.py`——DB 监听改为**轮询模式**（每 10s 查 pending 差集）→ POST 到配置的 Webhook URL（env `APPROVAL_NOTIFY_WEBHOOK`）；失败重试 3 次，不阻断主流程
- 职责分离断言留到 Phase 2（Phase 0 已决策暂缓）

### D6 MCP 网关（FR-6）

- 表：`mcp_servers`（新表，platform 自建：id/name/url/risk_level/credentials_ref/allowed_tools）
- 注入：Agent 装配时（console `_assemble_config`）把 MCP 工具展开为 `MCPTools(url=网关代理地址, include_tools=白名单)`；网关代理（`app/mcp_gateway.py`，FastAPI 反向代理 + streamable-http）负责凭证注入与审计
- 审计表：`tool_audit`（ts/tenant/user/component/tool/args 摘要/status）
- MVP 简化：第一版可不做代理转发，先做"注册表 + include_tools 白名单 + 调用日志依赖 tracing"；代理与凭证注入标记 P2

### D7 评测门控（FR-7）

- 表：`eval_suites`（id/name/cases: JSON[]），cases = `{input, must_contain[], must_not_contain[], max_tool_calls?}`
- `POST /console/eval-suites/{id}/run?component_id=...`：对 current 版本逐用例跑 run，判定通过数
- 门控：`POST /components/{id}/configs/{v}/publish` 原生端点前置——console 包一层 `POST /console/agents/{id}/versions/{v}/publish`：先跑绑定的 eval-suite，不达标 409 并附报告
- 断言引擎 MVP：字符串包含/不包含 + 工具调用数上限（不用 LLM-as-judge，避免评测成本）

### D8 可观测（FR-8）

- Langfuse：agno tracing 已走 OTel，配置 OTEL_EXPORTER 指向 Langfuse OTel endpoint（零代码，运维配置）；验证后写运行手册
- 成本聚合：`GET /console/metrics/by-tenant`——metrics 表按 `user_id` 的 tenant 前缀 GROUP BY（sqlite/PG 同构 SQL）

### D9 渠道（FR-9）

- `app/interfaces/feishu.py`：飞书事件订阅回调 → 验签 → 解析文本 → 以 tenant=飞书租户 ID 调 assistant run（非流式）→ 回复卡片消息；长任务先回"处理中"，完成后推送
- 验签/token 管理走 env 配置

### D10 沙箱加固（FR-10）

- sandbox_server 加 Bearer 校验（与 AgentOS 同 JWT_SECRET，scope=`sandbox:exec`）
- 配额：内存计数器（sandbox_id 按 tenant 前缀）+ 每日计数落 sqlite 小表；超限 429

## 3. 数据模型增量（平台自建表，与 agno 表分离 schema 命名 `platform_*`）

| 表 | 用途 | 关联 FR |
|---|---|---|
| platform_mcp_servers | MCP 注册表 | FR-6 |
| platform_tool_audit | 工具调用审计 | FR-6 |
| platform_eval_suites | 评测集 | FR-7 |
| platform_sandbox_quota | 沙箱配额计数 | FR-10 |

## 4. 关键风险

| 风险 | 缓解 |
|---|---|
| Team/Workflow 声明式水合在 agno 2.8.2 未实证（Agent 已实证） | M1 先做 spike：手工构造 Team config 走 from_dict 全流程，失败则 Team 声明式降级为"代码注册 + UI 展示" |
| PG 分支行为差异（delete_config stage 校验等） | FR-3.3 连接级冒烟清单逐项过 |
| 通知轮询漏/重 | pending 差集以 approval id 为键，内存去重 + 重启容忍重发（webhook 幂等由接收方保证，文档注明） |
| 前端页面工作量膨胀 | 每页严格"列表+详情"两视图，禁止图表库，禁止编辑器类组件 |
