# Agno Phase 1 · MVP — Tasks

| 状态 | draft v1.0 | 周期 | 4–6 周（估） | 前置 | Phase 0 收口 + 云端 PG 到位（M2 前置） |
|---|---|---|---|---|

图例：`[ ]` 未开始 `[~]` 进行中 `[x]` 完成 `[S]` spike（先验证再展开）。

## M0 已完成预置（Phase 0 带入，登记用）

- [x] PG 切换层代码（app/db.py 工厂 + docker-compose.yml 备用 + requirements 锁定 psycopg）✅ 2026-08-10（仅代码，未连接）
- [x] 声明式 Agent 配置层：创建/版本/发布/设当前/删草稿/编辑回显 ✅ 2026-08-10
- [x] UI：workflow 聊天模式 + 内联审批卡片 ✅ 2026-08-10
- [x] 冒烟测试 7/7（含 workflows/console 断言）✅ 2026-08-10

## M1 声明式配置层补全（P0，第 1–2 周）

- [ ] **P1-T1** [S] Team/Workflow config 水合 spike：手工构造 `Team.to_dict()` config → `from_dict(registry)` → run 通过。失败则降级策略见 design D1
- [ ] **P1-T2** `POST /console/teams`（TeamForm，成员按 component_id+version 冻结引用已发布 Agent）
- [ ] **P1-T3** `POST /console/workflows`（WorkflowForm，顺序 steps）
- [ ] **P1-T4** 前端 /agents-admin 扩展为 /components-admin：三 tab（Agents/Teams/Workflows）+ 对应创建表单
- [ ] **P1-T5** 配置层 RBAC：console 写操作需管理员 scope（scope 设计与 FR-2 矩阵一起定）
- 验收：FR-1.4 验收场景（UI 5 分钟组队跑通）

## M2 租户层 + Postgres（P0，第 2–3 周；云端 PG 为硬前置）

- [ ] **P1-T6** JWT_SECRET 轮换（32+ 字节）+ 全量 token 重签 + .env.example 更新
- [ ] **P1-T7** TenantEnforcementMiddleware（sub 格式强制）+ make_token.py 正式化
- [ ] **P1-T8** 双用户隔离测试 + RBAC 矩阵 + isolation_scan 入 CI（Phase 0 T7–T10 平移）
- [ ] **P1-T9** `scripts/pg_smoke.py` 连接级冒烟（含 delete_config stage 校验核查，FR-3.3）
- [ ] **P1-T10** `scripts/migrate_sqlite_to_pg.py`（仅 components/configs/links）
- [ ] **P1-T11** `DB_BACKEND=postgres` 全链路验收（冒烟 + 控制台 + UI e2e）
- 验收：FR-2 / FR-3 验收标准

## M3 UI 管理页 + HITL 闭环（P1，第 3–4 周）

- [ ] **P1-T12** Traces 页（列表 + spans 瀑布）
- [ ] **P1-T13** Sessions 独立页（三 tab）
- [ ] **P1-T14** Metrics 页（原生 /metrics 可视化）
- [ ] **P1-T15** Memory 页（user_profile/user_memory 只读）
- [ ] **P1-T16** 计划面板（`/console/sessions/{id}/plan` 薄端点 + Chat 侧栏 checklist，T13 结论：plan 为骨架、progress 模糊匹配、容忍一轮滞后）
- [ ] **P1-T17** Approvals 管理页（pending 轮询 + resolve，复用内联卡片逻辑）
- [ ] **P1-T18** 审批通知 Webhook（轮询差集 + 重试，env 配置）
- 验收：FR-4 / FR-5 验收标准

## M4 治理：MCP 网关 + 评测门控（P2，第 4–5 周）

- [ ] **P1-T19** MCP 注册表（platform_mcp_servers 表 + CRUD 端点）
- [ ] **P1-T20** console 装配集成：Agent 表单可选 MCP 工具 → include_tools 白名单展开
- [ ] **P1-T21** 评测集 CRUD + 断言引擎（包含/不包含/工具数上限）
- [ ] **P1-T22** 发布门控：`/console/agents/{id}/versions/{v}/publish` 包原生端点，不达标 409
- [ ] **P1-T23**（可选）MCP 代理转发 + 凭证注入 + platform_tool_audit
- 验收：FR-6（简化版）/ FR-7 验收标准

## M5 可观测/渠道/沙箱加固（P3，第 5–6 周）

- [ ] **P1-T24** Langfuse OTel 接入验证 + 运行手册
- [ ] **P1-T25** 租户成本聚合端点 `/console/metrics/by-tenant`
- [ ] **P1-T26** 飞书 interface 样板
- [ ] **P1-T27** 沙箱鉴权 + 配额（429）
- [ ] **P1-T28**（视情况）性能基准补跑（Phase 0 T20/T21 平移，PG 环境下）

## 出口检查单

- [ ] FR-1 ~ FR-7 验收标准全部通过（FR-8~10 视资源裁剪）
- [ ] 全部跑在云端 PG 上，sqlite 仅用于测试
- [ ] CI 含：冒烟（sqlite）+ 隔离扫描 + RBAC 矩阵
- [ ] 运行手册更新（三服务 + PG + 通知 webhook + Langfuse）
- [ ] MVP 评审：是否进入 Phase 2（规模化/多地域/计费）
