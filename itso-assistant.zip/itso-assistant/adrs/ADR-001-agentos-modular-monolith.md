# ADR-001: 以 AgentOS 为运行时主体的模块化单体

- 状态：accepted（2026-08-19）
- 关联：01-初始设计 §3.2、§3.3

## 上下文

ITSO AI Assistant 需要多用户隔离的 Agent 运行时、会话/记忆持久化、HITL 审批、后台 Run 与调度。本仓 `Agno/backend` 已完成 Phase 0 PoC（K1–K8 实测），`Agno/docs/phase-1-mvp` 已规划多租户增量路线。试点 NFR：私有化小规模（<50 ITSO）、数据不出内网。

## 决策

以 **AgentOS（agno==2.8.2）为运行时主体**，ITSO 领域能力（契约/任务/来源适配/调度工具）以**增量 Router + 自研 Toolkit + 平台表**挂载，不拆微服务。原则：*能落到 AgentOS 原生能力的需求，不允许在平台层重写*。

## 后果

- 正面：复用 PoC 已实测的认证/隔离/审批/沙箱/追踪链路；单进程部署满足私有化小规模；main.py 薄装配原则延续
- 负面/风险：Agno 无租户原语（E1），隔离靠 JWT `tenant:user` 编码 + user_isolation + 隔离扫描 CI 兜底；Agno 升级受锁版本约束，schedules 能力未实测（R1，Slice 0 验证）

## 替代方案

- **DeepAgents/LangGraph 内核**（顶层 docs/08 的选择）：生态更强，但 Agno 路线已有 PoC 实测与 MVP 规划资产，业务方已明确选择 Agno 路线；两路线在 docs/08 层面仍需最终对齐（遗留事项）
- **微服务拆分**：试点规模无收益，复杂度不可接受
