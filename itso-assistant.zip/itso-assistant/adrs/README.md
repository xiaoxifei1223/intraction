# ITSO AI Assistant 架构决策记录（ADR）索引

设计主文档：[../01-初始设计.md](../01-初始设计.md)（v1.0，评审通过）

| 编号 | 标题 | 状态 | 日期 |
|---|---|---|---|
| [ADR-001](ADR-001-agentos-modular-monolith.md) | 以 AgentOS 为运行时主体的模块化单体 | accepted | 2026-08-19 |
| [ADR-002](ADR-002-per-itso-agent-contract-driven.md) | 每 ITSO 一个专属 Agent + 契约驱动装配 | accepted | 2026-08-19 |
| [ADR-003](ADR-003-tiered-autonomy-two-level-confirmation.md) | 三级自治 + 两级确认 + 契约治理闸口 | accepted | 2026-08-19 |
| [ADR-004](ADR-004-task-model-three-horizon-execution.md) | 任务一等公民建模 + 三时序执行模式 | accepted | 2026-08-19 |
| [ADR-005](ADR-005-source-adapter-layer-kci-gras.md) | 来源适配层（边界映射防腐），首批 KCI/GRAS 连接器 | accepted | 2026-08-19 |
| [ADR-006](ADR-006-explicit-contract-vs-implicit-memory.md) | 授权信息只进契约（显式），经验沉淀进记忆（隐式） | accepted | 2026-08-19 |
