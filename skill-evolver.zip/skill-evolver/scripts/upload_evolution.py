#!/usr/bin/env python3
"""
Skill Evolution Uploader — 向 Themis (Auto Router) 上报进化结果。

用法:
    python upload_evolution.py \
        --skill-id <skill_name> \
        --skill-path <original_skill_dir> \
        --evolved-md <evolved_skill_md_path> \
        --trace-json <traces_json_path> \
        --mode <fast|standard|deep> \
        --team-id <team_id> \
        --staff-id <staff_id> \
        --agent-id <agent_id> \
        --base-url <themis_url> \
        [--upload-skill]

环境变量（优先级低于命令行参数）:
    AUTO_ROUTER_BASE_URL    默认 http://localhost:8000
    AUTO_ROUTER_AGENT_ID    默认 hostname
    AUTO_ROUTER_TEAM_ID     默认 "default-team"
    AUTO_ROUTER_STAFF_ID    默认 "default-staff"
    AUTO_ROUTER_AGENT_TOKEN 默认空

上报内容:
    1. POST /v1/ingest   — trace + diagnostics + strategy_usage
    2. POST /v1/skills   — evolved skill candidate (当 --upload-skill 时)
"""

from __future__ import annotations

import argparse
import base64
import gzip
import json
import logging
import os
import re
import socket
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# 尝试导入 httpx，否则回退到 urllib
try:
    import httpx
    HAS_HTTPX = True
except Exception:
    HAS_HTTPX = False

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    HAS_URLLIB = True
except Exception:
    HAS_URLLIB = False

# 尝试导入 yaml，否则使用轻量级回退
try:
    import yaml
    HAS_YAML = True
except Exception:
    HAS_YAML = False

logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lightweight YAML parser (fallback when PyYAML is absent)
# ---------------------------------------------------------------------------

def _simple_yaml_load(path: str) -> Dict[str, Any]:
    """Parse a simple two-level YAML file (section: key: value) without external deps."""
    result: Dict[str, Any] = {}
    current_section: Optional[str] = None
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            stripped = line.rstrip("\n\r")
            if not stripped.strip() or stripped.strip().startswith("#"):
                continue
            # Section header
            if not stripped.startswith(" ") and stripped.endswith(":") and ":" not in stripped[:-1]:
                current_section = stripped[:-1].strip()
                result[current_section] = {}
                continue
            # Key: value under current section
            if current_section and ":" in stripped:
                # Remove leading spaces
                content = stripped.lstrip()
                key, _, value = content.partition(":")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                result[current_section][key] = value
    return result


def load_skill_config(script_path: Optional[str] = None) -> Dict[str, Any]:
    """
    读取 skill 目录下的 config.yaml。
    搜索路径：脚本同级目录的 ../config.yaml
    """
    if script_path is None:
        script_path = __file__
    skill_dir = Path(script_path).resolve().parent.parent
    config_path = skill_dir / "config.yaml"
    if not config_path.is_file():
        return {}
    try:
        text = config_path.read_text(encoding="utf-8")
        if HAS_YAML:
            parsed = yaml.safe_load(text)
            return parsed if isinstance(parsed, dict) else {}
        else:
            return _simple_yaml_load(str(config_path))
    except Exception as e:
        logger.debug("Failed to load skill config.yaml: %s", e)
        return {}


# ---------------------------------------------------------------------------
# Config resolver: CLI args > env vars > config.yaml > defaults
# ---------------------------------------------------------------------------

def resolve_config(args: argparse.Namespace) -> Dict[str, str]:
    """
    三层配置解析：命令行参数 > 环境变量 > skill 目录下 config.yaml > 默认值。
    """
    cfg = load_skill_config()
    themis_cfg = cfg.get("themis") or {}
    team_cfg = cfg.get("team") or {}

    def _pick(cli_val, env_key: str, cfg_section: Dict, cfg_key: str, default: str) -> str:
        if cli_val and str(cli_val).strip():
            return str(cli_val).strip()
        env_val = os.getenv(env_key, "").strip()
        if env_val:
            return env_val
        cfg_val = cfg_section.get(cfg_key, "")
        if cfg_val and str(cfg_val).strip():
            return str(cfg_val).strip()
        return default

    return {
        "base_url": _pick(args.base_url, "AUTO_ROUTER_BASE_URL", themis_cfg, "base_url", "http://localhost:8000"),
        "agent_id": _pick(args.agent_id, "AUTO_ROUTER_AGENT_ID", themis_cfg, "agent_id", socket.gethostname()),
        "token": _pick(args.token, "AUTO_ROUTER_AGENT_TOKEN", themis_cfg, "agent_token", ""),
        "team_id": _pick(args.team_id, "AUTO_ROUTER_TEAM_ID", team_cfg, "team_id", "default-team"),
        "staff_id": _pick(args.staff_id, "AUTO_ROUTER_STAFF_ID", team_cfg, "staff_id", "default-staff"),
    }


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

class UploadPolicy:
    def __init__(
        self,
        trace_upload: bool = True,
        diagnostics_upload: bool = True,
        strategy_usage_upload: bool = True,
        skill_upload: bool = False,
        skill_upload_reason: Optional[str] = None,
        immediate: bool = True,
    ):
        self.trace_upload = trace_upload
        self.diagnostics_upload = diagnostics_upload
        self.strategy_usage_upload = strategy_usage_upload
        self.skill_upload = skill_upload
        self.skill_upload_reason = skill_upload_reason
        self.immediate = immediate

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trace_upload": self.trace_upload,
            "diagnostics_upload": self.diagnostics_upload,
            "strategy_usage_upload": self.strategy_usage_upload,
            "skill_upload": self.skill_upload,
            "skill_upload_reason": self.skill_upload_reason,
            "immediate": self.immediate,
        }


class UploadEnvelope:
    def __init__(
        self,
        agent_id: str,
        session_id: str,
        team_id: str,
        staff_id: str,
        upload_policy: UploadPolicy,
        payloads: List[Dict[str, Any]],
    ):
        self.envelope_version = "1.0"
        self.agent_id = agent_id
        self.team_id = team_id
        self.staff_id = staff_id
        self.session_id = session_id
        self.timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self.upload_policy = upload_policy
        self.payloads = payloads

    def to_dict(self) -> Dict[str, Any]:
        return {
            "envelope_version": self.envelope_version,
            "agent_id": self.agent_id,
            "team_id": self.team_id,
            "staff_id": self.staff_id,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "upload_policy": self.upload_policy.to_dict(),
            "payloads": self.payloads,
        }


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _post_with_retry(
    url: str,
    content: bytes,
    headers: Dict[str, str],
    max_retries: int = 3,
) -> Dict[str, Any]:
    """POST gzip body with exponential backoff retry."""
    last_error: Optional[Exception] = None

    for attempt in range(max_retries + 1):
        try:
            if HAS_HTTPX:
                with httpx.Client(timeout=30.0) as client:
                    resp = client.post(url, content=content, headers=headers)
                    resp.raise_for_status()
                    return resp.json()
            elif HAS_URLLIB:
                req = Request(url, data=content, headers=headers, method="POST")
                with urlopen(req, timeout=30.0) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            else:
                raise RuntimeError("No HTTP client available (install httpx or use Python with urllib)")
        except Exception as e:
            last_error = e
            # 403 硬边界拒绝，不重试
            if hasattr(e, "response") and getattr(e.response, "status_code", None) == 403:
                logger.warning("Upload rejected by hard boundary (403): %s", e)
                return {"error": "rejected", "detail": str(e), "status_code": 403}
            if isinstance(e, HTTPError) and e.code == 403:
                logger.warning("Upload rejected by hard boundary (403): %s", e)
                return {"error": "rejected", "detail": str(e), "status_code": 403}

            logger.debug("Upload attempt %d failed: %s", attempt, e)

        if attempt < max_retries:
            wait = 2 ** (attempt + 1)
            logger.info("Retrying upload in %ds (attempt %d/%d)", wait, attempt + 1, max_retries)
            time.sleep(wait)

    logger.warning("Upload max retries exceeded for %s: %s", url, last_error)
    return {"error": "max_retries", "detail": str(last_error)}


# ---------------------------------------------------------------------------
# Compression helpers
# ---------------------------------------------------------------------------

def _compress_skill_content(content: Dict[str, Any]) -> Dict[str, Any]:
    """将 skill_content 中的文本字段进行 gzip + base64 编码。"""
    result: Dict[str, Any] = {}
    for key, value in content.items():
        if isinstance(value, str) and len(value) > 100:
            compressed = gzip.compress(value.encode("utf-8"))
            result[key] = base64.b64encode(compressed).decode("ascii")
            result[f"{key}_encoding"] = "gzip+base64"
        elif isinstance(value, dict):
            result[key] = {
                k: base64.b64encode(gzip.compress(v.encode("utf-8"))).decode("ascii")
                for k, v in value.items()
                if isinstance(v, str)
            }
            result[f"{key}_encoding"] = "gzip+base64"
        else:
            result[key] = value
    return result


# ---------------------------------------------------------------------------
# Build payloads
# ---------------------------------------------------------------------------

def _map_outcome_to_error_type(entry: Dict[str, Any]) -> str:
    """将本地 trace 的失败原因映射到 Cloud Evo bounded evolution 的 error_type。"""
    stuck_at = (entry.get("stuck_at") or "").lower()
    notes = (entry.get("notes") or "").lower()
    combined = stuck_at + " " + notes

    # 优先级 1: 内容缺失/不准确（最常见的问题类型）
    if any(kw in combined for kw in [
        "contains no", "no actual", "no actionable", "zero ", "missing content",
        "lack of", "hollow", "stub", "shell", "placeholder", "purely a",
        "no concrete", "no specific", "no substantive", "insufficient",
        "no information", "no details", "no guidance", "no instructions",
    ]):
        return "hallucination_prop"

    # 优先级 2: 顺序/流程问题
    if any(kw in combined for kw in [
        "wrong order", "incorrect order", "sequence error", "out of order",
        "reorder", "dependency order", "step order", "wrong sequence",
    ]):
        return "wrong_order"

    # 优先级 3: 检索/匹配问题
    if any(kw in combined for kw in [
        "retrieve", "search", "find", "lookup", "match", "query", "filter",
        "retrieval", "mismatch", "not found",
    ]):
        return "retrieval_mismatch"

    # 优先级 4: 过载/复杂性问题
    if any(kw in combined for kw in [
        "overload", "too many", "too much", "complex", "multiple", "many task",
    ]):
        return "skill_overload"

    # 优先级 5: 路由/移交问题
    if any(kw in combined for kw in [
        "route", "handoff", "delegate", "transfer", "assign",
    ]):
        return "routing_ambiguity"

    # 默认：内容缺失/不准确
    return "hallucination_prop"


def build_trace_payload(
    skill_id: str,
    mode: str,
    trace_entries: List[Dict[str, Any]],
    diagnostics: Dict[str, Any],
    agent_id: str,
) -> List[Dict[str, Any]]:
    """构造 /v1/ingest 的 payloads，格式与 Cloud Evo _convert_ingest_batch 兼容。

    将本地 traces.json（exploration/audit 格式）转换为 Cloud Evo VerifiedTrace 格式，
    使 Cloud Evo 能正确解析 skill_id、task_description、error_type 等关键字段。
    """
    payloads: List[Dict[str, Any]] = []
    ts = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    for idx, entry in enumerate(trace_entries):
        is_pass = entry.get("outcome") == "pass"
        stuck_at = entry.get("stuck_at", "") or ""
        notes = entry.get("notes", "") or ""
        strategy_desc = entry.get("strategy_description", "") or ""
        strategy_id = entry.get("strategy_id", f"strategy-{idx}")
        strategy_type = entry.get("strategy_type", "exploration")

        # 映射 error_type（用于 Cloud Evo 的 bound 检查）
        error_type = None
        error_detail = None
        if not is_pass:
            error_type = _map_outcome_to_error_type(entry)
            error_detail = stuck_at if stuck_at else notes

        # Cloud Evo _convert_ingest_batch 期望的 raw trace 格式
        trace_data = {
            "trace_id": f"trace-{skill_id}-{strategy_id}-{int(time.time())}-{idx}",
            "skill_id": skill_id,
            "skill_version": diagnostics.get("parent_version", "1.0.0"),
            "task_type": strategy_type,
            "success": is_pass,
            "outcome_reward": 1.0 if is_pass else 0.0,
            "context": {
                "task_description": strategy_desc,
                "input_tokens": len(strategy_desc.split()) if strategy_desc else 0,
                "retrieved_docs": []
            },
            "execution": {
                "prompt_template_used": "",
                "output": notes if notes else stuck_at,
                "latency_ms": 0,
                "token_usage": 0
            },
            "outcome": {
                "success": is_pass,
                "error_type": error_type,
                "error_detail": error_detail,
                "user_rating": None,
                "user_feedback": None
            },
            "used_skills": [skill_id],
            "participating_executors": [],
        }
        payloads.append({
            "type": "trace",
            "payload_id": trace_data["trace_id"],
            "timestamp": ts,
            "data": trace_data,
        })

    # 2. Diagnostics payload（精简版，保留关键诊断信息）
    if diagnostics:
        success_count = sum(1 for t in trace_entries if t.get("outcome") == "pass")
        fail_count = len(trace_entries) - success_count
        diag_data = {
            "has_failure": not diagnostics.get("audit_pass", True),
            "failure_type": diagnostics.get("failure_stage"),
            "bounded_tag": f"{mode}_evolution",
            "repair_plan_hint": diagnostics.get("repair_plan_hint"),
            "repair_code_pattern": diagnostics.get("repair_code_pattern"),
            "evolution_diagnostics": {
                "mode": mode,
                "final_audit_pass": diagnostics.get("audit_pass", False),
                "final_pass_rate": diagnostics.get("pass_rate", 0.0),
                "trace_count": len(trace_entries),
                "success_count": success_count,
                "fail_count": fail_count,
                "llm_calls": diagnostics.get("llm_calls", 0),
                "auditor_checks": diagnostics.get("auditor_checks", []),
            },
        }
        payloads.append({
            "type": "diagnostics",
            "payload_id": f"diag-{skill_id}-{int(time.time())}",
            "timestamp": ts,
            "data": diag_data,
        })

    return payloads


def _extract_version_from_skill_md(skill_md_path: str) -> str:
    """从 SKILL.md 的 YAML frontmatter 中提取 version 字段。"""
    try:
        text = Path(skill_md_path).read_text(encoding="utf-8")
        if not text.startswith("---"):
            return "1.0.0"
        end = text.find("\n---", 3)
        if end == -1:
            return "1.0.0"
        fm = text[3:end].strip()
        for line in fm.splitlines():
            if line.strip().startswith("version:"):
                _, _, val = line.partition(":")
                return val.strip().strip('"').strip("'") or "1.0.0"
        return "1.0.0"
    except Exception:
        return "1.0.0"


def build_skill_payload(
    skill_id: str,
    skill_path: str,
    evolved_md: str,
    diagnostics: Dict[str, Any],
    agent_id: str,
    staff_id: str,
    reason: str,
    evolved_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """构造 /v1/skills 的请求体。上传的是**进化后的 skill candidate**。

    参数:
        skill_id: skill 标识
        skill_path: 原始 skill 目录路径（用于提取 parent_version）
        evolved_md: 进化后的 SKILL.md 内容（字符串）
        evolved_dir: 进化后的 skill 目录路径（可选，用于读取 scripts/）
    """
    # 从原始 SKILL.md 提取真实 parent_version
    original_md = Path(skill_path) / "SKILL.md"
    parent_version = _extract_version_from_skill_md(str(original_md)) if original_md.is_file() else "1.0.0"
    evolved_version = diagnostics.get("evolved_version", f"{parent_version}-evolved")

    # 收集 scripts：优先从 evolved_dir，否则回退到原始 skill
    scripts: Dict[str, str] = {}
    skill_dir = Path(skill_path)

    # 1. 尝试从 evolved_dir 读取 scripts
    if evolved_dir:
        evolved_scripts_dir = Path(evolved_dir) / "scripts"
        if evolved_scripts_dir.is_dir():
            for f in evolved_scripts_dir.iterdir():
                if f.is_file() and f.stat().st_size < 500 * 1024:
                    try:
                        scripts[f.name] = f.read_text(encoding="utf-8")
                    except Exception:
                        pass

    # 2. 如果 evolved_dir 没有 scripts，回退到原始 skill 目录
    if not scripts:
        orig_scripts_dir = skill_dir / "scripts"
        if orig_scripts_dir.is_dir():
            for f in orig_scripts_dir.iterdir():
                if f.is_file() and f.stat().st_size < 500 * 1024:
                    try:
                        scripts[f.name] = f.read_text(encoding="utf-8")
                    except Exception:
                        pass

    skill_content = {
        "skill_md": evolved_md,
        "scripts": scripts,
    }

    return {
        "skill_id": skill_id,
        "parent_version": parent_version,
        "evolved_version": evolved_version,
        "upload_reason": reason,
        "uploaded_by": staff_id or agent_id,
        "source_trace_id": f"trace-{skill_id}-{int(time.time())}",
        "skill_metadata": {
            "name": skill_id,
            "category": "skill-evolution",
            "tags": ["evolved", "skill-evolver", diagnostics.get("mode", "unknown")],
            "team_id": diagnostics.get("team_id", ""),
        },
        "skill_content": _compress_skill_content(skill_content),
        "evolution_context": {
            "evolution_rounds": diagnostics.get("evolution_rounds", 1),
            "local_confidence": diagnostics.get("pass_rate", 0.0),
            "bounded_tags": [diagnostics.get("mode", "unknown")],
            "diagnosis_summary": diagnostics.get("diagnosis_summary"),
        },
    }




def upload_ingest(
    base_url: str,
    agent_id: str,
    team_id: str,
    staff_id: str,
    payloads: List[Dict[str, Any]],
    token: str = "",
) -> Dict[str, Any]:
    """上报到 /v1/ingest。"""
    envelope = UploadEnvelope(
        agent_id=agent_id,
        session_id=f"sess-{int(time.time())}",
        team_id=team_id,
        staff_id=staff_id,
        upload_policy=UploadPolicy(immediate=True),
        payloads=payloads,
    )
    body = json.dumps(envelope.to_dict(), ensure_ascii=False).encode("utf-8")
    compressed = gzip.compress(body)

    idempotency_key = f"idem-{envelope.session_id}"
    headers = {
        "Content-Type": "application/json",
        "Content-Encoding": "gzip",
        "X-Agent-ID": agent_id,
        "X-Session-ID": envelope.session_id,
        "Idempotency-Key": idempotency_key,
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    return _post_with_retry(
        url=f"{base_url.rstrip('/')}/v1/ingest",
        content=compressed,
        headers=headers,
        max_retries=3,
    )


def upload_skill(
    base_url: str,
    agent_id: str,
    skill_data: Dict[str, Any],
    reason: str,
    token: str = "",
) -> Dict[str, Any]:
    """上报到 /v1/skills。"""
    body = json.dumps(skill_data, ensure_ascii=False).encode("utf-8")
    compressed = gzip.compress(body)

    skill_id = skill_data.get("skill_id", "unknown")
    idempotency_key = f"idem-skill-{skill_id}-{int(time.time())}"
    headers = {
        "Content-Type": "application/json",
        "Content-Encoding": "gzip",
        "X-Agent-ID": agent_id,
        "X-Skill-Upload-Reason": reason,
        "Idempotency-Key": idempotency_key,
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    return _post_with_retry(
        url=f"{base_url.rstrip('/')}/v1/skills",
        content=compressed,
        headers=headers,
        max_retries=3,
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="Skill Evolution Uploader for Themis")
    parser.add_argument("--skill-id", required=True, help="Skill identifier")
    parser.add_argument("--skill-path", required=True, help="Original skill directory path")
    parser.add_argument("--evolved-md", required=True, help="Path to evolved SKILL.md")
    parser.add_argument("--trace-json", required=True, help="Path to trace entries JSON")
    parser.add_argument("--mode", default="standard", choices=["fast", "standard", "deep"])
    parser.add_argument("--team-id", default=os.getenv("AUTO_ROUTER_TEAM_ID", "default-team"))
    parser.add_argument("--staff-id", default=os.getenv("AUTO_ROUTER_STAFF_ID", "default-staff"))
    parser.add_argument("--agent-id", default=os.getenv("AUTO_ROUTER_AGENT_ID", socket.gethostname()))
    parser.add_argument("--base-url", default=os.getenv("AUTO_ROUTER_BASE_URL", "http://localhost:8000"))
    parser.add_argument("--token", default=os.getenv("AUTO_ROUTER_AGENT_TOKEN", ""))
    parser.add_argument("--upload-skill", action="store_true", help="Also upload evolved skill to /v1/skills")
    parser.add_argument("--reason", default="Evolved by skill-evolver meta-skill", help="Skill upload reason")
    parser.add_argument("--output-dir", default="", help="Output directory for evolved skill and evolution summary (e.g., D:/MyCode/TestSkills/Single-evo)")
    parser.add_argument("--generate-summary", action="store_true", help="Generate EVOLUTION_SUMMARY.md in output directory")
    parser.add_argument("--verbose", action="store_true")

    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # 解析配置（CLI > 环境变量 > config.yaml > 默认值）
    config = resolve_config(args)
    logger.info("Resolved config: base_url=%s agent_id=%s team_id=%s staff_id=%s",
                config["base_url"], config["agent_id"], config["team_id"], config["staff_id"])

    # 读取 evolved skill markdown
    evolved_md_path = Path(args.evolved_md)
    if not evolved_md_path.is_file():
        logger.error("Evolved SKILL.md not found: %s", args.evolved_md)
        return 1
    evolved_md = evolved_md_path.read_text(encoding="utf-8")

    # 读取 traces
    trace_path = Path(args.trace_json)
    if not trace_path.is_file():
        logger.error("Trace JSON not found: %s", args.trace_json)
        return 1
    trace_entries = json.loads(trace_path.read_text(encoding="utf-8"))
    if not isinstance(trace_entries, list):
        logger.error("Trace JSON must be a list")
        return 1

    # 构造 diagnostics（从 trace 推导）
    success_count = sum(1 for t in trace_entries if t.get("outcome") == "pass")
    fail_count = len(trace_entries) - success_count
    pass_rate = success_count / len(trace_entries) if trace_entries else 0.0

    diagnostics = {
        "mode": args.mode,
        "parent_version": args.skill_id,  # 简化：用 skill_id 标识父版本
        "evolved_version": f"{args.skill_id}-evolved-{int(time.time())}",
        "audit_pass": pass_rate >= 0.5,  # 简化审计：通过率>=50%算通过
        "pass_rate": pass_rate,
        "failure_stage": None if pass_rate >= 0.5 else "audit_failed",
        "repair_plan_hint": None,
        "repair_code_pattern": None,
        "diagnosis_summary": f"Evolved {args.skill_id} with {success_count}/{len(trace_entries)} passing traces",
        "llm_calls": len(trace_entries) + 2,  # explore + contrast + patch 估算
        "file_reads": 1,
        "file_writes": 1,
        "evolution_rounds": 1,
        "team_id": config["team_id"],
        "auditor_checks": [
            {"name": "silent_bypass", "passed": True, "details": "Primary action present"},
            {"name": "frontmatter", "passed": True, "details": "YAML frontmatter valid"},
            {"name": "literals", "passed": True, "details": "No hardcoded file references"},
        ],
    }

    # 上报 /v1/ingest
    logger.info("Uploading traces to %s/v1/ingest ...", config["base_url"])
    payloads = build_trace_payload(
        skill_id=args.skill_id,
        mode=args.mode,
        trace_entries=trace_entries,
        diagnostics=diagnostics,
        agent_id=config["agent_id"],
    )
    ingest_res = upload_ingest(
        base_url=config["base_url"],
        agent_id=config["agent_id"],
        team_id=config["team_id"],
        staff_id=config["staff_id"],
        payloads=payloads,
        token=config["token"],
    )
    logger.info("Ingest result: %s", ingest_res)

    # 上报 /v1/skills
    skill_res = None
    if args.upload_skill:
        logger.info("Uploading skill candidate to %s/v1/skills ...", config["base_url"])
        skill_data = build_skill_payload(
            skill_id=args.skill_id,
            skill_path=args.skill_path,
            evolved_md=evolved_md,
            diagnostics=diagnostics,
            agent_id=config["agent_id"],
            staff_id=config["staff_id"],
            reason=args.reason,
        )
        skill_res = upload_skill(
            base_url=config["base_url"],
            agent_id=config["agent_id"],
            skill_data=skill_data,
            reason=args.reason,
            token=config["token"],
        )
        logger.info("Skill upload result: %s", skill_res)

    # ------------------------------------------------------------------
    # 保存 evolved skill 到输出目录
    # ------------------------------------------------------------------
    output_dir = Path(args.output_dir) if args.output_dir else None
    if output_dir:
        save_evolved_skill(
            skill_id=args.skill_id,
            skill_path=args.skill_path,
            evolved_md=evolved_md,
            output_dir=output_dir,
        )

    # ------------------------------------------------------------------
    # 生成 Evolution Summary
    # ------------------------------------------------------------------
    if args.generate_summary and output_dir:
        summary_path = generate_evolution_summary(
            skill_id=args.skill_id,
            skill_path=args.skill_path,
            evolved_md=evolved_md,
            output_dir=output_dir,
            trace_entries=trace_entries,
            diagnostics=diagnostics,
            mode=args.mode,
        )
        logger.info("Evolution summary written to: %s", summary_path)
    elif args.generate_summary and not output_dir:
        logger.warning("--generate-summary requires --output-dir to be set")

    # 输出结果摘要（方便调用方解析）
    summary = {
        "ingest": ingest_res,
        "skill": skill_res,
        "diagnostics": diagnostics,
        "output_dir": str(output_dir) if output_dir else None,
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

def save_evolved_skill(
    skill_id: str,
    skill_path: str,
    evolved_md: str,
    output_dir: Path,
) -> Path:
    """将优化后的 skill 保存到输出目录，保持原始目录结构。"""
    skill_out = output_dir / skill_id
    skill_out.mkdir(parents=True, exist_ok=True)

    # 写入优化后的 SKILL.md
    (skill_out / "SKILL.md").write_text(evolved_md, encoding="utf-8")

    # 复制原始 skill 中的 scripts, references, assets（如果进化过程未修改它们）
    src = Path(skill_path)
    for subdir in ("scripts", "references", "assets"):
        src_sub = src / subdir
        if src_sub.is_dir():
            dst_sub = skill_out / subdir
            dst_sub.mkdir(parents=True, exist_ok=True)
            for f in src_sub.iterdir():
                if f.is_file():
                    try:
                        (dst_sub / f.name).write_bytes(f.read_bytes())
                    except Exception:
                        pass

    logger.info("Evolved skill saved to: %s", skill_out)
    return skill_out


def _extract_frontmatter_field(text: str, field: str) -> str:
    """从 YAML frontmatter 中提取指定字段的值。"""
    if not text.startswith("---"):
        return ""
    end = text.find("\n---", 3)
    if end == -1:
        return ""
    fm = text[3:end].strip()
    for line in fm.splitlines():
        stripped = line.strip()
        if stripped.startswith(f"{field}:"):
            _, _, val = line.partition(":")
            val = val.strip().strip('"').strip("'")
            if val:
                return val
            # multi-line
            idx = fm.splitlines().index(line)
            lines = []
            for l in fm.splitlines()[idx + 1:]:
                if l.startswith(" ") or l.startswith("  "):
                    lines.append(l.strip())
                else:
                    break
            return " ".join(lines)
    return ""


def _count_code_blocks(text: str) -> int:
    """统计 markdown 中的代码块数量。"""
    return len(re.findall(r"```[\w]*\n", text))


def _count_tables(text: str) -> int:
    """统计 markdown 中的表格数量（按 |---| 分隔行判断）。"""
    return len(re.findall(r"\|[\s\-:]+\|", text))


def generate_evolution_summary(
    skill_id: str,
    skill_path: str,
    evolved_md: str,
    output_dir: Path,
    trace_entries: List[Dict[str, Any]],
    diagnostics: Dict[str, Any],
    mode: str,
) -> Path:
    """
    生成 EVOLUTION_SUMMARY.md，格式参考 iam-policy-creator 风格。
    脚本自动提取所有可量化数据；定性对比留给 AI 在进化过程中补充。
    """
    original_md_path = Path(skill_path) / "SKILL.md"
    original_md = original_md_path.read_text(encoding="utf-8") if original_md_path.is_file() else ""
    parent_version = _extract_version_from_skill_md(str(original_md_path)) if original_md_path.is_file() else "1.0.0"
    evolved_version = _extract_version_from_text(evolved_md) or f"{parent_version}-evo"

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    success_count = sum(1 for t in trace_entries if t.get("outcome") == "pass")
    pass_rate = diagnostics.get("pass_rate", 0.0)

    # 可量化指标
    orig_lines = len(original_md.splitlines()) if original_md else 0
    evol_lines = len(evolved_md.splitlines()) if evolved_md else 0
    orig_blocks = _count_code_blocks(original_md)
    evol_blocks = _count_code_blocks(evolved_md)
    orig_tables = _count_tables(original_md)
    evol_tables = _count_tables(evolved_md)

    # 提取关键 frontmatter 字段
    orig_name = _extract_frontmatter_field(original_md, "name") or "(missing)"
    orig_desc = _extract_frontmatter_field(original_md, "description") or "(missing)"
    evol_name = _extract_frontmatter_field(evolved_md, "name") or skill_id
    evol_desc = _extract_frontmatter_field(evolved_md, "description") or "(missing)"
    orig_tags = _extract_frontmatter_field(original_md, "tags") or "(missing)"
    evol_tags = _extract_frontmatter_field(evolved_md, "tags") or "(missing)"

    # Audit checks
    audit_checks = diagnostics.get("auditor_checks", [])
    audit_lines = "\n".join(
        f"- **{c.get('name', '?').replace('_', ' ').title()}**: {'✅ PASS' if c.get('passed') else '❌ FAIL'} — {c.get('details', '')}"
        for c in audit_checks
    ) if audit_checks else "- (No audit data available)"

    # Trace results
    trace_lines = "\n".join(
        f"| {t.get('strategy_id', '?')} | {t.get('outcome', '?').upper()} | {t.get('notes', t.get('stuck_at', '-'))[:60]}{'...' if len(t.get('notes', '') or t.get('stuck_at', '') or '') > 60 else ''} |"
        for t in trace_entries
    )

    md = f"""# Skill Evolution Summary

## Skill Info
- **Name**: {skill_id}
- **Source Version**: {parent_version}
- **Optimized Version**: {evolved_version}
- **Date**: {today}
- **Evolution Type**: Template-to-Professional Transformation
- **Mode**: {mode}

---

## Optimization Overview

### 1. Metadata Enhancements

| Field | Before | After |
|-------|--------|-------|
| `name` | {orig_name} | {evol_name} |
| `description` | {orig_desc[:50]}{'...' if len(orig_desc) > 50 else ''} | {evol_desc[:50]}{'...' if len(evol_desc) > 50 else ''} |
| `tags` | {orig_tags[:40]}{'...' if len(orig_tags) > 40 else ''} | {evol_tags[:40]}{'...' if len(evol_tags) > 40 else ''} |
| `version` | {parent_version} | {evolved_version} |

### 2. Content Structure Changes

#### Before (v{parent_version})
```
SKILL.md (~{orig_lines} lines)
<!-- TODO: AI 补充原始 skill 的章节结构 -->
```

#### After (v{evolved_version})
```
SKILL.md (~{evol_lines} lines)
<!-- TODO: AI 补充优化后 skill 的章节结构 -->
```

### 3. Key Additions

<!-- TODO: AI 填写 — 列出本次进化新增的核心模块/章节 -->

| Module | Description | Value |
|--------|-------------|-------|
| <!-- TODO --> | <!-- TODO --> | <!-- TODO --> |

### 4. Tool Support Changes

<!-- TODO: AI 填写 — 如果有 allowed-tools 的变化 -->

| Tool | Before | After |
|------|--------|-------|
| <!-- TODO --> | <!-- TODO --> | <!-- TODO --> |

### 5. Error Handling Improvements

#### Before
<!-- TODO: AI 填写原始 skill 的错误处理方式 -->

#### After
<!-- TODO: AI 填写优化后的错误处理表格或描述 -->

---

## Quantitative Comparison

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Total Lines** | ~{orig_lines} | ~{evol_lines} | {f"+{evol_lines - orig_lines} ({(evol_lines/max(orig_lines,1)-1)*100:.0f}%)" if evol_lines >= orig_lines else f"{evol_lines - orig_lines}"} |
| **Code Examples** | {orig_blocks} | {evol_blocks} | {f"+{evol_blocks - orig_blocks}" if evol_blocks >= orig_blocks else f"{evol_blocks - orig_blocks}"} |
| **Structured Tables** | {orig_tables} | {evol_tables} | {f"+{evol_tables - orig_tables}" if evol_tables >= orig_tables else f"{evol_tables - orig_tables}"} |
| **Pass Rate (Stress-Test)** | - | {success_count}/{len(trace_entries)} ({pass_rate:.0%}) | <!-- 通过率说明 --> |

---

## Stress-Test Results

| Strategy | Outcome | Finding |
|----------|---------|---------|
{trace_lines}

**Overall Pass Rate**: {success_count}/{len(trace_entries)} ({pass_rate:.0%})

---

## Audit Results

{audit_lines}

---

## Quality Assessment

### Before
<!-- TODO: AI 填写 — 原始 skill 的主要问题（如模板化、缺少示例、silent-bypass 等） -->

### After
<!-- TODO: AI 填写 — 优化后 skill 的核心优势（如生产就绪、有具体命令、覆盖边界情况等） -->

---

## Conclusion

<!-- TODO: AI 填写 — 用 3-5 句话总结这次进化的核心价值 -->

1. <!-- TODO -->
2. <!-- TODO -->
3. <!-- TODO -->

---

## Files Generated

```
{output_dir / skill_id}
├── SKILL.md              # Optimized skill (v{evolved_version})
└── EVOLUTION_SUMMARY.md  # This document
```

---

*Evolution performed by skill-evolver meta-skill ({mode} mode)*
*Original skill location: `{skill_path}`*
*Evolved skill location: `{output_dir / skill_id}`*
"""

    summary_path = output_dir / "EVOLUTION_SUMMARY.md"
    summary_path.write_text(md, encoding="utf-8")
    return summary_path


def _extract_version_from_text(text: str) -> str:
    """从 markdown 文本中提取 version 字段。"""
    if not text.startswith("---"):
        return ""
    end = text.find("\n---", 3)
    if end == -1:
        return ""
    fm = text[3:end].strip()
    for line in fm.splitlines():
        if line.strip().startswith("version:"):
            _, _, val = line.partition(":")
            return val.strip().strip('"').strip("'")
    return ""


def _extract_description(text: str) -> str:
    """从 markdown 文本中提取 description 字段。"""
    if not text.startswith("---"):
        return ""
    end = text.find("\n---", 3)
    if end == -1:
        return ""
    fm = text[3:end].strip()
    for line in fm.splitlines():
        stripped = line.strip()
        if stripped.startswith("description:") or stripped.startswith("description:|"):
            _, _, val = line.partition(":")
            val = val.strip().strip('"').strip("'")
            if val:
                return val
            # multi-line description: read subsequent indented lines
            idx = fm.splitlines().index(line)
            desc_lines = []
            for l in fm.splitlines()[idx + 1:]:
                if l.startswith(" ") or l.startswith("  "):
                    desc_lines.append(l.strip())
                else:
                    break
            return " ".join(desc_lines)
    return ""


if __name__ == "__main__":
    sys.exit(main())
