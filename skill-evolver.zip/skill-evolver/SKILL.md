---
name: skill-evolver
description: |
  Meta-skill for evolving and improving other skills through structured error exploration,
  contrastive analysis, surgical patching, and independent audit.

  TRIGGER PHRASES — load this skill when the user says ANY of the following:
  - "进化 xxx skill" / "优化 xxx skill" / "改进 xxx skill" / "升级 xxx skill"
  - "evolve the xxx skill" / "refine the xxx skill" / "optimize the xxx skill" / "improve the xxx skill"
  - "xxx skill 不好" / "xxx skill 不行" / "xxx skill 有问题" / "xxx skill 需要改进"
  - "xxx skill 不好用" / "xxx skill 缺东西" / "xxx skill 太简单"
  - "进化 D:\\path\\to\\skill" / "优化 C:\\path\\to\\skill" / "evolve /path/to/skill"
  - "把 xxx skill 进化一下" / "帮我进化 xxx skill" / "请你进化 xxx skill"
  - "xxx skill 需要增强" / "xxx skill 需要升级" / "xxx skill 需要优化"
  - "xxx skill 的 output 到 D:\\dir" / "xxx skill 输出到 C:\\dir"
  - Any user input containing BOTH a skill name/path AND the word "进化" or "evolve" or "optimize" or "improve" or "refine"
  - Any user input containing a skill path (e.g., D:\\MyCode\\...\\skill-name) AND a verb like "进化/优化/改进/升级/evolve/refine/optimize/improve"

  What the skill does:
  1. Parse the user's intent to extract skill name, skill path, and output directory
  2. Load the current SKILL.md and bundled resources
  3. Design K=3-4 stress-test strategies targeting the skill's weak spots
  4. Run parallel sub-agents to explore failure modes
  5. Contrast winners vs losers to identify missing guidance
  6. Apply surgical patches (localized edits, not rewrites)
  7. Run an independent auditor (9 checks including silent-bypass, overfit, under-abstraction)
  8. Save the evolved skill to the user-specified output directory
  9. Generate EVOLUTION_SUMMARY.md for human review
  10. Upload traces + evolved skill to Themis for cloud co-evolution

  DO NOT load this skill for: creating a new skill from scratch (use skill-creator),
  debugging code, or general coding tasks.
version: 1.0.1
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [meta-skill, evolution, self-improvement, skill-evolver]
---

# Skill Evolver (Meta-Skill)

> **Meta-skill** that authors, deploys, and refines domain-specific skills.
> Inspired by: SkillEvolver (arXiv:2605.10500v1) + Claude Code Skill-Creator design patterns.

## When to Use

Invoke this skill when the user signals a skill needs improvement:

- **Complaint-triggered**: "The `pdf-reader` skill is broken", "`data-pipeline` skill misses date-format edge cases"
- **Explicit request**: "Evolve the `api-testing` skill", "Refine `frontend-builder`", "Optimize skill at `D:/skills/my-skill`"
- **Failure-driven**: A skill was loaded but the task failed; the user asks to fix the skill itself

## Evolution Pipeline

```
Parse Intent → Load Skill → Error Exploration (K stress-tests)
  → Contrastive Analysis (winners \ losers)
  → Surgical Patch
  → Independent Audit
  → Finalize & Upload
```

Unlike one-shot generation, this pipeline **deploys the skill in simulated scenarios first**, so failures come from actual usage traces, not from the authoring agent's self-reflection.

## Step-by-Step Workflow

### Step 0 — Parse Intent

Extract from the user's message:

1. **Skill name** — the identifier (e.g., `pdf-reader`)
2. **Skill path** — directory containing `SKILL.md` (ask user if ambiguous)
3. **User complaint / improvement hint** — what went wrong

If the user only gives a name, search common skill directories:
- `~/.config/agents/skills/`
- `~/.kimi/skills/`
- `.agents/skills/`
- User-provided paths

Read the current `SKILL.md` and any bundled resources (`scripts/`, `references/`, `assets/`).

### Step 1 — Error Exploration (Strategy-Diversified)

**Goal**: Expose failure modes that the current skill hides.  
**Method**: Design **K = 3–4 stress-test strategies** aimed at the skill's weak spots, then run each in a fresh sub-agent.

#### 1.1 Extract Decision Axes

Analyze the skill and identify 2–3 **decision axes** — dimensions where different approaches could vary:

| Axis type | Example |
|-----------|---------|
| Input variation | Different file sizes, encodings, schema versions |
| Platform variance | Windows vs macOS path handling, shell differences |
| Interpretation depth | Quick start vs advanced edge-case handling |
| Error handling | Graceful degradation vs strict failure |

#### 1.2 Design Stress-Test Strategies

For each axis, write a concrete **strategy description** that a sub-agent can follow. Target observed or suspected weak spots:

```
Strategy 1: Minimal-input stress — provide the smallest valid input to test
           whether the skill's primary action still triggers.
Strategy 2: Platform-mismatch stress — simulate the opposite platform from
           what the skill assumes (e.g., Windows paths on a POSIX skill).
Strategy 3: Edge-case stress — provide input that is technically valid but
           at a boundary (empty file, maximum length, unusual encoding).
Strategy 4: Error-cascade stress — provide slightly malformed input and
           observe whether the skill guides recovery or silently fails.
```

**Rules for strategies**:
- Each strategy must differ on at least one major axis
- No strategy should copy training-instance constants (filenames, IDs, hardcoded values)
- Strategies must be **executable** by a fresh agent that only sees the skill + task

#### 1.3 Run Parallel Exploration

For each strategy, spawn a **fresh sub-agent** via the `Agent` tool with this prompt:

```
You are a Domain-Skill Agent testing a skill.
You have ONLY the following skill loaded:
--- SKILL START ---
<current SKILL.md content>
--- SKILL END ---

Your task: <strategy description>
Constraints:
- Do NOT use any knowledge outside the skill.
- Report: (a) whether you could follow the skill, (b) where you got stuck,
  (c) whether the skill's primary action was triggered, (d) any silent
  bypass (you ignored the skill and improvised).
- Return a JSON summary: {"outcome": "pass|fail", "stuck_at": "...",
  "primary_action_triggered": true|false, "silent_bypass": true|false,
  "notes": "..."}
```

Collect all JSON summaries as **exploration traces**.

### Step 2 — Contrastive Analysis

Compare **winning traces** (`outcome: pass`) vs **losing traces** (`outcome: fail`).

**Questions to answer**:
1. What did winners do that losers lacked? (missing guidance)
2. Where did the skill **mislead** the agent? (wrong or outdated instructions)
3. What was **under-specified**? (agent had to guess)
4. What caused **silent bypass**? (agent ignored the skill and improvised)
5. Are there **untraceable claims**? ("always", "never", "required" without evidence)

**Output**: A structured delta (`Δ`) with:

```json
{
  "analysis_summary": "One-sentence summary of the root cause",
  "additions": [
    {"target_section": "Quick Start|Constraints|Examples|Scripts",
     "new_content": "...",
     "reason": "..."}
  ],
  "deletions": [
    {"target_section": "...", "old_content": "...", "reason": "..."}
  ],
  "modifications": [
    {"target_section": "...", "old_content": "...", "new_content": "...",
     "reason": "..."}
  ]
}
```

**Guidelines**:
- ONLY change sections that the traces **prove** are wrong or missing
- Preserve all working guidance
- Do NOT add generic advice available from pretraining alone
- Target 1–3 specific issues max per iteration

### Step 3 — Surgical Patch

Apply the delta as a **surgical patch** (localized edit, not a rewrite).

**Patch rules**:
1. Apply `modifications` first (exact string match, fallback to fuzzy)
2. Then `additions` at appropriate sections
3. Then `deletions`
4. Preserve YAML frontmatter (`name`, `description`, `version`)
5. Bump version: `1.0.0` → `1.0.1` (or `v1.0.0` → `v1.0.1`)

**If no current skill** (creating from scratch):
- Generate a minimal `SKILL.md` with YAML frontmatter
- Include only what the traces prove is needed

### Step 4 — Independent Audit

Run an **auditor pass** on the patched skill. Check these 9 items:

| # | Check | What it catches |
|---|-------|-----------------|
| 1 | **Framing** | Name/description borrows a specific instance noun instead of abstract operation |
| 2 | **Literals** | Hardcoded filenames, field names, entity strings, or soft-qualifier numericals |
| 2b | **Script bloat** | Individual script > 200 lines (likely a bundled solution generator) |
| 3 | **Untraceable claims** | Imperative assertions ("never", "always", "required") without trace provenance |
| 4 | **Shape-bake** | Scripts index by hardcoded column/sheet/key without runtime probe |
| 5 | **Coverage** | Mechanical task with zero bundled scripts (when scripts would help) |
| 6 | **X-ref** | Any ≥4-char string literal matching a training filename/field/value |
| 7 | **Under-abstraction** | Parametric-axis constant without "re-derive at runtime" instruction |
| 8 | **Primary-action hoisting** | Primary script declared but constraints/background prose routes before invocation |
| 9 | **Silent-bypass** | Primary script declared but exploration traces contain zero invocations under majority-fail |

**Audit method**: Spawn a fresh sub-agent with ONLY the patched skill and ask it to attempt one of the stress-test tasks. Observe whether:
- The skill is actually loaded and followed
- The primary action is triggered
- The agent improvises instead of following the skill

If any check fails, convert the violation into a **refinement target** and return to Step 3 (Surgical Patch).

### Step 5 — Finalize, Summarize & Upload

#### 5.1 Save the evolved skill to output directory

将优化后的 skill 写入**输出目录**（保持原始目录结构）。如果用户指定了输出目录（如 `D:/MyCode/TestSkills/Single-evo`），按以下结构保存：

```
<output-dir>/
└── <skill-name>/
    ├── SKILL.md              ← 优化后的 SKILL.md
    ├── scripts/              ← 如果有修改后的 scripts
    └── references/           ← 如果有修改后的 references
```

如果用户未指定输出目录，默认保存到原始 skill 同级目录下的 `Single-evo/<skill-name>/`。

**命名规则**： evolved version 使用 `<原始版本>-evo-<日期>` 格式，例如 `v1.0.0-evo-20250607`。

#### 5.2 Generate Evolution Summary（给人看的进化总结）

每次进化完成后，必须生成一份 **`EVOLUTION_SUMMARY.md`**，放在**输出目录的根目录**下（与 evolved skill 目录同级）。这份文档是给人审查的，不是给机器消费的。

**文档结构模板**：

```markdown
# Skill Evolution Summary

## Skill Information

| Field | Value |
|-------|-------|
| **Skill Name** | <skill_name> |
| **Source Path** | <原始 skill 路径> |
| **Source Version** | <从原始 frontmatter 提取的版本> |
| **Optimized Version** | <进化后的版本> |
| **Evolution Date** | <YYYY-MM-DD> |
| **Evolution Mode** | <fast|standard|deep> |
| **Domain** | <从原始 description 推断的领域> |

---

## Optimization Overview

简述这次进化的核心目标和转变。例如：
- 从模板化描述转变为可操作的步骤
- 补充了领域特定的最佳实践
- 修复了 silent-bypass 或 under-abstraction 问题

### Key Transformation Goals
1. <目标1>
2. <目标2>
3. <目标3>

---

## 1. Metadata Enhancements

| Field | Before | After | Improvement |
|-------|--------|-------|-------------|
| **Description** | "..." | "..." | <改进说明> |
| **Version** | x.y.z | x.y.z-evodate | 版本升级 |
| **Tags/Triggers** | ... | ... | <改进说明> |

---

## 2. Content Structure Changes

### Before
```
<原始 skill 的目录结构>
```
**Stats**: ~X lines, Y examples

### After
```
<优化后 skill 的目录结构>
```
**Stats**: ~X lines, Y examples, Z commands

---

## 3. Key Additions

### 3.1 新增模块/章节
| 模块 | 描述 | 价值 |
|------|------|------|
| <模块名> | <描述> | <为什么重要> |

### 3.2 新增示例/命令
| 类型 | 数量 | 描述 |
|------|------|------|
| <类型> | N | <描述> |

---

## 4. Error Handling Improvements

### Before
```markdown
| Error | Cause | Solution |
|-------|-------|----------|
| <原始的通用错误> | ... | ... |
```

### After
```markdown
| Error | Cause | Solution |
|-------|-------|----------|
| <领域特定的具体错误> | ... | 包含具体命令 |
```

---

## 5. Quantitative Comparison

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Total Lines** | ~X | ~Y | Zx |
| **Code Examples** | N | M | +K |
| **Error Scenarios** | N | M | +K |
| **Decision Tables** | N | M | +K |
| **Trigger Phrases** | N | M | +K |

---

## 6. Stress-Test Results

| Strategy | Outcome | Finding |
|----------|---------|---------|
| <策略1> | pass/fail | <发现> |
| <策略2> | pass/fail | <发现> |
| <策略3> | pass/fail | <发现> |

**Pass Rate**: X/Y (Z%)

---

## 7. Audit Results

| Check | Status | Details |
|-------|--------|---------|
| Silent-bypass | ✅/❌ | ... |
| Frontmatter | ✅/❌ | ... |
| Literals | ✅/❌ | ... |
| Under-abstraction | ✅/❌ | ... |
| Primary-action hoisting | ✅/❌ | ... |

---

## Conclusion

总结这次进化的核心价值和影响。例如：
- 从模板占位符转变为生产就绪的 skill
- 新增的具体能力（如安全加固、成本优化）
- 对不同用户群体的价值

### Impact Assessment
- **For New Users**: ...
- **For Experienced Users**: ...

### Future Enhancement Opportunities
- <潜在改进点1>
- <潜在改进点2>

---

## Change Log

### v<新版本> (<日期>)
- ✅ <改进项1>
- ✅ <改进项2>
- ✅ <改进项3>

---

*Evolution performed by skill-evolver meta-skill.*
*Original skill location: `<原始路径>`*
*Evolved skill location: `<输出路径>`*
```

**生成规则**：
- 必须包含 **Before vs After 的量化对比**（行数、示例数、错误场景数）
- 必须列出 **stress-test 的结果和发现**
- 必须列出 **audit 的通过情况**
- 结论部分要说明 **对谁有价值**（新手/专家/团队）

#### 5.3 Build trace JSON

Create a `traces.json` file with the exploration and audit results.区分 exploration traces（ stress-test 结果）和 audit trace（独立审计结果）：

```json
[
  {
    "type": "exploration",
    "strategy_id": "stress-minimal-input",
    "strategy_type": "exploration",
    "strategy_description": "Minimal-input stress test",
    "outcome": "pass",
    "stuck_at": null,
    "primary_action_triggered": true,
    "silent_bypass": false,
    "notes": "Skill guided correctly with 1-line input"
  },
  {
    "type": "exploration",
    "strategy_id": "stress-platform-mismatch",
    "strategy_type": "exploration",
    "strategy_description": "Platform-mismatch stress test",
    "outcome": "fail",
    "stuck_at": "Path handling section assumes POSIX only",
    "primary_action_triggered": false,
    "silent_bypass": true,
    "notes": "Agent ignored skill and used pathlib manually"
  },
  {
    "type": "audit",
    "strategy_id": "independent-audit",
    "outcome": "pass",
    "notes": "All 9 checks passed, no silent bypass detected"
  }
]
```

#### 5.4 Upload to Themis（一键完成）

使用 **`scripts/evolve_and_upload.py`** 一键完成：保存 skill + 生成 summary + 上报 Themis。

**参数说明**（全部来自本次进化过程的上下文，不是固定值）：

| 参数 | 来源 |
|------|------|
| `--skill-id` | 用户指定的 skill 名称 |
| `--skill-path` | 用户指定的原始 skill 目录 |
| `--evolved-md` | Step 5.1 中写入的优化后 SKILL.md 文件路径 |
| `--trace-json` | Step 5.3 中生成的 traces.json 文件路径 |
| `--output-dir` | 用户指定的输出目录（如 `D:/MyCode/TestSkills/Single-evo`） |
| `--mode` | 本次进化使用的模式（fast/standard/deep） |
| `--reason` | 用户反馈的问题描述或进化目标简述 |

**命令模板**（由 AI 根据实际对话填充变量后执行）：

```bash
python <skill-evolver路径>/scripts/evolve_and_upload.py \
  --skill-id "<用户指定的skill名称>" \
  --skill-path "<用户指定的原始skill目录>" \
  --evolved-md "<优化后的SKILL.md路径>" \
  --trace-json "<traces.json路径>" \
  --mode <fast|standard|deep> \
  --output-dir "<用户指定的输出目录>" \
  --reason "<简述用户反馈的问题和进化目标>"
```

**完整示例**（假设用户说："进化 `D:/MyCode/TestSkills/Human/13-aws-skills/dynamodb-table-designer`，输出到 `D:/MyCode/TestSkills/Single-evo`"）：

```bash
python D:/MySkill/skill-evolver/scripts/evolve_and_upload.py \
  --skill-id "dynamodb-table-designer" \
  --skill-path "D:/MyCode/TestSkills/Human/13-aws-skills/dynamodb-table-designer" \
  --evolved-md "D:/MyCode/TestSkills/Single-evo/dynamodb-table-designer/SKILL.md" \
  --trace-json "D:/MyCode/TestSkills/Single-evo/dynamodb-table-designer/traces.json" \
  --mode standard \
  --output-dir "D:/MyCode/TestSkills/Single-evo" \
  --reason "用户反馈：dynamodb-table-designer  skill 缺少分区键设计模式。优化目标：添加分区键策略、GSI/LSI设计、RCU/WCU计算示例。"
```

**这个脚本会一次性完成 4 件事**：
1. 将 evolved skill 保存到 `--output-dir/<skill-name>/`
2. 生成 `EVOLUTION_SUMMARY.md` 在 `--output-dir/`
3. 上报 trace + diagnostics + strategy_usage 到 `/v1/ingest`
4. 上报 evolved skill candidate 到 `/v1/skills`

**配置来源**（优先级从高到低）：
1. **命令行参数** — `--base-url`, `--team-id`, `--staff-id`
2. **环境变量** — `AUTO_ROUTER_BASE_URL`, `AUTO_ROUTER_TEAM_ID`
3. **`config.yaml`** — `skill-evolver/config.yaml`（推荐，一次配置永久生效）
4. **默认值**

**Themis behavior**:
- Ingest data 按 `team_id` 缓冲，达到 **10 条**触发批量 dispatch
- Skill candidates 按 `team_id` 缓冲，达到 **3 个 skills**触发 Cloud Evo 协同进化

## Best Practices

1. **Start with 3 stress-test strategies** — this is the sweet spot for cost vs quality
2. **Be specific in strategy descriptions** — vague strategies produce vague traces
3. **Preserve working guidance** — surgical patch, not rewrite
4. **Watch for Silent-Bypass** — if the agent ignores the skill, the primary action is not hoisted enough
5. **Team ID matters** — cloud co-evolution only triggers when `team_id` is set and the team reaches the threshold
6. **Iterate only if needed** — one pass (R=1) often gives 80% of the gain; a second pass (R=2) fixes under-abstraction and script loss

## Failure Modes

| Symptom | Cause | Fix |
|---------|-------|-----|
| "No skill found" | Path incorrect or skill not installed | Ask user for the exact directory containing `SKILL.md` |
| Sub-agent returns empty | Strategy description too vague | Rewrite strategy with concrete input/output examples |
| Audit always passes | Auditor shares context with author | Ensure auditor sub-agent has NO access to evolution reasoning |
| Upload 403 rejected | OPA hard boundary / missing team_id | Check `AUTO_ROUTER_TEAM_ID` and `AUTO_ROUTER_STAFF_ID` are set |
| Skill not improving | Strategies target wrong axes | Re-examine decision axes; ask user what specifically failed |

## Notes

- This skill runs **synchronously** in the current turn. For large skills, warn the user it may take 1–2 minutes.
- Each stress-test spawns a sub-agent with limited tool access (recommended: `ReadFile`, `WriteFile`, `Shell` only).
- Token usage is logged in the trace; monitor costs for deep mode.
- The evolved skill is additive — old versions remain in version control for comparison.
