"""EvolutionEngine — SkillEvolver core for hermes-lite.

Implements the Explore → Author → Deploy → Refine loop without Docker.
Trials run as forked AIAgent threads; skills are mutated via skill_manage.
"""

from __future__ import annotations

import contextlib
import json
import logging
import os
import re
import threading
import time
import uuid
from typing import Any, Dict, List, Optional

from agent.evolution_models import (
    AuditCheck,
    AuditReport,
    ContrastDelta,
    SkillPackage,
    SkillPatch,
    TaskDefinition,
    Trajectory,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_PARSE_TASK_PROMPT = """Analyze the following task and extract the key decision axes — the dimensions along which different strategies or approaches could vary.

Task: {description}
Domain: {domain}

Return ONLY a JSON array of strings, e.g.:
["axis1", "axis2", "axis3"]
"""

_GENERATE_STRATEGIES_PROMPT = """Given the following decision axes for a task, generate {width} diverse strategies.
Each strategy should explore a different combination of choices along the axes.

Decision axes: {axes}
Task: {description}

Return ONLY a JSON array of objects, each with a "name" and "description" field:
[{{"name": "strategy1", "description": "..."}}, ...]
"""

_GENERATE_STRESS_TESTS_PROMPT = """Given the current skill and past trajectories, generate {width} stress-test strategies that target the weak spots.

Current skill version: {skill_version}
Task: {description}
Past failures: {failures}

Return ONLY a JSON array of objects, each with a "name" and "description" field:
[{{"name": "stress1", "description": "..."}}, ...]
"""

_CONTRAST_PROMPT = """Analyze the following trial trajectories. Some passed, some failed.
Identify what distinguishes winning strategies from losing ones.

Winners ({winner_count}):
{winners}

Losers ({loser_count}):
{losers}

Return a structured analysis with:
1. What worked (patterns in winners)
2. What failed (patterns in losers)
3. Specific additions, deletions, or modifications to the skill that would improve it

Return ONLY valid JSON with this structure:
{{
  "analysis_summary": "...",
  "additions": [{{"target_section": "prose|code|constraints", "new_content": "...", "reason": "..."}}],
  "deletions": [{{"target_section": "...", "old_content": "...", "reason": "..."}}],
  "modifications": [{{"target_section": "...", "old_content": "...", "new_content": "...", "reason": "..."}}]
}}
"""

_DISTILL_PROMPT = """Write a complete SKILL.md for a new skill based on the following contrast analysis.

Task: {description}
Domain: {domain}
Analysis: {analysis}

The SKILL.md MUST start with YAML frontmatter containing at least:
---
name: {skill_name}
description: Brief description of what this skill does
version: 1.0.0
---

Then write the markdown body with:
- Overview
- Rules / Steps
- Examples
- Pitfalls / Notes

Return ONLY the SKILL.md content.
"""

_AUDIT_SYNTAX_PROMPT = """Review the following SKILL.md for syntax and structural issues.

{skill_content}

Return ONLY valid JSON:
{{"passed": true/false, "details": "...", "severity": "info|warning|critical"}}
"""

_AUDIT_SILENT_BYPASS_PROMPT = """Review the following trajectories and determine if the skill was actually used during the trials, or if it was silently bypassed (the task succeeded but the skill content was never referenced).

Trajectories:
{trajectories}

Skill content:
{skill_content}

Return ONLY valid JSON:
{{"passed": true/false, "details": "...", "severity": "info|warning|critical"}}
"""

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_json_array(text: str) -> List[Any]:
    """Extract a JSON array from LLM output (tolerates markdown fences)."""
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
    if text.endswith("```"):
        text = text.rsplit("\n", 1)[0]
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # Try to find array inside text
        m = re.search(r"\[.*\]", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                pass
        return []


def _extract_json_object(text: str) -> Dict[str, Any]:
    """Extract a JSON object from LLM output (tolerates markdown fences)."""
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    if text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    text = text.strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                pass
        return {}


def _build_messages(system: str, user: str) -> List[Dict[str, str]]:
    return [
        {"role": "system", "content": system or "You are a helpful assistant."},
        {"role": "user", "content": user},
    ]


def _call_llm_sync(
    messages: List[Dict[str, str]],
    parent_runtime: Dict[str, str],
    temperature: float = 0.3,
    max_tokens: int = 4096,
) -> str:
    """Synchronous LLM call via auxiliary_client.call_llm."""
    try:
        from agent.auxiliary_client import call_llm
        resp = call_llm(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            main_runtime=parent_runtime,
        )
        return resp.choices[0].message.content or ""
    except Exception as e:
        logger.warning("LLM call failed: %s", e)
        return ""


# ---------------------------------------------------------------------------
# Trial runner (forked agent pattern, no Docker)
# ---------------------------------------------------------------------------


def _run_single_trial(
    task: TaskDefinition,
    strategy: Dict[str, str],
    skill: Optional[SkillPackage],
    parent_agent: Any,
    trial_id: int,
) -> Trajectory:
    """Run one trial in a forked AIAgent thread.

    The fork inherits the parent's runtime and a whitelisted toolset.
    Returns the trajectory (outcome, logs, token usage estimate).
    """
    start_ms = int(time.time() * 1000)
    strategy_desc = strategy.get("description", strategy.get("name", "unknown"))

    # Build trial prompt
    trial_prompt = (
        f"You are running a trial for skill evolution.\n\n"
        f"Task: {task.description}\n"
        f"Strategy: {strategy_desc}\n\n"
        f"Complete the task using the available tools. "
        f"Return a concise summary of what you did and whether you succeeded."
    )

    if skill and skill.prose:
        trial_prompt += f"\n\nUse the following skill guidance:\n{skill.prose}"

    outcome = "fail"
    logs = ""
    token_usage = 0
    turns: List[Dict[str, Any]] = []

    try:
        from run_agent import AIAgent
        from model_tools import get_tool_definitions
        from hermes_cli.plugins import (
            set_thread_tool_whitelist,
            clear_thread_tool_whitelist,
        )

        _parent_runtime = parent_agent._current_main_runtime()
        _parent_api_mode = _parent_runtime.get("api_mode") or None
        if _parent_api_mode == "codex_app_server":
            _parent_api_mode = "codex_responses"

        # Whitelist: file + terminal + web for exploration
        trial_whitelist = {
            t["function"]["name"]
            for t in get_tool_definitions(
                enabled_toolsets=["hermes-lite", "file", "terminal", "web"],
                quiet_mode=True,
            )
        }

        trial_agent = AIAgent(
            model=parent_agent.model,
            max_iterations=16,
            quiet_mode=True,
            platform=parent_agent.platform,
            provider=parent_agent.provider,
            api_mode=_parent_api_mode,
            base_url=_parent_runtime.get("base_url") or None,
            api_key=_parent_runtime.get("api_key") or None,
            credential_pool=getattr(parent_agent, "_credential_pool", None),
            parent_session_id=parent_agent.session_id,
            enabled_toolsets=["hermes-lite", "file", "terminal", "web"],
            disabled_toolsets=getattr(parent_agent, "disabled_toolsets", None),
            skip_memory=True,
        )
        trial_agent._cached_system_prompt = parent_agent._cached_system_prompt
        trial_agent.session_start = parent_agent.session_start
        trial_agent.session_id = parent_agent.session_id
        trial_agent.suppress_status_output = True

        set_thread_tool_whitelist(
            trial_whitelist,
            deny_msg_fmt="Trial denied non-whitelisted tool: {tool_name}.",
        )
        try:
            with open(os.devnull, "w", encoding="utf-8") as _devnull, \
                 contextlib.redirect_stdout(_devnull), \
                 contextlib.redirect_stderr(_devnull):
                result = trial_agent.run_conversation(
                    user_message=trial_prompt,
                    conversation_history=[],
                )
            final_response = result.get("final_response", "")
            turns = [{"role": "assistant", "content": final_response}]
            token_usage = (
                result.get("input_tokens", 0)
                + result.get("output_tokens", 0)
            )
            # Heuristic: if the agent says it succeeded, mark as pass
            outcome = "pass" if any(
                kw in final_response.lower()
                for kw in ("success", "succeeded", "completed", "done", "pass")
            ) else "fail"
            logs = final_response[:2000]
        finally:
            clear_thread_tool_whitelist()
            try:
                trial_agent.close()
            except Exception:
                pass

    except Exception as e:
        logger.warning("Trial %d failed with exception: %s", trial_id, e)
        logs = f"Exception: {e}"

    duration_ms = int(time.time() * 1000) - start_ms
    return Trajectory(
        trial_id=trial_id,
        iteration=0,
        strategy_id=strategy.get("id", trial_id),
        skill_version=skill.version if skill else None,
        turns=turns,
        outcome=outcome,
        token_usage=token_usage,
        duration_ms=duration_ms,
        logs=logs,
    )


# ---------------------------------------------------------------------------
# EvolutionEngine
# ---------------------------------------------------------------------------


class EvolutionEngine:
    """Meta-skill engine: drives skill creation / refinement via LLM + trials."""

    def __init__(self, parent_agent: Any):
        self.parent_agent = parent_agent
        self._parent_runtime = parent_agent._current_main_runtime()

    # -- public API ---------------------------------------------------------

    def evolve(self, task: TaskDefinition) -> SkillPackage:
        """Run the full evolution loop (Algorithm 1 from SkillEvolver paper).

        Returns the best skill package after exploration, contrast, distill,
        refinement, audit, and validation.
        """
        logger.info("EvolutionEngine.start: task=%s max_iter=%s width=%s",
                    task.task_id, task.max_iterations, task.explore_width)

        # Line 1: Parse(T_train)
        axes = self._parse_task(task)
        logger.info("EvolutionEngine.axes: %s", axes)

        # Line 2-5: Bootstrap (r=0)
        strategies = self._diverse_strategies(axes, skill=None, history=[])
        trajectories = self._explore(task, strategies, skill=None)
        delta = self._contrast(trajectories)
        skill_v1 = self._distill(delta, task)
        skills_history = [skill_v1]
        logger.info("EvolutionEngine.bootstrap: skill_v1 created, %d trajectories", len(trajectories))

        # Line 6-14: Refinement loop
        for r in range(1, task.max_iterations):
            current_skill = skills_history[-1]
            self._deploy_skill(current_skill, task)
            strategies = self._diverse_strategies(axes, current_skill, trajectories)
            new_trajectories = self._explore(task, strategies, current_skill)
            trajectories.extend(new_trajectories)
            delta = self._contrast(trajectories)
            next_skill = self._surgical_patch(current_skill, delta)
            audit = self._audit(next_skill, task, trajectories)
            skills_history.append(next_skill)
            logger.info(
                "EvolutionEngine.iteration=%d skill=%s audit_pass=%s pass_rate=%.2f",
                r, next_skill.version, audit.overall_pass, audit.pass_rate,
            )
            if audit.overall_pass and audit.pass_rate >= 0.75:
                break

        # Line 15-16: Finalize and Validate
        best_skill = self._finalize(skills_history, task)
        validation = self._validate(best_skill, task)
        logger.info("EvolutionEngine.done: best=%s validation_pass=%d/%d",
                    best_skill.version,
                    sum(1 for t in validation if t.outcome == "pass"),
                    len(validation))
        return best_skill

    # -- internal steps -----------------------------------------------------

    def _parse_task(self, task: TaskDefinition) -> List[str]:
        prompt = _PARSE_TASK_PROMPT.format(
            description=task.description, domain=task.domain
        )
        messages = _build_messages("", prompt)
        text = _call_llm_sync(messages, self._parent_runtime, temperature=0.2)
        arr = _extract_json_array(text)
        if arr:
            return [str(a) for a in arr if a]
        # Fallback: split by newlines
        return [line.strip("-\n* ") for line in text.splitlines() if line.strip()]

    def _diverse_strategies(
        self,
        axes: List[str],
        skill: Optional[SkillPackage],
        history: List[Trajectory],
    ) -> List[Dict[str, str]]:
        if skill is None:
            prompt = _GENERATE_STRATEGIES_PROMPT.format(
                axes=json.dumps(axes),
                width=4,  # simplified
                description=self.parent_agent._last_user_message or "",
            )
        else:
            failures = [t.logs[:200] for t in history if t.outcome == "fail"]
            prompt = _GENERATE_STRESS_TESTS_PROMPT.format(
                skill_version=skill.version,
                width=4,
                failures=json.dumps(failures),
                description=self.parent_agent._last_user_message or "",
            )
        messages = _build_messages("", prompt)
        text = _call_llm_sync(messages, self._parent_runtime, temperature=0.7)
        arr = _extract_json_array(text)
        strategies = []
        for i, item in enumerate(arr):
            if isinstance(item, dict):
                strategies.append({
                    "id": i,
                    "name": item.get("name", f"strategy-{i}"),
                    "description": item.get("description", ""),
                })
        # Fallback: if LLM failed, create simple random strategies
        if not strategies:
            for i in range(4):
                strategies.append({
                    "id": i,
                    "name": f"strategy-{i}",
                    "description": f"Approach #{i+1} for {', '.join(axes)}",
                })
        return strategies

    def _explore(
        self,
        task: TaskDefinition,
        strategies: List[Dict[str, str]],
        skill: Optional[SkillPackage],
    ) -> List[Trajectory]:
        """Run K trials in parallel threads (MVP: no Docker)."""
        trajectories: List[Trajectory] = []
        threads: List[threading.Thread] = []
        results: List[Trajectory] = [None] * len(strategies)

        def _worker(idx: int, strategy: Dict[str, str]):
            results[idx] = _run_single_trial(
                task, strategy, skill, self.parent_agent, idx
            )

        for i, strategy in enumerate(strategies):
            t = threading.Thread(
                target=_worker, args=(i, strategy), daemon=True,
                name=f"evolve-trial-{i}",
            )
            threads.append(t)
            t.start()

        for t in threads:
            t.join(timeout=120)  # 2 min per trial cap

        for r in results:
            if r is not None:
                trajectories.append(r)
        return trajectories

    def _contrast(self, trajectories: List[Trajectory]) -> ContrastDelta:
        winners = [t for t in trajectories if t.outcome == "pass"]
        losers = [t for t in trajectories if t.outcome == "fail"]
        prompt = _CONTRAST_PROMPT.format(
            winner_count=len(winners),
            loser_count=len(losers),
            winners=json.dumps([{"trial_id": t.trial_id, "logs": t.logs} for t in winners]),
            losers=json.dumps([{"trial_id": t.trial_id, "logs": t.logs} for t in losers]),
        )
        messages = _build_messages("", prompt)
        text = _call_llm_sync(messages, self._parent_runtime, temperature=0.3, max_tokens=4096)
        obj = _extract_json_object(text)

        delta = ContrastDelta(iteration=0, analysis_summary=obj.get("analysis_summary", ""))
        for key in ("additions", "deletions", "modifications"):
            for patch_obj in obj.get(key, []):
                if isinstance(patch_obj, dict):
                    delta.__getattribute__(key).append(SkillPatch(
                        target_section=patch_obj.get("target_section", "prose"),
                        old_content=patch_obj.get("old_content"),
                        new_content=patch_obj.get("new_content", ""),
                        reason=patch_obj.get("reason", ""),
                        confidence=patch_obj.get("confidence", 1.0),
                    ))
        return delta

    def _distill(self, delta: ContrastDelta, task: TaskDefinition) -> SkillPackage:
        skill_name = task.task_id.replace(" ", "-").lower()[:64] or "evolved-skill"
        prompt = _DISTILL_PROMPT.format(
            description=task.description,
            domain=task.domain,
            analysis=delta.analysis_summary,
            skill_name=skill_name,
        )
        messages = _build_messages("", prompt)
        text = _call_llm_sync(messages, self._parent_runtime, temperature=0.4, max_tokens=8192)
        return SkillPackage(version="v1", prose=text)

    def _deploy_skill(self, skill: SkillPackage, task: TaskDefinition) -> None:
        """Deploy = write skill to disk via skill_manage."""
        try:
            from tools.skill_manager_tool import skill_manage
            skill_name = task.task_id.replace(" ", "-").lower()[:64] or "evolved-skill"
            result = skill_manage(
                action="create",
                name=skill_name,
                content=skill.prose,
            )
            logger.debug("Deploy skill result: %s", result)
        except Exception as e:
            logger.warning("Deploy skill failed: %s", e)

    def _surgical_patch(self, skill: SkillPackage, delta: ContrastDelta) -> SkillPackage:
        """Apply patches to skill via skill_manage patch action."""
        new_skill = skill.copy()
        # Increment version
        try:
            vnum = int(skill.version.lstrip("vV")) + 1
        except ValueError:
            vnum = 1
        new_skill.version = f"v{vnum}"

        # For MVP, we apply patches by rebuilding the prose content
        # In a fuller implementation we'd call skill_manage(action="patch")
        prose = skill.prose
        for patch in delta.modifications:
            if patch.old_content and patch.old_content in prose:
                prose = prose.replace(patch.old_content, patch.new_content, 1)
        for patch in delta.additions:
            if patch.target_section == "constraints":
                new_skill.constraints.append(patch.new_content)
            else:
                prose += f"\n\n## Added\n\n{patch.new_content}"
        new_skill.prose = prose
        return new_skill

    def _audit(
        self,
        skill: SkillPackage,
        task: TaskDefinition,
        trajectories: List[Trajectory],
    ) -> AuditReport:
        checks = []
        # 1. Syntax / structure check
        checks.append(self._audit_syntax(skill))
        # 2. Silent bypass check
        checks.append(self._audit_silent_bypass(skill, trajectories))
        # 3. Pass rate
        pass_count = sum(1 for t in trajectories if t.outcome == "pass")
        total = len(trajectories)
        pass_rate = pass_count / total if total else 0.0
        overall = all(c.passed for c in checks) and pass_rate >= 0.75
        return AuditReport(
            skill_version=skill.version,
            checks=checks,
            overall_pass=overall,
            pass_rate=pass_rate,
        )

    def _audit_syntax(self, skill: SkillPackage) -> AuditCheck:
        content = skill.prose
        passed = content.startswith("---") and "name:" in content and "description:" in content
        details = "Frontmatter valid" if passed else "Missing or invalid YAML frontmatter"
        severity = "warning" if not passed else "info"
        return AuditCheck(name="syntax", passed=passed, details=details, severity=severity)

    def _audit_silent_bypass(self, skill: SkillPackage, trajectories: List[Trajectory]) -> AuditCheck:
        # Heuristic: if pass rate is high but logs never mention skill keywords, flag it
        keywords = [skill.metadata.get("name", "")] if skill.metadata else []
        if not keywords or not keywords[0]:
            # Try to extract name from frontmatter
            m = re.search(r"^name:\s*(.+)$", skill.prose, re.MULTILINE)
            if m:
                keywords = [m.group(1).strip()]
        if not keywords or not keywords[0]:
            return AuditCheck(name="silent_bypass", passed=True, details="No skill name to check", severity="info")

        mentions = sum(
            1 for t in trajectories
            if any(kw.lower() in t.logs.lower() for kw in keywords)
        )
        total = len(trajectories)
        # If less than 30% mention the skill but pass rate is >50%, it's suspicious
        pass_rate = sum(1 for t in trajectories if t.outcome == "pass") / total if total else 0
        if pass_rate > 0.5 and mentions / total < 0.3:
            return AuditCheck(
                name="silent_bypass",
                passed=False,
                details=f"Skill possibly bypassed: only {mentions}/{total} trials referenced it",
                severity="critical",
            )
        return AuditCheck(
            name="silent_bypass",
            passed=True,
            details=f"Skill referenced in {mentions}/{total} trials",
            severity="info",
        )

    def _finalize(self, skills: List[SkillPackage], task: TaskDefinition) -> SkillPackage:
        # Simple heuristic: pick the highest version that has valid frontmatter
        for skill in reversed(skills):
            if skill.prose.startswith("---") and "name:" in skill.prose:
                return skill
        return skills[-1] if skills else SkillPackage()

    def _validate(self, skill: SkillPackage, task: TaskDefinition) -> List[Trajectory]:
        # Re-run with the final skill on a fresh set of validation strategies
        strategies = [{"id": i, "name": f"val-{i}", "description": "Validation run"}
                      for i in range(task.validate_trials)]
        return self._explore(task, strategies, skill)
