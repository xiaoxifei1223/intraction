"""Data models for SkillEvolver — lightweight dataclasses (no pydantic dep)."""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional


@dataclass
class TaskDefinition:
    task_id: str
    domain: str
    description: str
    train_variant_dir: str = ""
    val_variant_dir: str = ""
    decision_axes: List[str] = field(default_factory=list)
    expected_output_schema: Dict[str, Any] = field(default_factory=dict)
    max_iterations: int = 2
    explore_width: int = 4
    validate_trials: int = 3


@dataclass
class SkillPackage:
    version: str = "v1"
    prose: str = ""
    code: Optional[str] = None
    references: List[str] = field(default_factory=list)
    examples: List[Dict[str, Any]] = field(default_factory=list)
    constraints: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def copy(self) -> SkillPackage:
        return SkillPackage(
            version=self.version,
            prose=self.prose,
            code=self.code,
            references=list(self.references),
            examples=[dict(e) for e in self.examples],
            constraints=list(self.constraints),
            metadata=dict(self.metadata),
            created_at=datetime.now().isoformat(),
        )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Trajectory:
    trial_id: int = 0
    iteration: int = 0
    strategy_id: int = 0
    skill_version: Optional[str] = None
    turns: List[Dict[str, Any]] = field(default_factory=list)
    outcome: str = "fail"  # "pass" or "fail"
    failure_mode: Optional[str] = None
    token_usage: int = 0
    duration_ms: int = 0
    logs: str = ""


@dataclass
class SkillPatch:
    target_section: str
    new_content: str
    old_content: Optional[str] = None
    reason: str = ""
    confidence: float = 1.0


@dataclass
class ContrastDelta:
    iteration: int = 0
    additions: List[SkillPatch] = field(default_factory=list)
    deletions: List[SkillPatch] = field(default_factory=list)
    modifications: List[SkillPatch] = field(default_factory=list)
    analysis_summary: str = ""


@dataclass
class AuditCheck:
    name: str = ""
    passed: bool = False
    details: str = ""
    severity: str = "info"  # "info", "warning", "critical"


@dataclass
class AuditReport:
    skill_version: str = ""
    iteration: int = 0
    checks: List[AuditCheck] = field(default_factory=list)
    overall_pass: bool = False
    pass_rate: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ---------------------------------------------------------------------------
# JSON helpers
# ---------------------------------------------------------------------------

def _serialize(obj: Any) -> Any:
    if isinstance(obj, (TaskDefinition, SkillPackage, Trajectory,
                        SkillPatch, ContrastDelta, AuditCheck, AuditReport)):
        return asdict(obj)
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


def dumps(obj: Any) -> str:
    return json.dumps(obj, default=_serialize, ensure_ascii=False, indent=2)
