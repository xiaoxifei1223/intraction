"""Evolution Tool — agent-facing entry point for SkillEvolver.

Registers ``evolve_skill`` so the agent can explicitly trigger skill evolution
mid-turn or as a background process.
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
import uuid
from typing import Any, Dict, Optional

from tools.registry import registry, tool_error

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tool handler
# ---------------------------------------------------------------------------


def _handler(args: Dict[str, Any], **kwargs) -> str:
    """Handle evolve_skill tool call."""
    from agent.evolution_engine import EvolutionEngine
    from agent.evolution_models import TaskDefinition
    from run_agent import AIAgent

    task_id = args.get("task_id") or f"evolve-{uuid.uuid4().hex[:8]}"
    domain = args.get("domain", "general")
    description = args.get("description", "")
    if not description:
        return tool_error("'description' is required for evolve_skill.", success=False)

    max_iterations = int(args.get("max_iterations", 2))
    explore_width = int(args.get("explore_width", 4))
    validate_trials = int(args.get("validate_trials", 3))

    task = TaskDefinition(
        task_id=task_id,
        domain=domain,
        description=description,
        max_iterations=max_iterations,
        explore_width=explore_width,
        validate_trials=validate_trials,
    )

    # Retrieve the "current" parent agent from thread-local or global context.
    # The conversation_loop sets _current_agent_ctx when running the agent loop.
    parent_agent = _get_current_parent_agent()
    if parent_agent is None:
        return tool_error(
            "No active agent context found. evolve_skill must be called from within an agent turn.",
            success=False,
        )

    # Run evolution synchronously (MVP). Future: background thread.
    engine = EvolutionEngine(parent_agent)
    try:
        best_skill = engine.evolve(task)
    except Exception as e:
        logger.exception("evolve_skill failed")
        return tool_error(f"Evolution failed: {e}", success=False)

    return json.dumps({
        "success": True,
        "skill_id": task_id,
        "version": best_skill.version,
        "prose_preview": best_skill.prose[:500] + "..." if len(best_skill.prose) > 500 else best_skill.prose,
        "constraints": best_skill.constraints,
        "message": f"Evolved skill '{task_id}' → {best_skill.version}",
    }, ensure_ascii=False)


# ---------------------------------------------------------------------------
# Agent context helper
# ---------------------------------------------------------------------------

# Thread-local storage for the current agent instance so that tool handlers
# can reach back to the parent agent's runtime (model, provider, etc.).
_agent_ctx = threading.local()


def _get_current_parent_agent() -> Optional[Any]:
    """Return the agent currently running the conversation loop."""
    try:
        return _agent_ctx.agent
    except AttributeError:
        return None


def set_evolution_parent_agent(agent: Any) -> None:
    """Called by conversation_loop before tool execution to bind the agent."""
    _agent_ctx.agent = agent


def clear_evolution_parent_agent() -> None:
    """Called after the turn to unbind."""
    try:
        del _agent_ctx.agent
    except AttributeError:
        pass


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

EVOLVE_SKILL_SCHEMA = {
    "name": "evolve_skill",
    "description": (
        "Evolve a skill through automated exploration, contrast analysis, "
        "distillation, and surgical patching. This is the Meta-Skill that "
        "improves other skills.\n\n"
        "Use when:\n"
        "  • A skill is underperforming or missing coverage.\n"
        "  • You want to generate a new skill from task examples.\n"
        "  • The user asks to 'evolve', 'refine', or 'optimize' a skill.\n\n"
        "The engine will run K trials with diverse strategies, contrast winners "
        "vs losers, and produce an improved SKILL.md."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "description": {
                "type": "string",
                "description": (
                    "Detailed description of the task the skill should solve. "
                    "Include what the skill does, when it applies, and any "
                    "known pitfalls or edge cases."
                ),
            },
            "domain": {
                "type": "string",
                "description": "Domain label (e.g., 'python', 'devops', 'data-science').",
                "default": "general",
            },
            "task_id": {
                "type": "string",
                "description": (
                    "Optional stable identifier for this evolution task. "
                    "If omitted, a UUID is generated."
                ),
            },
            "max_iterations": {
                "type": "integer",
                "description": "Max refinement iterations (default 2).",
                "default": 2,
            },
            "explore_width": {
                "type": "integer",
                "description": "Number of parallel trial strategies (default 4).",
                "default": 4,
            },
            "validate_trials": {
                "type": "integer",
                "description": "Number of validation runs on the final skill (default 3).",
                "default": 3,
            },
        },
        "required": ["description"],
    },
}


registry.register(
    name="evolve_skill",
    toolset="skills",
    schema=EVOLVE_SKILL_SCHEMA,
    handler=_handler,
    emoji="🧬",
)
