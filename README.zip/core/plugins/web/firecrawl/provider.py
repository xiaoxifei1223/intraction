class Firecrawl:
    pass
