class FirecrawlBrowserProvider:
    pass
