class BrowserbaseBrowserProvider:
    pass
