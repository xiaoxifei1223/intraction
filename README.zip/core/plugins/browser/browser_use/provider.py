class BrowserUseBrowserProvider:
    pass
