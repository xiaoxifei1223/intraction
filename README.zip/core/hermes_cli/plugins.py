"""Compatibility shim for hermes_cli.plugins imports.

Hermes Lite does not load general plugins (they were stripped).
All hook invocations are no-ops.
"""

from __future__ import annotations

from typing import Any, Callable, Optional


def invoke_hook(name: str, *args: Any, **kwargs: Any) -> Any:
    """No-op — Hermes Lite does not support general plugins."""
    return None


def _ensure_plugins_discovered() -> None:
    """No-op."""
    pass


def get_pre_tool_call_block_message(*args: Any, **kwargs: Any) -> Optional[str]:
    """No block message — allow all tool calls."""
    return None


def discover_plugins() -> None:
    """No-op."""
    pass
