"""Compatibility shim for hermes_cli.config imports.

Redirects to hermes_lite.config where possible, otherwise returns
sensible defaults so that tool modules don't crash on import.
"""

from __future__ import annotations

from typing import Any, Optional

from hermes_constants import get_hermes_home


def load_config() -> dict[str, Any]:
    """Load config via hermes_lite.config or return empty dict."""
    try:
        from hermes_lite.config import load_config as _load
        return _load()
    except Exception:
        return {}


def cfg_get(key_path: str, default: Any = None) -> Any:
    """Get a config value by dot-path."""
    cfg = load_config()
    parts = key_path.split(".")
    node = cfg
    for part in parts:
        if not isinstance(node, dict):
            return default
        node = node.get(part)
        if node is None:
            return default
    return node if node is not None else default


def save_config(key_path: str, value: Any) -> None:
    """Save a config value by dot-path."""
    try:
        from hermes_lite.config import save_config_value
        save_config_value(key_path, value)
    except Exception:
        pass


def read_raw_config() -> dict[str, Any]:
    """Return raw config dict."""
    return load_config()


def get_env_value(key: str, default: str = "") -> str:
    """Read a value from ~/.hermes/.env."""
    import os
    return os.getenv(key, default)


def is_managed() -> bool:
    """Always return False — Hermes Lite is never managed."""
    return False


def save_env_value(key: str, value: str) -> None:
    """Write a value to ~/.hermes/.env (no-op in Lite)."""
    pass


def load_env() -> None:
    """Load .env file (no-op in Lite — env vars are read directly)."""
    pass
