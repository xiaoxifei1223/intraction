"""Compatibility shim for hermes_cli.timeouts imports."""

from __future__ import annotations

DEFAULT_TIMEOUT_SECONDS = 120


def get_timeout(*args, **kwargs) -> int:
    """Return default timeout."""
    return DEFAULT_TIMEOUT_SECONDS


def get_provider_request_timeout(*args, **kwargs) -> int:
    """Return default provider request timeout."""
    return DEFAULT_TIMEOUT_SECONDS


def get_provider_stale_timeout(*args, **kwargs) -> int:
    """Return default stale timeout."""
    return 300
