"""Compatibility shim for hermes_cli.models imports."""

from __future__ import annotations

from typing import Any, Optional


def ensure_lmstudio_model_loaded(*args: Any, **kwargs: Any) -> bool:
    """No-op."""
    return True


def _should_use_copilot_responses_api(*args: Any, **kwargs: Any) -> bool:
    """Return False."""
    return False


def copilot_default_headers(*args: Any, **kwargs: Any) -> dict[str, str]:
    """Return empty headers."""
    return {}


def github_model_reasoning_efforts(*args: Any, **kwargs: Any) -> dict[str, Any]:
    """Return empty dict."""
    return {}


def lmstudio_model_reasoning_options(*args: Any, **kwargs: Any) -> dict[str, Any]:
    """Return empty dict."""
    return {}
