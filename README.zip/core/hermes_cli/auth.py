"""Compatibility shim for hermes_cli.auth imports."""

from __future__ import annotations

import threading
from typing import Any, Optional

CODEX_ACCESS_TOKEN_REFRESH_SKEW_SECONDS = 60
DEFAULT_AGENT_KEY_MIN_TTL_SECONDS = 300
PROVIDER_REGISTRY: dict[str, Any] = {}

_auth_store_lock = threading.Lock()


def _codex_access_token_is_expiring(*args: Any, **kwargs: Any) -> bool:
    return False


def _decode_jwt_claims(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}


def _load_auth_store(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}


def _load_provider_state(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}


def _resolve_kimi_base_url(*args: Any, **kwargs: Any) -> Optional[str]:
    return None


def _resolve_zai_base_url(*args: Any, **kwargs: Any) -> Optional[str]:
    return None


def _save_auth_store(*args: Any, **kwargs: Any) -> None:
    pass


def _save_provider_state(*args: Any, **kwargs: Any) -> None:
    pass


def _store_provider_state(*args: Any, **kwargs: Any) -> None:
    pass


def read_credential_pool(*args: Any, **kwargs: Any) -> list[Any]:
    return []


def write_credential_pool(*args: Any, **kwargs: Any) -> None:
    pass


def resolve_codex_runtime_credentials(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}


def resolve_xai_oauth_runtime_credentials(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}


def get_auth_token(*args: Any, **kwargs: Any) -> Optional[str]:
    return None


def load_auth(*args: Any, **kwargs: Any) -> dict[str, Any]:
    return {}
