"""Compatibility shim for hermes_cli._subprocess_compat."""

from __future__ import annotations

import subprocess
from typing import Any


def run_subprocess(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess:
    """Passthrough to subprocess.run."""
    return subprocess.run(*args, **kwargs)


def windows_hide_flags() -> dict[str, Any]:
    """Return Windows-specific subprocess creation flags (empty on non-Windows)."""
    import sys
    if sys.platform == "win32":
        import subprocess
        return {"creationflags": subprocess.CREATE_NO_WINDOW}
    return {}
