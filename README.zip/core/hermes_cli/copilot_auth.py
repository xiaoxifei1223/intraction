"""Compatibility shim for hermes_cli.copilot_auth imports."""

from __future__ import annotations

from typing import Any, Optional


def copilot_request_headers(*args: Any, **kwargs: Any) -> dict[str, str]:
    """Return empty headers."""
    return {}


def resolve_copilot_token(*args: Any, **kwargs: Any) -> Optional[str]:
    """Return None."""
    return None
