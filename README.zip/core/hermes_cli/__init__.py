"""Hermes CLI compatibility shim for Hermes Lite.

Provides minimal stubs so that tools/ modules that import from
hermes_cli.config or hermes_cli.plugins continue to work without
pulling in the full CLI stack.
"""

__version__ = "0.1.0-lite"
