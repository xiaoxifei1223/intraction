"""Compatibility shim for hermes_cli.env_loader imports."""

from __future__ import annotations

from typing import Any


def load_hermes_dotenv(*args: Any, **kwargs: Any) -> None:
    """No-op — Hermes Lite reads env vars directly."""
    pass
