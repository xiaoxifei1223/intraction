"""Hermes Lite core — extracted and trimmed Hermes Agent internals."""
