---
name: skill-evolver
description: "Meta-Skill: drive skill evolution using the evolve_skill tool."
version: 1.0.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [meta-skill, evolution, self-improvement]
---

# Skill Evolver (Meta-Skill)

> **Meta-Skill**: A skill that knows how to create and improve *other* skills.
> Based on: SkillEvolver — Skill Learning as a Meta-Skill (arXiv:2605.10500v1)

## When to Use

Invoke this meta-skill when:

1. **User asks to evolve / refine / optimize a skill**
   - "Improve the python skill"
   - "Make this skill handle edge cases better"
   - "Evolve the testing skill based on what we learned"

2. **A skill failed during use**
   - The loaded skill didn't cover the scenario
   - You had to improvise beyond what the skill instructed
   - Capture the gap and evolve the skill

3. **Creating a new skill from scratch**
   - You solved a class of task repeatedly
   - Use evolution to explore diverse approaches and distill the best

## How It Works

The `evolve_skill` tool runs a closed loop:

```
Parse Task → Explore (K trials) → Contrast → Distill → Deploy → Refine → Audit → Validate
```

- **Explore**: Runs parallel trials with different strategies
- **Contrast**: Compares winners vs losers to find what works
- **Distill**: Generates a new SKILL.md from the contrast analysis
- **Refine**: Applies surgical patches to improve the skill iteratively
- **Audit**: Checks for silent bypass, syntax issues, and pass rate
- **Validate**: Final validation on fresh trials

## Usage

Call the tool with a rich task description:

```json
{
  "description": "Write Python unit tests for async functions. The skill should cover: pytest-asyncio setup, mock async dependencies, handling exceptions in async code, and verifying coroutine calls.",
  "domain": "python",
  "max_iterations": 2,
  "explore_width": 4
}
```

### Parameters

| Parameter | Required | Default | Meaning |
|-----------|----------|---------|---------|
| `description` | **Yes** | — | Detailed task specification |
| `domain` | No | `general` | Domain label for organization |
| `task_id` | No | auto | Stable ID (becomes skill name) |
| `max_iterations` | No | 2 | Refinement rounds |
| `explore_width` | No | 4 | Parallel trial count |
| `validate_trials` | No | 3 | Final validation runs |

## Best Practices

1. **Be specific in description**
   - Bad: "Make a skill for coding"
   - Good: "A skill for writing idempotent database migrations in SQLAlchemy, including rollback strategies and test data cleanup"

2. **Start with `explore_width=4, max_iterations=2`**
   - This is the sweet spot for cost vs quality (~8 LLM calls)
   - Increase only for high-stakes skills

3. **Always review the evolved skill**
   - The tool returns a `prose_preview`
   - Use `skill_view` to inspect the full result
   - Use `skill_manage(action="patch")` for final human tweaks

4. **Evolution is additive**
   - The engine creates a NEW skill version, never overwrites blindly
   - Old versions remain in `skills_history` for comparison

5. **Watch for Silent-Bypass**
   - If Audit reports "skill possibly bypassed", the task was too easy
   - Add constraints or harder validation examples in the description

## Example Session

```
User: "I keep writing bash scripts that fail on macOS vs Linux differences. Can you evolve a skill for portable shell scripting?"

→ evolve_skill(
    description="Portable shell scripting skill. Cover: POSIX sh vs bash differences, cross-platform path handling (macOS/linux), detecting GNU vs BSD utilities, safe temp file creation, and signal handling.",
    domain="devops",
    task_id="portable-shell",
    max_iterations=2,
    explore_width=4
  )

→ skill_view("portable-shell")  # Review the result
→ skill_manage(action="patch", name="portable-shell", ...)  # Final tweaks
```

## Failure Modes

| Symptom | Cause | Fix |
|---------|-------|-----|
| "No active agent context" | Called outside agent loop | Only call during an active turn |
| Low pass rate (<50%) | Task too hard or ambiguous | Refine description, add examples |
| Silent bypass warning | Skill not actually used | Make task require the skill's guidance |
| Syntax audit fail | Missing YAML frontmatter | Patch frontmatter manually or re-run |

## Notes

- Evolution runs synchronously in the current turn (MVP)
- Each trial spawns a forked agent with limited tool access
- Token usage is logged; monitor costs for large `explore_width`
