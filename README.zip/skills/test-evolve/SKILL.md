---
name: test-evolve
description: "Python coding best practices — basic version for evolution testing."
version: 1.0.0
author: Test
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [python, testing, evolution]
---

# Python 编码最佳实践

## 概述

本 Skill 定义了编写 Python 代码的基本规范。

## 规则

1. 使用 4 空格缩进
2. 函数名使用 snake_case
3. 类名使用 PascalCase

## 示例

```python
def process_data(data):
    return data.upper()
```

## 注意

- 本 Skill 是初始版本，将在使用过程中进化完善
