import * as vscode from 'vscode';
import { RpcClient } from './rpcClient';

export function registerHermesParticipant(
    context: vscode.ExtensionContext,
    client: RpcClient
): vscode.Disposable {
    const handler: vscode.ChatRequestHandler = async (
        request: vscode.ChatRequest,
        _context: vscode.ChatContext,
        response: vscode.ChatResponseStream,
        _token: vscode.CancellationToken
    ) => {
        const editor = vscode.window.activeTextEditor;
        const document = editor?.document;

        // Build VS Code context payload
        const vscodeContext: any = {};
        if (document) {
            vscodeContext.filePath = document.uri.fsPath;
            vscodeContext.languageId = document.languageId;
            const selection = editor.selection;
            if (!selection.isEmpty) {
                vscodeContext.selection = document.getText(selection);
                vscodeContext.selectionRange = {
                    startLine: selection.start.line,
                    startCharacter: selection.start.character,
                    endLine: selection.end.line,
                    endCharacter: selection.end.character
                };
            }
            const diagnostics = vscode.languages.getDiagnostics(document.uri);
            if (diagnostics.length > 0) {
                vscodeContext.diagnostics = diagnostics.slice(0, 10).map(d => ({
                    message: d.message,
                    severity: d.severity,
                    line: d.range.start.line
                }));
            }
        }
        const folders = vscode.workspace.workspaceFolders;
        if (folders) {
            vscodeContext.workspaceFolders = folders.map(f => f.uri.fsPath);
        }

        // Handle slash commands
        const command = request.command;
        if (command === 'skills') {
            try {
                const result = await client.listSkills();
                const skills: any[] = result.skills || [];
                response.markdown('## Available Skills\n\n');
                for (const s of skills.slice(0, 30)) {
                    response.markdown(`- **${s.name}** — ${s.description}\n`);
                }
            } catch (e: any) {
                response.markdown(`Error listing skills: ${e.message}`);
            }
            return;
        }

        if (command === 'review') {
            response.markdown('Background review is triggered automatically after each turn. You can enable/disable it in settings (`hermesLite.backgroundReview`).');
            return;
        }

        if (command === 'sandbox') {
            response.markdown('The code execution sandbox is available via the `execute_code` tool. Ask Hermes to run Python or shell code and it will use the sandbox.');
            return;
        }

        // Normal chat flow
        response.markdown('Thinking...\n\n');
        try {
            const result = await client.chat(request.prompt, vscodeContext);
            // Replace the "Thinking..." placeholder with the actual response
            // VS Code Chat API doesn't support replacing previous chunks easily,
            // so we just stream the final response.
            response.markdown(result.finalResponse || '(no response)');
        } catch (e: any) {
            response.markdown(`**Error:** ${e.message}`);
        }
    };

    const participant = vscode.chat.createChatParticipant('hermes', handler);
    participant.iconPath = vscode.Uri.joinPath(context.extensionUri, 'icon.png');

    return participant;
}
