import * as vscode from 'vscode';

export interface SkillItem {
    name: string;
    description: string;
    command: string;
}

export class SkillTreeProvider implements vscode.TreeDataProvider<SkillNode> {
    private _onDidChange = new vscode.EventEmitter<SkillNode | undefined>();
    readonly onDidChangeTreeData = this._onDidChange.event;

    private skills: SkillItem[] = [];

    refresh(skills: SkillItem[]): void {
        this.skills = skills;
        this._onDidChange.fire(undefined);
    }

    getTreeItem(element: SkillNode): vscode.TreeItem {
        return element;
    }

    getChildren(_element?: SkillNode): SkillNode[] {
        return this.skills.map(s => new SkillNode(s));
    }
}

class SkillNode extends vscode.TreeItem {
    constructor(public readonly skill: SkillItem) {
        super(skill.name, vscode.TreeItemCollapsibleState.None);
        this.description = skill.description;
        this.tooltip = `${skill.name}\n${skill.description}`;
        this.command = {
            command: 'hermesLite.insertSkillCommand',
            title: 'Insert Skill Command',
            arguments: [skill.command]
        };
    }
}
