import * as vscode from 'vscode';
import { spawn, ChildProcess } from 'child_process';
import { EventEmitter } from 'events';

interface JsonRpcMessage {
    jsonrpc: '2.0';
    id?: number | string;
    method?: string;
    params?: any;
    result?: any;
    error?: { code: number; message: string; data?: any };
}

export class RpcClient extends EventEmitter {
    private proc: ChildProcess | null = null;
    private pending = new Map<number | string, { resolve: (v: any) => void; reject: (e: Error) => void }>();
    private msgId = 0;
    private buffer = '';
    private _ready = false;

    get ready(): boolean { return this._ready; }

    start(pythonPath: string, scriptPath: string): void {
        if (this.proc) { return; }

        this.proc = spawn(pythonPath, ['-m', 'hermes_lite.server'], {
            cwd: scriptPath,
            env: { ...process.env, PYTHONUNBUFFERED: '1' }
        });

        this.proc.stdout?.on('data', (data: Buffer) => {
            this.buffer += data.toString('utf-8');
            let idx: number;
            while ((idx = this.buffer.indexOf('\n')) >= 0) {
                const line = this.buffer.slice(0, idx).trim();
                this.buffer = this.buffer.slice(idx + 1);
                if (line) { this._onLine(line); }
            }
        });

        this.proc.stderr?.on('data', (data: Buffer) => {
            const text = data.toString('utf-8').trim();
            if (text) {
                console.error('[hermes-lite backend]', text);
            }
        });

        this.proc.on('exit', (code) => {
            this._ready = false;
            this.emit('exit', code);
        });
    }

    stop(): void {
        if (!this.proc) { return; }
        this.proc.kill('SIGTERM');
        this.proc = null;
        this._ready = false;
    }

    async initialize(config: any): Promise<any> {
        const result = await this._request('initialize', config);
        this._ready = true;
        this.emit('ready');
        return result;
    }

    async chat(message: string, context?: any): Promise<any> {
        return this._request('chat', { message, context });
    }

    async listSkills(): Promise<any> {
        return this._request('skill/list', {});
    }

    async viewSkill(name: string): Promise<any> {
        return this._request('skill/view', { name });
    }

    async manageSkill(action: string, name: string, content?: string): Promise<any> {
        return this._request('skill/manage', { action, name, content });
    }

    async listSessions(): Promise<any> {
        return this._request('session/list', {});
    }

    private _onLine(line: string): void {
        let msg: JsonRpcMessage;
        try {
            msg = JSON.parse(line);
        } catch {
            console.warn('Invalid JSON from backend:', line.slice(0, 200));
            return;
        }

        if (msg.id !== undefined && (msg.result !== undefined || msg.error !== undefined)) {
            const pending = this.pending.get(msg.id);
            if (pending) {
                this.pending.delete(msg.id);
                if (msg.error) {
                    pending.reject(new Error(msg.error.message));
                } else {
                    pending.resolve(msg.result);
                }
            }
        } else if (msg.method) {
            this.emit(msg.method, msg.params);
        }
    }

    private _request(method: string, params: any): Promise<any> {
        return new Promise((resolve, reject) => {
            if (!this.proc || this.proc.killed) {
                reject(new Error('Backend process not running'));
                return;
            }
            const id = ++this.msgId;
            this.pending.set(id, { resolve, reject });
            const req: JsonRpcMessage = { jsonrpc: '2.0', id, method, params };
            this.proc.stdin?.write(JSON.stringify(req) + '\n');
        });
    }
}
