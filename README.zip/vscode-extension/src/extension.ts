import * as vscode from 'vscode';
import { RpcClient } from './rpcClient';
import { registerHermesParticipant } from './chatParticipant';
import { SkillTreeProvider } from './skillTreeView';

let client: RpcClient | null = null;
let skillProvider: SkillTreeProvider | null = null;

export function activate(context: vscode.ExtensionContext): void {
    const config = vscode.workspace.getConfiguration('hermesLite');
    const pythonPath = config.get<string>('pythonPath', 'python3');
    const model = config.get<string>('model', '');
    const provider = config.get<string>('provider', 'openai');
    const apiKey = config.get<string>('apiKey', '');
    const baseUrl = config.get<string>('baseUrl', '');
    const toolsets = config.get<string[]>('toolsets', ['hermes-lite']);
    const backgroundReview = config.get<boolean>('backgroundReview', true);
    const maxIterations = config.get<number>('maxIterations', 90);

    // Compute extension root (parent of vscode-extension folder)
    const extRoot = context.extensionUri.fsPath;
    const backendRoot = extRoot.replace(/vscode-extension$/, '');

    client = new RpcClient();

    // Start Python backend
    client.start(pythonPath, backendRoot);

    // Initialize once ready
    client.once('ready', () => {
        vscode.commands.executeCommand('setContext', 'hermesLite.enabled', true);
        loadSkills();
    });

    client.on('exit', (code: number) => {
        vscode.window.showWarningMessage(`Hermes Lite backend exited (code ${code}). Restarting...`);
        setTimeout(() => {
            client?.start(pythonPath, backendRoot);
        }, 2000);
    });

    // Register chat participant
    const participant = registerHermesParticipant(context, client);
    context.subscriptions.push(participant);

    // Register skill tree view
    skillProvider = new SkillTreeProvider();
    const treeView = vscode.window.createTreeView('hermesLite.skills', {
        treeDataProvider: skillProvider
    });
    context.subscriptions.push(treeView);

    // Register commands
    context.subscriptions.push(
        vscode.commands.registerCommand('hermesLite.openSettings', () => {
            vscode.commands.executeCommand('workbench.action.openSettings', 'hermesLite');
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('hermesLite.reloadSkills', () => {
            loadSkills();
            vscode.window.showInformationMessage('Skills reloaded');
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('hermesLite.toggleBackgroundReview', async () => {
            const cfg = vscode.workspace.getConfiguration('hermesLite');
            const current = cfg.get<boolean>('backgroundReview', true);
            await cfg.update('backgroundReview', !current, true);
            vscode.window.showInformationMessage(`Background review ${!current ? 'enabled' : 'disabled'}`);
        })
    );

    context.subscriptions.push(
        vscode.commands.registerCommand('hermesLite.insertSkillCommand', (command: string) => {
            const editor = vscode.window.activeTextEditor;
            if (editor) {
                editor.edit(edit => {
                    edit.insert(editor.selection.active, command + ' ');
                });
            }
        })
    );

    // Initialize backend with config
    async function initBackend() {
        try {
            await client!.initialize({
                model,
                provider,
                apiKey,
                baseUrl: baseUrl,
                toolsets,
                backgroundReview,
                maxIterations
            });
        } catch (e: any) {
            vscode.window.showErrorMessage(`Hermes Lite init failed: ${e.message}`);
        }
    }

    // Give the process a moment to start, then initialize
    setTimeout(initBackend, 1000);

    async function loadSkills() {
        try {
            const result = await client!.listSkills();
            skillProvider?.refresh(result.skills || []);
        } catch {
            // ignore
        }
    }
}

export function deactivate(): void {
    client?.stop();
    client = null;
}
