# Hermes Lite

嵌入式 Skill Agent 内核 —— Hermes Agent 的精简分支，保留核心对话能力、Skill 自我进化框架与代码沙箱，去除所有消息平台、UI 层与周期性维护模块。

## 架构

```
hermes-lite/
├── hermes_lite/          # Python 后端
│   ├── server.py         # JSON-RPC over stdio（VS Code 扩展用）
│   ├── cli.py            # 独立命令行交互
│   ├── config.py         # 精简配置系统
│   └── vscode_context.py # VS Code 上下文模型
├── core/                 # 提取的 Hermes 核心
│   ├── run_agent.py      # AIAgent 对话引擎
│   ├── agent/            # 对话循环、Skill 系统、记忆、压缩
│   └── tools/            # 工具注册表与核心工具
├── skills/               # 精简 bundled skills
└── vscode-extension/     # VS Code 扩展（TypeScript）
```

## 保留 vs 移除

| 保留 | 移除 |
|------|------|
| 核心 Agent 对话循环 | 25+ 消息平台适配器 |
| Skill 框架 + Background Review（每轮后自我进化） | Curator（7天周期优化） |
| Skill CRUD + 使用跟踪 | TUI / Web UI / Dashboard |
| 文件/终端/Web/代码执行/浏览器工具 | Cron / Kanban / LSP |
| 内置文件记忆 | 外部 Memory Provider 插件 |
| 上下文压缩 | 图像/视频生成插件 |
| 子代理委派 | Spotify / Google Meet 等独立插件 |

## 安装

### Python 后端

```bash
cd hermes-lite
pip install -e .
```

配置模型（`~/.hermes-lite/config.yaml`）：

```yaml
model: gpt-4o
provider: openai
toolsets:
  - hermes-lite
agent:
  background_review: true   # 每轮对话后自动 review skill
```

设置 API Key：

```bash
export OPENAI_API_KEY=sk-...
```

### VS Code 扩展

```bash
cd vscode-extension
npm install
npm run compile
```

在 VS Code 中按 `F5` 启动 Extension Development Host，然后在 Copilot Chat 中输入 `@hermes`。

## 使用方式

### 方式一：VS Code 扩展（推荐）

在 Copilot Chat 面板中：

```
@hermes 帮我重构这段代码
@hermes /skills          # 列出所有 skill
@hermes /review          # 说明 background review
@hermes /sandbox         # 说明代码沙箱
```

编辑器上下文（当前文件、选区、诊断）会自动传递给 Agent。

### 方式二：独立 CLI

```bash
hermes-lite chat              # 交互式对话
hermes-lite skills            # 列出技能
hermes-lite skill-view github-auth   # 查看技能
hermes-lite sessions          # 历史会话
hermes-lite config            # 当前配置
```

## Skill 自我进化

Hermes Lite 保留了 Hermes 最核心的 "自我进化" 机制：

1. **Background Review**：每轮对话结束后，fork 一个 review agent 分析本轮对话，自动创建或更新 skill。
2. **Skill CRUD**：Agent 可以通过 `skill_manage` 工具直接操作技能库（创建、编辑、补丁、删除）。
3. **使用跟踪**：每个 skill 的查看次数、使用次数、最后被使用时间都会记录到 `~/.hermes-lite/skills/.usage.json`。

> **注意**：7 天周期的 Curator（自动归档/合并 skill）已移除，改为完全由用户或 Background Review 驱动。

## 工具集

默认工具集 `hermes-lite` 包含：

- `web_search`, `web_extract` — Web 搜索与提取
- `terminal`, `process` — 本地终端与进程管理
- `read_file`, `write_file`, `patch`, `search_files` — 文件操作
- `browser_*` — 浏览器自动化
- `execute_code` — 代码执行沙箱
- `delegate_task` — 子代理委派
- `skills_list`, `skill_view`, `skill_manage` — Skill 管理
- `todo`, `memory`, `session_search` — 规划、记忆、历史搜索
- `clarify` — 澄清问题

## 开发

```bash
# 运行测试
pytest tests/

# 代码检查
ruff check hermes_lite/ core/
mypy hermes_lite/ core/
```

## License

MIT
