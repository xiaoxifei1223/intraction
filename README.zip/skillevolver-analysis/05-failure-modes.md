# 失败模式与审计机制

## 剩余失败的三类来源

论文将 SkillEvolver 未能解决的任务归纳为三类失败模式：

### H1: Pipeline Bugs（管道缺陷）

**具体表现**:
- **欠抽象（Under-abstraction）**: skill 过于具体，无法泛化到训练变体
- **发现脚本丢失（Discovery-script loss）**: 探索阶段生成的辅助脚本在后续迭代中丢失
- **静默绕过（Silent-bypass）**: skill 内容看起来有效，但运行时 agent 从未调用它
- **Train/Val Schema Drift**: 训练集和验证集的模式差异导致 skill 在验证时失效

**修复状态**: 论文称这些已被 **Auditor Checks 7-9** 解决。

### H2: Train/Validation Domain Gap（训练/验证域差距）

**具体表现**:
- 训练变体在 bug 家族、schema 或参数范围上发生漂移
- 训练时 skill 有效，但验证时遇到未见过的子领域变体

**论文态度**: 将其视为**现实的域内偏移（realistic in-domain shift）**，而非方法缺陷。即：skill 在训练分布上表现良好，但验证分布超出了合理预期范围。

### H3: Model-Capacity Walls（模型能力墙）

**具体表现**:
- 任务本身超出了底层 LLM 的硬件或模型能力
- 示例：`whisper-large-v3` 在 CPU FP32 上无法满足说话人分割（speaker-diarization）的门槛
- **连人工精选的 oracle skill 也在相同硬件上失败**

**论文态度**: 这是**基础设施限制**，不是 skill 学习方法的问题。

## Auditor 检查清单（推断）

论文提到 Auditor 执行多项检查，结合附录和正文推断如下：

### Check 1-3: 基础质量检查
- **语法/格式有效性**: skill 文件是否可解析？
- **完整性**: 必需字段（prose, code, constraints）是否齐全？
- **自洽性**: skill 内部指令是否逻辑矛盾？

### Check 4-6: 防泄漏检查
- **数据泄漏**: skill 是否记忆了训练集的具体答案？
- **路径泄漏**: skill 是否硬编码了训练集特定路径？
- **ID 泄漏**: skill 是否包含训练样本的标识符？

### Check 7-9: 部署特定检查（对应 H1）
- **Check 7 - 调用可达性**: skill 的入口是否被正确注册？agent 能否在运行时找到它？
- **Check 8 - 静默绕过检测**: 通过日志分析确认 skill 在 trial 中被实际调用，而非被忽略
- **Check 9 - Schema 兼容性**: skill 生成的输出格式是否与下游工具的输入 schema 匹配？

### Check 10-12: 泛化检查
- **训练变体测试**: 在多个训练变体上运行，确认 skill 不过拟合单一变体
- **最小策略测试**: 用极简策略测试 skill，确认它不会依赖过于特定的上下文
- **对抗性扰动**: 对输入做轻微扰动，检查 skill 的鲁棒性

## Silent-Bypass 详解

这是论文特别强调的**最隐蔽的失败模式**：

### 现象
- skill 的内容看起来完全正确：指令清晰、代码可运行、示例恰当
- 但 Domain-Skill Agent 在运行时**从未调用该 skill**
- 结果：任务可能成功（agent 自己解决了），也可能失败，但 skill 的存在与否不影响结果

### 原因推断
1. **加载顺序问题**: skill 未被正确注册到 agent 的工具列表
2. **优先级冲突**: agent 的内置工具优先级高于 skill
3. **描述不匹配**: skill 的描述与 agent 的意图匹配度不足，agent 选择了其他工具
4. **环境隔离**: skill 安装在容器中但路径未暴露给 agent

### 检测方法
- **日志审计**: 检查 trial 日志中是否有 skill 的调用记录
- **覆盖率分析**: 对比加载 skill 前后的工具调用序列
- **显式注入测试**: 强制 agent 在特定步骤调用 skill，观察行为变化

## 过拟合审计（Fresh-Agent Overfit Audit）

Auditor 的核心设计原则：

1. **Fresh Session**: Auditor agent 与探索/编写 agent 完全隔离，无记忆共享
2. **独立环境**: 在全新容器中运行，避免状态污染
3. **多策略测试**: 用多种不同策略测试 skill，而非单一路径
4. **对比基线**: 同时测试"无 skill"和"有 skill"的表现，确保增益真实

### 通过标准
```
Auditor(v_{r+1}, T_train, τ_r) clean ∧ #pass(τ_r) ≥ 3K/4
```

即：Auditor 检查全部通过，且本轮 K 个 trial 中至少 75% 通过。
