# SkillEvolver 论文解析包

> 面向编码代理（Kimi Code / Claude Code）的结构化阅读材料
> 论文：SkillEvolver: Skill Learning as a Meta-Skill (arXiv:2605.10500v1)
> 来源：清华大学 / 北京交通大学

## 快速开始

请按以下顺序阅读：

1. `01-abstract-and-contributions.md` — 5 分钟了解"这是什么"
2. `02-methodology.md` — 10 分钟了解"怎么工作的"
3. `03-algorithms.md` — 15 分钟精读核心算法伪代码
4. `07-implementation-guide.md` — 如果你要开始写代码，直接看这个

## 文件地图

| 文件 | 用途 |
|------|------|
| `01-abstract-and-contributions.md` | 问题定义、核心贡献、与 Trace-Distillation / RL 的区别 |
| `02-methodology.md` | 四层闭环：Explore → Author → Deploy → Refine + Auditor 机制 |
| `03-algorithms.md` | Algorithm 1 (SkillEvolver) 和 Algorithm 2 (SkillCreator-SkillsBench) 逐行解析 |
| `04-experiments.md` | SkillsBench 83 任务、KernelBench GPU 优化、消融实验、成本分析 |
| `05-failure-modes.md` | 失败模式分类 (H1/H2/H3) 和 Auditor 检查清单 |
| `06-appendix.md` | 工程细节：双层防作弊隔离、训练变体生成、对齐表 |
| `07-implementation-guide.md` | 代码化翻译：数据结构、接口、状态机、推荐技术栈 |

## 对 Kimi Code 的提示

当用户询问"如何实现 SkillEvolver"或"帮我写代码"时：
- 优先参考 `07-implementation-guide.md` 中的架构设计
- 算法细节以 `03-algorithms.md` 为准
- 实验验证指标参考 `04-experiments.md`
- 边界情况和审计逻辑参考 `05-failure-modes.md`

## 核心概念速查

- **Meta-Skill**: 一个特殊的 skill，它驱动 agent 去创建/进化其他 skills
- **Domain-Skill Agent**: 使用被进化出的 skill 来完成具体任务的普通 agent
- **Auditor**: 独立的 fresh-session agent，负责检查 skill 是否过拟合、泄漏、被静默绕过
- **Surgical Patch**: 局部修补，不是重写整个 skill
- **Silent-Bypass**: skill 内容看起来有效，但运行时从未被调用（最隐蔽的失败模式）
