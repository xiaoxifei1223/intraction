# 实现指南：论文→代码的桥梁

> 本文档面向编码代理（Kimi Code / Claude Code），提供将 SkillEvolver 论文转化为可运行系统的具体指导。
> 假设读者已阅读 `03-algorithms.md` 理解核心算法。

## 1. 系统架构映射

将论文概念映射到工程组件：

```
论文概念                    工程组件
─────────────────────────────────────────────────
Meta-Skill (SkillEvolver)   →  EvolutionEngine 服务
Domain-Skill Agent          →  Worker Agent (Docker/进程)
Task T                      →  TaskDefinition + 训练/验证数据
Skill Artifact (v)          →  SkillPackage (JSON + 文件)
Explore()                   →  TrialRunner (并行容器)
Contrast()                  →  TrajectoryAnalyzer (差异分析)
Distill()                   →  SkillGenerator (LLM 调用)
SurgicalPatch()             →  SkillPatcher (差异应用)
Auditor()                   →  AuditRunner (独立容器)
Harbor                      →  Container Orchestrator (Docker/k8s)
```

## 2. 核心数据模型

```python
# models.py
from pydantic import BaseModel, Field
from typing import Literal, Optional, List, Dict, Any
from datetime import datetime

class TaskDefinition(BaseModel):
    task_id: str
    domain: str
    description: str
    train_variant_dir: str
    val_variant_dir: str
    decision_axes: List[str]
    expected_output_schema: Dict[str, Any]
    max_iterations: int = 2
    explore_width: int = 4
    validate_trials: int = 3

class SkillPackage(BaseModel):
    version: str
    prose: str
    code: Optional[str] = None
    references: List[str] = []
    examples: List[Dict[str, Any]] = []
    constraints: List[str] = []
    metadata: Dict[str, Any] = {}
    created_at: datetime = Field(default_factory=datetime.now)

class Trajectory(BaseModel):
    trial_id: int
    iteration: int
    strategy_id: int
    skill_version: Optional[str] = None
    turns: List[Dict[str, Any]] = []
    outcome: Literal["pass", "fail"]
    failure_mode: Optional[str] = None
    token_usage: int = 0
    duration_ms: int = 0
    logs: str = ""

class ContrastDelta(BaseModel):
    iteration: int
    additions: List[SkillPatch] = []
    deletions: List[SkillPatch] = []
    modifications: List[SkillPatch] = []
    analysis_summary: str = ""

class SkillPatch(BaseModel):
    target_section: str
    old_content: Optional[str] = None
    new_content: str
    reason: str
    confidence: float = 1.0

class AuditReport(BaseModel):
    skill_version: str
    iteration: int
    checks: List[AuditCheck] = []
    overall_pass: bool
    pass_rate: float

class AuditCheck(BaseModel):
    name: str
    passed: bool
    details: str
    severity: Literal["info", "warning", "critical"]
```

## 3. 核心接口设计

```python
# engine.py
class EvolutionEngine:
    def __init__(self, llm_client, container_orchestrator):
        self.llm = llm_client
        self.orchestrator = container_orchestrator

    async def evolve(self, task):
        # Line 1: Parse(T_train)
        axes = await self._parse_task(task)

        # Line 2-5: Bootstrap (r=0)
        strategies = self._diverse_strategies(axes, skill=None, history=[])
        trajectories = await self._explore(task, strategies, skill=None)
        delta = self._contrast(trajectories)
        skill_v1 = await self._distill(delta)
        skills_history = [skill_v1]

        # Line 6-14: Refinement loop
        for r in range(1, task.max_iterations):
            current_skill = skills_history[-1]
            await self._deploy_skill(current_skill, task)
            strategies = self._diverse_strategies(axes, current_skill, trajectories)
            trajectories = await self._explore(task, strategies, current_skill)
            delta = self._contrast(trajectories)
            next_skill = await self._surgical_patch(current_skill, delta)
            audit = await self._audit(next_skill, task, trajectories)
            skills_history.append(next_skill)
            if audit.overall_pass and audit.pass_rate >= 0.75:
                break

        # Line 15-16: Finalize and Validate
        best_skill = await self._finalize(skills_history, task)
        validation = await self._validate(best_skill, task)
        return best_skill

    async def _parse_task(self, task):
        prompt = f"Analyze task structure and extract decision axes: {task.description}"
        response = await self.llm.generate(prompt)
        return self._extract_axes(response)

    def _diverse_strategies(self, axes, skill, history):
        if skill is None:
            return self._generate_strong_priors(axes)
        else:
            weak_spots = self._identify_weak_spots(skill, history)
            return self._generate_stress_tests(axes, weak_spots)

    async def _explore(self, task, strategies, skill):
        trials = []
        for i, strategy in enumerate(strategies):
            trial = self.orchestrator.create_trial(
                task_id=task.task_id,
                strategy_id=i,
                skill=skill,
                workspace_isolation=True
            )
            trials.append(trial)
        results = await asyncio.gather(*[self._run_trial(t, task) for t in trials])
        return results

    def _contrast(self, trajectories):
        winners = [t for t in trajectories if t.outcome == "pass"]
        losers = [t for t in trajectories if t.outcome == "fail"]
        prompt = f"Contrast winners ({len(winners)}) vs losers ({len(losers)}): {trajectories}"
        analysis = self.llm.generate(prompt)
        return self._parse_delta(analysis)

    async def _distill(self, delta):
        prompt = f"Write skill based on delta: {delta.analysis_summary}"
        return await self.llm.generate_structured(prompt, schema=SkillPackage)

    async def _surgical_patch(self, skill, delta):
        new_skill = skill.copy()
        for patch in delta.additions + delta.modifications:
            if patch.target_section == "prose":
                new_skill.prose = self._apply_text_patch(new_skill.prose, patch)
            elif patch.target_section == "code":
                new_skill.code = self._apply_code_patch(new_skill.code, patch)
            elif patch.target_section == "constraints":
                new_skill.constraints.append(patch.new_content)
        new_skill.version = f"v{int(skill.version[1:]) + 1}"
        return new_skill

    async def _audit(self, skill, task, trajectories):
        auditor = self.orchestrator.create_auditor(task.task_id)
        checks = []
        checks.append(await auditor.check_syntax(skill))
        checks.append(await auditor.check_data_leakage(skill, task))
        checks.append(await auditor.check_silent_bypass(skill, trajectories))
        checks.append(await auditor.check_schema_compatibility(skill, task))
        pass_rate = sum(1 for t in trajectories if t.outcome == "pass") / len(trajectories)
        overall = all(c.passed for c in checks) and pass_rate >= 0.75
        return AuditReport(
            skill_version=skill.version,
            checks=checks,
            overall_pass=overall,
            pass_rate=pass_rate
        )

    async def _finalize(self, skills, task):
        scored = [(await self._score_skill(s, task), s) for s in skills]
        scored.sort(reverse=True)
        return scored[0][1]

    async def _validate(self, skill, task):
        return await self._explore(task, [{}] * task.validate_trials, skill)
```

## 4. 容器编排层

```python
# orchestrator.py
class DockerOrchestrator:
    def create_trial(self, task_id, strategy_id, skill, workspace_isolation=True):
        workspace = f"/tmp/skillevolver/{task_id}/trial_{strategy_id}"
        os.makedirs(workspace, exist_ok=True)
        self._copy_task_data(task_id, workspace)
        env = {}
        if skill:
            skill_dir = f"{workspace}/.skills/{skill.version}"
            skill.to_filesystem(skill_dir)
            env["SKILL_PATH"] = skill_dir
        container = docker.run(
            image="agent-runtime:latest",
            volumes={workspace: {"bind": "/workspace", "mode": "rw"}},
            environment=env,
            network_mode="none"
        )
        return TrialContainer(container, workspace, strategy_id)

    def create_auditor(self, task_id):
        return AuditorAgent(
            container=docker.run(
                image="agent-runtime:latest",
                environment={"AUDITOR_MODE": "true"},
                volumes={}
            )
        )
```

## 5. 与 Copilot / IDE 集成

架构建议：

```
Copilot (IDE) → Skill Registry (本地服务) ← SkillEvolver (进化引擎)
                      ↑
                Local Skills Storage
```

### MCP 接口设计

```python
# mcp_server.py
from mcp.server import Server
app = Server("skillevolver")

@app.tool()
async def evolve_skill(task_description, domain, train_examples, current_skill_id=None):
    task = TaskDefinition(
        task_id=current_skill_id or generate_id(),
        domain=domain,
        description=task_description,
        train_variant_dir=prepare_examples(train_examples)
    )
    engine = EvolutionEngine(llm_client, orchestrator)
    skill = await engine.evolve(task)
    registry.save(skill)
    return {"skill_id": skill.metadata.get("task_id"), "version": skill.version}

@app.tool()
async def get_skill(skill_id, version=None):
    skill = registry.load(skill_id, version)
    return skill.dict()
```

## 6. 推荐技术栈

| 组件 | 推荐方案 |
|------|---------|
| 进化引擎 | Python + FastAPI |
| LLM 调用 | 多后端支持 (Kimi/OpenAI/Anthropic) |
| 容器隔离 | Docker + Python docker SDK |
| 任务调度 | APScheduler |
| Skill 存储 | SQLite + 文件系统 |
| MCP 协议 | mcp-python-sdk |
| 前端管理 | Tauri + React |

## 7. MVP 路线图

### Phase 1: 核心闭环 (2-3天)
- TaskDefinition + SkillPackage 数据模型
- _parse_task + _diverse_strategies (简化随机版)
- _explore (单进程串行)
- _contrast + _distill (直接调用 LLM)
- _surgical_patch (字符串替换)
- _audit (简化版：通过率 + 语法)

### Phase 2: 隔离与并行 (3-5天)
- Docker 容器编排
- 工作空间白名单 (PreToolUse hook)
- K 个 trial 并行
- 训练/测试数据分离

### Phase 3: 系统集成 (2-3天)
- MCP Server 封装
- Skill Registry 版本管理
- 对接 Copilot skill 加载
- Tauri 桌面界面

### Phase 4: 优化 (持续)
- 策略多样化升级为 LLM 生成
- Auditor 完整 12 项检查
- 失败模式自动分类
- 跨任务 skill 复用

## 8. 关键实现陷阱

1. **Silent-Bypass 检测**: 必须在 trial 日志中显式记录 skill 调用事件，不能只看最终任务成败。
2. **Surgical Patch 精确性**: 字符串替换容易出错。建议用 AST（代码）或段落标记（prose）做结构化 patch。
3. **Auditor 隔离性**: 必须确保 Auditor 的 LLM 会话、文件系统、环境变量与探索 agent 完全隔离。
4. **Skill 版本膨胀**: 每次迭代产生新版本，需要垃圾回收机制，只保留通过 Audit 的版本。
5. **成本控制**: R=2, K=4 意味着每任务 8 次 LLM 调用。需要 Token 预算控制和早期退出机制。
