# 附录与工程细节

## A.1 双层防作弊隔离设计

### 目标
确保训练阶段的探索不会"偷看"测试集或人工精选的参考 skill。

### Layer 1: 训练/测试分离
- **文件名不相交**: T_train 和 T_val 的文件名完全不同
- **数据值不相交**: 输入数据值经过重采样，与验证集无重叠
- **子领域可能不同**: 某些任务在子领域上有意制造差异
- **精选训练 skill 删除**: 人工编写的训练 skill 在源头被物理删除，探索期间不可达

### Layer 2: 工作空间白名单（Workspace Whitelist）
- **PreToolUse Hook**: 在每次 agent 工具调用前拦截
- **单运行工作空间前缀**: 每个 trial 被限制在单一目录前缀内
- **外部资源不可达**: 验证任务目录、精选验证 skill、测试套件位于外部路径
- **拒绝遍历**: 拒绝 `..` 路径遍历和任何解析到精选训练 skill 槽位的路径
- **双重检查**: 同时检查原始路径和符号链接解析后的路径

## A.2 训练变体生成方法（Training-Variant Generation）

### 独立性
- 训练变体生成管道与 SkillEvolver 完全正交
- 无论 SkillEvolver 的 R 值如何，使用相同的变体输出

### 生成原则
1. **保留任务结构**: 测试规格格式、期望输出形状保持不变
2. **重采样输入**: 具体输入值重新生成
3. **删除参考 skill**: 确保 agent 无法直接复制人工答案
4. **可运行性**: 所有变体必须能在 Harbor 容器中成功运行

## A.3 对齐表（Alignment Table）

论文 Table 4 比较了三种配置的关键设计轴：

| 设计轴 | SkillEvolver R=2 | SkillEvolver R=1 | SkillCreator-SkillsBench |
|--------|-----------------|-----------------|-------------------------|
| 试验次数 | K + (R-1)*K | K | 1-2 |
| 预算 | $3.92 | $3.64 | $6.97 |
| Oracle Policy | 无人工介入 | 无人工介入 | 自动化子代理 |
| 隔离设计 | 双层防作弊 | 双层防作弊 | 较弱 |
| 作者身份 | Meta-skill 驱动 | Meta-skill 驱动 | 自生成 + 自动反馈 |
| 精炼机制 | 部署驱动 + Auditor | 无精炼 | 静态评估反馈 |

## A.4 SkillCreator-SkillsBench 适配细节

原始 Anthropic Skill-Creator 包含人工环节：
1. Capture Intent 访谈（人工）
2. Skill 编写（Agent）
3. 人工评分
4. Eval-Viewer 反馈
5. 人工精炼

论文的适配版本用自动化子代理替换：
- **Eval Designer** → 替代 Capture Intent 访谈
- **Grader** → 替代人工评分
- **Analyzer** → 替代 eval-viewer 反馈

这使得 SkillCreator-SkillsBench 成为可自动运行的对比基线，但保留了其"静态评估反馈"的本质局限。

## A.5 SkillsBench 任务列表与分类

### 完整覆盖领域
1. Web Development
2. Data Science
3. DevOps
4. Chemistry
5. Quantum Computing
6. Seismology
7. Finance
8. Document Processing
9. ML Infrastructure
10. Control Systems
11. Game Analytics
12. Audio/Video Processing
13. Security
14. Scheduling
15. 更多...

### 分类标签含义
- **A**: Already easy — 无 skill 也能解
- **B1**: Curated helps — 人工 skill 有帮助
- **B2**: Curated neutral — 人工 skill 中性
- **B3**: Curated hurts — 人工 skill 反而有害
- **C1**: Curated unlocks (strong) — 无 skill 失败，人工 skill 强力解锁
- **C2**: Curated unlocks (weak) — 无 skill 失败，人工 skill 弱解锁
- **D**: Neither baseline nor curated solves — 两者都失败

### 被排除的 4 个任务
- 2 个需要付费外部 API
- 2 个在 Harbor 配置下存在持续基础设施不稳定
- **排除是对称的**: 所有条件（A/B/C/D）都同样排除这些任务

## A.6 每任务结果数据库

论文释放了完整的结果数据库，包含：
- 每任务 Pass@5（A/B/SkillCreator-SkillsBench/Evolver R=1/R=2）
- Evolver 的 Finalize 选择分布（v1 vs v2 vs merge）
- 每阶段 Pass@5（探索、精炼、验证）
- 每任务 Token 消耗和美元成本
- 可视化热图（与 SkillsBench 论文 Figures 11-12 同格式）

## A.7 单 LLM 评估说明

论文主实验使用单一 LLM（未明确说明具体模型，但上下文暗示为 Claude/GPT 级别）。

**Spot Test**: 作者在 GPT + Codex 上做了端到端运行测试，确认 meta-skill 的 LLM-agnostic 设计原则成立。

**局限**: 由于成本原因，未在替代 SOTA LLM 上运行完整基准扫描。
