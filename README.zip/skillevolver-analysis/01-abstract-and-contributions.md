# 摘要与核心贡献

## 论文基本信息

- **标题**: SkillEvolver: Skill Learning as a Meta-Skill
- **arXiv**: 2605.10500v1 [cs.AI]
- **日期**: 2026-05-11
- **机构**: 清华大学 (Hongning Wang 团队) + 北京交通大学
- **作者**: Genrui Zhang*, Erle Zhu*, Jinfeng Zhou, Caiyan Jia, Hongning Wang†

## 一句话概括

SkillEvolver 是一个**轻量级、即插即用的元技能（meta-skill）**，它让标准 CLI-agent 能够通过"探索→编写→部署→观察失败→局部修补"的闭环，从少量实战经验中自动进化出可复用的领域技能——**不修改模型权重**。

## 核心问题

现有 Agent 技能的困境：
1. **人工编写**: 成本高、不及时，长尾场景覆盖不到
2. **参数化自生成**: 模型直接凭预训练知识写 skill，缺乏落地反馈，效果有时比不用 skill 还差
3. **轨迹蒸馏/RL**: 需要大量离线轨迹池、跨任务聚合，不适合"按需、少量尝试"的真实场景

**本文聚焦**: 如何在只有少量训练尝试（few-trial）的预算下，为**新到达的单个任务**在线学习出一个可复用技能？

## 三个核心贡献

### 贡献 1: 在线技能学习的框架定义
将技能学习定义为**获取可复用的过程性工件（artifact）**，而非更新模型参数。SkillEvolver 作为一个 meta-skill，通过标准 skill 接口被任何 CLI-agent 加载，驱动其完成技能全生命周期。

### 贡献 2: 基于部署的精炼闭环
区别于以往"从探索轨迹提炼"的做法，SkillEvolver 的优化信号来自**部署后的实际使用失败**：
- 把候选 skill 作为真实依赖安装到 trial 容器中
- 让全新的 Domain-Skill Agent 去使用它
- 观察"skill 是否被静默绕过（silent-bypass）"、"是否误导 agent"、"是否遗漏关键指令"
- 用对比更新（contrastive update）将成功 vs 失败的轨迹转化为局部修补

### 贡献 3: 独立 Auditor 门控
每个精炼迭代后，由**全新会话的 Auditor**检查：
- 数据泄漏（data leakage）
- 过拟合（overfit）
- 部署特定失败（如 silent-bypass、train/val schema drift）
只有通过审计的 skill 才能进入接受序列。

## 与相关工作的关键区别

| 方法 | 更新对象 | 反馈来源 | 适用场景 |
|------|---------|---------|---------|
| **Parametric Self-Generation** (Anthropic Skill-Creator) | Skill 工件 | 模型预训练知识 | 快速生成，无验证 |
| **Trace Distillation** (Trace2Skill) | Skill 工件 | 预收集的大量轨迹池 | 离线、大批量 |
| **RL-based** (SkillRL) | Skill 库 + 模型策略 | 跨任务聚合 | 训练期、多任务 |
| **SkillEvolver (本文)** | Skill 工件 | **部署后新鲜 agent 的使用失败** | **在线、按需、少样本** |

## 实验结果速览

- **SkillsBench** (83 任务，15+ 领域): 56.8% avg@5 vs 人工精选 43.6% vs 无技能 29.9%
- **KernelBench** (GPU 内核优化): 平均加速比从 1.16 → 1.51
- **效率**: 进化后的 skill 让下游 agent Token 减少 19.4%，交互轮数减少 15.3%，运行时间减少 23.8%
- **成本**: 每任务平均 $3.64 (R=1)，远低于 SkillCreator-SkillsBench 的 $6.97

## 关键洞察

1. **迭代精炼是增益的主要来源**: R=1（无精炼）vs R=2（一次精炼）的对比显示，精炼贡献了大部分提升
2. **Skill 进化 ≠ 模型进化**: 学习目标是 skill 的 prose 和 code，不是模型权重，因此产物可 drop-in 到任何 agent
3. **Meta-Skill 的通用性**: 由于通过标准 skill 接口加载，理论上 LLM-agnostic（论文在 GPT + Codex 上做了端到端点测）
