# 核心算法伪代码解析

## Algorithm 1: SkillEvolver

```text
输入: 任务 T; 迭代上限 R; 探索宽度 K; 验证尝试数 V
输出: π(v*; T_val)

─────────────────────────────────────────────────────────────
1.  axes ← Parse(T_train)                    // §3.1 一次性理解任务结构
2.  S0 ← DiverseStrategies(axes, ∅, ∅)       // §3.2.1 初始化：K 个强先验策略
                                              //   通过 trial 索引路由
3.  τ0 ← Explore(T_train, S0, v=∅, K)        // §3.2.1 K 个并行 trial
                                              //   trial i 通过 env 索引加载 s0,i
4.  Δ0 ← Contrast(τ0+, τ0-)                 // §3.2.2 赢家 vs 输家
5.  v1 ← Distill(Δ0); mirror v1 to output    // §3.2.2 蒸馏 + 安全部署副本

6.  for r ← 1 to R-1 do                      // §3.2.1 部署-压力测试循环
7.      deploy vr as a live skill in trial container
                                              // §3.2.1 真实场景采样
8.      Sr ← DiverseStrategies(axes, vr, τr-1)
                                              // §3.2.1 持续：K 个压力测试策略
                                              //   针对 vr 的弱点
9.      τr ← Explore(T_train, Sr, vr, K)     // §3.2.1 trial i 先加载 sr,i，再咨询 vr
10.     Δr ← Contrast(τr+, τr-)              // §3.2.2 vr 在哪里误导了？
11.     vr+1 ← SurgicalPatch(vr, Δr)         // §3.2.2 手术式，非重写
12.     if Auditor(vr+1, T_train, τr) clean ∧ #pass(τr) ≥ 3K/4
                                              // §3.2.3 继续或退出
13.         then break
14. end

15. v* ← argmax_{v∈{v1,...,vR}} score(v; T_train)   // §3.1 最终选择（无 Harbor 调用）
16. return Validate(v*, T_val, V)              // §3.1 保留验证
─────────────────────────────────────────────────────────────
```

### 逐行解析

**Line 1: Parse(T_train)**
- 一次性理解任务结构，提取决策轴（decision axes）
- 例如：数据格式选择、API 调用顺序、错误处理策略等

**Line 2: DiverseStrategies(axes, ∅, ∅)**
- 初始阶段没有候选 skill，也没有历史轨迹
- 基于任务结构生成 K 个多样化的强先验策略
- 每个策略通过 trial 的环境索引独立路由，确保并行隔离

**Line 3: Explore(T_train, S0, v=∅, K)**
- K 个并行 trial，每个 trial i 加载策略 s0,i
- 此时还没有 skill（v=∅），agent 纯凭策略探索
- 收集完整轨迹 τ0

**Line 4: Contrast(τ0+, τ0-)**
- 将 K 个轨迹按成功/失败分组
- 提取对比差异 Δ0：成功轨迹共享什么？失败轨迹缺什么？

**Line 5: Distill(Δ0)**
- 将对比差异转化为 skill 工件 v1
- mirror 到输出目录，作为 failsafe deploy copy

**Line 7: deploy vr as a live skill**
- **关键设计**：从 r=1 开始，skill 不是被"参考"，而是被"安装"
- Domain-Skill Agent 把它当作真实依赖使用

**Line 8: DiverseStrategies(axes, vr, τr-1)**
- 迭代阶段：策略生成针对 vr 的**已观察弱点**
- 利用上一轮轨迹 τr-1 中的失败模式，构造压力测试策略

**Line 9: Explore(T_train, Sr, vr, K)**
- trial agent 先加载策略 sr,i，然后在需要时咨询 vr
- 这模拟了真实使用场景：agent 有任务策略，skill 是辅助工具

**Line 10: Contrast(τr+, τr-)**
- 核心问题：vr 在哪里帮助了 agent？在哪里误导了 agent？
- 对比信号现在反映的是 **skill 的部署效果**，而非 agent 的探索能力

**Line 11: SurgicalPatch(vr, Δr)**
- 局部修补：只修改导致失败的具体部分
- 保留已验证有效的 prose 和 code
- 避免"重写导致退化"

**Line 12: Auditor(vr+1, T_train, τr)**
- 独立 Auditor 用全新会话检查 vr+1
- 检查清单包括：泄漏、过拟合、silent-bypass、schema drift
- 同时要求本轮通过率 ≥ 3K/4（75%）

**Line 15: Finalize**
- 从历史版本中选择最优（基于 T_train 得分）
- 不调用 Harbor，纯本地评估

**Line 16: Validate**
- 在完全隔离的 T_val 上验证最终 skill
- V 次尝试取平均

## Algorithm 2: SkillCreator-SkillsBench（对比基线）

```text
输入: 任务 T
输出: skill v

─────────────────────────────────────────────────────────────
1.  Human Interview → Capture Intent
2.  Agent Self-Generation → Write Skill Draft
3.  Human Grading → Evaluate Draft
4.  Eval-Viewer Feedback → Human Refines
5.  Repeat 3-4 until satisfied
─────────────────────────────────────────────────────────────
```

论文中的适配版本用自动化子代理替换了人工环节：
- `Eval Designer` 替代 Capture Intent 访谈
- `Grader` 替代人工评分
- `Analyzer` 替代 eval-viewer 反馈

### 与 SkillEvolver 的关键差异

| 维度 | SkillCreator-SkillsBench | SkillEvolver |
|------|-------------------------|--------------|
| 反馈来源 | 预定义 eval + 静态分析 | 部署后新鲜 agent 的实际失败 |
| 迭代触发 | 人工/Grader 判断 | 自动对比 + Auditor 门控 |
| 失败检测 | 内容正确性 | 内容 + 调用模式 + 静默绕过 |
| 成本 | $6.97/任务 | $3.64/任务 (R=1) |
| 隔离性 | 较弱 | 双层防作弊 |

## 关键数据结构（推断）

```python
# Skill 工件结构（论文描述推断）
class SkillArtifact:
    prose: str                    # 自然语言指令
    code: str | None             # 可执行脚本
    references: list[FileRef]     # 参考文件
    examples: list[Example]     # 使用示例
    constraints: list[Constraint]  # 使用约束
    metadata: SkillMeta         # 版本、来源、审计状态

# 轨迹结构
class Trajectory:
    trial_id: int
    strategy_id: int
    skill_version: str | None     # 使用的 skill 版本
    turns: list[Turn]             # 交互轮次
    outcome: Literal["pass", "fail"]
    failure_mode: FailureMode | None

# 对比差异
class ContrastDelta:
    additions: list[SkillPatch]   # 成功轨迹有、失败轨迹无
    deletions: list[SkillPatch]   # 失败轨迹有、成功轨迹无
    modifications: list[SkillPatch]  # 两者都有但表现不同
```
