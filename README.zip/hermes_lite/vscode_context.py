"""Data models for VS Code editor context passed to the agent."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class VSCodeContext:
    """Snapshot of the VS Code editor state sent with each chat request."""

    file_path: Optional[str] = None
    """Absolute path of the active text editor's document."""

    language_id: Optional[str] = None
    """Language mode of the active document (e.g. 'python', 'typescript')."""

    selection: Optional[str] = None
    """Currently selected text in the editor."""

    selection_range: Optional[Dict[str, int]] = None
    """Line/column range of the selection: {startLine, startCharacter, endLine, endCharacter}."""

    diagnostics: Optional[List[Dict[str, Any]]] = None
    """Diagnostic items for the current document (errors, warnings)."""

    workspace_folders: Optional[List[str]] = None
    """List of workspace folder paths."""

    @classmethod
    def from_json(cls, data: Dict[str, Any]) -> "VSCodeContext":
        return cls(
            file_path=data.get("filePath"),
            language_id=data.get("languageId"),
            selection=data.get("selection"),
            selection_range=data.get("selectionRange"),
            diagnostics=data.get("diagnostics"),
            workspace_folders=data.get("workspaceFolders"),
        )

    def to_json(self) -> Dict[str, Any]:
        return {
            "filePath": self.file_path,
            "languageId": self.language_id,
            "selection": self.selection,
            "selectionRange": self.selection_range,
            "diagnostics": self.diagnostics,
            "workspaceFolders": self.workspace_folders,
        }
