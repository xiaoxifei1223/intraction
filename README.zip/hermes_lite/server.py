#!/usr/bin/env python3
"""Hermes Lite JSON-RPC server over stdio.

Launched by the VS Code extension as a child process.
Communicates via newline-delimited JSON-RPC 2.0 messages.

Protocol:
  Request  (client → server):  {"jsonrpc":"2.0","id":1,"method":"chat","params":{...}}
  Response (server → client):  {"jsonrpc":"2.0","id":1,"result":{...}}
  Notification (server → client): {"jsonrpc":"2.0","method":"message/delta","params":{...}}
"""

from __future__ import annotations

import json
import logging
import os
import queue
import sys
import threading
import traceback
from pathlib import Path
from typing import Any, Dict, Optional

# Ensure core/ is on the path so original Hermes imports work.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT / "core"))

from hermes_constants import get_hermes_home
from hermes_logging import setup_logging
from hermes_state import SessionDB

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# JSON-RPC helpers
# ---------------------------------------------------------------------------

def _send(obj: Dict[str, Any]) -> None:
    line = json.dumps(obj, ensure_ascii=False)
    sys.stdout.write(line + "\n")
    sys.stdout.flush()


def _notify(method: str, params: Optional[Dict[str, Any]] = None) -> None:
    _send({"jsonrpc": "2.0", "method": method, "params": params or {}})


def _reply(req_id: Any, result: Optional[Dict[str, Any]] = None, error: Optional[Dict[str, Any]] = None) -> None:
    msg: Dict[str, Any] = {"jsonrpc": "2.0", "id": req_id}
    if error:
        msg["error"] = error
    else:
        msg["result"] = result if result is not None else {}
    _send(msg)


# ---------------------------------------------------------------------------
# Agent wrapper
# ---------------------------------------------------------------------------

class _AgentWrapper:
    """Thin wrapper around AIAgent that bridges sync agent ↔ async JSON-RPC."""

    def __init__(self):
        self._agent: Optional[Any] = None
        self._session_db: Optional[SessionDB] = None
        self._lock = threading.Lock()
        self._config: Dict[str, Any] = {}

    def initialize(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Initialize or re-initialize the agent with user config."""
        from run_agent import AIAgent
        from toolsets import get_toolset
        from hermes_lite.config import resolve_llm_config

        self._config = config
        toolsets = config.get("toolsets", ["hermes-lite"])

        llm = resolve_llm_config(
            model=config.get("model", ""),
            provider=config.get("provider", ""),
            base_url=config.get("baseUrl", ""),
            api_key=config.get("apiKey", ""),
        )

        # Ensure Hermes home exists
        hermes_home = get_hermes_home()
        (hermes_home / "skills").mkdir(parents=True, exist_ok=True)
        (hermes_home / "logs").mkdir(parents=True, exist_ok=True)

        with self._lock:
            self._session_db = SessionDB(hermes_home / "sessions.db")
            self._agent = AIAgent(
                model=llm["model"],
                provider=llm["provider"],
                api_key=llm["api_key"],
                base_url=llm["base_url"],
                enabled_toolsets=toolsets,
                platform="vscode",
                quiet_mode=True,
                skip_memory=False,
            )
        return {"status": "ok", "model": llm["model"], "tools": len(toolsets)}

    def chat(self, req_id: Any, message: str, context: Optional[Dict[str, Any]] = None) -> None:
        """Run one conversation turn in a background thread, streaming results."""
        if self._agent is None:
            _reply(req_id, error={"code": -32000, "message": "Agent not initialized"})
            return

        def _run():
            try:
                # Inject VS Code editor context into the user message if provided
                full_message = message
                if context:
                    ctx_parts = ["[VS Code Context]"]
                    if context.get("filePath"):
                        ctx_parts.append(f"Current file: {context['filePath']}")
                    if context.get("selection"):
                        ctx_parts.append(f"Selection:\n```\n{context['selection']}\n```")
                    if context.get("diagnostics"):
                        ctx_parts.append(f"Diagnostics: {json.dumps(context['diagnostics'])}")
                    if len(ctx_parts) > 1:
                        full_message = "\n\n".join(ctx_parts + ["[/VS Code Context]", message])

                result = self._agent.run_conversation(user_message=full_message)
                final = result.get("final_response", "")
                _reply(req_id, result={"finalResponse": final, "apiCalls": result.get("api_calls", 0)})
            except Exception as exc:
                logger.exception("Chat turn failed")
                _reply(req_id, error={"code": -32001, "message": str(exc), "data": traceback.format_exc()})

        threading.Thread(target=_run, daemon=True).start()

    def list_skills(self) -> Dict[str, Any]:
        """Return a flat list of available skills."""
        from agent.skill_commands import get_skill_commands
        from agent.skill_utils import iter_skill_index_files
        from hermes_constants import get_hermes_home

        skills_dir = get_hermes_home() / "skills"
        cmds = get_skill_commands()
        skills = []
        for cmd_key, meta in cmds.items():
            skills.append({
                "name": meta.get("name", cmd_key.lstrip("/")),
                "description": meta.get("description", ""),
                "command": cmd_key,
            })
        return {"skills": skills}

    def view_skill(self, name: str) -> Dict[str, Any]:
        from tools.skills_tool import skill_view
        result = skill_view(name)
        try:
            data = json.loads(result)
        except Exception:
            data = {"success": False, "error": result}
        return data

    def manage_skill(self, action: str, name: str, content: Optional[str] = None) -> Dict[str, Any]:
        from tools.skill_manager_tool import skill_manage
        args: Dict[str, Any] = {"action": action, "name": name}
        if content is not None:
            args["content"] = content
        result = skill_manage(**args)
        try:
            data = json.loads(result)
        except Exception:
            data = {"success": False, "error": result}
        return data

    def list_sessions(self) -> Dict[str, Any]:
        if self._session_db is None:
            return {"sessions": []}
        rows = self._session_db.list_sessions(limit=50)
        sessions = []
        for row in rows:
            sessions.append({
                "id": row.get("session_id", ""),
                "title": row.get("title", "Untitled"),
                "createdAt": row.get("created_at", ""),
                "messageCount": row.get("message_count", 0),
            })
        return {"sessions": sessions}

    def shutdown(self) -> None:
        with self._lock:
            if self._agent and hasattr(self._agent, "_session_db") and self._agent._session_db:
                try:
                    self._agent._session_db.close()
                except Exception:
                    pass
            self._agent = None
            self._session_db = None


# Singleton agent wrapper
_AGENT = _AgentWrapper()


# ---------------------------------------------------------------------------
# Request dispatch
# ---------------------------------------------------------------------------

_METHODS = {
    "initialize": lambda p: _AGENT.initialize(p),
    "chat": lambda p: _AGENT.chat(p.pop("_reqId", None), p.get("message", ""), p.get("context")),
    "skill/list": lambda p: _AGENT.list_skills(),
    "skill/view": lambda p: _AGENT.view_skill(p.get("name", "")),
    "skill/manage": lambda p: _AGENT.manage_skill(p.get("action", ""), p.get("name", ""), p.get("content")),
    "session/list": lambda p: _AGENT.list_sessions(),
    "shutdown": lambda p: (_AGENT.shutdown(), {"status": "ok"})[1],
}


def _handle_request(req: Dict[str, Any]) -> None:
    req_id = req.get("id")
    method = req.get("method", "")
    params = req.get("params", {})

    if method not in _METHODS:
        _reply(req_id, error={"code": -32601, "message": f"Method not found: {method}"})
        return

    # chat is special — it replies asynchronously
    if method == "chat":
        params["_reqId"] = req_id
        _METHODS[method](params)
        return

    try:
        result = _METHODS[method](params)
        _reply(req_id, result=result)
    except Exception as exc:
        logger.exception("Request handler failed: %s", method)
        _reply(req_id, error={"code": -32000, "message": str(exc), "data": traceback.format_exc()})


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def _readline() -> Optional[str]:
    try:
        line = sys.stdin.readline()
        if not line:
            return None
        return line.strip()
    except KeyboardInterrupt:
        return None


def main() -> None:
    # Use ~/.hermes-lite as home directory so we don't collide with full Hermes
    os.environ.setdefault("HERMES_HOME", str(Path.home() / ".hermes-lite"))

    # Setup logging to file only (no stdout to avoid corrupting JSON-RPC)
    hermes_home = get_hermes_home()
    log_dir = hermes_home / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    setup_logging(mode="cli", hermes_home=hermes_home)
    logger.info("Hermes Lite server starting")

    # Suppress stdout from imported libraries (e.g., urllib3, openai)
    class _DevNull:
        def write(self, _: str) -> None:
            pass
        def flush(self) -> None:
            pass

    # Keep original stdout for JSON-RPC; redirect stray prints to stderr
    sys.stdout = sys.__stdout__
    print = lambda *a, **k: None  # noqa: E731

    try:
        while True:
            line = _readline()
            if line is None:
                break
            if not line:
                continue
            try:
                req = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Ignoring non-JSON line: %.200s", line)
                continue
            if not isinstance(req, dict):
                continue
            if "method" in req:
                _handle_request(req)
            else:
                # Unknown message — ignore
                pass
    except KeyboardInterrupt:
        pass
    finally:
        _AGENT.shutdown()
        logger.info("Hermes Lite server shutting down")


if __name__ == "__main__":
    main()
