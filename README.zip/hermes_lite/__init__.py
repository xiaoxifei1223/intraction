"""Hermes Lite — Embedded Skill Agent for VS Code.

A minimal, embeddable fork of Hermes Agent retaining:
- Core conversation loop with tool execution
- Skill framework with self-evolution (per-turn background review)
- Usage tracking
- Code execution sandbox

All messaging platforms, TUI, web UI, cron, and periodic curator
have been removed.
"""

__version__ = "0.1.0"
