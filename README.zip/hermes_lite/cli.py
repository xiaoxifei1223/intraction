#!/usr/bin/env python3
"""Hermes Lite CLI — minimal interactive command-line interface.

Stripped of gateway, TUI, cron, kanban, and messaging platforms.
Retains: chat, skill management, session browsing, and configuration.

Usage:
    hermes-lite chat                Start interactive chat
    hermes-lite skills              List available skills
    hermes-lite skill-view NAME     View a skill
    hermes-lite sessions            List recent sessions
    hermes-lite config              Show current config
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# Ensure core/ is importable
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_PROJECT_ROOT / "core"))

from hermes_constants import get_hermes_home
from hermes_logging import setup_logging


def _ensure_agent():
    """Lazy-initialize AIAgent with config."""
    from run_agent import AIAgent
    from toolsets import get_toolset
    from hermes_lite.config import load_config, resolve_llm_config

    cfg = load_config()
    toolsets = cfg.get("toolsets", ["hermes-lite"])

    llm = resolve_llm_config()

    agent = AIAgent(
        model=llm["model"],
        provider=llm["provider"],
        api_key=llm["api_key"],
        base_url=llm["base_url"],
        enabled_toolsets=toolsets,
        platform="cli",
        quiet_mode=False,
    )
    return agent


def cmd_chat(args: argparse.Namespace) -> int:
    """Interactive REPL."""
    setup_logging(mode="cli")
    agent = _ensure_agent()

    print("Hermes Lite — type /help for commands, /exit to quit.\n")

    while True:
        try:
            user_input = input("hermes> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            return 0

        if not user_input:
            continue

        if user_input in ("/exit", "/quit"):
            print("Goodbye.")
            return 0

        if user_input == "/help":
            print("""
Commands:
  /help          Show this help
  /skills        List available skills
  /skill NAME    View a skill
  /clear         Clear conversation history
  /new           Start a new session
  /exit, /quit   Exit

Anything else is sent to the agent.
""")
            continue

        if user_input == "/skills":
            from agent.skill_commands import get_skill_commands
            cmds = get_skill_commands()
            print("\nAvailable skills:")
            for cmd_key, meta in sorted(cmds.items()):
                print(f"  {cmd_key:<24} {meta.get('description', '')}")
            print()
            continue

        if user_input.startswith("/skill "):
            name = user_input[7:].strip()
            from tools.skills_tool import skill_view
            result = skill_view(name)
            try:
                data = json.loads(result)
                if data.get("success"):
                    print(f"\n--- {data.get('name', name)} ---\n")
                    print(data.get("content", "(no content)"))
                else:
                    print(f"Error: {data.get('error', 'unknown')}")
            except Exception:
                print(result)
            print()
            continue

        if user_input == "/clear":
            # Start fresh by creating a new agent instance
            agent = _ensure_agent()
            print("Conversation cleared.\n")
            continue

        if user_input == "/new":
            agent = _ensure_agent()
            print("New session started.\n")
            continue

        # Normal chat
        try:
            result = agent.chat(user_input)
            print(f"\n{result}\n")
        except Exception as exc:
            print(f"\nError: {exc}\n")

    return 0


def cmd_skills(args: argparse.Namespace) -> int:
    from agent.skill_commands import get_skill_commands
    cmds = get_skill_commands()
    print(json.dumps({
        cmd_key: {"name": meta.get("name"), "description": meta.get("description")}
        for cmd_key, meta in sorted(cmds.items())
    }, indent=2, ensure_ascii=False))
    return 0


def cmd_skill_view(args: argparse.Namespace) -> int:
    from tools.skills_tool import skill_view
    result = skill_view(args.name)
    try:
        data = json.loads(result)
        print(json.dumps(data, indent=2, ensure_ascii=False))
    except Exception:
        print(result)
    return 0


def cmd_sessions(args: argparse.Namespace) -> int:
    from hermes_state import SessionDB
    from hermes_constants import get_hermes_home
    db = SessionDB(get_hermes_home() / "sessions.db")
    rows = db.list_sessions_rich(limit=args.limit)
    for row in rows:
        print(f"{row.get('id', '')[:16]:<18} {row.get('started_at', ''):<22} {row.get('title', 'Untitled')}")
    return 0


def cmd_config(args: argparse.Namespace) -> int:
    from hermes_lite.config import load_config
    cfg = load_config()
    print(json.dumps(cfg, indent=2, ensure_ascii=False))
    return 0


def main(argv: list[str] | None = None) -> int:
    # Use ~/.hermes-lite as home directory so we don't collide with full Hermes
    import os
    os.environ.setdefault("HERMES_HOME", str(Path.home() / ".hermes-lite"))

    parser = argparse.ArgumentParser(prog="hermes-lite", description="Hermes Lite CLI")
    subparsers = parser.add_subparsers(dest="command")

    # chat
    chat_p = subparsers.add_parser("chat", help="Start interactive chat (default)")
    chat_p.set_defaults(func=cmd_chat)

    # skills
    skills_p = subparsers.add_parser("skills", help="List available skills")
    skills_p.set_defaults(func=cmd_skills)

    # skill-view
    sv_p = subparsers.add_parser("skill-view", help="View a skill")
    sv_p.add_argument("name", help="Skill name or path")
    sv_p.set_defaults(func=cmd_skill_view)

    # sessions
    sess_p = subparsers.add_parser("sessions", help="List recent sessions")
    sess_p.add_argument("--limit", type=int, default=20)
    sess_p.set_defaults(func=cmd_sessions)

    # config
    cfg_p = subparsers.add_parser("config", help="Show current configuration")
    cfg_p.set_defaults(func=cmd_config)

    args = parser.parse_args(argv)

    if args.command is None:
        # Default to interactive chat
        return cmd_chat(args)

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
