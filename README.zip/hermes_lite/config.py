"""Minimal configuration loader for Hermes Lite.

Stripped of gateway, cron, kanban, tts, dashboard, and messaging config.
Only retains: model, agent, terminal, web, browser, compression, skills,
approvals, security, and auxiliary.
"""

from __future__ import annotations

import os
import threading
from pathlib import Path
from typing import Any, Dict, Optional

from hermes_constants import get_hermes_home


DEFAULT_CONFIG: Dict[str, Any] = {
    "_config_version": 1,
    # LLM configuration — supports any OpenAI-compatible API endpoint.
    # Priority (high → low): env vars > config.yaml > defaults.
    "model": "",
    "provider": "openai",
    "base_url": "",
    "api_key": "",           # Read from env var first; only use this if env is unset.
    "providers": {},
    "fallback_providers": [],
    # Example configs:
    #   Moonshot (Kimi):  model=kimi-k2.5, base_url=https://api.moonshot.cn/v1
    #   Local Ollama:     model=llama3, base_url=http://localhost:11434/v1
    #   Local vLLM:       model=meta-llama/Meta-Llama-3-8B, base_url=http://localhost:8000/v1
    "toolsets": ["hermes-lite"],
    "agent": {
        "max_iterations": 90,
        "timeout_seconds": 120,
        "retry_attempts": 3,
        "background_review": True,
        "save_trajectories": False,
    },
    "terminal": {
        "backend": "local",
        "cwd": None,
        "dangerous_command_approval": "smart",
    },
    "web": {
        "search_backend": "ddgs",
        "extract_backend": "ddgs",
    },
    "browser": {
        "engine": "chromium",
        "headless": True,
        "timeout_seconds": 30,
    },
    "compression": {
        "enabled": True,
        "threshold_ratio": 0.5,
        "protected_messages": 6,
    },
    "skills": {
        "external_dirs": [],
        "inline_shell": False,
        "disabled": [],
        "platform_disabled": {},
    },
    "evolution": {
        "enabled": False,
        "interval_turns": 10,
        "max_iterations": 2,
        "explore_width": 4,
        "validate_trials": 3,
    },
    "approvals": {
        "mode": "smart",
    },
    "security": {
        "redact_secrets": True,
        "website_blacklist": [],
    },
    "auxiliary": {
        "vision": {"provider": "auto", "model": "auto"},
        "web_extract": {"provider": "auto", "model": "auto"},
        "approval": {"provider": "auto", "model": "auto"},
    },
    "logging": {
        "level": "INFO",
        "max_bytes": 10_000_000,
        "backup_count": 3,
    },
}


_CONFIG_LOCK = threading.RLock()
_config_cache: Optional[tuple] = None


def load_config() -> Dict[str, Any]:
    """Load user config.yaml merged over DEFAULT_CONFIG."""
    global _config_cache

    hermes_home = get_hermes_home()
    config_path = hermes_home / "config.yaml"

    with _CONFIG_LOCK:
        if _config_cache is not None:
            cached_path, cached_mtime, cached_size, cached_cfg = _config_cache
            if (cached_path == str(config_path) and config_path.exists()
                    and config_path.stat().st_mtime_ns == cached_mtime
                    and config_path.stat().st_size == cached_size):
                return cached_cfg

        cfg = _deep_copy(DEFAULT_CONFIG)
        if config_path.exists():
            try:
                import yaml
                with open(config_path, "r", encoding="utf-8") as f:
                    user_cfg = yaml.safe_load(f) or {}
                cfg = _deep_merge(cfg, user_cfg)
            except Exception as exc:
                import logging
                logging.getLogger(__name__).warning("Failed to load config.yaml: %s", exc)

        if config_path.exists():
            st = config_path.stat()
            _config_cache = (str(config_path), st.st_mtime_ns, st.st_size, cfg)
        else:
            _config_cache = (str(config_path), 0, 0, cfg)

        return cfg


def save_config_value(key_path: str, value: Any) -> None:
    """Set a config value by dot-path and persist to config.yaml."""
    hermes_home = get_hermes_home()
    config_path = hermes_home / "config.yaml"

    cfg = load_config()
    parts = key_path.split(".")
    node = cfg
    for part in parts[:-1]:
        if part not in node or not isinstance(node[part], dict):
            node[part] = {}
        node = node[part]
    node[parts[-1]] = value

    try:
        import yaml
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(cfg, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
    except Exception as exc:
        import logging
        logging.getLogger(__name__).warning("Failed to save config.yaml: %s", exc)

    global _config_cache
    _config_cache = None


def resolve_llm_config(
    model: str = "",
    provider: str = "",
    base_url: str = "",
    api_key: str = "",
) -> Dict[str, str]:
    """Resolve LLM config with priority: explicit args > env vars > config.yaml.

    Returns a dict with keys: model, provider, base_url, api_key.
    """
    cfg = load_config()
    cfg_model = cfg.get("model", "")
    cfg_provider = cfg.get("provider", "")
    cfg_base_url = cfg.get("base_url", "")
    cfg_api_key = cfg.get("api_key", "")

    # 1. Explicit arguments (highest priority)
    resolved_model = model or cfg_model
    resolved_provider = provider or cfg_provider
    resolved_base_url = base_url or cfg_base_url
    resolved_api_key = api_key or cfg_api_key

    # 2. Environment variables (override config.yaml if set)
    if not resolved_api_key:
        resolved_api_key = os.getenv("OPENAI_API_KEY", "")
    if not resolved_api_key and (resolved_provider in ("moonshot", "kimi") or "moonshot" in resolved_base_url):
        resolved_api_key = os.getenv("MOONSHOT_API_KEY", "")
    # Generic fallback: {PROVIDER}_API_KEY for any provider
    if not resolved_api_key and resolved_provider:
        env_key = f"{resolved_provider.upper()}_API_KEY"
        resolved_api_key = os.getenv(env_key, "")

    # 3. Auto-fill Moonshot defaults
    if resolved_api_key and not resolved_base_url and (resolved_provider in ("moonshot", "kimi") or "moonshot" in resolved_base_url):
        resolved_base_url = "https://api.moonshot.cn/v1"
    if resolved_api_key and not resolved_provider and resolved_base_url and "moonshot" in resolved_base_url:
        resolved_provider = "openai"

    return {
        "model": resolved_model,
        "provider": resolved_provider,
        "base_url": resolved_base_url,
        "api_key": resolved_api_key,
    }


def _deep_copy(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _deep_copy(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_deep_copy(v) for v in obj]
    return obj


def _deep_merge(base: Dict[str, Any], overlay: Dict[str, Any]) -> Dict[str, Any]:
    result = _deep_copy(base)
    for key, value in overlay.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = _deep_copy(value)
    return result
