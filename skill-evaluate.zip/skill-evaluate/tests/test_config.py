"""config loader / validator 测试。"""
import pytest
import yaml

from skill_evaluate.config import Loader, ValidationError, validate_all
from skill_evaluate.config.schema import merge_judge_config, JudgeConfig


def _write_skill(tmp_path):
    (tmp_path / "SKILL.md").write_text("---\nname: test-skill\n---\n# test\n")
    evals = tmp_path / "evals"
    (evals / "cases").mkdir(parents=True)
    (evals / "eval.yaml").write_text(yaml.safe_dump({
        "schema_version": "v1alpha1",
        "skills": [{"source": "local_path", "path": "."}],
        "engine": {"name": "litellm", "model": {"provider": "openai", "name": "gpt-4o"}},
        "cases": {"files": ["evals/cases/c1.yaml"]},
        "judge": {"type": "rule_based",
                  "success": [{"output_contains": {"all": ["ok"]}}]},
    }))
    (evals / "cases" / "c1.yaml").write_text(yaml.safe_dump({
        "id": "c1",
        "input": {"prompt": "hello"},
        "expect": {"must_contain": ["ok"]},
    }))
    return tmp_path, evals / "eval.yaml"


def test_load_defaults(tmp_path):
    skill_dir, eval_yaml = _write_skill(tmp_path)
    loader = Loader(skill_dir)
    cfg, cases = loader.load_all(eval_yaml)
    assert cfg.schema_version == "v1alpha1"
    assert cfg.cases.defaults.timeout_seconds == 300
    assert cfg.cases.defaults.max_turns == 10
    assert cfg.cases.parallelism == 1
    assert cfg.report.formats == ["json"]
    assert len(cases) == 1
    assert cases[0].id == "c1"
    validate_all(cfg, cases)


def test_case_id_defaults_to_filename(tmp_path):
    skill_dir, _ = _write_skill(tmp_path)
    case_file = tmp_path / "evals" / "cases" / "no-id.yaml"
    case_file.write_text(yaml.safe_dump({"input": {"prompt": "p"}}))
    case = Loader(skill_dir).load_case(case_file)
    assert case.id == "no-id"


def test_validate_rejects_bad_judge_type(tmp_path):
    skill_dir, eval_yaml = _write_skill(tmp_path)
    loader = Loader(skill_dir)
    cfg, cases = loader.load_all(eval_yaml)
    cfg.judge.type = "nonsense"
    with pytest.raises(ValidationError):
        validate_all(cfg, cases)


def test_validate_rejects_rule_with_two_fields(tmp_path):
    skill_dir, eval_yaml = _write_skill(tmp_path)
    loader = Loader(skill_dir)
    cfg, cases = loader.load_all(eval_yaml)
    cfg.judge.success[0].exit_code = 0  # 同时设置了 output_contains 和 exit_code
    with pytest.raises(ValidationError):
        validate_all(cfg, cases)


def test_merge_judge_config_case_overrides():
    g = JudgeConfig(type="agent_judge", model="openai/gpt-4o", pass_threshold=0.8)
    c = JudgeConfig(type="rule_based",
                    success=[])
    merged = merge_judge_config(g, c)
    assert merged.type == "rule_based"
    assert merged.model == "openai/gpt-4o"       # 全局回填
    assert merged.pass_threshold == 0.8


def test_merge_judge_config_case_empty_uses_global():
    g = JudgeConfig(type="script", script_path="s.sh")
    merged = merge_judge_config(g, JudgeConfig())
    assert merged.type == "script"
    assert merged.script_path == "s.sh"
