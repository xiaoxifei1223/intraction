"""端到端流水线测试：mock litellm.completion，验证 run 全链路与报告产物。"""
import json
from types import SimpleNamespace
from unittest.mock import patch

import pytest
import yaml

from skill_evaluate.cli import main


def _fake_response(content, in_tok=10, out_tok=20):
    return SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content=content))],
        usage=SimpleNamespace(prompt_tokens=in_tok, completion_tokens=out_tok),
    )


def _make_skill(tmp_path):
    skill = tmp_path / "demo-skill"
    (skill / "evals" / "cases").mkdir(parents=True)
    (skill / "SKILL.md").write_text(
        "---\nname: demo-skill\n---\n# Demo\nAlways reply with the Code Statistics format.\n")
    (skill / "evals" / "eval.yaml").write_text(yaml.safe_dump({
        "schema_version": "v1alpha1",
        "skills": [{"source": "local_path", "path": "."}],
        "engine": {"name": "litellm",
                   "model": {"provider": "openai", "name": "gpt-4o-mini"}},
        "cases": {"files": ["evals/cases/pass-case.yaml", "evals/cases/fail-case.yaml"],
                  "defaults": {"timeout_seconds": 60}},
        "benchmark": {"enabled": True},
        "report": {"formats": ["json", "junit", "html"]},
    }))
    (skill / "evals" / "cases" / "pass-case.yaml").write_text(yaml.safe_dump({
        "id": "pass-case",
        "input": {"prompt": "report stats"},
        "expect": {"must_contain": ["Total Files"]},
        "judge": {"type": "rule_based",
                  "success": [{"output_contains": {"all": ["Total Files", "Total Lines"]}}]},
    }))
    (skill / "evals" / "cases" / "fail-case.yaml").write_text(yaml.safe_dump({
        "id": "fail-case",
        "input": {"prompt": "report stats"},
        "expect": {"must_contain": ["NONEXISTENT"]},
        "judge": {"type": "rule_based",
                  "success": [{"output_contains": {"all": ["Total Files"]}}]},
    }))
    return skill


@pytest.fixture
def mock_litellm():
    with patch("litellm.completion") as m:
        m.side_effect = lambda **kw: _fake_response(
            "# Code Statistics\n- Total Files: 3\n- Total Lines: 140\n"
            "## Files by Extension\n| .py | 3 | 140 |")
        yield m


def test_full_run_pipeline(tmp_path, mock_litellm):
    skill = _make_skill(tmp_path)
    out_dir = tmp_path / "out"
    rc = main([
        "run", str(skill / "evals" / "eval.yaml"),
        "--api-key", "sk-test",
        "--output-dir", str(out_dir),
        "--iteration", "1",
    ])
    # fail-case expect 短路 → FAIL → 退出码 1
    assert rc == 1

    it = out_dir / "iteration-1"
    # 报告产物齐全
    for f in ("result.json", "benchmark.json", "benchmark.md",
              "report.json", "report.xml", "report.html"):
        assert (it / f).is_file(), f"缺少 {f}"
    # case 产物
    assert (it / "pass-case" / "with_skill" / "outputs" / "response.md").is_file()
    assert (it / "pass-case" / "with_skill" / "grading.json").is_file()
    assert (it / "pass-case" / "eval_metadata.json").is_file()
    # benchmark 开启 → without_skill 基线
    assert (it / "pass-case" / "without_skill" / "grading.json").is_file()

    result = json.loads((it / "result.json").read_text(encoding="utf-8"))
    statuses = {(c["case_id"], c["configuration"]): c["status"]
                for c in result["case_results"]}
    assert statuses[("pass-case", "with_skill")] == "PASS"
    assert statuses[("fail-case", "with_skill")] == "FAIL"
    assert result["total_tokens"] > 0

    bench = json.loads((it / "benchmark.json").read_text(encoding="utf-8"))
    assert "with_skill" in bench["run_summary"]
    assert "without_skill" in bench["run_summary"]
    assert "delta" in bench["run_summary"]

    # expect 短路：fail-case 的 grading 只有 expect 断言
    fail_grading = json.loads(
        (it / "fail-case" / "with_skill" / "grading.json").read_text(encoding="utf-8"))
    assert fail_grading["expectations"][0]["text"].startswith("expect.must_contain")

    # skill 注入验证：with_skill 的请求带 system 消息，without_skill 不带
    calls = mock_litellm.call_args_list
    with_skill_calls = [c for c in calls
                        if any(m["role"] == "system" for m in c.kwargs["messages"])]
    without_skill_calls = [c for c in calls
                           if not any(m["role"] == "system" for m in c.kwargs["messages"])]
    assert len(with_skill_calls) == 2   # 两个 case 的 with_skill
    assert len(without_skill_calls) == 2


def test_validate_and_list_cases(tmp_path):
    skill = _make_skill(tmp_path)
    assert main(["validate", str(skill / "evals" / "eval.yaml")]) == 0
    assert main(["list-cases", str(skill / "evals" / "eval.yaml")]) == 0


def test_report_command(tmp_path, mock_litellm):
    skill = _make_skill(tmp_path)
    out_dir = tmp_path / "out"
    main(["run", str(skill / "evals" / "eval.yaml"), "--api-key", "sk-test",
          "--output-dir", str(out_dir), "--iteration", "1"])
    result_json = out_dir / "iteration-1" / "result.json"
    regen = tmp_path / "regen"
    rc = main(["report", str(result_json), "--format", "html", "--format", "junit",
               "--output-dir", str(regen)])
    assert rc == 0
    assert (regen / "report.html").is_file()
    assert (regen / "report.xml").is_file()


def test_agent_judge_via_litellm(tmp_path):
    """agent_judge 走 litellm 的 verdict 解析与阈值判定。"""
    skill = tmp_path / "judge-skill"
    (skill / "evals" / "cases").mkdir(parents=True)
    (skill / "SKILL.md").write_text("---\nname: judge-skill\n---\n")
    (skill / "evals" / "eval.yaml").write_text(yaml.safe_dump({
        "schema_version": "v1alpha1",
        "skills": [{"source": "local_path", "path": "."}],
        "engine": {"name": "litellm", "model": {"provider": "openai", "name": "m"}},
        "cases": {"files": ["evals/cases/c.yaml"]},
    }))
    (skill / "evals" / "cases" / "c.yaml").write_text(yaml.safe_dump({
        "id": "c",
        "input": {"prompt": "do it"},
        "judge": {"type": "agent_judge",
                  "criteria": ["mentions cats", "mentions dogs"],
                  "pass_threshold": 0.5},
    }))

    verdict = json.dumps({"results": [
        {"criterion": "mentions cats", "passed": True, "evidence": "said cats"},
        {"criterion": "mentions dogs", "passed": False, "evidence": "no dogs"},
    ]})
    responses = iter([
        _fake_response("I like cats."),          # runner 输出
        _fake_response(f"```json\n{verdict}\n```"),  # judge verdict
    ])
    with patch("litellm.completion", side_effect=lambda **kw: next(responses)):
        rc = main(["run", str(skill / "evals" / "eval.yaml"),
                   "--api-key", "sk-test",
                   "--output-dir", str(tmp_path / "out"), "--iteration", "1"])
    # pass_rate=0.5 >= 0.5 → PASS → 退出码 0
    assert rc == 0
    grading = json.loads(
        (tmp_path / "out" / "iteration-1" / "c" / "with_skill" / "grading.json")
        .read_text(encoding="utf-8"))
    assert grading["summary"]["pass_rate"] == 0.5
