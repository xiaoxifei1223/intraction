"""rule_based / agent_judge 解析 / new_result 语义测试。"""
import pytest

from skill_evaluate.config.schema import Rule
from skill_evaluate.judges import JudgeInput, Status, new_result
from skill_evaluate.judges.agent_judge import extract_json
from skill_evaluate.judges.base import AssertionResult
from skill_evaluate.judges.rule_based import RuleBasedJudge, _args_partial_match
from skill_evaluate.transcript import Message, Transcript


# -- new_result 语义 ----------------------------------------------------------

def test_new_result_vacuous_pass():
    r = new_result([])
    assert r.status == Status.PASS
    assert r.summary.pass_rate == 1.0


def test_new_result_any_fail():
    r = new_result([AssertionResult("a", True), AssertionResult("b", False)])
    assert r.status == Status.FAIL
    assert r.summary.pass_rate == 0.5


# -- rule_based ----------------------------------------------------------------

def _ji(tmp_path, final="output text", exit_code=0, transcript=None):
    return JudgeInput(final_message=final, exit_code=exit_code,
                      workspace_path=tmp_path, transcript=transcript)


def test_failure_rule_short_circuits(tmp_path):
    judge = RuleBasedJudge(
        success=[Rule(output_contains={"all": ["output"]})],
        failure=[Rule(output_contains={"not": ["output"]})],  # 命中 → FAIL
    )
    r = judge.evaluate(_ji(tmp_path))
    assert r.status == Status.FAIL
    # failure 短路：只评了 1 条
    assert len(r.assertion_results) == 1


def test_success_rules_all_must_pass(tmp_path):
    judge = RuleBasedJudge(success=[
        Rule(output_contains={"all": ["output", "text"]}),
        Rule(exit_code=0),
    ], failure=[])
    assert judge.evaluate(_ji(tmp_path)).status == Status.PASS
    judge2 = RuleBasedJudge(success=[
        Rule(output_contains={"all": ["output", "nope"]}),
    ], failure=[])
    assert judge2.evaluate(_ji(tmp_path)).status == Status.FAIL


def test_no_rules_default_pass(tmp_path):
    assert RuleBasedJudge([], []).evaluate(_ji(tmp_path)).status == Status.PASS


def test_tool_called_partial_args(tmp_path):
    tr = Transcript([Message(role="tool_call", name="read_file",
                             args={"path": "a.txt", "encoding": "utf-8"}, turn=1)])
    judge = RuleBasedJudge(success=[
        Rule(tool_called={"name": "read_file", "args": {"path": "a.txt"}}),
    ], failure=[])
    assert judge.evaluate(_ji(tmp_path, transcript=tr)).status == Status.PASS
    judge2 = RuleBasedJudge(success=[
        Rule(tool_called={"name": "write_file"}),
    ], failure=[])
    assert judge2.evaluate(_ji(tmp_path, transcript=tr)).status == Status.FAIL


def test_args_partial_match():
    assert _args_partial_match({"a": 1}, {"a": 1, "b": 2})
    assert not _args_partial_match({"a": 1}, {"a": 2})
    assert not _args_partial_match({"a": 1}, {})


def test_turn_response_contains(tmp_path):
    tr = Transcript([
        Message(role="user", content="q", turn=1),
        Message(role="assistant", content="first answer", turn=1),
        Message(role="assistant", content="second answer", turn=2),
    ])
    judge = RuleBasedJudge(success=[
        Rule(turn_response_contains={"turn": 2, "contains_all": ["second"]}),
    ], failure=[])
    assert judge.evaluate(_ji(tmp_path, transcript=tr)).status == Status.PASS
    judge2 = RuleBasedJudge(success=[
        Rule(turn_response_contains={"turn": 5, "contains_all": ["x"]}),
    ], failure=[])
    r = judge2.evaluate(_ji(tmp_path, transcript=tr))
    assert r.status == Status.FAIL
    assert "未完成" in r.assertion_results[0].evidence


# -- agent_judge JSON 提取（无网络） ---------------------------------------------

def test_extract_json_plain():
    assert extract_json('{"results": []}') == {"results": []}


def test_extract_json_fenced():
    text = 'Here is my verdict:\n```json\n{"results": [{"passed": true}]}\n```\nDone.'
    assert extract_json(text) == {"results": [{"passed": True}]}


def test_extract_json_embedded():
    text = 'Some preamble {"results": [{"criterion": "a", "passed": false, "evidence": "e"}]} trailing'
    data = extract_json(text)
    assert data["results"][0]["passed"] is False


def test_extract_json_invalid():
    with pytest.raises(ValueError):
        extract_json("no json at all")
