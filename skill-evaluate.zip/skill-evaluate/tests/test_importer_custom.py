"""importer 与 custom engine 测试。"""
import json

import pytest
import yaml

from skill_evaluate.importer import import_evals_json
from skill_evaluate.engines.custom import TemplateError, render_template


def test_import_evals_json(tmp_path):
    src = tmp_path / "evals.json"
    src.write_text(json.dumps({
        "skill_name": "demo",
        "evals": [
            {"id": 1, "prompt": "Do the thing", "expected_output": "x",
             "files": [], "expectations": ["has thing", "no error"]},
            {"id": 2, "prompt": "Do another thing", "expected_output": "y",
             "files": [], "expectations": []},
        ],
    }))
    out = tmp_path / "out"
    eval_yaml = import_evals_json(src, out)
    doc = yaml.safe_load(eval_yaml.read_text())
    assert doc["schema_version"] == "v1alpha1"
    assert len(doc["cases"]["files"]) == 2
    case1 = yaml.safe_load((out / doc["cases"]["files"][0]).read_text())
    assert case1["judge"]["type"] == "agent_judge"
    assert case1["judge"]["criteria"] == ["has thing", "no error"]
    case2 = yaml.safe_load((out / doc["cases"]["files"][1]).read_text())
    assert "judge" not in case2


def test_render_template_basic():
    assert render_template("echo ${name}", {"name": "world"}) == "echo world"


def test_render_template_default():
    assert render_template("${missing:-fallback}", {}) == "fallback"


def test_render_template_required():
    with pytest.raises(TemplateError):
        render_template("${missing?must be set}", {})


def test_render_template_env(monkeypatch):
    monkeypatch.setenv("SKILL_EVAL_TEST_VAR", "fromenv")
    assert render_template("${SKILL_EVAL_TEST_VAR}", {}) == "fromenv"
