"""expect 短路检查测试。"""
from skill_evaluate.config.schema import Expect
from skill_evaluate.judges import JudgeInput, check_expect


def _input(tmp_path, final="hello world", exit_code=0):
    return JudgeInput(final_message=final, exit_code=exit_code,
                      workspace_path=tmp_path, skill_dir=tmp_path)


def test_must_contain(tmp_path):
    e = Expect(must_contain=["hello", "missing"])
    r = check_expect(e, _input(tmp_path))
    assert not r.all_passed
    assert r.checks[0].passed
    assert not r.checks[1].passed


def test_must_not_contain(tmp_path):
    e = Expect(must_not_contain=["world"])
    r = check_expect(e, _input(tmp_path))
    assert not r.all_passed


def test_exit_code(tmp_path):
    assert check_expect(Expect(exit_code=0), _input(tmp_path)).all_passed
    assert not check_expect(Expect(exit_code=1), _input(tmp_path)).all_passed


def test_files_exist(tmp_path):
    (tmp_path / "a.txt").write_text("x")
    e = Expect(files_exist=["a.txt"], files_not_exist=["b.txt"])
    assert check_expect(e, _input(tmp_path)).all_passed
    e2 = Expect(files_exist=["b.txt"])
    assert not check_expect(e2, _input(tmp_path)).all_passed


def test_file_contains(tmp_path):
    (tmp_path / "out.md").write_text("# Report\nTotal Files: 3")
    e = Expect(file_contains=[{"path": "out.md", "content": "Total Files"}])
    assert check_expect(e, _input(tmp_path)).all_passed


def test_path_escape_blocked(tmp_path):
    e = Expect(files_exist=["../../etc/passwd"])
    r = check_expect(e, _input(tmp_path))
    assert not r.all_passed
    assert "逃逸" in r.checks[0].evidence


def test_golden_file(tmp_path):
    (tmp_path / "expected.md").write_text("  golden content  \n")
    (tmp_path / "actual.md").write_text("golden content")
    e = Expect(golden_file="expected.md")
    ji = JudgeInput(final_message="", exit_code=0,
                    workspace_path=tmp_path, skill_dir=tmp_path)
    # workspace 中同名 expected.md 即 golden 自身 → 一致
    assert check_expect(e, ji).all_passed


def test_empty_expect_passes(tmp_path):
    assert check_expect(Expect(), _input(tmp_path)).all_passed
