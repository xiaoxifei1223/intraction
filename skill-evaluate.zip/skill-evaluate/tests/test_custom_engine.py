"""custom local engine 端到端测试（真实子进程，无需网络）。"""
import json
import sys

import yaml

from skill_evaluate.cli import main


def test_custom_local_engine(tmp_path):
    # 自定义 agent 脚本：读 input_file，写 session_result JSON 到 output_file
    agent_script = tmp_path / "fake_agent.py"
    agent_script.write_text(
        "import json, sys\n"
        "inp = json.load(open(sys.argv[1]))\n"
        "prompt = inp['messages'][-1]['content']\n"
        "out = {\n"
        "  'exit_code': 0,\n"
        "  'final_message': 'Total Files: 3\\nTotal Lines: 42 for ' + prompt[:20],\n"
        "  'turns': 1,\n"
        "}\n"
        "open(sys.argv[2], 'w').write(json.dumps(out))\n"
    )

    skill = tmp_path / "custom-skill"
    (skill / "evals" / "cases").mkdir(parents=True)
    (skill / "SKILL.md").write_text("---\nname: custom-skill\n---\n")
    (skill / "evals" / "eval.yaml").write_text(yaml.safe_dump({
        "schema_version": "v1alpha1",
        "skills": [{"source": "local_path", "path": "."}],
        "engine": {
            "name": "my-agent",
            "custom": {
                "transport": "local",
                "response_format": "session_result",
                "local": {
                    "command": sys.executable,
                    "args": [str(agent_script), "${input_file}", "${output_file}"],
                },
            },
        },
        "cases": {"files": ["evals/cases/c.yaml"]},
        "report": {"formats": ["json"]},
    }))
    (skill / "evals" / "cases" / "c.yaml").write_text(yaml.safe_dump({
        "id": "c",
        "input": {"prompt": "count the files"},
        "judge": {"type": "rule_based",
                  "success": [{"output_contains": {"all": ["Total Files", "Total Lines"]}}]},
    }))

    rc = main(["run", str(skill / "evals" / "eval.yaml"),
               "--output-dir", str(tmp_path / "out"), "--iteration", "1"])
    assert rc == 0
    grading = json.loads(
        (tmp_path / "out" / "iteration-1" / "c" / "with_skill" / "grading.json")
        .read_text())
    assert grading["summary"]["pass_rate"] == 1.0
