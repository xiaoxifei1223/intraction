"""HTML 报告：单页应用，数据内嵌（对齐 Go 版 internal/report/html.go 的思路）。"""
from __future__ import annotations

import html
import json

_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<title>skill-evaluate report - {title}</title>
<style>
  body {{ font-family: -apple-system, "Segoe UI", Roboto, sans-serif; margin: 2rem; color: #222; }}
  h1 {{ font-size: 1.5rem; }}
  .meta {{ color: #666; margin-bottom: 1.5rem; }}
  table {{ border-collapse: collapse; width: 100%; margin-bottom: 1.5rem; }}
  th, td {{ border: 1px solid #ddd; padding: 6px 10px; text-align: left; font-size: 0.9rem; }}
  th {{ background: #f5f5f5; }}
  .PASS {{ color: #138a36; font-weight: 600; }}
  .FAIL {{ color: #c62828; font-weight: 600; }}
  .ERROR {{ color: #e65100; font-weight: 600; }}
  .SKIP {{ color: #777; font-weight: 600; }}
  details {{ margin: 4px 0; }}
  summary {{ cursor: pointer; }}
  .evidence {{ white-space: pre-wrap; color: #555; font-size: 0.85rem; }}
  .bar {{ height: 10px; background: #eee; border-radius: 5px; overflow: hidden; width: 200px; }}
  .bar > div {{ height: 100%; background: #4caf50; }}
</style>
</head>
<body>
<h1>skill-evaluate report: {title}</h1>
<div class="meta">
  engine: {engine} &nbsp;|&nbsp; model: {model} &nbsp;|&nbsp;
  {start} → {end} &nbsp;|&nbsp; total tokens: {tokens}
</div>
{summary_html}
{benchmark_html}
<script id="report-data" type="application/json">{data_json}</script>
</body>
</html>
"""


def build_html(report_input: dict) -> str:
    case_results = report_input.get("case_results", [])
    rows: list[str] = []
    for c in case_results:
        status = c.get("status", "")
        grading = c.get("grading") or {}
        summary = grading.get("summary") or {}
        pass_rate = summary.get("pass_rate", 0.0)
        assertions = grading.get("assertion_results", [])
        detail_lines = []
        for a in assertions:
            mark = "✅" if a.get("passed") else "❌"
            detail_lines.append(
                f"<div>{mark} {html.escape(str(a.get('text', '')))}"
                f"<div class='evidence'>{html.escape(str(a.get('evidence', '')))}</div></div>")
        if c.get("error"):
            detail_lines.append(f"<div class='evidence'>ERROR: {html.escape(str(c['error']))}</div>")
        detail = (f"<details><summary>grading ({summary.get('passed', 0)}/"
                  f"{summary.get('total', 0)})</summary>{''.join(detail_lines)}</details>")
        rows.append(
            f"<tr><td>{html.escape(c.get('case_id', ''))}</td>"
            f"<td>{html.escape(c.get('configuration', ''))}</td>"
            f"<td class='{status}'>{status}</td>"
            f"<td><div class='bar'><div style='width:{pass_rate * 100:.0f}%'></div></div>"
            f" {pass_rate:.0%}</td>"
            f"<td>{c.get('duration_ms', 0) / 1000.0:.1f}s</td>"
            f"<td>{detail}</td></tr>")

    summary_html = (
        "<h2>Cases</h2><table><tr><th>Case</th><th>Configuration</th><th>Status</th>"
        "<th>Pass Rate</th><th>Duration</th><th>Details</th></tr>"
        + "".join(rows) + "</table>")

    benchmark_html = ""
    bench = report_input.get("benchmark")
    if bench:
        rs = bench.get("run_summary", {})
        benchmark_html = (
            "<h2>Benchmark</h2><table><tr><th>Configuration</th><th>Mean</th>"
            "<th>Stddev</th><th>Min</th><th>Max</th></tr>"
            + "".join(
                f"<tr><td>{conf}</td><td>{s['mean']:.2%}</td><td>{s['stddev']:.4f}</td>"
                f"<td>{s['min']:.2%}</td><td>{s['max']:.2%}</td></tr>"
                for conf, s in rs.items() if isinstance(s, dict))
            + f"</table><p>delta: {html.escape(str(rs.get('delta', '')))}</p>")

    return _HTML_TEMPLATE.format(
        title=html.escape(report_input.get("skill_name", "")),
        engine=html.escape(report_input.get("engine_name", "")),
        model=html.escape(report_input.get("model_name", "")),
        start=html.escape(report_input.get("start_time", "")),
        end=html.escape(report_input.get("end_time", "")),
        tokens=report_input.get("total_tokens", 0),
        summary_html=summary_html,
        benchmark_html=benchmark_html,
        data_json=html.escape(json.dumps(report_input, ensure_ascii=False)),
    )
