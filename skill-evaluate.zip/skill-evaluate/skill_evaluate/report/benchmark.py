"""Anthropic 兼容 benchmark.json / benchmark.md（对齐 Go 版 internal/report/benchmark*.go）。"""
from __future__ import annotations

import statistics
from datetime import datetime, timezone
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..evaluator import EvalResult


def _stat(values: list[float]) -> dict:
    if not values:
        return {"mean": 0.0, "stddev": 0.0, "min": 0.0, "max": 0.0}
    return {
        "mean": round(statistics.fmean(values), 4),
        "stddev": round(statistics.stdev(values), 4) if len(values) > 1 else 0.0,
        "min": round(min(values), 4),
        "max": round(max(values), 4),
    }


def compute_benchmark(
    results_by_case: dict[str, dict[str, list["EvalResult"]]],
    skill_name: str,
    skill_path: str,
    run_number: int = 1,
) -> dict:
    """results_by_case: case_id -> configuration -> [EvalResult]"""
    runs: list[dict] = []
    for case_id, by_variant in results_by_case.items():
        for configuration, case_results in by_variant.items():
            for r in case_results:
                grading = r.grading
                summary = grading.summary if grading else None
                runs.append({
                    "eval_id": case_id,
                    "eval_name": r.case_name,
                    "configuration": configuration,
                    "run_number": run_number,
                    "result": {
                        "pass_rate": summary.pass_rate if summary else 0.0,
                        "passed": summary.passed if summary else 0,
                        "failed": summary.failed if summary else 0,
                        "total": summary.total if summary else 0,
                        "time_seconds": round(r.duration_ms / 1000.0, 3),
                        "tokens": ((r.session.input_tokens + r.session.output_tokens)
                                   if r.session else 0),
                        "errors": r.error or "",
                    },
                    "expectations": [
                        {"text": a.text, "passed": a.passed, "evidence": a.evidence}
                        for a in (grading.assertion_results if grading else [])
                    ],
                })

    with_rates = [r["result"]["pass_rate"] for r in runs
                  if r["configuration"] == "with_skill"]
    without_rates = [r["result"]["pass_rate"] for r in runs
                     if r["configuration"] == "without_skill"]
    run_summary: dict = {"with_skill": _stat(with_rates)}
    if without_rates:
        run_summary["without_skill"] = _stat(without_rates)
        delta = (run_summary["with_skill"]["mean"]
                 - run_summary["without_skill"]["mean"])
        run_summary["delta"] = f"{delta:+.2f}"

    return {
        "metadata": {
            "skill_name": skill_name,
            "skill_path": skill_path,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "evals_run": sorted(results_by_case.keys()),
            "runs_per_configuration": run_number,
        },
        "runs": runs,
        "run_summary": run_summary,
    }


def write_benchmark_markdown(benchmark: dict) -> str:
    """WriteBenchmarkMarkdown: Summary 表 + Per-Case Results。"""
    lines: list[str] = ["# Skill Benchmark", ""]
    meta = benchmark.get("metadata", {})
    lines.append(f"- Skill: **{meta.get('skill_name', '')}**")
    lines.append(f"- Timestamp: {meta.get('timestamp', '')}")
    lines.append("")

    # Summary 表
    rs = benchmark.get("run_summary", {})
    has_baseline = "without_skill" in rs
    lines.append("## Summary")
    lines.append("")
    header = "| Configuration | Pass Rate (mean) | Stddev | Min | Max |"
    if has_baseline:
        header += " Delta |"
    lines.append(header)
    lines.append("|" + "---|" * (6 if has_baseline else 5))
    for conf in ("with_skill", "without_skill"):
        if conf not in rs:
            continue
        s = rs[conf]
        row = (f"| {conf} | {s['mean']:.2%} | {s['stddev']:.4f} "
               f"| {s['min']:.2%} | {s['max']:.2%} |")
        if has_baseline:
            row += f" {rs.get('delta', '') if conf == 'with_skill' else ''} |"
        lines.append(row)
    lines.append("")

    # Per-Case Results
    lines.append("## Per-Case Results")
    lines.append("")
    for run in benchmark.get("runs", []):
        lines.append(f"### {run['eval_id']} ({run['configuration']}, run {run['run_number']})")
        lines.append("")
        r = run["result"]
        lines.append(f"- Pass Rate: {r['pass_rate']:.2%} "
                     f"({r['passed']}/{r['total']}), "
                     f"Time: {r['time_seconds']}s, Tokens: {r['tokens']}")
        if r.get("errors"):
            lines.append(f"- Errors: {r['errors']}")
        lines.append("")
        if run.get("expectations"):
            lines.append("| Expectation | Result | Evidence |")
            lines.append("|---|---|---|")
            for e in run["expectations"]:
                mark = "✅" if e["passed"] else "❌"
                text = str(e["text"]).replace("|", "\\|")
                evidence = str(e["evidence"]).replace("|", "\\|").replace("\n", " ")
                lines.append(f"| {text} | {mark} | {evidence} |")
            lines.append("")
    return "\n".join(lines)
