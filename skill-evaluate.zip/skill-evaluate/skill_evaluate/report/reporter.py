"""Reporter：统一写盘入口（对齐 Go 版 internal/report/reporter.go + runner.WriteResults）。

产物目录布局：
  <skill>-workspace/iteration-<N>/
    benchmark.json  benchmark.md  result.json  [report.xml|report.html]
    <case-id>/
      eval_metadata.json
      with_skill/  outputs/response.md  grading.json
      without_skill/ (仅 benchmark.enabled) 同结构
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from .benchmark import compute_benchmark, write_benchmark_markdown
from .grading import to_anthropic_grading
from .html import build_html
from .junit import build_junit_xml

if TYPE_CHECKING:
    from ..evaluator import EvalResult


def build_report_input(
    results: list["EvalResult"],
    skill_name: str,
    engine_name: str,
    model_name: str,
    start_time: datetime,
    end_time: datetime,
    benchmark: dict | None = None,
) -> dict:
    case_results = []
    total_tokens = 0
    for r in results:
        session = r.session
        in_tok = session.input_tokens if session else 0
        out_tok = session.output_tokens if session else 0
        total_tokens += in_tok + out_tok
        case_results.append({
            "case_id": r.case_id,
            "title": r.case_name,
            "status": r.status.value,
            "duration_ms": r.duration_ms,
            "turns": session.turns if session else 0,
            "turns_total": r.turns_total,
            "input_tokens": in_tok,
            "output_tokens": out_tok,
            "error": r.error,
            "grading": r.grading.to_dict() if r.grading else None,
            "configuration": r.configuration,
            "prompt": r.prompt,
            "response": r.final_message,
            "turn_results": [t.to_dict() for t in r.turn_results],
        })
    return {
        "skill_name": skill_name,
        "schema_version": "v1alpha1",
        "engine_name": engine_name,
        "model_name": model_name,
        "start_time": start_time.isoformat(),
        "end_time": end_time.isoformat(),
        "case_results": case_results,
        "total_tokens": total_tokens,
        "benchmark": benchmark,
    }


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")


def group_results_by_case(
    results: list["EvalResult"],
) -> dict[str, dict[str, list["EvalResult"]]]:
    grouped: dict[str, dict[str, list["EvalResult"]]] = {}
    for r in results:
        grouped.setdefault(r.case_id, {}).setdefault(r.configuration, []).append(r)
    return grouped


def write_results(
    results: list["EvalResult"],
    output_dir: Path,
    skill_name: str,
    skill_path: str,
    engine_name: str,
    model_name: str,
    start_time: datetime,
    end_time: datetime,
    formats: list[str],
    run_number: int = 1,
) -> dict:
    """写全部产物，返回 report_input（即 result.json 的内容）。"""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    grouped = group_results_by_case(results)

    # 1. 每 case 产物
    for case_id, by_variant in grouped.items():
        case_dir = output_dir / case_id
        for variant, case_results in by_variant.items():
            for r in case_results:
                variant_dir = case_dir / variant
                (variant_dir / "outputs").mkdir(parents=True, exist_ok=True)
                (variant_dir / "outputs" / "response.md").write_text(
                    r.final_message, encoding="utf-8")
                _write_json(variant_dir / "grading.json",
                            to_anthropic_grading(r.grading))
        # eval_metadata.json
        first = next(iter(by_variant.values()))[0]
        assertions = []
        if first.grading:
            assertions = [a.text for a in first.grading.assertion_results]
        _write_json(case_dir / "eval_metadata.json", {
            "eval_id": case_id,
            "eval_name": first.case_name,
            "prompt": first.prompt,
            "assertions": assertions,
        })

    # 2. benchmark
    benchmark = compute_benchmark(grouped, skill_name, skill_path, run_number)
    _write_json(output_dir / "benchmark.json", benchmark)
    (output_dir / "benchmark.md").write_text(
        write_benchmark_markdown(benchmark), encoding="utf-8")

    # 3. result.json（始终写）
    report_input = build_report_input(
        results, skill_name, engine_name, model_name, start_time, end_time,
        benchmark={
            "run_summary": benchmark.get("run_summary", {}),
        },
    )
    _write_json(output_dir / "result.json", report_input)

    # 4. 格式化报告
    for fmt in formats:
        fmt = fmt.strip().lower()
        if fmt == "json":
            _write_json(output_dir / "report.json", report_input)
        elif fmt == "junit":
            (output_dir / "report.xml").write_text(
                build_junit_xml(report_input), encoding="utf-8")
        elif fmt == "html":
            (output_dir / "report.html").write_text(
                build_html(report_input), encoding="utf-8")
    return report_input
