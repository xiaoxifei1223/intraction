"""JUnit XML 报告（对齐 Go 版 internal/report/junit.go）。"""
from __future__ import annotations

import xml.etree.ElementTree as ET
from xml.dom import minidom

from ..judges.base import Status


def build_junit_xml(report_input: dict) -> str:
    case_results = report_input.get("case_results", [])
    skill_name = report_input.get("skill_name", "skill-evaluate")

    tests = len(case_results)
    failures = sum(1 for c in case_results if c.get("status") == Status.FAIL.value)
    errors = sum(1 for c in case_results if c.get("status") == Status.ERROR.value)
    skipped = sum(1 for c in case_results if c.get("status") == Status.SKIP.value)
    total_time = sum(c.get("duration_ms", 0) for c in case_results) / 1000.0

    testsuites = ET.Element("testsuites")
    suite = ET.SubElement(testsuites, "testsuite", {
        "name": skill_name,
        "tests": str(tests),
        "failures": str(failures),
        "errors": str(errors),
        "skipped": str(skipped),
        "time": f"{total_time:.3f}",
        "timestamp": report_input.get("start_time", ""),
    })

    for c in case_results:
        tc = ET.SubElement(suite, "testcase", {
            "name": c.get("case_id", ""),
            "classname": skill_name,
            "time": f"{c.get('duration_ms', 0) / 1000.0:.3f}",
        })
        status = c.get("status", "")
        grading = c.get("grading") or {}
        if status == Status.FAIL.value:
            failure = ET.SubElement(tc, "failure", {"type": "AssertionFailure"})
            failed_assertions = [
                a for a in grading.get("assertion_results", [])
                if not a.get("passed")
            ]
            failure.text = "\n".join(
                f"✗ {a.get('text')}: {a.get('evidence')}" for a in failed_assertions
            ) or "case failed"
        elif status == Status.ERROR.value:
            err = ET.SubElement(tc, "error")
            err.text = c.get("error") or grading.get("error_reason") or "unknown error"
        elif status == Status.SKIP.value:
            ET.SubElement(tc, "skipped")

    rough = ET.tostring(testsuites, encoding="unicode")
    return minidom.parseString(rough).toprettyxml(indent="  ")
