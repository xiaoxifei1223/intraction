"""Anthropic 兼容 grading.json（对齐 Go 版 internal/report/grading.go）。"""
from __future__ import annotations

from ..judges.base import Result


def to_anthropic_grading(result: Result | None) -> dict:
    """ConvertToAnthropicGrading: {expectations, summary}"""
    if result is None:
        return {
            "expectations": [],
            "summary": {"passed": 0, "failed": 0, "total": 0, "pass_rate": 0.0},
        }
    return {
        "expectations": [
            {"text": a.text, "passed": a.passed, "evidence": a.evidence}
            for a in result.assertion_results
        ],
        "summary": result.summary.to_dict(),
    }
