"""自定义引擎（对齐 Go 版 internal/agent/custom*.go，local/http 两种 transport）。

协议：
  输入 SessionInput: {case_id, variant, workspace, model, kwargs,
                      messages: [{role, content}], max_turns, timeout_seconds}
  输出 response_format=session_result: JSON {exit_code 必填, final_message,
       transcript, ...}；text 模式直接把 stdout/body 当 final_message。
模板变量: ${workspace} ${prompt} ${input_file} ${output_file} ${model}
          ${model_provider} ${model_name} ${api_key} ${case_id} ${variant}
          ${max_turns} ${timeout_seconds} ${session_input} ${messages}
          ${kwargs.<key>}，支持 ${VAR:-default} 与 ${VAR?err}。
"""
from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import time
import urllib.request
import uuid
from pathlib import Path

from ..config.schema import CustomEngineConfig
from ..credentials import Credentials, litellm_model_string
from ..transcript import Message, Transcript
from .base import ExecOptions, Engine, SessionResult

_VAR_RE = re.compile(r"\$\{([^}]+)\}")


class TemplateError(Exception):
    pass


def render_template(template: str, variables: dict[str, str]) -> str:
    """渲染 ${var} / ${var:-default} / ${var?error}。"""
    def _sub(m: re.Match) -> str:
        expr = m.group(1)
        if ":-" in expr:
            name, default = expr.split(":-", 1)
            return variables.get(name) or os.environ.get(name) or default
        if "?" in expr:
            name, err = expr.split("?", 1)
            val = variables.get(name) or os.environ.get(name)
            if not val:
                raise TemplateError(err or f"变量 {name} 未设置")
            return val
        val = variables.get(expr)
        if val is None:
            val = os.environ.get(expr, "")
        return val
    return _VAR_RE.sub(_sub, template)


def _safe_workspace_path(workspace: Path, rel: str) -> Path:
    p = (Path(workspace) / rel).resolve()
    if not str(p).startswith(str(Path(workspace).resolve())):
        raise TemplateError(f"路径逃逸 workspace: {rel}")
    return p


class CustomEngine(Engine):
    def __init__(self, name: str, cfg: CustomEngineConfig, creds: Credentials):
        self._name = name
        self.cfg = cfg
        self.creds = creds

    def name(self) -> str:
        return self._name

    def run(self, opts: ExecOptions, messages: list[Message]) -> SessionResult:
        session_id = uuid.uuid4().hex
        session_input = self._build_session_input(opts, messages)
        variables = self._build_variables(opts, messages, session_input)
        start = time.monotonic()
        if self.cfg.transport == "http":
            raw = self._run_http(variables, session_input)
        else:
            raw = self._run_local(opts, variables, session_input)
        duration_ms = int((time.monotonic() - start) * 1000)
        result = self._parse_output(raw)
        result.engine = self._name
        result.model = litellm_model_string(self.creds.provider, self.creds.model)
        result.session_id = session_id
        result.duration_ms = duration_ms
        return result

    # -- internals ----------------------------------------------------------

    def _build_session_input(self, opts: ExecOptions, messages: list[Message]) -> dict:
        return {
            "case_id": opts.case_id,
            "variant": opts.variant,
            "workspace": str(opts.workspace),
            "model": litellm_model_string(self.creds.provider, self.creds.model),
            "kwargs": self.cfg.kwargs,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "max_turns": opts.max_turns,
            "timeout_seconds": opts.timeout_sec,
        }

    def _build_variables(self, opts: ExecOptions, messages: list[Message],
                         session_input: dict) -> dict[str, str]:
        input_file = self.cfg.local.input_file or "inputs/messages.json"
        output_file = self.cfg.local.output_file or "outputs/session-result.json"
        prompt = "\n".join(m.content for m in messages if m.role == "user")
        variables: dict[str, str] = {
            "workspace": str(opts.workspace),
            "prompt": prompt,
            "input_file": str(_safe_workspace_path(opts.workspace, input_file)),
            "output_file": str(_safe_workspace_path(opts.workspace, output_file)),
            "model": litellm_model_string(self.creds.provider, self.creds.model),
            "model_provider": self.creds.provider,
            "model_name": self.creds.model,
            "api_key": self.creds.api_key,
            "case_id": opts.case_id,
            "variant": opts.variant,
            "max_turns": str(opts.max_turns),
            "timeout_seconds": str(opts.timeout_sec),
            "session_input": json.dumps(session_input, ensure_ascii=False),
            "messages": json.dumps(session_input["messages"], ensure_ascii=False),
        }
        for k, v in self.cfg.kwargs.items():
            variables[f"kwargs.{k}"] = str(v)
        return variables

    def _run_local(self, opts: ExecOptions, variables: dict[str, str],
                   session_input: dict) -> str:
        if not self.cfg.local.command:
            raise TemplateError("engine.custom.local.command 未配置")
        input_path = Path(variables["input_file"])
        input_path.parent.mkdir(parents=True, exist_ok=True)
        input_path.write_text(
            json.dumps(session_input, ensure_ascii=False, indent=2), encoding="utf-8")
        # 清除陈旧输出，并确保输出目录存在
        output_path = Path(variables["output_file"])
        output_path.parent.mkdir(parents=True, exist_ok=True)
        if output_path.exists():
            output_path.unlink()

        command = render_template(self.cfg.local.command, variables)
        args = [render_template(a, variables) for a in self.cfg.local.args]
        cwd = render_template(self.cfg.local.cwd, variables) if self.cfg.local.cwd \
            else str(opts.workspace)
        env = dict(os.environ)
        env.update({k: render_template(v, variables) for k, v in self.cfg.env.items()})

        cmd = [command, *args]
        if os.name != "nt" and (command.endswith(".sh") or command == "bash"):
            cmd = ["bash", command, *args]
        timeout = self.cfg.timeout_seconds or opts.timeout_sec
        proc = subprocess.run(
            cmd, cwd=cwd, env=env, capture_output=True, text=True,
            timeout=timeout if timeout > 0 else None,
        )
        if output_path.exists():
            return output_path.read_text(encoding="utf-8")
        if proc.returncode != 0 and not proc.stdout.strip():
            raise RuntimeError(
                f"自定义引擎退出码 {proc.returncode}: {proc.stderr.strip()[:500]}")
        return proc.stdout

    def _run_http(self, variables: dict[str, str], session_input: dict) -> str:
        http = self.cfg.http
        if not http.url:
            raise TemplateError("engine.custom.http.url 未配置")
        url = render_template(http.url, variables)
        if self.creds.api_key and self.creds.api_key in url:
            raise TemplateError("禁止把 ${api_key} 渲染进 URL")
        body = session_input
        if http.request_body:
            rendered = render_template(
                json.dumps(http.request_body, ensure_ascii=False), variables)
            body = json.loads(rendered)
        headers = {"Content-Type": "application/json"}
        headers.update({k: render_template(v, variables) for k, v in http.headers.items()})
        req = urllib.request.Request(
            url, data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
            headers=headers, method=http.method or "POST")
        timeout = self.cfg.timeout_seconds or 300
        with urllib.request.urlopen(req, timeout=timeout if timeout > 0 else None) as resp:
            return resp.read().decode("utf-8")

    def _parse_output(self, raw: str) -> SessionResult:
        result = SessionResult(exit_code=0)
        if self.cfg.response_format == "text":
            result.final_message = raw
            return result
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as e:
            raise RuntimeError(f"自定义引擎输出不是合法 JSON: {e}; 内容: {raw[:300]}")
        if "exit_code" not in data:
            raise RuntimeError("自定义引擎 session_result 缺少 exit_code 字段")
        result.exit_code = int(data.get("exit_code", 0))
        result.final_message = data.get("final_message", "") or ""
        result.stderr = data.get("stderr", "") or ""
        result.input_tokens = int(data.get("input_tokens", 0) or 0)
        result.output_tokens = int(data.get("output_tokens", 0) or 0)
        result.turns = int(data.get("turns", 0) or 0)
        tr = Transcript()
        for m in data.get("transcript", []) or []:
            if isinstance(m, dict):
                tr.add(Message(
                    role=m.get("role", ""), content=m.get("content", "") or "",
                    turn=int(m.get("turn", 0) or 0), name=m.get("name", "") or "",
                    args=m.get("args", {}) or {},
                ))
        result.transcript = tr
        return result
