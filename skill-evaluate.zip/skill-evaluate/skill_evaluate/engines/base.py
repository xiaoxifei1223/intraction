"""Engine 抽象（对齐 Go 版 internal/agent/agent.go）。"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from ..transcript import Message, Transcript


@dataclass
class ExecOptions:
    workspace: Path
    artifact_dir: Optional[Path] = None
    timeout_sec: int = 300
    max_turns: int = 10
    case_id: str = ""
    variant: str = "with_skill"          # with_skill | without_skill
    agent_metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PromptDeliveryMetadata:
    mode: str = "messages"               # messages | inline
    prompt_bytes: int = 0

    def to_dict(self) -> dict:
        return {"mode": self.mode, "prompt_bytes": self.prompt_bytes}


@dataclass
class SessionResult:
    engine: str = ""
    model: str = ""
    session_id: str = ""
    exit_code: int = 0
    duration_ms: int = 0
    turns: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    final_message: str = ""
    stderr: str = ""
    transcript: Transcript = field(default_factory=Transcript)
    prompt_delivery: Optional[PromptDeliveryMetadata] = None

    def to_dict(self) -> dict:
        return {
            "engine": self.engine,
            "model": self.model,
            "session_id": self.session_id,
            "exit_code": self.exit_code,
            "duration_ms": self.duration_ms,
            "turns": self.turns,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "final_message": self.final_message,
            "stderr": self.stderr,
            "transcript": self.transcript.to_list(),
            "prompt_delivery": self.prompt_delivery.to_dict() if self.prompt_delivery else None,
        }


class Engine(ABC):
    """Agent 执行引擎统一接口。"""

    @abstractmethod
    def name(self) -> str: ...

    def install_skill(self, skill_source: Path, workspace: Path, target: str = "") -> None:
        """把 skill 安装进 workspace（默认实现：拷贝文件，排除 evals/）。"""
        install_skill_files(skill_source, workspace, target)

    def check(self) -> None:
        """启动前检查（如凭证是否就绪）。默认 no-op。"""

    @abstractmethod
    def run(self, opts: ExecOptions, messages: list[Message]) -> SessionResult: ...


def list_skill_files(skill_source: Path) -> list[Path]:
    """遍历 skill 源目录文件，排除 evals/ 与隐藏目录（对齐 Go 版 ListSkillFiles）。"""
    skill_source = Path(skill_source)
    files: list[Path] = []
    for p in sorted(skill_source.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(skill_source)
        parts = rel.parts
        if parts[0] == "evals" or any(part.startswith(".") for part in parts):
            continue
        files.append(p)
    return files


def install_skill_files(skill_source: Path, workspace: Path, target: str = "") -> None:
    """默认 skill 安装：拷贝到 <workspace>/<target or skills/<name>/>。"""
    import shutil

    skill_source = Path(skill_source)
    if not skill_source.is_dir():
        return
    dest = Path(workspace) / (target or f"skills/{skill_source.name}")
    for src in list_skill_files(skill_source):
        rel = src.relative_to(skill_source)
        dst = dest / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)


def read_skill_prompt_context(skill_source: Path, max_bytes: int = 64 * 1024) -> str:
    """读取 skill 内容作为 prompt 上下文（litellm 引擎的"skill 安装"等价物）。

    包含 SKILL.md 全文 + 其余文件的相对路径清单与内容（受 max_bytes 截断）。
    """
    skill_source = Path(skill_source)
    chunks: list[str] = []
    total = 0

    def _append(text: str) -> bool:
        nonlocal total
        if total + len(text) > max_bytes:
            return False
        chunks.append(text)
        total += len(text)
        return True

    files = list_skill_files(skill_source)
    skill_md = skill_source / "SKILL.md"
    ordered = ([skill_md] if skill_md.is_file() else []) + [f for f in files if f.name != "SKILL.md"]
    for f in ordered:
        rel = f.relative_to(skill_source)
        try:
            content = f.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        if not _append(f"\n===== skill file: {rel} =====\n{content}\n"):
            _append(f"\n===== skill file: {rel} (truncated, omitted) =====\n")
            break
    return "".join(chunks)
