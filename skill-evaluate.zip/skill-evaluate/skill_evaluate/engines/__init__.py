"""Engine 工厂（对齐 Go 版 agent.DetectAgent）。"""
from __future__ import annotations

from ..config.schema import EngineConfig
from ..credentials import Credentials
from .base import Engine, ExecOptions, SessionResult  # noqa: F401
from .custom import CustomEngine
from .litellm_engine import LiteLLMEngine

BUILTIN_ENGINES = {"litellm"}


class UnsupportedEngineError(Exception):
    pass


def detect_engine(
    engine_cfg: EngineConfig,
    creds: Credentials,
    skill_contents: dict[str, str] | None = None,
) -> Engine:
    name = engine_cfg.name
    if name == "litellm":
        kwargs = dict(engine_cfg.kwargs)
        kwargs.update(engine_cfg.model.params)
        return LiteLLMEngine(creds, skill_contents=skill_contents, kwargs=kwargs)
    if engine_cfg.custom is not None:
        return CustomEngine(name, engine_cfg.custom, creds)
    raise UnsupportedEngineError(
        f"不支持的引擎 '{name}'。Python 版内置引擎: litellm；"
        f"其他引擎请配置 engine.custom。"
    )
