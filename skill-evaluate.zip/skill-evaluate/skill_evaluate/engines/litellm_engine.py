"""litellm 引擎：通过 litellm 统一 API (+ api_key) 直接调用 LLM。

这是 Python 版相对 Go 版的核心改动：Go 版通过外部 Agent CLI 子进程调用模型，
Python 版直接通过 litellm.completion(model="provider/name", api_key=..., base_url=...)
访问任意 provider（openai / anthropic / dashscope / azure / ollama ...）。

"skill 安装"的等价物：with_skill 时把 skill 文件内容作为 system 上下文注入消息；
without_skill（benchmark 基线）时不注入。
"""
from __future__ import annotations

import time
import uuid
from pathlib import Path

import litellm

from ..credentials import Credentials, litellm_model_string
from ..transcript import Message, Transcript
from .base import ExecOptions, Engine, PromptDeliveryMetadata, SessionResult

SKILL_SYSTEM_TEMPLATE = (
    "You are an AI assistant being evaluated on a specific Skill.\n"
    "The following Skill documents define capabilities, rules and output formats "
    "you MUST follow when responding:\n"
    "{skill_content}\n"
    "End of Skill documents."
)


class LiteLLMEngine(Engine):
    def __init__(
        self,
        credentials: Credentials,
        skill_contents: dict[str, str] | None = None,
        kwargs: dict | None = None,
    ):
        """
        credentials: 解析好的 provider/model/api_key/base_url
        skill_contents: variant -> skill 文本上下文（{"with_skill": "..."}）
        kwargs: 额外参数透传给 litellm.completion（temperature 等）
        """
        self.creds = credentials
        self.skill_contents = skill_contents or {}
        self.kwargs = kwargs or {}
        if not self.creds.model:
            raise ValueError(
                "未配置模型。请在 eval.yaml 的 engine.model 中设置 provider/name，"
                "或使用 --model，或设置 LITELLM_MODEL 环境变量。"
            )

    def name(self) -> str:
        return "litellm"

    # -- Engine API ---------------------------------------------------------

    def run(self, opts: ExecOptions, messages: list[Message]) -> SessionResult:
        session_id = uuid.uuid4().hex
        transcript = Transcript()
        llm_messages = self._build_llm_messages(opts, messages, transcript)

        start = time.monotonic()
        resp = self._completion(llm_messages, timeout=opts.timeout_sec)
        duration_ms = int((time.monotonic() - start) * 1000)

        final_message, input_tokens, output_tokens = self._parse_response(resp)
        assistant_msg = Message(
            role="assistant", content=final_message,
            turn=max((m.turn for m in messages), default=0) or 1,
        )
        transcript.add(assistant_msg)

        return SessionResult(
            engine=self.name(),
            model=litellm_model_string(self.creds.provider, self.creds.model),
            session_id=session_id,
            exit_code=0,
            duration_ms=duration_ms,
            turns=assistant_msg.turn,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            final_message=final_message,
            transcript=transcript,
            prompt_delivery=PromptDeliveryMetadata(
                mode="messages",
                prompt_bytes=sum(len(m.content.encode("utf-8")) for m in messages),
            ),
        )

    def run_turn(
        self,
        opts: ExecOptions,
        history: list[dict],
        user_content: str,
        turn_no: int,
    ) -> tuple[str, int, int, int]:
        """多轮：在 history（litellm 消息格式）上追加一轮，返回
        (assistant_text, input_tokens, output_tokens, duration_ms)。"""
        history.append({"role": "user", "content": user_content})
        start = time.monotonic()
        resp = self._completion(list(history), timeout=opts.timeout_sec)
        duration_ms = int((time.monotonic() - start) * 1000)
        text, in_tok, out_tok = self._parse_response(resp)
        history.append({"role": "assistant", "content": text})
        return text, in_tok, out_tok, duration_ms

    def build_system_messages(self, variant: str) -> list[dict]:
        skill_content = self.skill_contents.get(variant, "")
        if not skill_content:
            return []
        return [{
            "role": "system",
            "content": SKILL_SYSTEM_TEMPLATE.format(skill_content=skill_content),
        }]

    # -- internals ----------------------------------------------------------

    def _build_llm_messages(
        self, opts: ExecOptions, messages: list[Message], transcript: Transcript
    ) -> list[dict]:
        llm_messages = self.build_system_messages(opts.variant)
        for m in messages:
            transcript.add(m)
            role = m.role if m.role in ("user", "assistant", "system") else "user"
            llm_messages.append({"role": role, "content": m.content})
        if not any(m["role"] == "user" for m in llm_messages):
            raise ValueError("messages 中缺少 user 消息")
        return llm_messages

    def _completion(self, messages: list[dict], timeout: int = 300):
        kwargs = dict(self.kwargs)
        if timeout and timeout > 0:
            kwargs.setdefault("timeout", timeout)
        if self.creds.api_key:
            kwargs["api_key"] = self.creds.api_key
        if self.creds.base_url:
            kwargs["api_base"] = self.creds.base_url
        return litellm.completion(
            model=litellm_model_string(self.creds.provider, self.creds.model),
            messages=messages,
            **kwargs,
        )

    @staticmethod
    def _parse_response(resp) -> tuple[str, int, int]:
        final_message = ""
        try:
            final_message = resp.choices[0].message.content or ""
        except Exception:
            pass
        input_tokens = output_tokens = 0
        usage = getattr(resp, "usage", None)
        if usage is not None:
            input_tokens = int(getattr(usage, "prompt_tokens", 0) or 0)
            output_tokens = int(getattr(usage, "completion_tokens", 0) or 0)
        return final_message, input_tokens, output_tokens
