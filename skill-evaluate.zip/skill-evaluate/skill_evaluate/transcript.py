"""统一 transcript 模型（对齐 Go 版 pkg/transcript）。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# 角色: user / assistant / tool_call / tool_result / error
ROLE_USER = "user"
ROLE_ASSISTANT = "assistant"
ROLE_TOOL_CALL = "tool_call"
ROLE_TOOL_RESULT = "tool_result"
ROLE_ERROR = "error"


@dataclass
class Message:
    role: str
    content: str = ""
    turn: int = 0
    name: str = ""                    # tool_call/tool_result 的工具名
    args: dict[str, Any] = field(default_factory=dict)  # tool_call 参数

    def to_dict(self) -> dict:
        d: dict[str, Any] = {"role": self.role, "content": self.content, "turn": self.turn}
        if self.name:
            d["name"] = self.name
        if self.args:
            d["args"] = self.args
        return d


@dataclass
class Transcript:
    messages: list[Message] = field(default_factory=list)

    def add(self, msg: Message) -> None:
        self.messages.append(msg)

    @property
    def turns(self) -> int:
        return max((m.turn for m in self.messages), default=0)

    def assistant_messages(self) -> list[Message]:
        return [m for m in self.messages if m.role == ROLE_ASSISTANT]

    def tool_calls(self) -> list[Message]:
        return [m for m in self.messages if m.role == ROLE_TOOL_CALL]

    def to_list(self) -> list[dict]:
        return [m.to_dict() for m in self.messages]

    def render_text(self, max_turns: int = 0) -> str:
        """渲染成可读文本，供 judge context 使用。"""
        lines: list[str] = []
        for m in self.messages:
            if max_turns and m.turn > max_turns:
                continue
            prefix = m.role.upper()
            if m.name:
                prefix += f"[{m.name}]"
            lines.append(f"--- {prefix} (turn {m.turn}) ---")
            lines.append(m.content)
        return "\n".join(lines)
