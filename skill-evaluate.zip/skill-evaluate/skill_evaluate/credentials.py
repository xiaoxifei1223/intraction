"""凭证解析：litellm 的 api_key / base_url 解析链。

优先级（高 -> 低）：
  1. CLI --api-key / --base-url
  2. provider 作用域环境变量: <PROVIDER>_API_KEY / <PROVIDER>_BASE_URL / <PROVIDER>_MODEL
  3. 通用环境变量: LITELLM_API_KEY / LITELLM_BASE_URL / LITELLM_MODEL
  4. 用户凭证文件: ~/.skill-evaluate/credentials.yaml
       providers:
         openai:
           api_key: sk-...
           base_url: https://...
  5. 项目 .env 文件（由 litellm/dotenv 自行加载，作为兜底）
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml


@dataclass
class Credentials:
    provider: str = ""
    model: str = ""
    api_key: str = ""
    base_url: str = ""


def _load_credentials_file() -> dict:
    path = Path.home() / ".skill-evaluate" / "credentials.yaml"
    if not path.is_file():
        return {}
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}
    return data.get("providers", {}) or {}


def _env(name: str) -> str:
    return os.environ.get(name, "") or ""


def resolve_credentials(
    provider: str = "",
    model: str = "",
    cli_api_key: str = "",
    cli_base_url: str = "",
) -> Credentials:
    """按优先级链解析 api_key / base_url / model。"""
    provider = (provider or "").strip()
    prefix = provider.upper().replace("-", "_") if provider else ""

    file_creds = _load_credentials_file().get(provider, {}) if provider else {}

    api_key = (
        cli_api_key
        or (f"{prefix}_API_KEY" and _env(f"{prefix}_API_KEY"))
        or _env("LITELLM_API_KEY")
        or file_creds.get("api_key", "")
        or ""
    )
    base_url = (
        cli_base_url
        or (f"{prefix}_BASE_URL" and _env(f"{prefix}_BASE_URL"))
        or _env("LITELLM_BASE_URL")
        or file_creds.get("base_url", "")
        or ""
    )
    resolved_model = (
        model
        or (f"{prefix}_MODEL" and _env(f"{prefix}_MODEL"))
        or _env("LITELLM_MODEL")
        or file_creds.get("model", "")
        or ""
    )
    return Credentials(
        provider=provider, model=resolved_model, api_key=api_key, base_url=base_url
    )


def litellm_model_string(provider: str, model: str) -> str:
    """组合成 litellm 的 model 字符串：'provider/name'；无 provider 时原样返回。"""
    if provider and "/" not in model:
        return f"{provider}/{model}"
    return model


def mask_secret(s: str) -> str:
    if not s:
        return s
    if len(s) <= 8:
        return "***"
    return s[:4] + "***" + s[-4:]
