"""expect 短路检查（对齐 Go 版 internal/judge/expect.go）。

任一 expect 失败 → 立即 FAIL，跳过 judge；全部通过则继续 judge，
通过项也会以 expect.<rule> 断言的形式 prepend 进最终 grading。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ..config.schema import Expect
from .base import AssertionResult, JudgeInput


class ExpectCheckError(Exception):
    pass


def _safe_path(workspace: Path, rel: str) -> Path:
    p = (Path(workspace) / rel).resolve()
    if not str(p).startswith(str(Path(workspace).resolve())):
        raise ExpectCheckError(f"路径逃逸 workspace: {rel}")
    return p


@dataclass
class ExpectResult:
    checks: list[AssertionResult] = field(default_factory=list)

    @property
    def all_passed(self) -> bool:
        return all(c.passed for c in self.checks)

    def to_assertion_results(self) -> list[AssertionResult]:
        return list(self.checks)


def check_expect(expect: Expect, judge_input: JudgeInput) -> ExpectResult:
    """纯函数：依次执行 7 类 expect 检查。"""
    result = ExpectResult()
    if expect is None or expect.is_empty():
        return result

    output = judge_input.final_message or ""

    # 1. must_contain（针对 final_message 子串）
    for s in expect.must_contain:
        ok = s in output
        result.checks.append(AssertionResult(
            text=f"expect.must_contain: '{s}'",
            passed=ok,
            evidence="输出中包含该字符串" if ok else f"输出中未找到 '{s}'",
        ))

    # 2. must_not_contain
    for s in expect.must_not_contain:
        ok = s not in output
        result.checks.append(AssertionResult(
            text=f"expect.must_not_contain: '{s}'",
            passed=ok,
            evidence="输出中不包含该字符串" if ok else f"输出中不应包含 '{s}'",
        ))

    # 3. exit_code
    if expect.exit_code is not None:
        ok = judge_input.exit_code == expect.exit_code
        result.checks.append(AssertionResult(
            text=f"expect.exit_code: {expect.exit_code}",
            passed=ok,
            evidence=f"实际退出码 {judge_input.exit_code}",
        ))

    workspace = judge_input.workspace_path
    # 4. files_exist
    for rel in expect.files_exist:
        ok = False
        evidence = ""
        try:
            if workspace is None:
                raise ExpectCheckError("无 workspace")
            p = _safe_path(workspace, rel)
            ok = p.exists()
            evidence = str(p) if ok else f"文件不存在: {rel}"
        except ExpectCheckError as e:
            evidence = str(e)
        result.checks.append(AssertionResult(
            text=f"expect.files_exist: '{rel}'", passed=ok, evidence=evidence))

    # 5. files_not_exist
    for rel in expect.files_not_exist:
        ok = True
        evidence = ""
        try:
            if workspace is None:
                raise ExpectCheckError("无 workspace")
            p = _safe_path(workspace, rel)
            ok = not p.exists()
            if not ok:
                evidence = f"文件不应存在: {rel}"
        except ExpectCheckError as e:
            ok = False
            evidence = str(e)
        result.checks.append(AssertionResult(
            text=f"expect.files_not_exist: '{rel}'", passed=ok, evidence=evidence))

    # 6. file_contains [{path, content}]
    for fc in expect.file_contains:
        rel, content = fc.get("path", ""), fc.get("content", "")
        ok = False
        evidence = ""
        try:
            if workspace is None:
                raise ExpectCheckError("无 workspace")
            p = _safe_path(workspace, rel)
            if not p.is_file():
                evidence = f"文件不存在: {rel}"
            else:
                text = p.read_text(encoding="utf-8", errors="replace")
                ok = content in text
                evidence = "文件包含预期内容" if ok else f"文件 {rel} 未包含 '{content[:80]}'"
        except ExpectCheckError as e:
            evidence = str(e)
        result.checks.append(AssertionResult(
            text=f"expect.file_contains: '{rel}'", passed=ok, evidence=evidence))

    # 7. golden_file（相对 skill_dir，TrimSpace 后全等比较）
    if expect.golden_file:
        ok = False
        evidence = ""
        try:
            if judge_input.skill_dir is None:
                raise ExpectCheckError("无 skill_dir")
            golden = (Path(judge_input.skill_dir) / expect.golden_file).resolve()
            if not str(golden).startswith(str(Path(judge_input.skill_dir).resolve())):
                raise ExpectCheckError(f"golden_file 路径逃逸 skill 目录: {expect.golden_file}")
            if not golden.is_file():
                evidence = f"golden 文件不存在: {expect.golden_file}"
            elif workspace is None:
                evidence = "无 workspace"
            else:
                actual = _safe_path(workspace, golden.name)
                if not actual.is_file():
                    # 尝试在 workspace 根找同名文件，否则用 golden_file 的相对路径
                    actual = _safe_path(workspace, expect.golden_file)
                if not actual.is_file():
                    evidence = f"workspace 中找不到对比文件: {actual.name}"
                else:
                    expected_text = golden.read_text(encoding="utf-8", errors="replace").strip()
                    actual_text = actual.read_text(encoding="utf-8", errors="replace").strip()
                    ok = expected_text == actual_text
                    evidence = "与 golden 文件一致" if ok else "与 golden 文件不一致"
        except ExpectCheckError as e:
            evidence = str(e)
        result.checks.append(AssertionResult(
            text=f"expect.golden_file: '{expect.golden_file}'", passed=ok, evidence=evidence))

    return result
