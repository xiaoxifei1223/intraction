"""rule_based judge（对齐 Go 版 internal/judge/rule_based.go）。

优先级：先评 failure 规则，任一命中立即 FAIL 短路；再评 success 规则
（全部须过）；无规则默认 PASS。per-turn 规则要求该 turn 已完成。
"""
from __future__ import annotations

import json
from pathlib import Path

from ..config.schema import Rule
from .base import AssertionResult, Judge, JudgeInput, Result, Status, new_result
from .expect import _safe_path


class RuleBasedJudge(Judge):
    def __init__(self, success: list[Rule], failure: list[Rule]):
        self.success = success or []
        self.failure = failure or []

    def evaluate(self, judge_input: JudgeInput) -> Result:
        assertions: list[AssertionResult] = []
        # failure 规则优先：任一命中立即 FAIL 短路
        for rule in self.failure:
            a = self._evaluate_rule(rule, judge_input, kind="failure")
            assertions.append(a)
            if not a.passed:
                return new_result(assertions)
        for rule in self.success:
            assertions.append(self._evaluate_rule(rule, judge_input, kind="success"))
        return new_result(assertions)

    # -- rule evaluators ----------------------------------------------------

    def _evaluate_rule(self, rule: Rule, ji: JudgeInput, kind: str) -> AssertionResult:
        if rule.output_contains is not None:
            return self._output_contains(rule, ji, kind)
        if rule.exit_code is not None:
            ok = ji.exit_code == rule.exit_code
            return AssertionResult(
                text=f"{kind}.exit_code == {rule.exit_code}", passed=ok,
                evidence=f"实际退出码 {ji.exit_code}")
        if rule.tool_called is not None:
            return self._tool_called(rule, ji, kind)
        if rule.files_exist is not None:
            return self._files(rule.files_exist, ji, kind, must_exist=True)
        if rule.files_not_exist is not None:
            return self._files(rule.files_not_exist, ji, kind, must_exist=False)
        if rule.turn_response_contains is not None:
            return self._turn_contains(rule, ji, kind)
        if rule.turn_response_not_contains is not None:
            return self._turn_not_contains(rule, ji, kind)
        if rule.tool_called_in_turn is not None:
            return self._tool_in_turn(rule, ji, kind, must_call=True)
        if rule.tool_not_called_in_turn is not None:
            return self._tool_in_turn(rule, ji, kind, must_call=False)
        return AssertionResult(text=f"{kind}.<empty rule>", passed=False,
                               evidence="规则未设置任何字段")

    def _output_contains(self, rule: Rule, ji: JudgeInput, kind: str) -> AssertionResult:
        spec = rule.output_contains or {}
        output = ji.final_message or ""
        if "all" in spec:
            missing = [s for s in spec["all"] if s not in output]
            ok = not missing
            return AssertionResult(
                text=f"{kind}.output_contains.all: {spec['all']}", passed=ok,
                evidence="全部命中" if ok else f"缺少: {missing}")
        if "any" in spec:
            hits = [s for s in spec["any"] if s in output]
            ok = bool(hits)
            return AssertionResult(
                text=f"{kind}.output_contains.any: {spec['any']}", passed=ok,
                evidence=f"命中: {hits}" if ok else "均未命中")
        if "not" in spec:
            hits = [s for s in spec["not"] if s in output]
            ok = not hits
            return AssertionResult(
                text=f"{kind}.output_contains.not: {spec['not']}", passed=ok,
                evidence="均未出现" if ok else f"不应出现: {hits}")
        return AssertionResult(text=f"{kind}.output_contains.<empty>", passed=False,
                               evidence="output_contains 需要 all/any/not 之一")

    def _tool_called(self, rule: Rule, ji: JudgeInput, kind: str) -> AssertionResult:
        spec = rule.tool_called or {}
        name = spec.get("name", "")
        args = spec.get("args", {}) or {}
        calls = ji.transcript.tool_calls() if ji.transcript else []
        for c in calls:
            if name and c.name != name:
                continue
            if args and not _args_partial_match(args, c.args):
                continue
            return AssertionResult(
                text=f"{kind}.tool_called: {name}", passed=True,
                evidence=f"命中工具调用 {c.name}")
        return AssertionResult(
            text=f"{kind}.tool_called: {name}", passed=False,
            evidence=f"未调用工具 {name}（共 {len(calls)} 次工具调用）")

    def _files(self, files: list[str], ji: JudgeInput, kind: str,
               must_exist: bool) -> AssertionResult:
        label = "files_exist" if must_exist else "files_not_exist"
        if ji.workspace_path is None:
            return AssertionResult(text=f"{kind}.{label}: {files}", passed=False,
                                   evidence="无 workspace")
        bad: list[str] = []
        for rel in files:
            try:
                exists = _safe_path(ji.workspace_path, rel).exists()
            except Exception:
                exists = False
            if exists != must_exist:
                bad.append(rel)
        ok = not bad
        return AssertionResult(
            text=f"{kind}.{label}: {files}", passed=ok,
            evidence="全部满足" if ok else f"不满足: {bad}")

    def _turn_response(self, ji: JudgeInput, turn: int) -> str | None:
        """取指定 turn 的 assistant 响应；turn 未完成返回 None。"""
        if ji.transcript is None:
            return None
        for m in ji.transcript.messages:
            if m.turn == turn and m.role == "assistant":
                return m.content
        return None

    def _turn_contains(self, rule: Rule, ji: JudgeInput, kind: str) -> AssertionResult:
        spec = rule.turn_response_contains or {}
        turn = int(spec.get("turn", 0))
        resp = self._turn_response(ji, turn)
        if resp is None:
            return AssertionResult(
                text=f"{kind}.turn_response_contains turn={turn}", passed=False,
                evidence=f"turn {turn} 未完成或无响应")
        all_spec = spec.get("contains_all", []) or []
        any_spec = spec.get("contains_any", []) or []
        missing = [s for s in all_spec if s not in resp]
        ok_all = not missing
        hits = [s for s in any_spec if s in resp]
        ok_any = (not any_spec) or bool(hits)
        ok = ok_all and ok_any
        evidence_parts = []
        if missing:
            evidence_parts.append(f"缺少: {missing}")
        if any_spec:
            evidence_parts.append(f"any 命中: {hits}")
        return AssertionResult(
            text=f"{kind}.turn_response_contains turn={turn}", passed=ok,
            evidence="; ".join(evidence_parts) or "命中")

    def _turn_not_contains(self, rule: Rule, ji: JudgeInput, kind: str) -> AssertionResult:
        spec = rule.turn_response_not_contains or {}
        turn = int(spec.get("turn", 0))
        resp = self._turn_response(ji, turn)
        if resp is None:
            return AssertionResult(
                text=f"{kind}.turn_response_not_contains turn={turn}", passed=False,
                evidence=f"turn {turn} 未完成或无响应")
        not_spec = spec.get("not_contains", []) or []
        hits = [s for s in not_spec if s in resp]
        ok = not hits
        return AssertionResult(
            text=f"{kind}.turn_response_not_contains turn={turn}", passed=ok,
            evidence="均未出现" if ok else f"不应出现: {hits}")

    def _tool_in_turn(self, rule: Rule, ji: JudgeInput, kind: str,
                      must_call: bool) -> AssertionResult:
        spec = (rule.tool_called_in_turn if must_call
                else rule.tool_not_called_in_turn) or {}
        turn = int(spec.get("turn", 0))
        name = spec.get("name", "")
        args = spec.get("args", {}) or {}
        label = "tool_called_in_turn" if must_call else "tool_not_called_in_turn"
        if ji.transcript is None:
            return AssertionResult(text=f"{kind}.{label}", passed=False,
                                   evidence="无 transcript")
        turn_msgs = [m for m in ji.transcript.messages if m.turn == turn]
        if not turn_msgs:
            return AssertionResult(
                text=f"{kind}.{label} turn={turn}", passed=False,
                evidence=f"turn {turn} 未完成")
        calls = [m for m in turn_msgs if m.role == "tool_call"]
        found = any(
            (not name or c.name == name) and (not args or _args_partial_match(args, c.args))
            for c in calls
        )
        ok = found == must_call
        return AssertionResult(
            text=f"{kind}.{label} turn={turn} name={name}", passed=ok,
            evidence=f"turn {turn} 工具调用: {[c.name for c in calls]}")


def _args_partial_match(expected: dict, actual: dict) -> bool:
    """args 部分匹配（对齐 Go 版）：expected 的每个键值在 actual 中相等即可。"""
    for k, v in expected.items():
        if k not in actual:
            return False
        av = actual[k]
        if isinstance(v, (dict, list)) or isinstance(av, (dict, list)):
            if json.dumps(v, sort_keys=True) != json.dumps(av, sort_keys=True):
                return False
        elif av != v:
            return False
    return True
