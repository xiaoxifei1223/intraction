"""Judge 工厂。"""
from __future__ import annotations

from pathlib import Path

from ..config.schema import JudgeConfig
from ..credentials import Credentials
from .agent_judge import AgentJudge
from .base import (  # noqa: F401
    AssertionResult,
    Judge,
    JudgeInput,
    Result,
    ResultSummary,
    Status,
    new_result,
)
from .expect import ExpectResult, check_expect  # noqa: F401
from .rule_based import RuleBasedJudge
from .script import ScriptJudge


class JudgeConfigError(Exception):
    pass


def new_judge(cfg: JudgeConfig, skill_dir: Path,
              judge_creds: Credentials | None = None) -> Judge | None:
    """按 judge.type 构建 Judge；type 为空返回 None（不评分，仅 expect）。"""
    jtype = cfg.type
    if not jtype:
        return None
    if jtype == "rule_based":
        return RuleBasedJudge(success=cfg.success, failure=cfg.failure)
    if jtype == "script":
        script = Path(cfg.script_path)
        if not script.is_absolute():
            script = Path(skill_dir) / script
        return ScriptJudge(script, timeout_seconds=cfg.timeout_seconds)
    if jtype == "agent_judge":
        if judge_creds is None:
            raise JudgeConfigError("agent_judge 需要裁判模型凭证")
        return AgentJudge(cfg, judge_creds)
    raise JudgeConfigError(f"不支持的 judge.type: {jtype}")
