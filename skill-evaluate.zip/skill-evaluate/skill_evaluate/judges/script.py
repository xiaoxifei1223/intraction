"""script judge（对齐 Go 版 internal/judge/script.go + interpreter.go）。

契约：脚本在 workspace 下执行，注入环境变量
  EVAL_TRANSCRIPT_PATH / EVAL_FINAL_MESSAGE / EVAL_EXIT_CODE
exit 0 → PASS，非 0 → FAIL；stdout=evidence，stderr=debug。默认超时 30s。
按扩展名/shebang 选择解释器（sh/bash/python/node）。
"""
from __future__ import annotations

import os
import shlex
import stat
import subprocess
import tempfile
from pathlib import Path

from ..config.schema import DEFAULT_SCRIPT_TIMEOUT_SECONDS
from .base import AssertionResult, Judge, JudgeInput, Result, Status, new_result

_INTERPRETER_BY_EXT = {
    ".sh": ["bash"],
    ".bash": ["bash"],
    ".py": ["python"],
    ".js": ["node"],
    ".mjs": ["node"],
    ".ps1": ["powershell", "-File"],
}


def plan_script(script_path: Path) -> list[str]:
    """按扩展名 / shebang 选择解释器命令前缀。"""
    ext = script_path.suffix.lower()
    if ext in _INTERPRETER_BY_EXT:
        return [*_INTERPRETER_BY_EXT[ext], str(script_path)]
    # shebang
    try:
        with open(script_path, "rb") as f:
            first = f.readline(256).decode("utf-8", errors="replace").strip()
    except OSError:
        first = ""
    if first.startswith("#!"):
        parts = shlex.split(first[2:])
        if parts:
            if os.path.basename(parts[0]) == "env" and len(parts) > 1:
                return [parts[1], *parts[2:], str(script_path)]
            return [*parts, str(script_path)]
    # 无扩展名无 shebang：unix 直接执行，windows 用 bash 兜底
    if os.name == "nt":
        return ["bash", str(script_path)]
    script_path.chmod(script_path.stat().st_mode | stat.S_IXUSR)
    return [str(script_path)]


class ScriptJudge(Judge):
    def __init__(self, script_path: Path, timeout_seconds: int | None = None):
        self.script_path = Path(script_path)
        self.timeout_seconds = (
            timeout_seconds if timeout_seconds and timeout_seconds > 0
            else DEFAULT_SCRIPT_TIMEOUT_SECONDS
        )

    def evaluate(self, judge_input: JudgeInput) -> Result:
        if not self.script_path.is_file():
            r = Result(status=Status.ERROR,
                       error_reason=f"judge 脚本不存在: {self.script_path}")
            return r

        workspace = judge_input.workspace_path or Path.cwd()
        # transcript 序列化到临时文件
        transcript_path = ""
        tmp = tempfile.NamedTemporaryFile(
            mode="w", suffix=".json", prefix="skill-eval-transcript-",
            delete=False, encoding="utf-8")
        try:
            import json
            json.dump(
                judge_input.transcript.to_list() if judge_input.transcript else [],
                tmp, ensure_ascii=False, indent=2)
            tmp.close()
            transcript_path = tmp.name

            env = dict(os.environ)
            env["EVAL_TRANSCRIPT_PATH"] = transcript_path
            env["EVAL_FINAL_MESSAGE"] = judge_input.final_message or ""
            env["EVAL_EXIT_CODE"] = str(judge_input.exit_code)

            cmd = plan_script(self.script_path)
            proc = subprocess.run(
                cmd, cwd=str(workspace), env=env,
                capture_output=True, text=True, timeout=self.timeout_seconds,
            )
            passed = proc.returncode == 0
            evidence = proc.stdout.strip()
            if proc.stderr.strip():
                evidence = (evidence + "\n[stderr] " + proc.stderr.strip()).strip()
            return new_result([AssertionResult(
                text=f"script: {self.script_path.name} (exit {proc.returncode})",
                passed=passed,
                evidence=evidence or f"exit code {proc.returncode}",
            )])
        except subprocess.TimeoutExpired:
            r = Result(status=Status.ERROR,
                       error_reason=f"judge 脚本超时（{self.timeout_seconds}s）")
            return r
        except Exception as e:
            r = Result(status=Status.ERROR, error_reason=f"judge 脚本执行失败: {e}")
            return r
        finally:
            if transcript_path:
                try:
                    os.unlink(transcript_path)
                except OSError:
                    pass
