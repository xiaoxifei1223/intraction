"""agent_judge：LLM 裁判（Python 版改为通过 litellm 直接调用，对齐 Go 版语义）。

流程（对齐 Go 版 internal/judge/agent_judge.go）：
  1. MaterializeJudgeContext：按 judge.context 把 final_message/transcript/
     workspace 文件等组织成 Review Materials；
  2. buildJudgePrompt：criteria 编号列表 + 材料 + 强制 JSON 输出格式；
  3. litellm.completion 调用裁判模型；
  4. extractJSON：裸文本 → ```json fence → 花括号状态机 → 引号修复；
  5. validate：结果数必须等于 criteria 数、evidence 非空；
  6. pass_rate >= pass_threshold（默认 0.7）→ PASS；无 criteria → vacuous PASS。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import litellm

from ..config.schema import DEFAULT_PASS_THRESHOLD, JudgeConfig
from ..credentials import Credentials, litellm_model_string
from .base import AssertionResult, Judge, JudgeInput, Result, Status, new_result

JUDGE_PROMPT_TEMPLATE = """You are an expert evaluator judging the output of an AI agent.

# Agent's Task Output (Final Message)
{final_message}

# Review Materials
{materials}

# Evaluation Criteria
For EACH numbered criterion below, decide whether the agent's output satisfies it.
{criteria_block}

# Output Requirements
Respond with ONLY a JSON object in exactly this format (no markdown fences, no extra text):
{{"results": [{{"criterion": "<criterion text>", "passed": true, "evidence": "<specific evidence from the output>"}}, ...]}}

Rules:
- The "results" array MUST contain exactly {criteria_count} entries, one per criterion, in order.
- "passed" must be a boolean.
- "evidence" must quote or reference concrete parts of the agent's output; it must not be empty.
"""


class AgentJudge(Judge):
    def __init__(self, cfg: JudgeConfig, creds: Credentials,
                 workspace_files: list[str] | None = None):
        self.cfg = cfg
        self.creds = creds
        self.criteria = list(cfg.criteria or [])
        self.pass_threshold = (
            cfg.pass_threshold if cfg.pass_threshold is not None
            else DEFAULT_PASS_THRESHOLD
        )
        self.timeout_seconds = cfg.timeout_seconds or 0
        self.workspace_files = workspace_files or []

    def evaluate(self, judge_input: JudgeInput) -> Result:
        if not self.criteria:
            return new_result([])  # vacuous PASS
        prompt = self._build_prompt(judge_input)
        try:
            resp = self._completion(prompt)
            text = resp.choices[0].message.content or ""
        except Exception as e:
            return Result(status=Status.ERROR,
                          error_reason=f"agent_judge 调用裁判模型失败: {e}")
        try:
            verdicts = self._parse_verdicts(text)
        except Exception as e:
            return Result(
                status=Status.ERROR,
                error_reason=f"agent_judge 输出解析失败: {e}; 原始输出: {text[:300]}")
        assertions = [
            AssertionResult(text=v["criterion"], passed=bool(v["passed"]),
                            evidence=str(v["evidence"]))
            for v in verdicts
        ]
        result = new_result(assertions)
        # 阈值判定覆盖 new_result 的全过语义
        result.status = (Status.PASS if result.summary.pass_rate >= self.pass_threshold
                         else Status.FAIL)
        return result

    # -- prompt -------------------------------------------------------------

    def _build_prompt(self, judge_input: JudgeInput) -> str:
        materials = self._materialize_context(judge_input)
        criteria_block = "\n".join(
            f"{i + 1}. {c}" for i, c in enumerate(self.criteria))
        return JUDGE_PROMPT_TEMPLATE.format(
            final_message=judge_input.final_message or "(empty)",
            materials=materials or "(none)",
            criteria_block=criteria_block,
            criteria_count=len(self.criteria),
        )

    def _materialize_context(self, judge_input: JudgeInput) -> str:
        ctx = self.cfg.context
        sections: list[str] = []
        limits = (ctx.limits if ctx else {}) or {}
        max_bytes = int(limits.get("max_bytes", 64 * 1024) or 64 * 1024)
        transcript_max_turns = int(limits.get("transcript_max_turns", 0) or 0)

        def _trunc(s: str) -> str:
            return s if len(s) <= max_bytes else s[:max_bytes] + "\n... (truncated)"

        # transcript
        mode = (ctx.transcript if ctx else "") or "inline"
        if mode != "none" and judge_input.transcript and judge_input.transcript.messages:
            sections.append("## Transcript\n" + _trunc(
                judge_input.transcript.render_text(max_turns=transcript_max_turns)))

        # workspace generated files
        if judge_input.workspace_path is not None:
            files_section = self._workspace_files_section(judge_input.workspace_path)
            if files_section:
                sections.append(_trunc(files_section))

        # attachments
        for att in (ctx.attachments if ctx else []) or []:
            path, label = att.get("path", ""), att.get("label", "")
            p = Path(path)
            if judge_input.skill_dir and not p.is_absolute():
                p = Path(judge_input.skill_dir) / path
            if p.is_file():
                content = p.read_text(encoding="utf-8", errors="replace")
                sections.append(f"## Attachment: {label or path}\n{_trunc(content)}")
        return "\n\n".join(sections)

    def _workspace_files_section(self, workspace: Path, max_files: int = 20) -> str:
        lines: list[str] = []
        count = 0
        for p in sorted(Path(workspace).rglob("*")):
            if count >= max_files:
                lines.append("... (more files omitted)")
                break
            if not p.is_file() or any(part.startswith(".") for part in p.parts):
                continue
            rel = p.relative_to(workspace)
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            if len(content) > 4096:
                content = content[:4096] + "\n... (file truncated)"
            lines.append(f"### workspace file: {rel}\n{content}")
            count += 1
        return "## Workspace Files\n" + "\n\n".join(lines) if lines else ""

    # -- llm ----------------------------------------------------------------

    def _completion(self, prompt: str):
        kwargs: dict = {}
        if self.creds.api_key:
            kwargs["api_key"] = self.creds.api_key
        if self.creds.base_url:
            kwargs["api_base"] = self.creds.base_url
        if self.timeout_seconds > 0:
            kwargs["timeout"] = self.timeout_seconds
        return litellm.completion(
            model=litellm_model_string(self.creds.provider, self.creds.model),
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )

    # -- verdict parsing ----------------------------------------------------

    def _parse_verdicts(self, text: str) -> list[dict]:
        data = extract_json(text)
        results = data.get("results")
        if not isinstance(results, list):
            raise ValueError("缺少 results 数组")
        if len(results) != len(self.criteria):
            raise ValueError(
                f"results 数量 {len(results)} 与 criteria 数量 {len(self.criteria)} 不一致")
        for i, r in enumerate(results):
            if "passed" not in r:
                raise ValueError(f"results[{i}] 缺少 passed 字段")
            if not str(r.get("evidence", "")).strip():
                raise ValueError(f"results[{i}] evidence 为空")
            r.setdefault("criterion", self.criteria[i])
        return results


def extract_json(text: str) -> dict:
    """容错提取 JSON：裸文本 → ```json fence → 花括号状态机 → 引号修复。"""
    text = text.strip()
    # 1. 直接解析
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    # 2. ```json fence
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass
    # 3. 花括号状态机找第一个完整对象
    candidate = _scan_first_object(text)
    if candidate:
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            # 4. 引号修复兜底
            repaired = _repair_json_quotes(candidate)
            return json.loads(repaired)
    raise ValueError("无法从输出中提取 JSON 对象")


def _scan_first_object(text: str) -> str:
    depth = 0
    start = -1
    in_str = False
    escape = False
    for i, ch in enumerate(text):
        if in_str:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == "{":
            if depth == 0:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start >= 0:
                return text[start:i + 1]
    return ""


def _repair_json_quotes(s: str) -> str:
    """修复字符串值内未转义的双引号（best-effort，对齐 Go 版 repairJSONQuotes）。"""
    out: list[str] = []
    in_str = False
    escape = False
    for ch in s:
        if in_str:
            if escape:
                out.append(ch)
                escape = False
            elif ch == "\\":
                out.append(ch)
                escape = True
            elif ch == '"':
                out.append(ch)
                in_str = False
            else:
                out.append(ch)
        else:
            out.append(ch)
            if ch == '"':
                in_str = True
    return "".join(out)
