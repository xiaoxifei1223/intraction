"""Judge 统一接口与结果模型（对齐 Go 版 internal/judge/judge.go）。"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from ..engines.base import SessionResult
from ..transcript import Transcript


class Status(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    SKIP = "SKIP"
    ERROR = "ERROR"


@dataclass
class AssertionResult:
    text: str
    passed: bool
    evidence: str = ""

    def to_dict(self) -> dict:
        return {"text": self.text, "passed": self.passed, "evidence": self.evidence}


@dataclass
class ResultSummary:
    passed: int = 0
    failed: int = 0
    total: int = 0
    pass_rate: float = 0.0

    def to_dict(self) -> dict:
        return {
            "passed": self.passed, "failed": self.failed,
            "total": self.total, "pass_rate": self.pass_rate,
        }


@dataclass
class Result:
    status: Status = Status.PASS
    skip_reason: Optional[str] = None
    error_reason: Optional[str] = None
    turns_executed: int = 0
    turns_total: int = 0
    assertion_results: list[AssertionResult] = field(default_factory=list)
    summary: ResultSummary = field(default_factory=ResultSummary)

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "skip_reason": self.skip_reason,
            "error_reason": self.error_reason,
            "turns_executed": self.turns_executed,
            "turns_total": self.turns_total,
            "assertion_results": [a.to_dict() for a in self.assertion_results],
            "summary": self.summary.to_dict(),
        }


def new_result(assertions: list[AssertionResult]) -> Result:
    """对齐 Go 版 NewResult：无断言 → vacuous PASS(pass_rate=1)；有 failed → FAIL。"""
    r = Result(assertion_results=assertions)
    total = len(assertions)
    passed = sum(1 for a in assertions if a.passed)
    failed = total - passed
    r.summary = ResultSummary(
        passed=passed, failed=failed, total=total,
        pass_rate=(passed / total) if total else 1.0,
    )
    r.status = Status.FAIL if failed else Status.PASS
    return r


@dataclass
class JudgeInput:
    case_id: str = ""
    final_message: str = ""
    exit_code: int = 0
    workspace_path: Optional[Path] = None
    skill_dir: Optional[Path] = None
    transcript: Optional[Transcript] = None
    turn_results: list[dict] = field(default_factory=list)
    session_result: Optional[SessionResult] = None


class Judge:
    def evaluate(self, judge_input: JudgeInput) -> Result:
        raise NotImplementedError
