"""import：Anthropic evals.json → eval.yaml + cases/*.yaml。

每个 expectation 转为 agent_judge 的一条 criterion（对齐 Go 版 internal/cli/import.go）。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import yaml


class ImportError_(Exception):
    pass


def _slug(text: str, fallback: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", text.lower()).strip("-")[:48]
    return slug or fallback


def import_evals_json(evals_json: str | Path, output_dir: str | Path) -> Path:
    src = Path(evals_json)
    if not src.is_file():
        raise ImportError_(f"evals.json 不存在: {src}")
    data = json.loads(src.read_text(encoding="utf-8"))
    evals = data.get("evals")
    if not isinstance(evals, list) or not evals:
        raise ImportError_("evals.json 缺少非空 evals 数组")

    out = Path(output_dir)
    cases_dir = out / "cases"
    cases_dir.mkdir(parents=True, exist_ok=True)

    case_files: list[str] = []
    for i, ev in enumerate(evals, start=1):
        prompt = ev.get("prompt", "") or ""
        case_id = _slug(prompt[:40], f"eval-{ev.get('id', i)}")
        expectations = [str(e) for e in (ev.get("expectations") or [])]
        case_doc: dict = {
            "id": case_id,
            "title": f"Imported eval {ev.get('id', i)}",
            "input": {"prompt": prompt},
        }
        if expectations:
            case_doc["judge"] = {
                "type": "agent_judge",
                "criteria": expectations,
            }
        fname = f"cases/{case_id}.yaml"
        (out / fname).write_text(
            yaml.safe_dump(case_doc, allow_unicode=True, sort_keys=False),
            encoding="utf-8")
        case_files.append(fname)

    eval_doc = {
        "schema_version": "v1alpha1",
        "environment": {"type": "none"},
        "skills": [{"source": "local_path", "path": "."}],
        "engine": {"name": "litellm", "model": {}},
        "cases": {"files": case_files},
        "judge": {"type": "agent_judge"},
        "report": {"formats": ["json"]},
    }
    eval_yaml = out / "eval.yaml"
    eval_yaml.write_text(
        yaml.safe_dump(eval_doc, allow_unicode=True, sort_keys=False),
        encoding="utf-8")
    return eval_yaml
