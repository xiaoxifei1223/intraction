"""Configuration schema for skill-evaluate, aligned with skill-up v1alpha1.

eval.yaml  -> EvalConfig
cases/*.yaml -> CaseConfig
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

SCHEMA_VERSION = "v1alpha1"

# Documented defaults (mirrors internal/config/defaults.yaml of skill-up)
DEFAULT_TIMEOUT_SECONDS = 300
DEFAULT_MAX_TURNS = 10
DEFAULT_PARALLELISM = 1
DEFAULT_REPORT_FORMATS = ["json"]
DEFAULT_PASS_THRESHOLD = 0.7
DEFAULT_SCRIPT_TIMEOUT_SECONDS = 30


# ---------------------------------------------------------------------------
# engine / model
# ---------------------------------------------------------------------------

@dataclass
class ModelConfig:
    provider: str = ""
    name: str = ""
    base_url: str = ""
    params: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: dict | None) -> "ModelConfig":
        d = d or {}
        return cls(
            provider=d.get("provider", "") or "",
            name=d.get("name", "") or "",
            base_url=d.get("base_url", "") or "",
            params=d.get("params", {}) or {},
        )


@dataclass
class CustomEngineLocalConfig:
    command: str = ""
    args: list[str] = field(default_factory=list)
    cwd: str = ""
    input_file: str = ""    # default <workspace>/inputs/messages.json
    output_file: str = ""   # default <workspace>/outputs/session-result.json


@dataclass
class CustomEngineHttpConfig:
    url: str = ""
    method: str = "POST"
    headers: dict[str, str] = field(default_factory=dict)
    request_body: dict[str, Any] = field(default_factory=dict)


@dataclass
class CustomEngineConfig:
    transport: str = "local"                     # local | http
    timeout_seconds: int = 300
    response_format: str = "session_result"      # session_result | text
    env: dict[str, str] = field(default_factory=dict)
    kwargs: dict[str, Any] = field(default_factory=dict)
    local: CustomEngineLocalConfig = field(default_factory=CustomEngineLocalConfig)
    http: CustomEngineHttpConfig = field(default_factory=CustomEngineHttpConfig)

    @classmethod
    def from_dict(cls, d: dict | None) -> "CustomEngineConfig":
        d = d or {}
        local = d.get("local", {}) or {}
        http = d.get("http", {}) or {}
        return cls(
            transport=d.get("transport", "local") or "local",
            timeout_seconds=int(d.get("timeout_seconds", 300) or 300),
            response_format=d.get("response_format", "session_result") or "session_result",
            env=d.get("env", {}) or {},
            kwargs=d.get("kwargs", {}) or {},
            local=CustomEngineLocalConfig(
                command=local.get("command", "") or "",
                args=list(local.get("args", []) or []),
                cwd=local.get("cwd", "") or "",
                input_file=local.get("input_file", "") or "",
                output_file=local.get("output_file", "") or "",
            ),
            http=CustomEngineHttpConfig(
                url=http.get("url", "") or "",
                method=http.get("method", "POST") or "POST",
                headers=http.get("headers", {}) or {},
                request_body=http.get("request_body", {}) or {},
            ),
        )


@dataclass
class EngineConfig:
    name: str = "litellm"          # python 版默认引擎为 litellm
    version: str = ""
    model: ModelConfig = field(default_factory=ModelConfig)
    kwargs: dict[str, Any] = field(default_factory=dict)
    custom: Optional[CustomEngineConfig] = None

    @classmethod
    def from_dict(cls, d: dict | None) -> "EngineConfig":
        d = d or {}
        custom = d.get("custom")
        return cls(
            name=d.get("name", "litellm") or "litellm",
            version=d.get("version", "") or "",
            model=ModelConfig.from_dict(d.get("model")),
            kwargs=d.get("kwargs", {}) or {},
            custom=CustomEngineConfig.from_dict(custom) if custom else None,
        )


# ---------------------------------------------------------------------------
# skills / environment
# ---------------------------------------------------------------------------

@dataclass
class SkillRef:
    source: str = "local_path"     # local_path
    path: str = "."
    target: str = ""

    @classmethod
    def from_dict(cls, d: dict | None) -> "SkillRef":
        d = d or {}
        return cls(
            source=d.get("source", "local_path") or "local_path",
            path=d.get("path", ".") or ".",
            target=d.get("target", "") or "",
        )


@dataclass
class Environment:
    type: str = "none"             # python 版仅支持 none（本地执行）
    workspace_mount: str = "/workspace"
    env: dict[str, str] = field(default_factory=dict)
    setup_steps: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict | None) -> "Environment":
        d = d or {}
        return cls(
            type=d.get("type", "none") or "none",
            workspace_mount=d.get("workspace_mount", "/workspace") or "/workspace",
            env=d.get("env", {}) or {},
            setup_steps=list(d.get("setup_steps", []) or []),
        )


# ---------------------------------------------------------------------------
# judge
# ---------------------------------------------------------------------------

@dataclass
class Rule:
    """rule_based 规则：每条只设置一个字段。"""
    output_contains: Optional[dict] = None    # {all, any, not}
    exit_code: Optional[int] = None
    tool_called: Optional[dict] = None        # {name, args}
    files_exist: Optional[list[str]] = None
    files_not_exist: Optional[list[str]] = None
    turn_response_contains: Optional[dict] = None      # {turn, contains_all, contains_any}
    turn_response_not_contains: Optional[dict] = None  # {turn, not_contains}
    tool_called_in_turn: Optional[dict] = None         # {turn, name, args}
    tool_not_called_in_turn: Optional[dict] = None     # {turn, name}

    @classmethod
    def from_dict(cls, d: dict | None) -> "Rule":
        d = d or {}
        return cls(
            output_contains=d.get("output_contains"),
            exit_code=d.get("exit_code"),
            tool_called=d.get("tool_called"),
            files_exist=d.get("files_exist"),
            files_not_exist=d.get("files_not_exist"),
            turn_response_contains=d.get("turn_response_contains"),
            turn_response_not_contains=d.get("turn_response_not_contains"),
            tool_called_in_turn=d.get("tool_called_in_turn"),
            tool_not_called_in_turn=d.get("tool_not_called_in_turn"),
        )


@dataclass
class JudgeContextConfig:
    profile: str = ""
    final_message: str = ""     # inline | file | none
    transcript: str = ""
    workspace_diff: str = ""
    generated_files: str = ""
    limits: dict[str, int] = field(default_factory=dict)
    attachments: list[dict[str, str]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict | None) -> Optional["JudgeContextConfig"]:
        if not d:
            return None
        return cls(
            profile=d.get("profile", "") or "",
            final_message=d.get("final_message", "") or "",
            transcript=d.get("transcript", "") or "",
            workspace_diff=d.get("workspace_diff", "") or "",
            generated_files=d.get("generated_files", "") or "",
            limits=d.get("limits", {}) or {},
            attachments=list(d.get("attachments", []) or []),
        )


@dataclass
class JudgeConfig:
    type: str = ""                       # rule_based | script | agent_judge | ""
    script_path: str = ""
    model: str = ""                      # agent_judge 模型, 可为 "provider/model"
    criteria: list[str] = field(default_factory=list)
    skills: list[SkillRef] = field(default_factory=list)
    context: Optional[JudgeContextConfig] = None
    pass_threshold: Optional[float] = None   # 默认 0.7
    timeout_seconds: Optional[int] = None    # script 默认 30
    success: list[Rule] = field(default_factory=list)
    failure: list[Rule] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict | None) -> "JudgeConfig":
        d = d or {}
        return cls(
            type=d.get("type", "") or "",
            script_path=d.get("script_path", "") or "",
            model=d.get("model", "") or "",
            criteria=list(d.get("criteria", []) or []),
            skills=[SkillRef.from_dict(s) for s in (d.get("skills") or [])],
            context=JudgeContextConfig.from_dict(d.get("context")),
            pass_threshold=d.get("pass_threshold"),
            timeout_seconds=d.get("timeout_seconds"),
            success=[Rule.from_dict(r) for r in (d.get("success") or [])],
            failure=[Rule.from_dict(r) for r in (d.get("failure") or [])],
        )

    def is_empty(self) -> bool:
        return not (
            self.type or self.script_path or self.model or self.criteria
            or self.success or self.failure or self.context
        )


def merge_judge_config(global_cfg: JudgeConfig, case_cfg: JudgeConfig) -> JudgeConfig:
    """case 级 type 非空 = 整体覆盖（仅 model/pass_threshold/timeout/context 从全局回填）。

    对齐 Go 版 factory.go:MergeJudgeConfig。
    """
    if case_cfg.type:
        merged = case_cfg
        if not merged.model:
            merged.model = global_cfg.model
        if merged.pass_threshold is None:
            merged.pass_threshold = global_cfg.pass_threshold
        if merged.timeout_seconds is None:
            merged.timeout_seconds = global_cfg.timeout_seconds
        if merged.context is None:
            merged.context = global_cfg.context
        return merged
    # case 未声明 type：若 case 完全为空则用全局；否则把 case 非空字段叠加到全局上
    if case_cfg.is_empty():
        return global_cfg
    merged = JudgeConfig(
        type=global_cfg.type,
        script_path=case_cfg.script_path or global_cfg.script_path,
        model=case_cfg.model or global_cfg.model,
        criteria=case_cfg.criteria or global_cfg.criteria,
        skills=case_cfg.skills or global_cfg.skills,
        context=case_cfg.context or global_cfg.context,
        pass_threshold=(
            case_cfg.pass_threshold if case_cfg.pass_threshold is not None
            else global_cfg.pass_threshold
        ),
        timeout_seconds=(
            case_cfg.timeout_seconds if case_cfg.timeout_seconds is not None
            else global_cfg.timeout_seconds
        ),
        success=case_cfg.success or global_cfg.success,
        failure=case_cfg.failure or global_cfg.failure,
    )
    return merged


# ---------------------------------------------------------------------------
# cases
# ---------------------------------------------------------------------------

@dataclass
class RetryPolicy:
    max_retries: int = 0
    retry_on: list[str] = field(default_factory=list)   # timeout | error

    @classmethod
    def from_dict(cls, d: dict | None) -> "RetryPolicy":
        d = d or {}
        return cls(
            max_retries=int(d.get("max_retries", 0) or 0),
            retry_on=list(d.get("retry_on", []) or []),
        )


@dataclass
class CaseDefaults:
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS
    max_turns: int = DEFAULT_MAX_TURNS
    collect_artifacts: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict | None) -> "CaseDefaults":
        d = d or {}
        return cls(
            timeout_seconds=int(d.get("timeout_seconds", DEFAULT_TIMEOUT_SECONDS)
                                if d.get("timeout_seconds") is not None else DEFAULT_TIMEOUT_SECONDS),
            max_turns=int(d.get("max_turns", DEFAULT_MAX_TURNS)
                          if d.get("max_turns") is not None else DEFAULT_MAX_TURNS),
            collect_artifacts=list(d.get("collect_artifacts", []) or []),
        )


@dataclass
class CasesConfig:
    files: list[str] = field(default_factory=list)
    defaults: CaseDefaults = field(default_factory=CaseDefaults)
    parallelism: int = DEFAULT_PARALLELISM
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)

    @classmethod
    def from_dict(cls, d: dict | None) -> "CasesConfig":
        d = d or {}
        return cls(
            files=list(d.get("files", []) or []),
            defaults=CaseDefaults.from_dict(d.get("defaults")),
            parallelism=int(d.get("parallelism", DEFAULT_PARALLELISM) or DEFAULT_PARALLELISM),
            retry_policy=RetryPolicy.from_dict(d.get("retry_policy")),
        )


@dataclass
class Expect:
    must_contain: list[str] = field(default_factory=list)
    must_not_contain: list[str] = field(default_factory=list)
    exit_code: Optional[int] = None
    files_exist: list[str] = field(default_factory=list)
    files_not_exist: list[str] = field(default_factory=list)
    golden_file: str = ""
    file_contains: list[dict[str, str]] = field(default_factory=list)  # [{path, content}]

    @classmethod
    def from_dict(cls, d: dict | None) -> "Expect":
        d = d or {}
        return cls(
            must_contain=list(d.get("must_contain", []) or []),
            must_not_contain=list(d.get("must_not_contain", []) or []),
            exit_code=d.get("exit_code"),
            files_exist=list(d.get("files_exist", []) or []),
            files_not_exist=list(d.get("files_not_exist", []) or []),
            golden_file=d.get("golden_file", "") or "",
            file_contains=list(d.get("file_contains", []) or []),
        )

    def is_empty(self) -> bool:
        return not (
            self.must_contain or self.must_not_contain
            or self.exit_code is not None
            or self.files_exist or self.files_not_exist
            or self.golden_file or self.file_contains
        )


@dataclass
class PostCondition:
    must_contain_any: list[str] = field(default_factory=list)
    must_contain_all: list[str] = field(default_factory=list)
    must_not_contain: list[str] = field(default_factory=list)
    on_fail: str = "fail"            # fail | skip_remaining

    @classmethod
    def from_dict(cls, d: dict | None) -> Optional["PostCondition"]:
        if not d:
            return None
        return cls(
            must_contain_any=list(d.get("must_contain_any", []) or []),
            must_contain_all=list(d.get("must_contain_all", []) or []),
            must_not_contain=list(d.get("must_not_contain", []) or []),
            on_fail=d.get("on_fail", "fail") or "fail",
        )


@dataclass
class CaptureRule:
    variable: str = ""
    pattern: str = ""       # 正则，取第一个分组或整体
    jsonpath: str = ""      # 简化 JSONPath: $.a.b[0]

    @classmethod
    def from_dict(cls, d: dict | None) -> "CaptureRule":
        d = d or {}
        return cls(
            variable=d.get("variable", "") or "",
            pattern=d.get("pattern", "") or "",
            jsonpath=d.get("jsonpath", "") or "",
        )


@dataclass
class Turn:
    role: str = "user"
    content: str = ""
    post_condition: Optional[PostCondition] = None
    capture: list[CaptureRule] = field(default_factory=list)
    timeout_seconds: int = 0

    @classmethod
    def from_dict(cls, d: dict | None) -> "Turn":
        d = d or {}
        return cls(
            role=d.get("role", "user") or "user",
            content=d.get("content", "") or "",
            post_condition=PostCondition.from_dict(d.get("post_condition")),
            capture=[CaptureRule.from_dict(c) for c in (d.get("capture") or [])],
            timeout_seconds=int(d.get("timeout_seconds", 0) or 0),
        )


@dataclass
class CaseInput:
    prompt: str = ""
    turns: list[Turn] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict | None) -> "CaseInput":
        d = d or {}
        return cls(
            prompt=d.get("prompt", "") or "",
            turns=[Turn.from_dict(t) for t in (d.get("turns") or [])],
        )


@dataclass
class CaseContext:
    repo_fixture: str = ""
    files: dict[str, str] = field(default_factory=dict)   # path -> inline content

    @classmethod
    def from_dict(cls, d: dict | None) -> "CaseContext":
        d = d or {}
        return cls(
            repo_fixture=d.get("repo_fixture", "") or "",
            files=d.get("files", {}) or {},
        )


@dataclass
class Constraints:
    timeout_seconds: Optional[int] = None
    max_turns: Optional[int] = None

    @classmethod
    def from_dict(cls, d: dict | None) -> "Constraints":
        d = d or {}
        return cls(
            timeout_seconds=d.get("timeout_seconds"),
            max_turns=d.get("max_turns"),
        )


@dataclass
class CaseConfig:
    id: str = ""
    title: str = ""
    description: str = ""
    tag: str = ""                    # trigger_test | functional_test
    input: CaseInput = field(default_factory=CaseInput)
    context: CaseContext = field(default_factory=CaseContext)
    constraints: Constraints = field(default_factory=Constraints)
    expect: Expect = field(default_factory=Expect)
    judge: JudgeConfig = field(default_factory=JudgeConfig)
    collect_artifacts: list[str] = field(default_factory=list)
    source_file: str = ""            # loader 填充

    @classmethod
    def from_dict(cls, d: dict | None) -> "CaseConfig":
        d = d or {}
        return cls(
            id=d.get("id", "") or "",
            title=d.get("title", "") or "",
            description=d.get("description", "") or "",
            tag=d.get("tag", "") or "",
            input=CaseInput.from_dict(d.get("input")),
            context=CaseContext.from_dict(d.get("context")),
            constraints=Constraints.from_dict(d.get("constraints")),
            expect=Expect.from_dict(d.get("expect")),
            judge=JudgeConfig.from_dict(d.get("judge")),
            collect_artifacts=list(d.get("collect_artifacts", []) or []),
        )


# ---------------------------------------------------------------------------
# eval.yaml 顶层
# ---------------------------------------------------------------------------

@dataclass
class BenchmarkConfig:
    enabled: bool = False

    @classmethod
    def from_dict(cls, d: dict | None) -> "BenchmarkConfig":
        d = d or {}
        return cls(enabled=bool(d.get("enabled", False)))


@dataclass
class ReportConfig:
    formats: list[str] = field(default_factory=lambda: list(DEFAULT_REPORT_FORMATS))
    artifacts: list[str] = field(default_factory=list)   # transcript | logs

    @classmethod
    def from_dict(cls, d: dict | None) -> "ReportConfig":
        d = d or {}
        formats = d.get("formats")
        return cls(
            formats=list(formats) if formats else list(DEFAULT_REPORT_FORMATS),
            artifacts=list(d.get("artifacts", []) or []),
        )


@dataclass
class EvalConfig:
    schema_version: str = SCHEMA_VERSION
    environment: Environment = field(default_factory=Environment)
    skills: list[SkillRef] = field(default_factory=list)
    engine: EngineConfig = field(default_factory=EngineConfig)
    cases: CasesConfig = field(default_factory=CasesConfig)
    judge: JudgeConfig = field(default_factory=JudgeConfig)
    benchmark: BenchmarkConfig = field(default_factory=BenchmarkConfig)
    report: ReportConfig = field(default_factory=ReportConfig)

    @classmethod
    def from_dict(cls, d: dict | None) -> "EvalConfig":
        d = d or {}
        return cls(
            schema_version=d.get("schema_version", SCHEMA_VERSION) or SCHEMA_VERSION,
            environment=Environment.from_dict(d.get("environment")),
            skills=[SkillRef.from_dict(s) for s in (d.get("skills") or [])],
            engine=EngineConfig.from_dict(d.get("engine")),
            cases=CasesConfig.from_dict(d.get("cases")),
            judge=JudgeConfig.from_dict(d.get("judge")),
            benchmark=BenchmarkConfig.from_dict(d.get("benchmark")),
            report=ReportConfig.from_dict(d.get("report")),
        )
