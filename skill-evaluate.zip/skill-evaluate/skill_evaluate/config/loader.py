"""Loader：加载 eval.yaml + cases/*.yaml，应用默认值，定位 skill 根目录。"""
from __future__ import annotations

import os
from pathlib import Path

import yaml

from .schema import CaseConfig, EvalConfig

MAX_SKILL_DIR_SEARCH_DEPTH = 10


class ConfigError(Exception):
    pass


def find_skill_dir(start: str | Path) -> Path:
    """从 start 向上最多 10 层找 SKILL.md，定位 skill 根目录。

    找不到时返回 start 本身（文件则返回其父目录）。
    """
    p = Path(start).resolve()
    if p.is_file():
        p = p.parent
    for _ in range(MAX_SKILL_DIR_SEARCH_DEPTH):
        if (p / "SKILL.md").is_file():
            return p
        if p.parent == p:
            break
        p = p.parent
    p = Path(start).resolve()
    return p.parent if p.is_file() else p


class Loader:
    def __init__(self, skill_dir: str | Path):
        self.skill_dir = Path(skill_dir).resolve()

    # -- public API ---------------------------------------------------------

    def load_eval(self, eval_yaml: str | Path) -> EvalConfig:
        path = self._resolve(eval_yaml)
        if not path.is_file():
            raise ConfigError(f"eval.yaml 不存在: {path}")
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            raise ConfigError(f"eval.yaml 格式错误（应为 mapping）: {path}")
        cfg = EvalConfig.from_dict(data)
        if not cfg.cases.files:
            # 自动发现 cases 目录
            cases_dir = path.parent / "cases"
            if cases_dir.is_dir():
                cfg.cases.files = [
                    str(cases_dir / f) for f in sorted(os.listdir(cases_dir))
                    if f.endswith((".yaml", ".yml"))
                ]
        return cfg

    def load_case(self, case_file: str | Path) -> CaseConfig:
        path = self._resolve(case_file)
        if not path.is_file():
            raise ConfigError(f"case 文件不存在: {path}")
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            raise ConfigError(f"case 文件格式错误（应为 mapping）: {path}")
        case = CaseConfig.from_dict(data)
        case.source_file = str(path)
        if not case.id:
            case.id = path.stem
        return case

    def load_all(self, eval_yaml: str | Path) -> tuple[EvalConfig, list[CaseConfig]]:
        cfg = self.load_eval(eval_yaml)
        cases = [self.load_case(f) for f in cfg.cases.files]
        return cfg, cases

    # -- helpers ------------------------------------------------------------

    def _resolve(self, p: str | Path) -> Path:
        path = Path(p)
        if path.is_absolute():
            return path
        # 相对路径优先相对 skill 根目录，其次相对 cwd
        candidate = self.skill_dir / path
        if candidate.exists():
            return candidate
        return Path.cwd() / path
