"""Validator：校验 eval 配置与 case 配置。"""
from __future__ import annotations

from .schema import CaseConfig, EvalConfig

VALID_JUDGE_TYPES = {"", "rule_based", "script", "agent_judge"}
VALID_CASE_TAGS = {"", "trigger_test", "functional_test"}
VALID_RULE_KEYS = {
    "output_contains", "exit_code", "tool_called", "files_exist", "files_not_exist",
    "turn_response_contains", "turn_response_not_contains",
    "tool_called_in_turn", "tool_not_called_in_turn",
}


class ValidationError(Exception):
    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("\n".join(errors))


def validate_rule(rule, where: str, errors: list[str]) -> None:
    set_keys = [
        k for k in VALID_RULE_KEYS
        if getattr(rule, k) is not None
    ]
    if len(set_keys) == 0:
        errors.append(f"{where}: 规则必须设置一个字段 {sorted(VALID_RULE_KEYS)}")
    elif len(set_keys) > 1:
        errors.append(f"{where}: 规则只能设置一个字段, 实际设置了 {set_keys}")


def validate_judge(judge, where: str, errors: list[str]) -> None:
    if judge.type not in VALID_JUDGE_TYPES:
        errors.append(f"{where}: 不支持的 judge.type '{judge.type}'"
                      f"（可选: rule_based/script/agent_judge）")
    if judge.type == "script" and not judge.script_path:
        errors.append(f"{where}: judge.type=script 需要 script_path")
    if judge.pass_threshold is not None and not (0.0 <= judge.pass_threshold <= 1.0):
        errors.append(f"{where}: pass_threshold 必须在 [0, 1] 之间")
    for i, r in enumerate(judge.success):
        validate_rule(r, f"{where}.success[{i}]", errors)
    for i, r in enumerate(judge.failure):
        validate_rule(r, f"{where}.failure[{i}]", errors)


def validate_case(case: CaseConfig, errors: list[str]) -> None:
    where = f"case '{case.id or case.source_file}'"
    if not case.input.prompt and not case.input.turns:
        errors.append(f"{where}: input.prompt 或 input.turns 必须提供一个")
    if case.input.prompt and case.input.turns:
        errors.append(f"{where}: input.prompt 与 input.turns 不能同时设置")
    if case.tag not in VALID_CASE_TAGS:
        errors.append(f"{where}: 不支持的 tag '{case.tag}'")
    if case.constraints.timeout_seconds is not None and case.constraints.timeout_seconds == 0:
        errors.append(f"{where}: timeout_seconds 不能为 0（用 -1 表示不限制）")
    validate_judge(case.judge, f"{where}.judge", errors)


def validate_all(eval_cfg: EvalConfig, cases: list[CaseConfig]) -> None:
    errors: list[str] = []
    if eval_cfg.schema_version != "v1alpha1":
        errors.append(f"不支持的 schema_version '{eval_cfg.schema_version}'（仅支持 v1alpha1）")
    if eval_cfg.environment.type != "none":
        errors.append(f"environment.type '{eval_cfg.environment.type}' 暂不支持"
                      "（Python 版当前仅支持 none 本地执行）")
    if eval_cfg.engine.name != "litellm" and eval_cfg.engine.custom is None:
        errors.append(f"engine.name '{eval_cfg.engine.name}' 不是内置引擎且未配置 engine.custom"
                      "（Python 版内置引擎: litellm）")
    if eval_cfg.cases.parallelism < 1:
        errors.append("cases.parallelism 必须 >= 1")
    if not cases:
        errors.append("未加载到任何 case（检查 cases.files）")
    validate_judge(eval_cfg.judge, "judge", errors)
    seen_ids: set[str] = set()
    for case in cases:
        if case.id in seen_ids:
            errors.append(f"case id 重复: '{case.id}'")
        seen_ids.add(case.id)
        validate_case(case, errors)
    if errors:
        raise ValidationError(errors)
