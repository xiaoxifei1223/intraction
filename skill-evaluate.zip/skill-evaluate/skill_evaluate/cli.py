"""skill-evaluate CLI（对齐 Go 版 internal/cli）。

命令: run / validate / list-cases / report / import / init
"""
from __future__ import annotations

import argparse
import fnmatch
import logging
import sys
from pathlib import Path

from . import __version__
from .config import (
    ConfigError,
    Loader,
    ValidationError,
    find_skill_dir,
    validate_all,
)
from .config.schema import CaseConfig, EvalConfig
from .credentials import Credentials, mask_secret, resolve_credentials
from .engines import detect_engine
from .engines.base import read_skill_prompt_context
from .judges import Status
from .runner import Runner, utcnow

logger = logging.getLogger("skill_evaluate")


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _setup_logging(verbosity: int) -> None:
    level = logging.WARNING
    if verbosity == 1:
        level = logging.INFO
    elif verbosity >= 2:
        level = logging.DEBUG
    logging.basicConfig(level=level, format="%(levelname)s %(name)s: %(message)s")


def _load_dotenv() -> None:
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass


def _parse_model(model: str) -> tuple[str, str]:
    """'provider/name' -> (provider, name)；无 '/' 时 provider 为空。"""
    if "/" in model:
        provider, name = model.split("/", 1)
        return provider, name
    return "", model


def _filter_cases(cases: list[CaseConfig], include: list[str],
                  exclude: list[str]) -> list[CaseConfig]:
    out = []
    for c in cases:
        if include and not any(fnmatch.fnmatch(c.id, p) or fnmatch.fnmatch(c.title, p)
                               for p in include):
            continue
        if exclude and any(fnmatch.fnmatch(c.id, p) or fnmatch.fnmatch(c.title, p)
                           for p in exclude):
            continue
        out.append(c)
    return out


def _load_eval(args) -> tuple[EvalConfig, list[CaseConfig], Path, Loader]:
    """加载 eval.yaml（支持 --auto 探测 evals/eval.yaml 或 evals.json）。"""
    eval_path = getattr(args, "eval_yaml", None)
    if eval_path is None or (eval_path == "auto"):
        # auto 模式
        cwd = Path.cwd()
        for candidate in (cwd / "evals" / "eval.yaml", cwd / "eval.yaml"):
            if candidate.is_file():
                eval_path = str(candidate)
                break
        else:
            evals_json = cwd / "evals" / "evals.json"
            if evals_json.is_file():
                raise ConfigError(
                    f"检测到 Anthropic evals.json: {evals_json}\n"
                    f"请先运行: skill-evaluate import {evals_json} --output evals")
            raise ConfigError(
                "未找到 eval.yaml（尝试了 evals/eval.yaml, eval.yaml）。"
                "请显式指定: skill-evaluate run <path/to/eval.yaml>")
    skill_dir = find_skill_dir(eval_path)
    loader = Loader(skill_dir)
    eval_cfg, cases = loader.load_all(eval_path)
    return eval_cfg, cases, skill_dir, loader


def _resolve_judge_creds(eval_cfg: EvalConfig, runner_creds: Credentials,
                         args) -> Credentials:
    """judge 凭证链：judge.model 'provider/model' → provider 环境变量 → runner 兜底。"""
    judge_model = eval_cfg.judge.model or ""
    provider, name = _parse_model(judge_model) if judge_model else ("", "")
    if not provider and not name:
        return runner_creds
    creds = resolve_credentials(
        provider=provider or runner_creds.provider,
        model=name,
        cli_api_key=getattr(args, "api_key", "") or "",
        cli_base_url=getattr(args, "base_url", "") or "",
    )
    if not creds.api_key:
        creds.api_key = runner_creds.api_key
    if not creds.base_url:
        creds.base_url = runner_creds.base_url
    return creds


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------

def cmd_run(args) -> int:
    eval_cfg, cases, skill_dir, _loader = _load_eval(args)

    # CLI overrides
    if args.engine:
        eval_cfg.engine.name = args.engine
    if args.model:
        provider, name = _parse_model(args.model)
        if provider:
            eval_cfg.engine.model.provider = provider
        eval_cfg.engine.model.name = name
    if args.base_url:
        eval_cfg.engine.model.base_url = args.base_url
    if args.parallelism:
        eval_cfg.cases.parallelism = max(1, args.parallelism)
    if args.format:
        eval_cfg.report.formats = args.format

    cases = _filter_cases(cases, args.include_case_name or [],
                          args.exclude_case_name or [])
    if not cases:
        print("没有匹配的 case（检查 --include-case-name/--exclude-case-name）",
              file=sys.stderr)
        return 1

    try:
        validate_all(eval_cfg, cases)
    except ValidationError as e:
        print(f"配置校验失败:\n{e}", file=sys.stderr)
        return 1

    if args.dry_run:
        print(f"[dry-run] skill: {skill_dir}")
        print(f"[dry-run] engine: {eval_cfg.engine.name}, "
              f"model: {eval_cfg.engine.model.provider}/{eval_cfg.engine.model.name}")
        for c in cases:
            print(f"[dry-run] case: {c.id} ({c.title})")
        return 0

    # 凭证
    runner_creds = resolve_credentials(
        provider=eval_cfg.engine.model.provider,
        model=eval_cfg.engine.model.name,
        cli_api_key=args.api_key or "",
        cli_base_url=args.base_url or eval_cfg.engine.model.base_url,
    )
    judge_creds = _resolve_judge_creds(eval_cfg, runner_creds, args)
    logger.info("runner model=%s api_key=%s base_url=%s",
                runner_creds.model, mask_secret(runner_creds.api_key),
                runner_creds.base_url)

    # skill prompt 上下文（litellm 引擎的 skill 注入）
    skill_contents: dict[str, str] = {}
    for skill_ref in eval_cfg.skills:
        src = Path(skill_ref.path)
        if not src.is_absolute():
            src = skill_dir / src
        skill_contents["with_skill"] = (
            skill_contents.get("with_skill", "")
            + read_skill_prompt_context(src))

    engine = detect_engine(eval_cfg.engine, runner_creds,
                           skill_contents=skill_contents)
    engine.check()

    runner = Runner(
        eval_cfg, skill_dir, engine, runner_creds, judge_creds,
        output_dir=Path(args.output_dir) if args.output_dir else None,
    )
    start = utcnow()
    results, iteration_dir = runner.evaluate(cases, iteration=args.iteration)
    end = utcnow()
    runner.write_results(results, iteration_dir, start, end,
                         formats=eval_cfg.report.formats)

    # 汇总（只看 with_skill 决定退出码，对齐 Go 版）
    with_skill = [r for r in results if r.configuration == "with_skill"]
    n_pass = sum(1 for r in with_skill if r.status == Status.PASS)
    n_fail = sum(1 for r in with_skill if r.status == Status.FAIL)
    n_error = sum(1 for r in with_skill if r.status == Status.ERROR)
    print(f"\n=== Summary (with_skill) ===")
    print(f"PASS: {n_pass}  FAIL: {n_fail}  ERROR: {n_error}  "
          f"(total {len(with_skill)})")
    for r in with_skill:
        mark = {"PASS": "✅", "FAIL": "❌", "ERROR": "💥", "SKIP": "⏭️"}[r.status.value]
        line = f"{mark} {r.case_id}: {r.status.value} ({r.duration_ms / 1000:.1f}s)"
        if r.error:
            line += f" - {r.error[:120]}"
        print(line)
    print(f"\nreports: {iteration_dir}")
    return 1 if (n_fail or n_error) else 0


def cmd_validate(args) -> int:
    try:
        eval_cfg, cases, skill_dir, _ = _load_eval(args)
        validate_all(eval_cfg, cases)
    except (ConfigError, ValidationError) as e:
        print(f"校验失败:\n{e}", file=sys.stderr)
        return 1
    print(f"OK: {len(cases)} 个 case 校验通过 (skill: {skill_dir})")
    return 0


def cmd_list_cases(args) -> int:
    try:
        _eval_cfg, cases, _skill_dir, _ = _load_eval(args)
    except ConfigError as e:
        print(f"加载失败: {e}", file=sys.stderr)
        return 1
    print(f"{'ID':<32} {'TAG':<16} {'TITLE':<32} PROMPT")
    print("-" * 100)
    for c in cases:
        prompt = (c.input.prompt or "")[:50].replace("\n", " ")
        print(f"{c.id:<32} {c.tag:<16} {c.title[:30]:<32} {prompt}")
    return 0


def cmd_report(args) -> int:
    """从已有 result.json 重新生成报告。"""
    from .report import build_html, build_junit_xml

    result_json = Path(args.result_json)
    if not result_json.is_file():
        print(f"result.json 不存在: {result_json}", file=sys.stderr)
        return 1
    import json
    report_input = json.loads(result_json.read_text(encoding="utf-8"))
    out_dir = Path(args.output_dir) if args.output_dir else result_json.parent
    out_dir.mkdir(parents=True, exist_ok=True)
    formats = args.format or ["json"]
    for fmt in formats:
        fmt = fmt.strip().lower()
        if fmt == "json":
            (out_dir / "report.json").write_text(
                json.dumps(report_input, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8")
        elif fmt == "junit":
            (out_dir / "report.xml").write_text(
                build_junit_xml(report_input), encoding="utf-8")
        elif fmt == "html":
            (out_dir / "report.html").write_text(
                build_html(report_input), encoding="utf-8")
        print(f"written: {out_dir / {'json': 'report.json', 'junit': 'report.xml', 'html': 'report.html'}[fmt]}")
    return 0


def cmd_import(args) -> int:
    from .importer import ImportError_, import_evals_json

    try:
        eval_yaml = import_evals_json(args.evals_json, args.output)
    except (ImportError_, ValueError) as e:
        print(f"导入失败: {e}", file=sys.stderr)
        return 1
    print(f"导入完成: {eval_yaml}")
    print(f"运行: skill-evaluate run {eval_yaml} --model <provider/name> --api-key <key>")
    return 0


def cmd_init(args) -> int:
    """写用户配置文件模板（~/.skill-evaluate/credentials.yaml）。"""
    template = """# skill-evaluate 用户凭证配置
# 优先级: CLI --api-key > <PROVIDER>_API_KEY 环境变量 > LITELLM_API_KEY > 本文件
providers:
  openai:
    api_key: ""
    base_url: ""
  anthropic:
    api_key: ""
    base_url: ""
  dashscope:
    api_key: ""
    base_url: ""
"""
    path = Path.home() / ".skill-evaluate" / "credentials.yaml"
    if args.print:
        print(template)
        return 0
    if path.exists() and not args.force:
        print(f"已存在: {path}（用 --force 覆盖）", file=sys.stderr)
        return 1
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(template, encoding="utf-8")
    print(f"written: {path}")
    return 0


# ---------------------------------------------------------------------------
# argparse
# ---------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="skill-evaluate",
        description="Agent Skill 评估与进化工具（Python 版，LLM 经 litellm 访问）")
    p.add_argument("--version", action="version", version=f"skill-evaluate {__version__}")
    p.add_argument("-v", "--verbose", action="count", default=0,
                   help="-v info, -vv debug")
    sub = p.add_subparsers(dest="command", required=True)

    def add_common(sp, positional: bool = True):
        if positional:
            sp.add_argument("eval_yaml", nargs="?", default="auto",
                            help="eval.yaml 路径（缺省自动探测 evals/eval.yaml）")

    sp = sub.add_parser("run", help="运行评估")
    add_common(sp)
    sp.add_argument("--include-case-name", action="append",
                    help="只运行匹配的 case（glob，可多次）")
    sp.add_argument("--exclude-case-name", action="append",
                    help="排除匹配的 case（glob，可多次）")
    sp.add_argument("--format", action="append",
                    help="报告格式 json/junit/html（可多次）")
    sp.add_argument("--output-dir", help="报告输出目录（默认 <skill>-workspace/）")
    sp.add_argument("--engine", help="覆盖 engine.name（litellm 或自定义引擎名）")
    sp.add_argument("--model", help="覆盖模型，格式 provider/name 或 name")
    sp.add_argument("--api-key", help="litellm API key（最高优先级）")
    sp.add_argument("--base-url", help="自定义 API base url")
    sp.add_argument("--parallelism", type=int, help="并发度（覆盖 cases.parallelism）")
    sp.add_argument("--iteration", type=int, default=0,
                    help="迭代编号；0 = 自动递增")
    sp.add_argument("--dry-run", action="store_true", help="只打印计划，不执行")
    sp.set_defaults(func=cmd_run)

    sp = sub.add_parser("validate", help="校验 eval 配置")
    add_common(sp)
    sp.set_defaults(func=cmd_validate)

    sp = sub.add_parser("list-cases", help="列出所有 case")
    add_common(sp)
    sp.set_defaults(func=cmd_list_cases)

    sp = sub.add_parser("report", help="从 result.json 重新生成报告")
    sp.add_argument("result_json", help="result.json 路径")
    sp.add_argument("--format", action="append", help="json/junit/html（可多次）")
    sp.add_argument("--output-dir", help="输出目录（默认 result.json 同目录）")
    sp.set_defaults(func=cmd_report)

    sp = sub.add_parser("import", help="导入 Anthropic evals.json")
    sp.add_argument("evals_json", help="evals.json 路径")
    sp.add_argument("--output", default="evals", help="输出目录（默认 evals/）")
    sp.set_defaults(func=cmd_import)

    sp = sub.add_parser("init", help="初始化用户凭证配置")
    sp.add_argument("--print", action="store_true", help="只打印模板")
    sp.add_argument("--force", action="store_true", help="覆盖已有文件")
    sp.set_defaults(func=cmd_init)

    return p


def main(argv: list[str] | None = None) -> int:
    # Windows 控制台默认 GBK，统一 stdout/stderr 为 UTF-8
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    parser = build_parser()
    args = parser.parse_args(argv)
    _setup_logging(args.verbose)
    _load_dotenv()
    try:
        return args.func(args)
    except ConfigError as e:
        print(f"配置错误: {e}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
