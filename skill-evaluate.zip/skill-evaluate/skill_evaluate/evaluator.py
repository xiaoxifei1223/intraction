"""Evaluator：单 case 生命周期编排（对齐 Go 版 internal/evaluator/evaluator.go）。

调用链：
  prepareCaseWorkspace(fixtures/skill 安装) → 构建 messages
  → engine.run / 多轮 run_turn(post_condition + capture)
  → expect 短路预检 → judge 评分 → EvalResult
"""
from __future__ import annotations

import json
import re
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .config.schema import CaseConfig, EvalConfig, Turn, merge_judge_config
from .credentials import Credentials
from .engines.base import Engine, ExecOptions, SessionResult, install_skill_files
from .judges import (
    JudgeInput,
    Result,
    Status,
    check_expect,
    new_judge,
    new_result,
)
from .transcript import Message, Transcript


@dataclass
class TurnResult:
    turn: int = 0
    status: str = "completed"          # completed | failed | skipped
    response: str = ""
    duration_ms: int = 0
    post_condition_passed: Optional[bool] = None
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "turn": self.turn, "status": self.status, "response": self.response,
            "duration_ms": self.duration_ms,
            "post_condition_passed": self.post_condition_passed,
            "error": self.error,
        }


@dataclass
class EvalResult:
    case_id: str = ""
    case_name: str = ""
    prompt: str = ""
    configuration: str = "with_skill"   # with_skill | without_skill
    status: Status = Status.PASS
    session: Optional[SessionResult] = None
    grading: Optional[Result] = None
    turns_total: int = 0
    turn_results: list[TurnResult] = field(default_factory=list)
    error: Optional[str] = None
    duration_ms: int = 0

    @property
    def final_message(self) -> str:
        return self.session.final_message if self.session else ""

    @property
    def exit_code(self) -> int:
        return self.session.exit_code if self.session else -1


@dataclass
class EvaluatorOptions:
    eval_cfg: EvalConfig
    skill_dir: Path
    workspace_root: Path           # iteration 目录
    engine: Engine
    runner_creds: Credentials
    judge_creds: Credentials
    with_baseline: bool = False    # benchmark.enabled → 跑 without_skill
    keep_workspace: bool = False


class Evaluator:
    def __init__(self, opts: EvaluatorOptions):
        self.opts = opts

    # -- public -------------------------------------------------------------

    def evaluate_all(self, cases: list[CaseConfig]) -> list[EvalResult]:
        variants = ["with_skill"] + (["without_skill"] if self.opts.with_baseline else [])
        results: list[EvalResult] = []
        for case in cases:
            for variant in variants:
                results.append(self.execute_with_retry(case, variant))
        return results

    def execute_with_retry(self, case: CaseConfig, variant: str) -> EvalResult:
        policy = self.opts.eval_cfg.cases.retry_policy
        max_attempts = 1 + max(0, policy.max_retries)
        last: Optional[EvalResult] = None
        for attempt in range(max_attempts):
            result = self.execute_case(case, variant)
            last = result
            if result.status != Status.ERROR:
                return result
            kind = "timeout" if (result.error and "timeout" in result.error.lower()) else "error"
            if kind not in policy.retry_on and "error" not in policy.retry_on:
                return result
            if attempt < max_attempts - 1:
                time.sleep(min(2 ** attempt, 30))  # 指数退避
        return last  # type: ignore[return-value]

    def execute_case(self, case: CaseConfig, variant: str) -> EvalResult:
        defaults = self.opts.eval_cfg.cases.defaults
        timeout = (case.constraints.timeout_seconds
                   if case.constraints.timeout_seconds is not None
                   else defaults.timeout_seconds)
        max_turns = (case.constraints.max_turns
                     if case.constraints.max_turns is not None
                     else defaults.max_turns)

        workspace = self._prepare_workspace(case, variant)
        exec_opts = ExecOptions(
            workspace=workspace,
            timeout_sec=timeout,
            max_turns=max_turns,
            case_id=case.id,
            variant=variant,
        )
        result = EvalResult(
            case_id=case.id,
            case_name=case.title or case.id,
            prompt=case.input.prompt or (case.input.turns[0].content if case.input.turns else ""),
            configuration=variant,
        )
        start = time.monotonic()
        try:
            if case.input.turns:
                session, turn_results = self._execute_multi_turn(case, exec_opts)
                result.turn_results = turn_results
                result.turns_total = len(case.input.turns)
            else:
                messages = [Message(role="user", content=case.input.prompt, turn=1)]
                session = self.opts.engine.run(exec_opts, messages)
                result.turns_total = 1
            result.session = session
        except Exception as e:
            result.status = Status.ERROR
            result.error = str(e)
            result.duration_ms = int((time.monotonic() - start) * 1000)
            return result
        result.duration_ms = int((time.monotonic() - start) * 1000)

        # 非零 exit code 且无 expect/judge 处理 → FAIL（对齐 Go handleExecutionResult）
        judge_cfg = merge_judge_config(self.opts.eval_cfg.judge, case.judge)
        if session.exit_code != 0 and case.expect.exit_code is None and not judge_cfg.type:
            result.status = Status.FAIL
            result.grading = new_result([])
            result.grading.status = Status.FAIL
            result.grading.error_reason = f"agent 退出码非零: {session.exit_code}"
            return result

        self._evaluate_session(case, judge_cfg, result)
        return result

    # -- multi-turn ---------------------------------------------------------

    def _execute_multi_turn(
        self, case: CaseConfig, exec_opts: ExecOptions
    ) -> tuple[SessionResult, list[TurnResult]]:
        engine = self.opts.engine
        if not hasattr(engine, "run_turn"):
            raise RuntimeError(f"引擎 {engine.name()} 不支持多轮会话")

        variables: dict[str, str] = {}
        history: list[dict] = []
        if hasattr(engine, "build_system_messages"):
            history.extend(engine.build_system_messages(exec_opts.variant))

        transcript = Transcript()
        turn_results: list[TurnResult] = []
        final_text = ""
        total_in = total_out = 0
        total_ms = 0

        for i, turn in enumerate(case.input.turns, start=1):
            content = _render_turn_variables(turn.content, variables)
            transcript.add(Message(role="user", content=content, turn=i))
            tr = TurnResult(turn=i)
            try:
                text, in_tok, out_tok, ms = engine.run_turn(  # type: ignore[attr-defined]
                    exec_opts, history, content, i)
            except Exception as e:
                tr.status = "failed"
                tr.error = str(e)
                turn_results.append(tr)
                raise
            tr.response = text
            tr.duration_ms = ms
            total_in += in_tok
            total_out += out_tok
            total_ms += ms
            final_text = text
            transcript.add(Message(role="assistant", content=text, turn=i))

            # capture 变量捕获
            for cap in turn.capture:
                value = _capture(cap.pattern, cap.jsonpath, text)
                if value is not None:
                    variables[cap.variable] = value

            # post_condition 检查
            if turn.post_condition:
                pc_ok, pc_evidence = _check_post_condition(turn.post_condition, text)
                tr.post_condition_passed = pc_ok
                if not pc_ok:
                    tr.status = "failed"
                    tr.error = f"post_condition 未满足: {pc_evidence}"
                    turn_results.append(tr)
                    if turn.post_condition.on_fail == "skip_remaining":
                        for j in range(i + 1, len(case.input.turns) + 1):
                            turn_results.append(TurnResult(turn=j, status="skipped"))
                        break
                    raise RuntimeError(f"turn {i} post_condition 失败: {pc_evidence}")
            turn_results.append(tr)

        session = SessionResult(
            engine=engine.name(),
            exit_code=0,
            duration_ms=total_ms,
            turns=len([t for t in turn_results if t.status == "completed"]),
            input_tokens=total_in,
            output_tokens=total_out,
            final_message=final_text,
            transcript=transcript,
        )
        return session, turn_results

    # -- judge phase ----------------------------------------------------------

    def _evaluate_session(self, case: CaseConfig, judge_cfg, result: EvalResult) -> None:
        session = result.session
        assert session is not None
        judge_input = JudgeInput(
            case_id=case.id,
            final_message=session.final_message,
            exit_code=session.exit_code,
            workspace_path=self._case_workspace(case, result.configuration),
            skill_dir=self.opts.skill_dir,
            transcript=session.transcript,
            turn_results=[t.to_dict() for t in result.turn_results],
            session_result=session,
        )

        # expect 短路预检：任一失败 → 立即 FAIL，跳过 judge
        expect_result = check_expect(case.expect, judge_input)
        expect_assertions = expect_result.to_assertion_results()
        if not expect_result.all_passed:
            result.status = Status.FAIL
            result.grading = new_result(expect_assertions)
            return

        judge = new_judge(judge_cfg, self.opts.skill_dir, self.opts.judge_creds)
        if judge is None:
            # 无 judge：expect 通过即 PASS
            result.grading = new_result(expect_assertions)
            result.status = result.grading.status
            return

        grading = judge.evaluate(judge_input)
        if grading.status == Status.ERROR:
            result.status = Status.ERROR
            result.error = grading.error_reason
            result.grading = grading
            return
        # expect 断言 prepend 进最终 grading 并重算 summary
        grading.assertion_results = expect_assertions + grading.assertion_results
        merged = new_result(grading.assertion_results)
        # 保留 judge 的阈值判定（agent_judge 已按 pass_threshold 算过 status）
        merged.status = grading.status if expect_result.all_passed else Status.FAIL
        if not expect_result.all_passed:
            merged.status = Status.FAIL
        result.grading = merged
        result.status = merged.status

    # -- workspace ------------------------------------------------------------

    def _case_workspace(self, case: CaseConfig, variant: str) -> Path:
        return self.opts.workspace_root / case.id / variant

    def _prepare_workspace(self, case: CaseConfig, variant: str) -> Path:
        ws = self._case_workspace(case, variant)
        if ws.exists():
            shutil.rmtree(ws)
        ws.mkdir(parents=True, exist_ok=True)

        # fixtures：inline files
        for rel, content in case.context.files.items():
            target = (ws / rel).resolve()
            if not str(target).startswith(str(ws.resolve())):
                raise ValueError(f"context.files 路径逃逸 workspace: {rel}")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content, encoding="utf-8")

        # fixtures：repo_fixture 目录拷贝
        if case.context.repo_fixture:
            src = Path(case.context.repo_fixture)
            if not src.is_absolute():
                src = self.opts.skill_dir / src
            if src.is_dir():
                for item in sorted(src.rglob("*")):
                    if item.is_file():
                        rel = item.relative_to(src)
                        dst = ws / rel
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(item, dst)

        # skill 安装到 workspace（供 expect.files_exist / script judge 检查）
        if variant == "with_skill":
            for skill_ref in self.opts.eval_cfg.skills:
                src = Path(skill_ref.path)
                if not src.is_absolute():
                    src = self.opts.skill_dir / src
                install_skill_files(src, ws, target=skill_ref.target)
        return ws


# -- helpers -----------------------------------------------------------------

_VAR_PATTERN = re.compile(r"\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}")


def _render_turn_variables(content: str, variables: dict[str, str]) -> str:
    return _VAR_PATTERN.sub(lambda m: variables.get(m.group(1), m.group(0)), content)


def _capture(pattern: str, jsonpath: str, text: str) -> Optional[str]:
    if pattern:
        m = re.search(pattern, text, re.DOTALL)
        if m:
            return m.group(1) if m.groups() else m.group(0)
        return None
    if jsonpath:
        return _jsonpath_extract(jsonpath, text)
    return None


def _jsonpath_extract(jsonpath: str, text: str) -> Optional[str]:
    """简化 JSONPath: $.a.b[0]；先在 text 中找 JSON 对象。"""
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return None
    if not jsonpath.startswith("$."):
        return None
    cur = data
    for part in jsonpath[2:].split("."):
        mm = re.match(r"([^\[\]]+)(?:\[(\d+)\])?", part)
        if not mm:
            return None
        key, idx = mm.group(1), mm.group(2)
        if not isinstance(cur, dict) or key not in cur:
            return None
        cur = cur[key]
        if idx is not None:
            if not isinstance(cur, list) or int(idx) >= len(cur):
                return None
            cur = cur[int(idx)]
    return cur if isinstance(cur, str) else json.dumps(cur, ensure_ascii=False)


def _check_post_condition(pc, text: str) -> tuple[bool, str]:
    for s in pc.must_contain_all:
        if s not in text:
            return False, f"must_contain_all 缺少 '{s}'"
    if pc.must_contain_any and not any(s in text for s in pc.must_contain_any):
        return False, f"must_contain_any 均未命中 {pc.must_contain_any}"
    for s in pc.must_not_contain:
        if s in text:
            return False, f"must_not_contain 命中 '{s}'"
    return True, ""
