"""skill-evaluate: Agent Skill 评估与进化工具（Python 版）。

Go 版 alibaba/skill-up 的 Python 3.12 移植，LLM 访问统一走 litellm + api_key。
"""
import os as _os

# 使用 litellm 本地 model cost map，避免离线环境下的远程拉取告警
_os.environ.setdefault("LITELLM_LOCAL_MODEL_COST_MAP", "True")

__version__ = "0.1.0"
