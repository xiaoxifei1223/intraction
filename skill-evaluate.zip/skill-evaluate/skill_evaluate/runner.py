"""Runner：迭代级编排（对齐 Go 版 internal/runner/runner.go）。

- workspace 默认位于 skill 目录同级的 <skill>-workspace/
- --iteration 0 时自动找 iteration-N 下一个编号
- parallelism 并发执行 case，retry_policy 在 evaluator 内处理
"""
from __future__ import annotations

import logging
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

from .config.schema import CaseConfig, EvalConfig
from .credentials import Credentials
from .engines.base import Engine
from .evaluator import EvalResult, Evaluator, EvaluatorOptions
from .report.reporter import write_results

logger = logging.getLogger("skill_evaluate.runner")


class Runner:
    def __init__(
        self,
        eval_cfg: EvalConfig,
        skill_dir: Path,
        engine: Engine,
        runner_creds: Credentials,
        judge_creds: Credentials,
        output_dir: Path | None = None,
    ):
        self.eval_cfg = eval_cfg
        self.skill_dir = Path(skill_dir)
        self.engine = engine
        self.runner_creds = runner_creds
        self.judge_creds = judge_creds
        self._output_dir = Path(output_dir) if output_dir else None

    # -- workspace / iteration ------------------------------------------------

    def workspace_root(self) -> Path:
        if self._output_dir:
            return self._output_dir
        return self.skill_dir.parent / f"{self.skill_dir.name}-workspace"

    def resolve_iteration_dir(self, iteration: int) -> Path:
        root = self.workspace_root()
        if iteration > 0:
            return root / f"iteration-{iteration}"
        return root / f"iteration-{self.next_iteration_number(root)}"

    @staticmethod
    def next_iteration_number(root: Path) -> int:
        max_n = 0
        if root.is_dir():
            for child in root.iterdir():
                m = re.fullmatch(r"iteration-(\d+)", child.name)
                if m:
                    max_n = max(max_n, int(m.group(1)))
        return max_n + 1

    # -- run ------------------------------------------------------------------

    def evaluate(
        self, cases: list[CaseConfig], iteration: int = 0
    ) -> tuple[list[EvalResult], Path]:
        iteration_dir = self.resolve_iteration_dir(iteration)
        iteration_dir.mkdir(parents=True, exist_ok=True)
        logger.info("workspace: %s", iteration_dir)

        evaluator = Evaluator(EvaluatorOptions(
            eval_cfg=self.eval_cfg,
            skill_dir=self.skill_dir,
            workspace_root=iteration_dir,
            engine=self.engine,
            runner_creds=self.runner_creds,
            judge_creds=self.judge_creds,
            with_baseline=self.eval_cfg.benchmark.enabled,
        ))

        variants = ["with_skill"] + (
            ["without_skill"] if self.eval_cfg.benchmark.enabled else [])
        tasks = [(case, variant) for case in cases for variant in variants]

        parallelism = max(1, self.eval_cfg.cases.parallelism)
        results: list[EvalResult] = []
        if parallelism <= 1:
            for case, variant in tasks:
                results.append(evaluator.execute_with_retry(case, variant))
        else:
            with ThreadPoolExecutor(max_workers=parallelism) as pool:
                futures = {
                    pool.submit(evaluator.execute_with_retry, case, variant): (case.id, variant)
                    for case, variant in tasks
                }
                for fut in as_completed(futures):
                    case_id, variant = futures[fut]
                    try:
                        r = fut.result()
                    except Exception as e:  # 兜底：不应到达（evaluator 内部已捕获）
                        logger.exception("case %s (%s) 执行异常", case_id, variant)
                        from .judges import Status
                        r = EvalResult(case_id=case_id, configuration=variant,
                                       status=Status.ERROR, error=str(e))
                    results.append(r)
                    logger.info("[%s/%s] %s", case_id, variant, r.status.value)
        # 稳定排序：case 顺序 → with_skill 在前
        order = {c.id: i for i, c in enumerate(cases)}
        results.sort(key=lambda r: (order.get(r.case_id, 999), r.configuration != "with_skill"))
        return results, iteration_dir

    def write_results(
        self,
        results: list[EvalResult],
        iteration_dir: Path,
        start_time: datetime,
        end_time: datetime,
        formats: list[str],
        run_number: int = 1,
    ) -> dict:
        model_name = self.runner_creds.model
        if self.runner_creds.provider:
            model_name = f"{self.runner_creds.provider}/{model_name}"
        return write_results(
            results=results,
            output_dir=iteration_dir,
            skill_name=self.skill_dir.name,
            skill_path=str(self.skill_dir),
            engine_name=self.engine.name(),
            model_name=model_name,
            start_time=start_time,
            end_time=end_time,
            formats=formats,
            run_number=run_number,
        )


def utcnow() -> datetime:
    return datetime.now(timezone.utc)
