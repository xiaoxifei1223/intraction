# skill-evaluate

**Agent Skill 评估与进化工具(Python 3.12)** — Go 版 [alibaba/skill-up](../skill-up-main) 的 Python 移植。

与 Go 版的最大区别:**LLM 访问统一走 [litellm](https://github.com/BerriAI/litellm) + API key**。
Go 版通过外部 Agent CLI(claude / codex / qodercli 等)子进程调用模型;Python 版直接通过
`litellm.completion(model="provider/name", api_key=..., base_url=...)` 访问任意 provider
(openai / anthropic / dashscope / azure / deepseek / moonshot / ollama …),runner 执行和
agent_judge 裁判都走这一条通道。

---

# 一步一步使用教程

## 第 1 步:环境准备

要求 **Python ≥ 3.12**。检查:

```bash
python --version        # 应显示 Python 3.12.x
```

## 第 2 步:安装

```bash
cd D:\MyCode\skill-evaluate

# 创建虚拟环境
python -m venv .venv

# 安装(Windows)
.venv/Scripts/pip install -e .
# 安装(Linux/macOS)
# .venv/bin/pip install -e .
```

验证安装成功:

```bash
.venv/Scripts/skill-evaluate --version
# 输出: skill-evaluate 0.1.0
```

> 下面的命令都以 Windows 为例。Linux/macOS 把 `.venv/Scripts/skill-evaluate`
> 换成 `.venv/bin/skill-evaluate` 即可。如果已 `activate` 虚拟环境,直接写 `skill-evaluate`。

## 第 3 步:配置 API key

工具按下面的优先级找 key(找到即止):

```
CLI --api-key  >  <PROVIDER>_API_KEY 环境变量  >  LITELLM_API_KEY  >  ~/.skill-evaluate/credentials.yaml  >  .env
```

**方式 A:环境变量(推荐)**

```bash
# Windows Git Bash
export DASHSCOPE_API_KEY=sk-xxx
# Windows CMD
set DASHSCOPE_API_KEY=sk-xxx
# Windows PowerShell
$env:DASHSCOPE_API_KEY="sk-xxx"
```

provider 环境变量名规则:provider 名大写 + `_API_KEY`,例如
`OPENAI_API_KEY`、`ANTHROPIC_API_KEY`、`DEEPSEEK_API_KEY`、`MOONSHOT_API_KEY`、`DASHSCOPE_API_KEY`。

**方式 B:凭证文件(多 provider 时方便)**

```bash
.venv/Scripts/skill-evaluate init
# 生成 ~/.skill-evaluate/credentials.yaml,编辑填入你的 key
```

```yaml
providers:
  dashscope:
    api_key: "sk-xxx"
  openai:
    api_key: "sk-yyy"
    base_url: ""             # 自定义端点填这里
```

**方式 C:命令行直传(临时用)**

```bash
skill-evaluate run evals/eval.yaml --api-key sk-xxx
```

## 第 4 步:跑通自带示例(验证一切正常)

```bash
cd D:\MyCode\skill-evaluate\examples\code-stats

# 先校验配置是否正确(不调 LLM,免费)
../../.venv/Scripts/skill-evaluate validate evals/eval.yaml
# 输出: OK: 2 个 case 校验通过

# 看看有哪些 case(不调 LLM)
../../.venv/Scripts/skill-evaluate list-cases evals/eval.yaml

# dry-run:打印执行计划,不真正调用(不调 LLM)
../../.venv/Scripts/skill-evaluate run evals/eval.yaml --api-key sk-dry --dry-run

# 真实运行(会调 LLM,产生少量 token 消耗)
../../.venv/Scripts/skill-evaluate run evals/eval.yaml --model dashscope/qwen-plus
```

看到类似输出即成功:

```
=== Summary (with_skill) ===
PASS: 2  FAIL: 0  ERROR: 0  (total 2)
✅ analyze-directory: PASS (4.1s)
✅ rule-based-format: PASS (3.2s)

reports: D:\MyCode\skill-evaluate\examples\code-stats-workspace\iteration-1
```

## 第 5 步:看懂报告

运行结束后,报告写在 `<skill目录>-workspace/iteration-<N>/`:

```
code-stats-workspace/iteration-1/
├── result.json          # 原始事实源:每个 case 的状态/token/响应/grading 全量
├── benchmark.json       # Anthropic 兼容的汇总:with_skill vs without_skill 统计
├── benchmark.md         # 人可读的 markdown 汇总表(直接贴进 PR/文档)
├── report.json          # 格式化报告(--format json)
├── report.xml           # JUnit XML(--format junit,CI 用)
├── report.html          # 网页报告(--format html,浏览器打开)
└── <case-id>/
    ├── eval_metadata.json
    ├── with_skill/
    │   ├── outputs/response.md     # 模型装了 skill 时的完整回答
    │   └── grading.json            # 逐条断言:text/passed/evidence
    └── without_skill/              # benchmark.enabled: true 时才有
        ├── outputs/response.md     # 不装 skill 的基线回答
        └── grading.json
```

最快的看法:**浏览器打开 `report.html`**,或 `cat benchmark.md`。

`grading.json` 里每一条断言长这样:

```json
{
  "text": "success.output_contains.all: ['Total Files', 'Total Lines']",
  "passed": true,
  "evidence": "全部命中"
}
```

## 第 6 步:为你自己的 Skill 创建评估

假设你的 skill 在 `D:\MyCode\my-skills\my-skill\`,里面有 `SKILL.md`。

**6.1 建目录结构**

```
my-skill/
├── SKILL.md                 # 你的被测 skill(必须叫这个名字)
└── evals/
    ├── eval.yaml            # 评估总配置
    └── cases/               # 每个文件是一个测试用例
        └── case-1.yaml
```

**6.2 写 eval.yaml(最小配置)**

```yaml
schema_version: v1alpha1

skills:
  - source: local_path
    path: .                  # skill 目录(相对 eval.yaml 所在的 skill 根)

engine:
  name: litellm
  model:
    provider: dashscope      # litellm provider 名
    name: qwen-plus          # 模型名

cases:
  files:
    - evals/cases/case-1.yaml

judge:
  type: rule_based           # 先用最简单的规则裁判

report:
  formats: [json, html]
```

**6.3 写第一个 case**

```yaml
# evals/cases/case-1.yaml
id: basic-usage
title: 基本使用场景
input:
  prompt: |
    这里写一段模拟用户真实请求的提示词,
    触发你的 skill 应该处理的场景。
expect:                      # 短路预检:不满足直接 FAIL,不浪费 judge
  must_contain: ["关键词A"]
  must_not_contain: ["I cannot", "无法"]
judge:
  type: rule_based
  success:                   # 全部通过才 PASS
    - output_contains:
        all: ["关键词A", "关键词B"]
  failure:                   # 任一命中立即 FAIL
    - output_contains:
        not: ["作为一个AI", "I cannot"]
```

**6.4 校验并运行**

```bash
cd D:\MyCode\my-skills\my-skill
D:\MyCode\skill-evaluate\.venv\Scripts\skill-evaluate validate evals/eval.yaml
D:\MyCode\skill-evaluate\.venv\Scripts\skill-evaluate run evals/eval.yaml
```

## 第 7 步:选择合适的 judge(三种)

| judge 类型 | 适用场景 | 成本 | 配置要点 |
|---|---|---|---|
| `rule_based` | 输出包含/不包含关键词、退出码、文件是否存在、工具是否调用 | 免费 | `success`(全过)+ `failure`(任一即 FAIL) |
| `script` | 需要复杂校验逻辑(JSON 结构、数值比较、调用外部工具) | 免费 | 脚本 exit 0 = PASS,非 0 = FAIL |
| `agent_judge` | 开放式质量评估(代码评审质量、回答是否解决了问题) | 一次额外 LLM 调用 | `criteria` 列表 + `pass_threshold`(默认 0.7) |

**script judge 示例**(脚本里能读到 3 个环境变量):

```yaml
judge:
  type: script
  script_path: evals/scripts/check.sh    # .sh/.py/.js 都可以,自动识别解释器
  timeout_seconds: 30
```

脚本内可用环境变量:`EVAL_FINAL_MESSAGE`(模型最终回答)、`EVAL_EXIT_CODE`、`EVAL_TRANSCRIPT_PATH`(对话记录 JSON 路径)。

**agent_judge 示例**:

```yaml
judge:
  type: agent_judge
  model: dashscope/qwen-plus       # 裁判模型,可以和被测模型不同
  criteria:                        # 每条标准独立判定 true/false
    - "回答正确识别了空指针问题"
    - "给出了具体的修复建议"
    - "输出包含 Strengths/Issues 结构"
  pass_threshold: 0.7              # 通过率 ≥ 0.7 才算 PASS
```

## 第 8 步:跑 benchmark(证明 skill 有价值)

在 eval.yaml 里加一行:

```yaml
benchmark:
  enabled: true
```

重跑后,每个 case 会跑两遍:**装 skill** 和 **不装 skill(基线)**,
`benchmark.md` 会给出对比和 delta:

```
| Configuration | Pass Rate (mean) | Delta |
| with_skill    | 100.00%          | +0.17 |
| without_skill | 83.33%           |       |
```

delta 为正说明你的 skill 确实提升了模型表现——这就是"评估驱动进化"的核心指标。

## 第 9 步:进化循环(评估 → 改进 → 再评估)

```bash
# 第 1 轮:建立基线
skill-evaluate run evals/eval.yaml        # 自动写到 iteration-1

# 根据 grading.json 里失败的断言,修改 SKILL.md 或补充 case

# 第 2 轮:验证改进(自动写到 iteration-2,互不覆盖)
skill-evaluate run evals/eval.yaml

# 对比两轮的 benchmark.md,确认 pass rate 提升
```

也可以显式指定迭代号:`--iteration 3`。

**进化技巧**:
- case 失败 → 看 `<case-id>/with_skill/outputs/response.md` 里模型到底回答了什么
- 看 `grading.json` 里 `passed: false` 的断言和 evidence,定位是 skill 写得不清还是 case 期望不合理
- 修 skill 后 pass rate 上升 = 有效改进;把修过的场景固化为新 case = 回归保障

## 第 10 步(可选):导入 Anthropic 格式的 evals.json

如果你的 skill 已有 Anthropic skill-creator 风格的 `evals.json`:

```bash
skill-evaluate import path/to/evals.json --output evals
# 自动生成 evals/eval.yaml + evals/cases/*.yaml
# 每条 expectation 自动转成 agent_judge 的 criterion
skill-evaluate run evals/eval.yaml --model dashscope/qwen-plus
```

## 第 11 步(可选):CI 集成

```bash
# 退出码:any FAIL/ERROR → 1,全 PASS → 0
skill-evaluate run evals/eval.yaml --format junit --format json
```

JUnit 报告在 `<skill>-workspace/iteration-N/report.xml`,可直接被
Jenkins/GitHub Actions 的 JUnit 插件消费。

## 常见问题

**Q: 自定义 API 端点(代理/私有部署)怎么配?**

```bash
skill-evaluate run evals/eval.yaml --model openai/gpt-4o \
    --api-key sk-xxx --base-url https://your-proxy/v1
```

**Q: 裁判模型想和被测模型用不同的?**

eval.yaml 里 `engine.model` 是被测模型,`judge.model` 单独指定裁判模型:

```yaml
judge:
  type: agent_judge
  model: openai/gpt-4o      # 裁判用更强的模型
```

**Q: 只想跑某一个 case?**

```bash
skill-evaluate run evals/eval.yaml --include-case-name "basic-*"
skill-evaluate run evals/eval.yaml --exclude-case-name "slow-*"
```

**Q: 并发加速?**

```bash
skill-evaluate run evals/eval.yaml --parallelism 4
# 注意 provider 的 RPM 限流
```

**Q: 已有 result.json,想重新出 HTML 报告?**

```bash
skill-evaluate report <path>/result.json --format html
```

**Q: 多轮对话场景怎么测?**

```yaml
input:
  turns:
    - role: user
      content: "创建一个 config.json"
      capture:
        - variable: filename
          pattern: "created (\\S+)"        # 从回答里抓变量
    - role: user
      content: "读取 {{filename}} 的内容"   # 后续轮引用
      post_condition:                       # 本轮回答必须满足
        must_contain_any: ["{"]
        on_fail: fail                       # 或 skip_remaining
```

**Q: 我的 agent 不是 LLM API,是自己的程序?**

用自定义引擎(local 子进程或 http):

```yaml
engine:
  name: my-agent
  custom:
    transport: local
    response_format: session_result   # 输出 JSON {exit_code, final_message, ...}
    local:
      command: python
      args: [my_agent.py, "${input_file}", "${output_file}"]
```

输入是 `${input_file}`(JSON:`{case_id, messages, workspace, ...}`),
把结果 JSON 写到 `${output_file}` 即可。

---

# 参考手册

## 报告产物布局

```
<skill>-workspace/iteration-<N>/
  benchmark.json  benchmark.md  result.json  report.xml  report.html
  <case-id>/
    eval_metadata.json
    with_skill/    outputs/response.md  grading.json
    without_skill/ outputs/response.md  grading.json   # benchmark.enabled 时
```

## CLI 一览

```
skill-evaluate run [eval.yaml]      运行评估
    --model provider/name           覆盖模型
    --api-key / --base-url          覆盖凭证/端点
    --parallelism N                 并发度
    --format json|junit|html        报告格式(可多次)
    --output-dir DIR                报告输出目录
    --iteration N                   迭代编号(0=自动递增)
    --include-case-name GLOB        只跑匹配的 case
    --exclude-case-name GLOB        排除匹配的 case
    --dry-run                       只打印计划不执行
skill-evaluate validate [eval.yaml] 校验配置
skill-evaluate list-cases           列出 case
skill-evaluate report <result.json> 重新生成报告
skill-evaluate import <evals.json>  导入 Anthropic evals.json
skill-evaluate init                 初始化凭证配置
```

## 与 Go 版的差异

| 维度 | Go 版 skill-up | Python 版 skill-evaluate |
|---|---|---|
| LLM 访问 | 外部 Agent CLI 子进程 | **litellm + api_key 直连** |
| 内置引擎 | claude_code / codex / qodercli / qwen_code | **litellm**(任意 provider) |
| skill 安装 | 拷贝到 CLI 的 skills 目录 | workspace 拷贝 + **system prompt 注入** |
| agent_judge | 再跑一次 Agent CLI | **litellm.completion 直调裁判模型** |
| runtime | none / docker / opensandbox | none(本地) |
| MCP | 支持(mock/real) | 暂不支持 |
| 自定义引擎 | local / http | local / http(已保留) |

判定语义与报告字段(vacuous PASS、failure 短路、expect 短路、pass_threshold、
`iteration-N` 目录布局、Anthropic grading/benchmark 字段名)与 Go 版保持一致。

## 测试

```bash
.venv/Scripts/python -m pytest tests/ -q     # 36 个测试(含 mock litellm 的端到端)
```
